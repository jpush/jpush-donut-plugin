/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 6715:
/***/ ((module) => {

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}
function _asyncToGenerator(fn) {
  return function () {
    var self = this,
      args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(undefined);
    });
  };
}
module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 6546:
/***/ ((module, exports, __webpack_require__) => {

var keys = __webpack_require__(8677);
var getProto = __webpack_require__(6245);
var unique = __webpack_require__(1193);
var getOwnPropertyNames = Object.getOwnPropertyNames;
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
exports = function (obj) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
    _ref$prototype = _ref.prototype,
    prototype = _ref$prototype === void 0 ? true : _ref$prototype,
    _ref$unenumerable = _ref.unenumerable,
    unenumerable = _ref$unenumerable === void 0 ? false : _ref$unenumerable,
    _ref$symbol = _ref.symbol,
    symbol = _ref$symbol === void 0 ? false : _ref$symbol;
  var ret = [];
  if ((unenumerable || symbol) && getOwnPropertyNames) {
    var getKeys = keys;
    if (unenumerable && getOwnPropertyNames) getKeys = getOwnPropertyNames;
    do {
      ret = ret.concat(getKeys(obj));
      if (symbol && getOwnPropertySymbols) {
        ret = ret.concat(getOwnPropertySymbols(obj));
      }
    } while (prototype && (obj = getProto(obj)) && obj !== Object.prototype);
    ret = unique(ret);
  } else {
    if (prototype) {
      for (var key in obj) {
        ret.push(key);
      }
    } else {
      ret = keys(obj);
    }
  }
  return ret;
};
module.exports = exports;

/***/ }),

/***/ 32:
/***/ ((module, exports, __webpack_require__) => {

var restArgs = __webpack_require__(2968);
exports = restArgs(function (fn, ctx, args) {
  return restArgs(function (callArgs) {
    return fn.apply(ctx, args.concat(callArgs));
  });
});
module.exports = exports;

/***/ }),

/***/ 3782:
/***/ ((module, exports, __webpack_require__) => {

var has = __webpack_require__(3702);
var isArr = __webpack_require__(4680);
exports = function (str, obj) {
  if (isArr(str)) return str;
  if (obj && has(obj, str)) return [str];
  var ret = [];
  str.replace(regPropName, function (match, number, quote, str) {
    ret.push(quote ? str.replace(regEscapeChar, '$1') : number || match);
  });
  return ret;
};
var regPropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
var regEscapeChar = /\\(\\)?/g;
module.exports = exports;

/***/ }),

/***/ 220:
/***/ ((module, exports, __webpack_require__) => {

var isObj = __webpack_require__(3058);
var isArr = __webpack_require__(4680);
var extend = __webpack_require__(4371);
exports = function (obj) {
  if (!isObj(obj)) return obj;
  return isArr(obj) ? obj.slice() : extend({}, obj);
};
module.exports = exports;

/***/ }),

/***/ 6307:
/***/ ((module, exports, __webpack_require__) => {

var toArr = __webpack_require__(8690);
exports = function () {
  var args = toArr(arguments);
  var ret = [];
  for (var i = 0, len = args.length; i < len; i++) {
    ret = ret.concat(toArr(args[i]));
  }
  return ret;
};
module.exports = exports;

/***/ }),

/***/ 1841:
/***/ ((module, exports, __webpack_require__) => {

var idxOf = __webpack_require__(8605);
var isStr = __webpack_require__(2510);
var isArrLike = __webpack_require__(2157);
var values = __webpack_require__(8133);
exports = function (arr, val) {
  if (isStr(arr)) return arr.indexOf(val) > -1;
  if (!isArrLike(arr)) arr = values(arr);
  return idxOf(arr, val) >= 0;
};
module.exports = exports;

/***/ }),

/***/ 8337:
/***/ ((module, exports, __webpack_require__) => {

var isUndef = __webpack_require__(5617);
var each = __webpack_require__(6295);
exports = function (keysFn, defaults) {
  return function (obj) {
    each(arguments, function (src, idx) {
      if (idx === 0) return;
      var keys = keysFn(src);
      each(keys, function (key) {
        if (!defaults || isUndef(obj[key])) obj[key] = src[key];
      });
    });
    return obj;
  };
};
module.exports = exports;

/***/ }),

/***/ 6295:
/***/ ((module, exports, __webpack_require__) => {

var isArrLike = __webpack_require__(2157);
var keys = __webpack_require__(8677);
var optimizeCb = __webpack_require__(4116);
exports = function (obj, iterator, ctx) {
  iterator = optimizeCb(iterator, ctx);
  var i, len;
  if (isArrLike(obj)) {
    for (i = 0, len = obj.length; i < len; i++) {
      iterator(obj[i], i, obj);
    }
  } else {
    var _keys = keys(obj);
    for (i = 0, len = _keys.length; i < len; i++) {
      iterator(obj[_keys[i]], _keys[i], obj);
    }
  }
  return obj;
};
module.exports = exports;

/***/ }),

/***/ 8770:
/***/ ((module, exports) => {

exports = function (str, suffix) {
  var idx = str.length - suffix.length;
  return idx >= 0 && str.indexOf(suffix, idx) === idx;
};
module.exports = exports;

/***/ }),

/***/ 4371:
/***/ ((module, exports, __webpack_require__) => {

var createAssigner = __webpack_require__(8337);
var allKeys = __webpack_require__(6546);
exports = createAssigner(allKeys);
module.exports = exports;

/***/ }),

/***/ 4277:
/***/ ((module, exports, __webpack_require__) => {

var keys = __webpack_require__(8677);
var createAssigner = __webpack_require__(8337);
exports = createAssigner(keys);
module.exports = exports;

/***/ }),

/***/ 8043:
/***/ ((module, exports, __webpack_require__) => {

var safeCb = __webpack_require__(8540);
var each = __webpack_require__(6295);
exports = function (obj, predicate, ctx) {
  var ret = [];
  predicate = safeCb(predicate, ctx);
  each(obj, function (val, idx, list) {
    if (predicate(val, idx, list)) ret.push(val);
  });
  return ret;
};
module.exports = exports;

/***/ }),

/***/ 8268:
/***/ ((module, exports, __webpack_require__) => {

var toSrc = __webpack_require__(4110);
var stripCmt = __webpack_require__(6808);
var startWith = __webpack_require__(6068);
var isStr = __webpack_require__(2510);
exports = function (fn) {
  var fnStr = stripCmt(isStr(fn) ? fn : toSrc(fn));
  var open;
  var close;
  if (!startWith(fnStr, 'async') && !startWith(fnStr, 'function') && !startWith(fnStr, '(')) {
    open = 0;
    close = fnStr.indexOf('=>');
  } else {
    open = fnStr.indexOf('(') + 1;
    close = fnStr.indexOf(')');
  }
  var ret = fnStr.slice(open, close);
  ret = ret.match(regArgNames);
  return ret === null ? [] : ret;
};
var regArgNames = /[^\s,]+/g;
module.exports = exports;

/***/ }),

/***/ 6245:
/***/ ((module, exports, __webpack_require__) => {

var isObj = __webpack_require__(3058);
var isFn = __webpack_require__(5309);
var getPrototypeOf = Object.getPrototypeOf;
var ObjectCtr = {}.constructor;
exports = function (obj) {
  if (!isObj(obj)) return;
  if (getPrototypeOf && !false) return getPrototypeOf(obj);
  var proto = obj.__proto__;
  if (proto || proto === null) return proto;
  if (isFn(obj.constructor)) return obj.constructor.prototype;
  if (obj instanceof ObjectCtr) return ObjectCtr.prototype;
};
module.exports = exports;

/***/ }),

/***/ 3702:
/***/ ((module, exports) => {

var hasOwnProp = Object.prototype.hasOwnProperty;
exports = function (obj, key) {
  return hasOwnProp.call(obj, key);
};
module.exports = exports;

/***/ }),

/***/ 4344:
/***/ ((module, exports) => {

exports = function (val) {
  return val;
};
module.exports = exports;

/***/ }),

/***/ 8605:
/***/ ((module, exports) => {

exports = function (arr, val, fromIdx) {
  return Array.prototype.indexOf.call(arr, val, fromIdx);
};
module.exports = exports;

/***/ }),

/***/ 4680:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(2207);
if (Array.isArray && !false) {
  exports = Array.isArray;
} else {
  exports = function (val) {
    return objToStr(val) === '[object Array]';
  };
}
module.exports = exports;

/***/ }),

/***/ 2157:
/***/ ((module, exports, __webpack_require__) => {

var isNum = __webpack_require__(7804);
var isFn = __webpack_require__(5309);
var MAX_ARR_IDX = Math.pow(2, 53) - 1;
exports = function (val) {
  if (!val) return false;
  var len = val.length;
  return isNum(len) && len >= 0 && len <= MAX_ARR_IDX && !isFn(val);
};
module.exports = exports;

/***/ }),

/***/ 5309:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(2207);
exports = function (val) {
  var objStr = objToStr(val);
  return objStr === '[object Function]' || objStr === '[object GeneratorFunction]' || objStr === '[object AsyncFunction]';
};
module.exports = exports;

/***/ }),

/***/ 1750:
/***/ ((module, exports, __webpack_require__) => {

var keys = __webpack_require__(8677);
exports = function (obj, src) {
  var _keys = keys(src);
  var len = _keys.length;
  if (obj == null) return !len;
  obj = Object(obj);
  for (var i = 0; i < len; i++) {
    var key = _keys[i];
    if (src[key] !== obj[key] || !(key in obj)) return false;
  }
  return true;
};
module.exports = exports;

/***/ }),

/***/ 6041:
/***/ ((module, exports) => {

exports = function (val) {
  return val == null;
};
module.exports = exports;

/***/ }),

/***/ 7804:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(2207);
exports = function (val) {
  return objToStr(val) === '[object Number]';
};
module.exports = exports;

/***/ }),

/***/ 3058:
/***/ ((module, exports) => {

exports = function (val) {
  var type = typeof val;
  return !!val && (type === 'function' || type === 'object');
};
module.exports = exports;

/***/ }),

/***/ 5828:
/***/ ((module, exports, __webpack_require__) => {

var isObj = __webpack_require__(3058);
var isFn = __webpack_require__(5309);
exports = function (val) {
  return isObj(val) && isFn(val.then) && isFn(val.catch);
};
module.exports = exports;

/***/ }),

/***/ 2510:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(2207);
exports = function (val) {
  return objToStr(val) === '[object String]';
};
module.exports = exports;

/***/ }),

/***/ 5617:
/***/ ((module, exports) => {

exports = function (val) {
  return val === void 0;
};
module.exports = exports;

/***/ }),

/***/ 8677:
/***/ ((module, exports, __webpack_require__) => {

var has = __webpack_require__(3702);
if (Object.keys && !false) {
  exports = Object.keys;
} else {
  exports = function (obj) {
    var ret = [];
    for (var key in obj) {
      if (has(obj, key)) ret.push(key);
    }
    return ret;
  };
}
module.exports = exports;

/***/ }),

/***/ 572:
/***/ ((module, exports) => {

exports = function (arr) {
  var len = arr ? arr.length : 0;
  if (len) return arr[len - 1];
};
module.exports = exports;

/***/ }),

/***/ 6640:
/***/ ((module, exports) => {

var regSpace = /^\s+/;
exports = function (str, chars) {
  if (chars == null) return str.replace(regSpace, '');
  var start = 0;
  var len = str.length;
  var charLen = chars.length;
  var found = true;
  var i;
  var c;
  while (found && start < len) {
    found = false;
    i = -1;
    c = str.charAt(start);
    while (++i < charLen) {
      if (c === chars[i]) {
        found = true;
        start++;
        break;
      }
    }
  }
  return start >= len ? '' : str.substr(start, len);
};
module.exports = exports;

/***/ }),

/***/ 3078:
/***/ ((module, exports, __webpack_require__) => {

var safeCb = __webpack_require__(8540);
var keys = __webpack_require__(8677);
var isArrLike = __webpack_require__(2157);
exports = function (obj, iterator, ctx) {
  iterator = safeCb(iterator, ctx);
  var _keys = !isArrLike(obj) && keys(obj);
  var len = (_keys || obj).length;
  var results = Array(len);
  for (var i = 0; i < len; i++) {
    var curKey = _keys ? _keys[i] : i;
    results[i] = iterator(obj[curKey], curKey, obj);
  }
  return results;
};
module.exports = exports;

/***/ }),

/***/ 474:
/***/ ((module, exports, __webpack_require__) => {

var extendOwn = __webpack_require__(4277);
var isMatch = __webpack_require__(1750);
exports = function (attrs) {
  attrs = extendOwn({}, attrs);
  return function (obj) {
    return isMatch(obj, attrs);
  };
};
module.exports = exports;

/***/ }),

/***/ 408:
/***/ ((module, exports) => {

exports = function () {};
module.exports = exports;

/***/ }),

/***/ 9359:
/***/ ((module, exports) => {

if (Date.now && !false) {
  exports = Date.now;
} else {
  exports = function () {
    return new Date().getTime();
  };
}
module.exports = exports;

/***/ }),

/***/ 2207:
/***/ ((module, exports) => {

var ObjToStr = Object.prototype.toString;
exports = function (val) {
  return ObjToStr.call(val);
};
module.exports = exports;

/***/ }),

/***/ 4116:
/***/ ((module, exports, __webpack_require__) => {

var isUndef = __webpack_require__(5617);
exports = function (fn, ctx, argCount) {
  if (isUndef(ctx)) return fn;
  switch (argCount == null ? 3 : argCount) {
    case 1:
      return function (val) {
        return fn.call(ctx, val);
      };
    case 3:
      return function (val, idx, collection) {
        return fn.call(ctx, val, idx, collection);
      };
    case 4:
      return function (accumulator, val, idx, collection) {
        return fn.call(ctx, accumulator, val, idx, collection);
      };
  }
  return function () {
    return fn.apply(ctx, arguments);
  };
};
module.exports = exports;

/***/ }),

/***/ 3004:
/***/ ((module, exports, __webpack_require__) => {

var isArr = __webpack_require__(4680);
var safeGet = __webpack_require__(4185);
exports = function (path) {
  if (!isArr(path)) return shallowProperty(path);
  return function (obj) {
    return safeGet(obj, path);
  };
};
function shallowProperty(key) {
  return function (obj) {
    return obj == null ? void 0 : obj[key];
  };
}
module.exports = exports;

/***/ }),

/***/ 2968:
/***/ ((module, exports) => {

exports = function (fn, startIdx) {
  startIdx = startIdx == null ? fn.length - 1 : +startIdx;
  return function () {
    var len = Math.max(arguments.length - startIdx, 0);
    var rest = new Array(len);
    var i;
    for (i = 0; i < len; i++) {
      rest[i] = arguments[i + startIdx];
    }
    switch (startIdx) {
      case 0:
        return fn.call(this, rest);
      case 1:
        return fn.call(this, arguments[0], rest);
      case 2:
        return fn.call(this, arguments[0], arguments[1], rest);
    }
    var args = new Array(startIdx + 1);
    for (i = 0; i < startIdx; i++) {
      args[i] = arguments[i];
    }
    args[startIdx] = rest;
    return fn.apply(this, args);
  };
};
module.exports = exports;

/***/ }),

/***/ 510:
/***/ ((module, exports) => {

var regSpace = /\s+$/;
exports = function (str, chars) {
  if (chars == null) return str.replace(regSpace, '');
  var end = str.length - 1;
  var charLen = chars.length;
  var found = true;
  var i;
  var c;
  while (found && end >= 0) {
    found = false;
    i = -1;
    c = str.charAt(end);
    while (++i < charLen) {
      if (c === chars[i]) {
        found = true;
        end--;
        break;
      }
    }
  }
  return end >= 0 ? str.substring(0, end + 1) : '';
};
module.exports = exports;

/***/ }),

/***/ 8540:
/***/ ((module, exports, __webpack_require__) => {

var isFn = __webpack_require__(5309);
var isObj = __webpack_require__(3058);
var isArr = __webpack_require__(4680);
var optimizeCb = __webpack_require__(4116);
var matcher = __webpack_require__(474);
var identity = __webpack_require__(4344);
var property = __webpack_require__(3004);
exports = function (val, ctx, argCount) {
  if (val == null) return identity;
  if (isFn(val)) return optimizeCb(val, ctx, argCount);
  if (isObj(val) && !isArr(val)) return matcher(val);
  return property(val);
};
module.exports = exports;

/***/ }),

/***/ 4185:
/***/ ((module, exports, __webpack_require__) => {

var isUndef = __webpack_require__(5617);
var castPath = __webpack_require__(3782);
exports = function (obj, path) {
  path = castPath(path, obj);
  var prop;
  prop = path.shift();
  while (!isUndef(prop)) {
    obj = obj[prop];
    if (obj == null) return;
    prop = path.shift();
  }
  return obj;
};
module.exports = exports;

/***/ }),

/***/ 7626:
/***/ ((module, exports) => {

exports = function (timeout) {
  return new Promise(function (resolve) {
    return setTimeout(resolve, timeout);
  });
};
module.exports = exports;

/***/ }),

/***/ 6068:
/***/ ((module, exports) => {

exports = function (str, prefix) {
  return str.indexOf(prefix) === 0;
};
module.exports = exports;

/***/ }),

/***/ 6808:
/***/ ((module, exports) => {

exports = function (str) {
  str = ('__' + str + '__').split('');
  var mode = {
    singleQuote: false,
    doubleQuote: false,
    regex: false,
    blockComment: false,
    lineComment: false,
    condComp: false
  };
  for (var i = 0, l = str.length; i < l; i++) {
    if (mode.regex) {
      if (str[i] === '/' && str[i - 1] !== '\\') mode.regex = false;
      continue;
    }
    if (mode.singleQuote) {
      if (str[i] === "'" && str[i - 1] !== '\\') mode.singleQuote = false;
      continue;
    }
    if (mode.doubleQuote) {
      if (str[i] === '"' && str[i - 1] !== '\\') mode.doubleQuote = false;
      continue;
    }
    if (mode.blockComment) {
      if (str[i] === '*' && str[i + 1] === '/') {
        str[i + 1] = '';
        mode.blockComment = false;
      }
      str[i] = '';
      continue;
    }
    if (mode.lineComment) {
      if (str[i + 1] === '\n') mode.lineComment = false;
      str[i] = '';
      continue;
    }
    mode.doubleQuote = str[i] === '"';
    mode.singleQuote = str[i] === "'";
    if (str[i] === '/') {
      if (str[i + 1] === '*') {
        str[i] = '';
        mode.blockComment = true;
        continue;
      }
      if (str[i + 1] === '/') {
        str[i] = '';
        mode.lineComment = true;
        continue;
      }
      mode.regex = true;
    }
  }
  return str.join('').slice(2, -2);
};
module.exports = exports;

/***/ }),

/***/ 8690:
/***/ ((module, exports, __webpack_require__) => {

var isArrLike = __webpack_require__(2157);
var map = __webpack_require__(3078);
var isArr = __webpack_require__(4680);
var isStr = __webpack_require__(2510);
exports = function (val) {
  if (!val) return [];
  if (isArr(val)) return val;
  if (isArrLike(val) && !isStr(val)) return map(val);
  return [val];
};
module.exports = exports;

/***/ }),

/***/ 4110:
/***/ ((module, exports, __webpack_require__) => {

var isNil = __webpack_require__(6041);
exports = function (fn) {
  if (isNil(fn)) return '';
  try {
    return fnToStr.call(fn);
  } catch (e) {}
  try {
    return fn + '';
  } catch (e) {}
  return '';
};
var fnToStr = Function.prototype.toString;
module.exports = exports;

/***/ }),

/***/ 3647:
/***/ ((module, exports, __webpack_require__) => {

var ltrim = __webpack_require__(6640);
var rtrim = __webpack_require__(510);
var regSpace = /^\s+|\s+$/g;
exports = function (str, chars) {
  if (chars == null) return str.replace(regSpace, '');
  return ltrim(rtrim(str, chars), chars);
};
module.exports = exports;

/***/ }),

/***/ 1193:
/***/ ((module, exports, __webpack_require__) => {

var filter = __webpack_require__(8043);
exports = function (arr, cmp) {
  cmp = cmp || isEqual;
  return filter(arr, function (item, idx, arr) {
    var len = arr.length;
    while (++idx < len) {
      if (cmp(item, arr[idx])) return false;
    }
    return true;
  });
};
function isEqual(a, b) {
  return a === b;
}
module.exports = exports;

/***/ }),

/***/ 8133:
/***/ ((module, exports, __webpack_require__) => {

var each = __webpack_require__(6295);
exports = function (obj) {
  var ret = [];
  each(obj, function (val) {
    ret.push(val);
  });
  return ret;
};
module.exports = exports;

/***/ }),

/***/ 4697:
/***/ ((module, exports, __webpack_require__) => {

var now = __webpack_require__(9359);
exports = function (condition) {
  var timeout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var interval = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 250;
  function evalCondition() {
    return new Promise(function (resolve, reject) {
      try {
        resolve(condition());
      } catch (e) {
        reject(e);
      }
    });
  }
  return new Promise(function (resolve, reject) {
    var startTime = now();
    var pollCondition = function () {
      evalCondition().then(function (val) {
        var elapsed = now() - startTime;
        if (val) {
          resolve(val);
        } else if (timeout && elapsed >= timeout) {
          reject(Error('Wait timed out after '.concat(timeout, ' ms')));
        } else {
          setTimeout(pollCondition, interval);
        }
      }, reject);
    };
    pollCondition();
  });
};
module.exports = exports;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

// EXTERNAL MODULE: ../../node_modules/.pnpm/@babel+runtime@7.22.6/node_modules/@babel/runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(6715);
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/startWith.js
var startWith = __webpack_require__(6068);
var startWith_default = /*#__PURE__*/__webpack_require__.n(startWith);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/endWith.js
var endWith = __webpack_require__(8770);
var endWith_default = /*#__PURE__*/__webpack_require__.n(endWith);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/contain.js
var contain = __webpack_require__(1841);
var contain_default = /*#__PURE__*/__webpack_require__.n(contain);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/fnParams.js
var fnParams = __webpack_require__(8268);
var fnParams_default = /*#__PURE__*/__webpack_require__.n(fnParams);
;// CONCATENATED MODULE: ./src/appservice/util.ts





var Function = __webpack_require__.g.Function;
var AsyncFunction = Object.getPrototypeOf( /*#__PURE__*/asyncToGenerator_default()(function* () {})).constructor;
function canIMock(method) {
  return !startWith_default()(method, 'on') && !startWith_default()(method, 'off');
}
function isSync(method) {
  return endWith_default()(method, 'Sync') || contain_default()(syncMethods, method);
}
var syncMethods = ['stopRecord', 'getRecorderManager', 'pauseVoice', 'stopVoice', 'pauseBackgroundAudio', 'stopBackgroundAudio', 'getBackgroundAudioManager', 'createAudioContext', 'createInnerAudioContext', 'createVideoContext', 'createCameraContext', 'createMapContext', 'canIUse', 'startAccelerometer', 'stopAccelerometer', 'startCompass', 'stopCompass', 'hideToast', 'hideLoading', 'showNavigationBarLoading', 'hideNavigationBarLoading', 'navigateBack', 'createAnimation', 'pageScrollTo', 'createSelectorQuery', 'createCanvasContext', 'createContext', 'drawCanvas', 'hideKeyboard', 'stopPullDownRefresh', 'arrayBufferToBase64', 'base64ToArrayBuffer'];
function parseFn(fnStr) {
  var result = fnParams_default()(fnStr);
  if (fnStr[fnStr.length - 1] !== '}') {
    result.push('return ' + fnStr.slice(fnStr.indexOf('=>') + 2));
  } else {
    result.push(fnStr.slice(fnStr.indexOf('{') + 1, fnStr.lastIndexOf('}')));
  }
  return result;
}
function isAppServiceRemoteDebugMode() {
  return __webpack_require__.g.__isAppServiceRemoteDebugMode__ && __webpack_require__.g.$$autoDebug;
}
function callFnWhenRemoteDebugAppservice(functionDeclaration, args, ctx) {
  var res = __webpack_require__.g.$$autoDebug.$eval('(' + functionDeclaration + ')', args, ctx);
  return res;
}
function callAsyncFnWhenRemoteDebugAppservice(_x, _x2, _x3) {
  return _callAsyncFnWhenRemoteDebugAppservice.apply(this, arguments);
}
function _callAsyncFnWhenRemoteDebugAppservice() {
  _callAsyncFnWhenRemoteDebugAppservice = asyncToGenerator_default()(function* (functionDeclaration, args, ctx) {
    var res = yield __webpack_require__.g.$$autoDebug.$eval('(' + functionDeclaration + ')', args, ctx);
    return res;
  });
  return _callAsyncFnWhenRemoteDebugAppservice.apply(this, arguments);
}
function callFn(_x4, _x5) {
  return _callFn.apply(this, arguments);
}
function _callFn() {
  _callFn = asyncToGenerator_default()(function* (functionDeclaration, args, ctx = null) {
    var fnParams = parseFn(functionDeclaration);
    var fn;
    if (startWith_default()(functionDeclaration, 'async')) {
      if (isAppServiceRemoteDebugMode()) {
        return yield callAsyncFnWhenRemoteDebugAppservice(functionDeclaration, args, ctx);
      }
      fn = AsyncFunction.apply(null, fnParams);
      return yield fn.apply(ctx, args);
    } else {
      if (isAppServiceRemoteDebugMode()) {
        return callFnWhenRemoteDebugAppservice(functionDeclaration, args, ctx);
      }
      fn = Function.apply(null, fnParams);
      return fn.apply(ctx, args);
    }
  });
  return _callFn.apply(this, arguments);
}
function callFnSync(functionDeclaration, args, ctx = null) {
  var fnParams = parseFn(functionDeclaration);
  if (isAppServiceRemoteDebugMode()) {
    return callFnWhenRemoteDebugAppservice(functionDeclaration, args, ctx);
  }
  var fn = Function.apply(null, fnParams);
  return fn.apply(ctx, args);
}
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/last.js
var last = __webpack_require__(572);
var last_default = /*#__PURE__*/__webpack_require__.n(last);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/isUndef.js
var isUndef = __webpack_require__(5617);
var isUndef_default = /*#__PURE__*/__webpack_require__.n(isUndef);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/isFn.js
var isFn = __webpack_require__(5309);
var isFn_default = /*#__PURE__*/__webpack_require__.n(isFn);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/trim.js
var trim = __webpack_require__(3647);
var trim_default = /*#__PURE__*/__webpack_require__.n(trim);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/toArr.js
var toArr = __webpack_require__(8690);
var toArr_default = /*#__PURE__*/__webpack_require__.n(toArr);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/concat.js
var concat = __webpack_require__(6307);
var concat_default = /*#__PURE__*/__webpack_require__.n(concat);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/bind.js
var bind = __webpack_require__(32);
var bind_default = /*#__PURE__*/__webpack_require__.n(bind);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/clone.js
var clone = __webpack_require__(220);
var clone_default = /*#__PURE__*/__webpack_require__.n(clone);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/waitUntil.js
var waitUntil = __webpack_require__(4697);
var waitUntil_default = /*#__PURE__*/__webpack_require__.n(waitUntil);
;// CONCATENATED MODULE: ./src/common/bridge.ts

var jsBridge = __webpack_require__.g.WeixinJSBridge;
var isReady = false;
var callbacks = [];
__webpack_require__.g.__wxConfig.clientDebug = true;
function ready() {
  isReady = true;
  for (var i = 0, len = callbacks.length; i < len; i++) {
    callbacks[i]();
  }
  callbacks = [];
}
var descriptor = Object.getOwnPropertyDescriptor(__webpack_require__.g, 'WeixinJSBridge');
if (jsBridge && jsBridge.on) {
  ready();
} else if (descriptor && descriptor.configurable === false) {
  waitUntil_default()(() => __webpack_require__.g.WeixinJSBridge && __webpack_require__.g.WeixinJSBridge.on, 5000, 50).then(() => {
    jsBridge = __webpack_require__.g.WeixinJSBridge;
    ready();
  });
} else {
  Object.defineProperty(__webpack_require__.g, 'WeixinJSBridge', {
    set(val) {
      if (val && val.on) {
        jsBridge = val;
        ready();
      }
    },
    get() {
      return jsBridge;
    },
    configurable: true
  });
}
/* harmony default export */ const bridge = ({
  on(...args) {
    return jsBridge.on(...args);
  },
  publish(...args) {
    return jsBridge.publish(...args);
  },
  invoke(...args) {
    if (__webpack_require__.g.__isAppServiceRemoteDebugMode__ && args[0] === 'sendAutoMessage') {
      var _global$__debugMessag;
      (_global$__debugMessag = __webpack_require__.g.__debugMessager) === null || _global$__debugMessag === void 0 ? void 0 : _global$__debugMessag.sendToDevtools(args[0], args[1]);
    }
    return jsBridge.invoke(...args);
  },
  subscribe(...args) {
    return jsBridge.subscribe(...args);
  },
  onReady(cb) {
    if (isReady) {
      cb();
    } else {
      callbacks.push(cb);
    }
  }
});
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/each.js
var each = __webpack_require__(6295);
var each_default = /*#__PURE__*/__webpack_require__.n(each);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/noop.js
var noop = __webpack_require__(408);
var noop_default = /*#__PURE__*/__webpack_require__.n(noop);
;// CONCATENATED MODULE: ./src/common/serviceGlobal.ts


var serviceGlobal = {};
var serviceGlobal_callbacks = [];
var serviceGlobal_isReady = false;
var origPassWAServiceGlobal = __webpack_require__.g.__passWAServiceGlobal__ || (noop_default());
__webpack_require__.g.__passWAServiceGlobal__ = function (__WAServiceGlobal__) {
  each_default()(__WAServiceGlobal__, (val, key) => {
    serviceGlobal_isReady = true;
    if (key !== 'Protect') {
      serviceGlobal[key] = val;
    }
  });
  if (serviceGlobal_isReady) {
    serviceGlobal_callbacks.forEach(callback => {
      callback(serviceGlobal);
    });
    serviceGlobal_callbacks = [];
  }
  origPassWAServiceGlobal(__WAServiceGlobal__);
};
/* harmony default export */ function common_serviceGlobal(callback) {
  if (!serviceGlobal_isReady) {
    serviceGlobal_callbacks.push(callback);
  } else {
    callback(serviceGlobal);
  }
}
;// CONCATENATED MODULE: ./src/common/url.config.ts
var CGI_DOMAIN_ONLINE = 'https://servicewechat.com/';
var CGI_DOMAIN_RDM = 'https://wxardm.weixin.qq.com/';
var MP_DOMAIN = 'https://mp.weixin.qq.com/';
var CGI_DOMAIN = CGI_DOMAIN_ONLINE;
var urlConfig = {
  jsLoginURL: `${CGI_DOMAIN}wxa-dev-logic/jslogin`,
  jsRefreshSessionURL: `${CGI_DOMAIN}wxa-dev-logic/jsrefresh_session`,
  jsOperateWXDATAURL: `${CGI_DOMAIN}wxa-dev-logic/jsoperatewxdata`,
  jsAuthorizeURL: `${CGI_DOMAIN}wxa-dev-logic/jsauthorize`,
  jsAuthorizeConfirmURL: `${CGI_DOMAIN}wxa-dev-logic/jsauthorize-confirm`,
  getUserPhoneNumber: `${CGI_DOMAIN}wxa-dev-logic/jsgetuserwxphone`,
  checkWeRunState: `${CGI_DOMAIN}wxa-dev-logic/checkwerunstate`,
  getUserAutoFillData: `${CGI_DOMAIN}wxa-dev-logic/getuserfillinfo`,
  setUserAutoFillData: `${CGI_DOMAIN}wxa-dev-logic/saveuserfillinfo`,
  deleteUserAutoFillData: `${CGI_DOMAIN}wxa-dev-logic/deleteuserfillinfo`,
  requestAuthUserAutoFillData: `${CGI_DOMAIN}wxa-dev-logic/authuserfillinfo`,
  clearUserAutoFillInfo: `${CGI_DOMAIN}wxa-dev-logic/clearuserfillinfo`,
  batchGetCardInfoURL: `${MP_DOMAIN}debug/cgi-bin/webdebugger/getcarditeminfo`,
  batchAddCardURL: `${MP_DOMAIN}debug/cgi-bin/webdebugger/acceptcarditem`
};
var errcodeConfig = {
  ILLEGAL_URL: -2005,
  NOT_LIMITS: -1024,
  NOT_LIMITS_QY: -1025,
  NOT_LIMITS_CARD: -1026,
  NOT_LOGIN: 41001,
  INVALID_TOKEN: 40001,
  INVALID_LOGIN: 42001,
  NEED_CONFORM: -12000,
  AUTH_DENY: -12006,
  SCOPE_UNAUTHORIZED: -12007,
  INVALID_CODE: 10010,
  INVALID_CARD_ID: 10023
};
;// CONCATENATED MODULE: ./src/appservice/sdk/utils.ts


var ____wxConfig__ = __webpack_require__.g.__wxConfig;
var _requestSkipCheckDomain;
var autoTestInfo = {};
var appid;
common_serviceGlobal(g => {
  var _wxConfig__$debugL;
  autoTestInfo = (____wxConfig__ === null || ____wxConfig__ === void 0 ? void 0 : (_wxConfig__$debugL = ____wxConfig__.debugLaunchInfo) === null || _wxConfig__$debugL === void 0 ? void 0 : _wxConfig__$debugL.autoTest) || {};
  console.log('autoTestInfo..', autoTestInfo);
  _requestSkipCheckDomain = g.__appServiceSDK__._requestSkipCheckDomain;
  appid = autoTestInfo.appid;
});
var request = options => {
  var {
    success,
    fail,
    complete
  } = options;
  var urlSplit = (options.url || '').split('?');
  var urlResult = urlSplit[0];
  var query = [`newticket=${autoTestInfo.newticket}`, `appid=${autoTestInfo.appid}`, `clientversion=${autoTestInfo.clientversion}`];
  if (autoTestInfo.testuser) {
    query.push(`testuser=${autoTestInfo.testuser}`);
  }
  options.url = `${urlResult}?${query.join('&')}`;
  if (success || fail || complete) {
    return _requestSkipCheckDomain(options);
  } else {
    return new Promise((resolve, reject) => {
      _requestSkipCheckDomain({
        ...options,
        success: resolve,
        fail: reject
      });
    });
  }
};
var getAppid = () => {
  return appid;
};
function authorizeRequest(api, isAllowed, scopes, callback, otherRes) {
  request({
    url: `${urlConfig.jsAuthorizeConfirmURL}`,
    method: 'POST',
    data: {
      scope: scopes,
      opt: isAllowed ? 1 : 2
    },
    success: res => {
      var body = res.data;
      var errMsg = 'fail request error';
      if (body.baseresponse && body.baseresponse.errcode === 0) {
        if (isAllowed) {
          errMsg = 'ok';
        } else {
          errMsg = 'fail auth deny';
        }
      }
      return callback({
        errMsg: `${api}:${errMsg}`,
        ...otherRes
      });
    }
  });
}
;// CONCATENATED MODULE: ./src/appservice/sdk/account.sdk.ts



function login(api, args, callback) {
  return request({
    url: `${urlConfig.jsLoginURL}`,
    method: 'POST',
    data: {
      scope: ['snsapi_base']
    },
    success: res => {
      var body = res.data;
      callback({
        errMsg: `${api}:ok`,
        code: body.code
      });
    },
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function refreshSession(api, args, callback) {
  return request({
    url: `${urlConfig.jsRefreshSessionURL}`,
    method: 'POST',
    data: {
      scope: ['snsapi_base']
    },
    success: res => {
      var body = res.data;
      callback({
        errMsg: `${api}:ok`,
        expireIn: body.session_expire_in,
        err_code: body.baseresponse.errcode
      });
    },
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function operateWXDataConfirm(api, args, callback, options) {
  var isAllowed = true;
  var scopeList = options.scopeList;
  return request({
    url: `${urlConfig.jsOperateWXDATAURL}`,
    method: 'POST',
    data: {
      data: JSON.stringify(args.data || {}),
      grant_scope: scopeList[0].scope,
      opt: isAllowed ? 1 : 2
    },
    success: res => {
      var body = res.data;
      return callback({
        errMsg: `${api}:ok`,
        data: JSON.parse(body.data)
      });
    }
  });
}
function operateWXData(_x, _x2, _x3) {
  return _operateWXData.apply(this, arguments);
}
function _operateWXData() {
  _operateWXData = asyncToGenerator_default()(function* (api, args, callback) {
    var reqBody = {
      data: JSON.stringify(args.data || {})
    };
    if (args.data.api_name === 'webapi_plugin_setauth') {
      reqBody.ext_info = {
        source_env: 2
      };
    }
    return request({
      url: `${urlConfig.jsOperateWXDATAURL}`,
      method: 'POST',
      data: reqBody,
      success: res => {
        var body = res.data;
        var baseresponse = body.baseresponse;
        if (baseresponse) {
          var errcode = body.baseresponse.errcode;
          if (errcode === 0) {
            var respData = JSON.parse(body.data);
            return callback({
              errMsg: `${api}:ok`,
              data: respData
            });
          }
          if (errcode === errcodeConfig.NEED_CONFORM) {
            return operateWXDataConfirm(api, args, callback, {
              imageUrl: body.appicon_url,
              appName: body.appname,
              scopeList: [body.scope]
            });
          }
          if (errcode === errcodeConfig.SCOPE_UNAUTHORIZED) {
            return callback({
              errMsg: `${api}:fail ${baseresponse.errmsg}`
            });
          }
          return callback({
            errMsg: `${api}:fail ${baseresponse.errmsg}`,
            err_code: errcode
          });
        } else {
          callback({
            errMsg: `${api}:fail no baseresponse`
          });
        }
      },
      fail: () => {
        callback({
          errMsg: `${api}:fail response fail`
        });
      }
    });
  });
  return _operateWXData.apply(this, arguments);
}
function authorize(api, args, callback) {
  return request({
    url: `${urlConfig.jsAuthorizeURL}`,
    method: 'POST',
    data: {
      scope: args.scope || []
    },
    success: res => {
      var body = res.data;
      var baseresponse = body.baseresponse;
      if (baseresponse) {
        var errcode = baseresponse.errcode;
        if (errcode === 0) {
          return callback({
            errMsg: `${api}:ok`,
            body
          });
        }
        if (errcode === errcodeConfig.NEED_CONFORM) {
          var scopeList = body.scope_list || [];
          var isAllowed = true;
          var alloewScopeList = [];
          scopeList.forEach(item => {
            alloewScopeList.push(item.scope);
          });
          return authorizeRequest(api, isAllowed, scopeList, callback);
        }
      }
    },
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function openWeRunSetting(api, args, callback) {
  return request({
    url: `${urlConfig.checkWeRunState}`,
    method: 'POST',
    data: {
      appid: getAppid()
    },
    success: res => {
      var body = res.data;
      var state = body.state;
      if (state === 1) {
        return callback({
          errMsg: `${api}:ok`
        });
      }
      var wording = body.wording || 'USER_NOT_OPEN_WECHAT_MOVEMENT';
      return callback({
        errMsg: `${api}:fail ${wording}`
      });
    },
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
var accountSDK = (/* unused pure expression or super */ null && ({
  login,
  refreshSession,
  operateWXData,
  authorize,
  openWeRunSetting
}));
;// CONCATENATED MODULE: ./src/appservice/sdk/phone.sdk.ts



function getPhoneNumber(api, args, callback) {
  request({
    url: `${urlConfig.getUserPhoneNumber}`,
    method: 'POST',
    data: {
      appid: getAppid()
    },
    success: function () {
      var _ref = asyncToGenerator_default()(function* (res) {
        var body = res.data;
        console.log('getPhoneNumber', body);
        var baseresponse = body.jsapi_baseresponse;
        var errcode = baseresponse ? parseInt(baseresponse.errcode, 10) : -10000;
        try {
          if (errcode === 0) {
            var userData;
            var _res = {};
            try {
              _res = JSON.parse(body.data);
              userData = JSON.parse(_res.data);
            } catch (e) {
              throw new Error(`GET_DATA_ERROR ${e}`);
            }
            if (!userData || !userData.mobile) {
              throw new Error(`USER_NOT_BOUND_PHONE`);
            }
            if (userData.need_auth) {
              throw new Error(`PHONE_BOUND_NEED_VERIFIED`);
            }
            var scopeList = [body.scope];
            var isAllowed = true;
            var alloewScopeList = [];
            scopeList.forEach(item => {
              alloewScopeList.push(item.scope);
            });
            return authorizeRequest(api, isAllowed, scopeList, callback, _res);
          } else if (errcode === -12001) {
            throw new Error('APPID_NO_PERMISSIONS');
          } else if (errcode === -12004) {
            throw new Error('WX_LOGIN_FIRST');
          } else {
            throw new Error(`SYSTEM_ERROR errorCode:${errcode}`);
          }
        } catch (e) {
          return callback({
            errMsg: `${api}:fail ${e}`
          });
        }
      });
      return function success(_x) {
        return _ref.apply(this, arguments);
      };
    }(),
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
;// CONCATENATED MODULE: ./src/appservice/sdk/autofill.sdk.ts



function getUserAutoFillData(api, args, callback) {
  var bodyQuery = {
    appid: getAppid(),
    get_all_info: false,
    source: 1,
    user_info_list: args.fields,
    client_version: args.clientVersion
  };
  request({
    url: `${urlConfig.getUserAutoFillData}`,
    method: 'POST',
    data: bodyQuery,
    success: function () {
      var _ref = asyncToGenerator_default()(function* (res) {
        var body = res.data;
        callback({
          errMsg: `${api}:ok`,
          userData: body.user_info_json || '{}',
          authStatus: body.auth_status,
          authInfo: body.auth_info,
          authGroupList: body.auth_group_list
        });
      });
      return function success(_x) {
        return _ref.apply(this, arguments);
      };
    }(),
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function setUserAutoFillData(api, args, callback) {
  var bodyQuery = {
    appid: getAppid(),
    source: 1,
    user_info_json: args.dataList,
    client_version: args.clientVersion
  };
  request({
    url: `${urlConfig.getUserAutoFillData}`,
    method: 'POST',
    data: bodyQuery,
    success: function () {
      var _ref2 = asyncToGenerator_default()(function* (res) {
        var body = res.data;
        callback({
          errMsg: `${api}:ok`
        });
      });
      return function success(_x2) {
        return _ref2.apply(this, arguments);
      };
    }(),
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function deleteUserAutoFillData(api, args, callback) {
  var bodyQuery = {
    appid: getAppid(),
    source: 1,
    group_key: args.groupKey,
    group_id: args.groupId,
    client_version: args.clientVersion
  };
  request({
    url: `${urlConfig.deleteUserAutoFillData}`,
    method: 'POST',
    data: bodyQuery,
    success: function () {
      var _ref3 = asyncToGenerator_default()(function* (res) {
        var body = res.data;
        callback({
          errMsg: `${api}:ok`
        });
      });
      return function success(_x3) {
        return _ref3.apply(this, arguments);
      };
    }(),
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function requestAuthUserAutoFillData(api, args, callback) {
  var yes = true;
  var bodyQuery = {
    appid: getAppid(),
    source: 1,
    auth_info_list: args.fields || [],
    auth_status: args.authStatus,
    user_confirm: yes,
    client_version: args.clientVersion
  };
  request({
    url: `${urlConfig.requestAuthUserAutoFillData}`,
    method: 'POST',
    data: bodyQuery,
    success: function () {
      var _ref4 = asyncToGenerator_default()(function* (res) {
        var body = res.data;
        callback({
          errMsg: `${api}:ok`
        });
      });
      return function success(_x4) {
        return _ref4.apply(this, arguments);
      };
    }(),
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
;// CONCATENATED MODULE: ./src/appservice/sdk/index.ts



var SDK = {
  login: login,
  refreshSession: refreshSession,
  operateWXData: operateWXData,
  authorize: authorize,
  openWeRunSetting: openWeRunSetting,
  getPhoneNumber: getPhoneNumber,
  getUserAutoFillData: getUserAutoFillData,
  setUserAutoFillData: setUserAutoFillData,
  deleteUserAutoFillData: deleteUserAutoFillData,
  requestAuthUserAutoFillData: requestAuthUserAutoFillData
};
;// CONCATENATED MODULE: ./src/appservice/app.ts














var __appServiceEngine__;
var ____wx;
function callWxMethod(params) {
  var {
    method,
    pluginId
  } = params;
  var wx = getWx(pluginId);
  var {
    args
  } = params;
  return new Promise((resolve, reject) => {
    if (!wx[method]) {
      return reject(Error(`wx.${method} not exists`));
    }
    if (isSync(method)) {
      resolve({
        result: wx[method].apply(wx, args)
      });
    } else {
      args = args[0] || {};
      wx[method]({
        ...args,
        success(res) {
          resolve({
            result: res
          });
        },
        fail(res) {
          reject(Error(res.errMsg.replace(`${method}:fail `, '')));
        }
      });
    }
  });
}
function callFunction(_x) {
  return _callFunction.apply(this, arguments);
}
function _callFunction() {
  _callFunction = asyncToGenerator_default()(function* (params) {
    var {
      functionDeclaration,
      args
    } = params;
    return {
      result: yield callFn(functionDeclaration, args)
    };
  });
  return _callFunction.apply(this, arguments);
}
function getCurrentPage() {
  return _getCurrentPage.apply(this, arguments);
}
function _getCurrentPage() {
  _getCurrentPage = asyncToGenerator_default()(function* () {
    return last_default()((yield getPageStack()).pageStack);
  });
  return _getCurrentPage.apply(this, arguments);
}
function getPageStack() {
  return _getPageStack.apply(this, arguments);
}
function _getPageStack() {
  _getPageStack = asyncToGenerator_default()(function* () {
    var pages = __appServiceEngine__.getCurrentPagesByDomain();
    return {
      pageStack: pages.map(page => {
        var {
          route
        } = page;
        var pluginPos = route.indexOf('__plugin__/');
        if (pluginPos > -1) {
          route = 'plugin-private://' + route.slice(pluginPos + 11);
        }
        return {
          pageId: page.__wxWebviewId__,
          path: route,
          query: page.options
        };
      })
    };
  });
  return _getPageStack.apply(this, arguments);
}
var pluginGlobals = {};
var originWxMethods = {};
var originWxMethodsGetterMap = {};
var originWxMethodsValMap = {};
function getMethodKey(method, pluginId = '') {
  return pluginId ? `${pluginId}_${method}` : method;
}
function getWx(pluginId = '') {
  if (pluginId) {
    if (!pluginGlobals[pluginId]) {
      throw Error(`Plugin ${pluginId} not exists`);
    }
    return pluginGlobals[pluginId].wx;
  }
  if (typeof wx === 'undefined') {
    return ____wx;
  }
  return wx;
}
function mockWxMethod(_x2) {
  return _mockWxMethod.apply(this, arguments);
}
function _mockWxMethod() {
  _mockWxMethod = asyncToGenerator_default()(function* (params) {
    var {
      method,
      result,
      pluginId
    } = params;
    var {
      functionDeclaration,
      args
    } = params;
    var wx = getWx(pluginId);
    if (!wx[method]) {
      throw Error(`wx.${method} not exists`);
    }
    if (!canIMock(method)) {
      throw Error(`You can't mock wx.${method}`);
    }
    if (isUndef_default()(result) && isUndef_default()(functionDeclaration)) {
      restoreWxMethod(method, pluginId);
      return;
    }
    if (!isUndef_default()(result)) {
      functionDeclaration = `function () {
      return arguments[arguments.length - 1];
    }`;
      args = [result];
    }
    var fn;
    var ctx = {
      origin: bind_default()(getOriginWxMethod(method, pluginId), wx)
    };
    if (isSync(method)) {
      fn = function () {
        return callFnSync(functionDeclaration, concat_default()(toArr_default()(arguments), args), ctx);
      };
    } else {
      fn = /*#__PURE__*/function () {
        var _ref = asyncToGenerator_default()(function* (...wxArgs) {
          var usePromise = false;
          var obj = wxArgs[0];
          if (isUndef_default()(obj)) {
            usePromise = true;
          } else if (isUndef_default()(obj.success) && isUndef_default()(obj.fail) && isUndef_default()(obj.complete)) {
            usePromise = true;
          }
          if (usePromise) {
            args = concat_default()(wxArgs, args);
            return new Promise( /*#__PURE__*/function () {
              var _ref2 = asyncToGenerator_default()(function* (resolve, reject) {
                var result = yield callFn(functionDeclaration, args, ctx);
                var errMsg = result.errMsg || `${method}:ok`;
                if (errMsg.indexOf(`${method}:ok`) > -1) {
                  resolve(result);
                } else {
                  reject(result);
                }
              });
              return function (_x4, _x5) {
                return _ref2.apply(this, arguments);
              };
            }());
          } else {
            var passedObj = clone_default()(obj);
            delete passedObj.success;
            delete passedObj.fail;
            delete passedObj.complete;
            var _result = yield callFn(functionDeclaration, concat_default()([passedObj], args), ctx);
            var errMsg = _result.errMsg || `${method}:ok`;
            if (errMsg.indexOf(`${method}:ok`) > -1) {
              if (obj.success) obj.success(_result);
            } else {
              if (obj.fail) obj.fail(_result);
            }
            if (obj.complete) obj.complete(_result);
          }
        });
        return function fn() {
          return _ref.apply(this, arguments);
        };
      }();
    }
    replaceWxMethod(method, fn, pluginId);
  });
  return _mockWxMethod.apply(this, arguments);
}
function getOriginWxMethod(method, pluginId) {
  var wx = getWx(pluginId);
  var methodKey = getMethodKey(method, pluginId);
  if (originWxMethods[methodKey]) {
    if (originWxMethodsGetterMap[methodKey]) {
      return originWxMethods[methodKey]();
    }
    return originWxMethods[methodKey];
  }
  var descriptor = Object.getOwnPropertyDescriptor(wx, method);
  if (descriptor && descriptor.get) {
    return descriptor.get();
  }
  return wx[method];
}
function restoreWxMethod(method, pluginId) {
  var wx = getWx(pluginId);
  var methodKey = getMethodKey(method, pluginId);
  if (!originWxMethods[methodKey]) return;
  var descriptor = Object.getOwnPropertyDescriptor(wx, method);
  if (descriptor) {
    if (originWxMethodsGetterMap[methodKey]) {
      Object.defineProperty(wx, method, {
        get: originWxMethods[methodKey]
      });
    } else {
      Object.defineProperty(wx, method, {
        value: originWxMethods[methodKey]
      });
    }
  } else {
    wx[method] = originWxMethods[methodKey];
  }
  delete originWxMethods[methodKey];
}
function replaceWxMethod(method, fn, pluginId) {
  var wx = getWx(pluginId);
  var methodKey = getMethodKey(method, pluginId);
  var descriptor = Object.getOwnPropertyDescriptor(wx, method);
  if (!originWxMethods[methodKey]) {
    var originMethod;
    var isGetter = false;
    var isVal = false;
    if (descriptor) {
      if (!descriptor.get) {
        isVal = true;
        originMethod = descriptor.value;
      } else {
        isGetter = true;
        originMethod = descriptor.get;
      }
    } else {
      originMethod = wx[method];
    }
    if (originMethod) {
      originWxMethodsValMap[methodKey] = isVal;
      originWxMethodsGetterMap[methodKey] = isGetter;
      originWxMethods[methodKey] = originMethod;
    }
  }
  if (descriptor) {
    Object.defineProperty(wx, method, {
      get: () => fn
    });
  } else {
    wx[method] = fn;
  }
}
var logMethods = ['log', 'info', 'warn', 'error', 'debug'];
function enableLog() {
  return _enableLog.apply(this, arguments);
}
function _enableLog() {
  _enableLog = asyncToGenerator_default()(function* () {
    logMethods.forEach(method => {
      var origin = console[method];
      console[method] = function (...args) {
        bridge.invoke('sendAutoMessage', {
          method: 'App.logAdded',
          params: {
            type: method,
            args
          }
        });
        if (isFn_default()(origin)) {
          origin.apply(console, args);
        }
      };
    });
  });
  return _enableLog.apply(this, arguments);
}
function addBinding(_x3) {
  return _addBinding.apply(this, arguments);
}
function _addBinding() {
  _addBinding = asyncToGenerator_default()(function* (params) {
    var {
      name
    } = params;
    var bindingFunction = function (...args) {
      bridge.invoke('sendAutoMessage', {
        method: 'App.bindingCalled',
        params: {
          name,
          args
        }
      });
    };
    if (__webpack_require__.g.__isAppServiceRemoteDebugMode__ && __webpack_require__.g.$$autoDebug) {
      var _global$$$autoDebug;
      (_global$$$autoDebug = __webpack_require__.g.$$autoDebug) === null || _global$$$autoDebug === void 0 ? void 0 : _global$$$autoDebug.setSubContextGlobalFunctions(name, bindingFunction);
    } else {
      __webpack_require__.g[name] = bindingFunction;
    }
  });
  return _addBinding.apply(this, arguments);
}
function exit() {
  return _exit.apply(this, arguments);
}
function _exit() {
  _exit = asyncToGenerator_default()(function* () {
    bridge.invoke('exitMiniProgram', {});
  });
  return _exit.apply(this, arguments);
}
function captureScreenshot() {
  return _captureScreenshot.apply(this, arguments);
}
function _captureScreenshot() {
  _captureScreenshot = asyncToGenerator_default()(function* () {
    return new Promise((resolve, reject) => {
      function throwErr() {
        reject(Error(`fail to capture screenshot`));
      }
      bridge.invoke('private_captureScreen', {}, /*#__PURE__*/function () {
        var _ref3 = asyncToGenerator_default()(function* (res) {
          var {
            errMsg
          } = res;
          if (contain_default()(errMsg, `:ok`)) {
            var {
              tempFilePath
            } = res;
            getOriginWxMethod('saveFile')({
              tempFilePath,
              success(res) {
                var fs = getOriginWxMethod('getFileSystemManager')();
                var savedFilePath = res.savedFilePath;
                fs.readFile({
                  filePath: savedFilePath,
                  encoding: 'base64',
                  success(res) {
                    getOriginWxMethod('removeSavedFile')({
                      filePath: savedFilePath
                    });
                    resolve({
                      data: res.data
                    });
                  },
                  fail() {
                    throwErr();
                  }
                });
              },
              fail() {
                throwErr();
              }
            });
          } else {
            throwErr();
          }
        });
        return function (_x6) {
          return _ref3.apply(this, arguments);
        };
      }());
    });
  });
  return _captureScreenshot.apply(this, arguments);
}
var app_wxConfig_ = __webpack_require__.g.__wxConfig;
common_serviceGlobal(g => {
  var _appServiceEngine__, _appServiceEngine__$_, _wxConfig__$debugL;
  __appServiceEngine__ = g.__appServiceEngine__;
  ____wx = g.wx;
  var createPluginGlobal = (_appServiceEngine__ = __appServiceEngine__) === null || _appServiceEngine__ === void 0 ? void 0 : (_appServiceEngine__$_ = _appServiceEngine__.__getCreatePluginGlobal) === null || _appServiceEngine__$_ === void 0 ? void 0 : _appServiceEngine__$_.call(_appServiceEngine__);
  var setCreatePluginGlobal = __appServiceEngine__.__setCreatePluginGlobal;
  setCreatePluginGlobal === null || setCreatePluginGlobal === void 0 ? void 0 : setCreatePluginGlobal((pluginId, pluginVersion) => {
    var pluginGlobal = createPluginGlobal === null || createPluginGlobal === void 0 ? void 0 : createPluginGlobal(pluginId, pluginVersion);
    pluginGlobals[pluginId] = pluginGlobal;
    return pluginGlobal;
  });
  g.Reporter.registerErrorListener(msg => {
    var lines = msg.split('\n');
    if (trim_default()(lines[0]) !== 'MiniProgramError') return;
    msg = lines[2];
    msg = trim_default()(msg.replace(/^((Type)|(Range)|(Reference)|(Syntax))?Error:/, ''));
    bridge.invoke('sendAutoMessage', {
      method: 'App.exceptionThrown',
      params: {
        message: msg,
        stack: lines.slice(2).join('\n')
      }
    });
  });
  if (app_wxConfig_ !== null && app_wxConfig_ !== void 0 && (_wxConfig__$debugL = app_wxConfig_.debugLaunchInfo) !== null && _wxConfig__$debugL !== void 0 && _wxConfig__$debugL.autoTest) {
    var originInvoke = g.WeixinJSBridge.invoke;
    Object.defineProperty(g.WeixinJSBridge, 'invoke', {
      value(...argsArr) {
        var [name, args, callback, keepOriginalParams] = argsArr;
        if (SDK[name]) {
          return SDK[name](name, args, callback);
        }
        return originInvoke.apply(g.WeixinJSBridge, argsArr);
      }
    });
    g.WeixinJSBridge.subscribe('callAutoInvoke', argsInvoke => {
      var {
        name,
        args,
        callbackId
      } = argsInvoke;
      var callback = res => {
        g.WeixinJSBridge.publish('callbackAutoInvoke', {
          callbackId,
          res: res
        });
      };
      if (SDK[name]) {
        return SDK[name](name, args, callback);
      }
    });
  }
});
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/isPromise.js
var isPromise = __webpack_require__(5828);
var isPromise_default = /*#__PURE__*/__webpack_require__.n(isPromise);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/safeGet.js
var safeGet = __webpack_require__(4185);
var safeGet_default = /*#__PURE__*/__webpack_require__.n(safeGet);
;// CONCATENATED MODULE: ./src/appservice/page.ts



var page_appServiceEngine_;
common_serviceGlobal(g => {
  page_appServiceEngine_ = g.__appServiceEngine__;
});
function setData(params) {
  var {
    pageId,
    data
  } = params;
  var page = getPage(pageId);
  return new Promise(resolve => {
    page.setData(data, () => {
      resolve();
    });
  });
}
function getData(params) {
  var {
    pageId,
    path
  } = params;
  var page = getPage(pageId);
  var data = Object.assign({}, page.data);
  delete data.__webviewId__;
  if (path) data = safeGet_default()(data, path);
  return {
    data
  };
}
function callMethod(params) {
  var {
    method,
    args
  } = params;
  var page = getPage(params.pageId);
  return new Promise((resolve, reject) => {
    if (!page[method]) {
      return reject(Error(`page.${method} not exists`));
    }
    var result = page[method].apply(page, args);
    if (isPromise_default()(result)) {
      result.then(result => {
        resolve({
          result
        });
      }, reject);
    } else {
      resolve({
        result
      });
    }
  });
}
function getPage(pageId) {
  var pages = page_appServiceEngine_.getCurrentPagesByDomain();
  for (var page of pages) {
    if (page.__wxWebviewId__ === pageId) {
      return page;
    }
  }
  throw Error('page destroyed');
}
;// CONCATENATED MODULE: ./src/appservice/element.ts





var exparser;
var __virtualDOM__;
common_serviceGlobal(g => {
  exparser = g.exparser;
  __virtualDOM__ = g.__virtualDOM__;
});
function element_callMethod(params) {
  var {
    nodeId,
    method,
    args,
    pageId
  } = params;
  var host = __virtualDOM__.getNodeById(nodeId, pageId);
  if (!host) return;
  return new Promise((resolve, reject) => {
    var caller = exparser.Element.getMethodCaller(host);
    if (!caller[method]) {
      return reject(Error(`component.${method} not exists`));
    }
    var result = exparser.safeCallback('Event Handler', caller[method], caller, args, host);
    if (isPromise_default()(result)) {
      result.then(result => {
        resolve({
          result
        });
      }, reject);
    } else {
      resolve({
        result
      });
    }
  });
}
function element_getData(params) {
  var {
    nodeId,
    pageId,
    path
  } = params;
  var host = __virtualDOM__.getNodeById(nodeId, pageId);
  var data = host.data;
  if (path) data = safeGet_default()(data, path);
  return {
    data
  };
}
function element_setData(params) {
  var {
    nodeId,
    pageId,
    data
  } = params;
  var host = __virtualDOM__.getNodeById(nodeId, pageId);
  host.setData(data);
}
function callContextMethod(params) {
  var {
    nodeId,
    videoId,
    pageId,
    method,
    args
  } = params;
  var compInst;
  if (nodeId) {
    compInst = __virtualDOM__.getNodeById(nodeId, pageId);
  } else {
    compInst = getPage(pageId);
  }
  var context;
  if (videoId) {
    context = getOriginWxMethod('createVideoContext')(videoId, compInst);
  } else {
    throw Error('id is not provided');
  }
  return {
    result: context[method].apply(context, args)
  };
}
;// CONCATENATED MODULE: ./src/appservice/methods.ts



var methods = {
  'App.callWxMethod': callWxMethod,
  'App.callFunction': callFunction,
  'App.getCurrentPage': getCurrentPage,
  'App.getPageStack': getPageStack,
  'App.mockWxMethod': mockWxMethod,
  'App.enableLog': enableLog,
  'App.addBinding': addBinding,
  'App.exit': exit,
  'App.captureScreenshot': captureScreenshot,
  'Page.setData': setData,
  'Page.getData': getData,
  'Page.callMethod': callMethod,
  'Element.callMethod': element_callMethod,
  'Element.getData': element_getData,
  'Element.setData': element_setData,
  'Element.callContextMethod': callContextMethod
};
/* harmony default export */ const appservice_methods = (methods);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/sleep.js
var sleep = __webpack_require__(7626);
var sleep_default = /*#__PURE__*/__webpack_require__.n(sleep);
;// CONCATENATED MODULE: ./src/appservice/index.ts







bridge.onReady( /*#__PURE__*/asyncToGenerator_default()(function* () {
  bridge.on('onAutoMessageReceive', /*#__PURE__*/function () {
    var _ref2 = asyncToGenerator_default()(function* (msg) {
      var {
        method,
        params,
        id
      } = msg;
      var resultMsg = {
        id
      };
      if (!isUndef_default()(params.pageId) && !appservice_methods[method]) {
        try {
          getPage(params.pageId);
          bridge.publish('sendAutoMessage', msg, [params.pageId]);
          return;
        } catch (e) {
          resultMsg.error = {
            message: e.message
          };
        }
      } else {
        try {
          resultMsg.result = yield appservice_callMethod(method, params);
        } catch (e) {
          resultMsg.error = {
            message: e.message
          };
        }
      }
      bridge.invoke('sendAutoMessage', resultMsg);
    });
    return function (_x) {
      return _ref2.apply(this, arguments);
    };
  }());
  bridge.subscribe('sendAutoMessage', resultMsg => {
    bridge.invoke('sendAutoMessage', resultMsg);
  });
  yield waitUntil_default()(() => __webpack_require__.g.getCurrentPages && __webpack_require__.g.getCurrentPages().length > 0, 0, 50);
  yield sleep_default()(1000);
  bridge.invoke('sendAutoMessage', {
    method: 'App.initialized',
    params: {
      from: __webpack_require__.g.__isAppServiceRemoteDebugMode__ ? 'appservice' : 'devtools'
    }
  });
}));
function appservice_callMethod(_x2, _x3) {
  return _callMethod.apply(this, arguments);
}
function _callMethod() {
  _callMethod = asyncToGenerator_default()(function* (method, params) {
    if (appservice_methods[method]) {
      return (yield appservice_methods[method](params)) || {};
    } else {
      throw Error(`appservice ${method} unimplemented`);
    }
  });
  return _callMethod.apply(this, arguments);
}
})();

/******/ })()
;