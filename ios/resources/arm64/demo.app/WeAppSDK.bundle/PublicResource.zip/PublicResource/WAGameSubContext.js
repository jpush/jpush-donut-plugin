this.__wxLibrary = { 
  fileName: 'WAGameSubContext.js',
  envType: 'Service',
  contextType: 'Game:SubContext',
  execStart: Date.now(), /* @snapshot-ignore Date.now */
  mayHaveSnapshot: true
};
var __WAGameSubContextStartTime__ = this.__wxLibrary.execStart

;(function (global) { /* LIBRARY_CLOSURE_START (global) */

var __libVersionInfo__ = {"updateTime":"2025.3.14 16:25:27","version":"3.6.5","features":{"pruneWxConfigByPage":true,"injectGameContextPlugin":true,"lazyCodeLoading2":true,"lazyCodeLoadingForDevTool":true,"injectAppSeparatedPlugin":true,"nativeTrans":true,"gameLive":true,"skyline":true,"supportInvokeWithAppId":true,"supportAudits":true,"wkFeatureVersion":5,"delayedServiceCodeCache":true,"gameLiveInvite":true,"globalConsole":true,"earlyDispatchSubPkgReady":true,"glassEasel":1,"supportListenTaskStateChange":true,"supportListenNewPerformanceMetric":true,"collectInvokeCost":true,"expt":["clicfg_appbrand_ios_native_socket_wcwss_new","clicfg_appbrand_ios_native_readfile","clicfg_appbrand_native_readfile","clicfg_canvas_use_magic_brush","clicfg_appbrand_report_trace_event","clicfg_appbrand_skyline_text_style","clicfg_appbrand_ios_allow_worker_binding_message","clicfg_appbrand_ios_arkit2wevision_usevertialplane","clicfg_appbrand_ios_enable_async_create_request_task","clicfg_appbrand_ios_use_jsapi_args_binding","clicfg_appbrand_webview_slow_frame","clicfg_appbrand_webview_native_intersection_observer","clicfg_appbrand_ios_control_close_condom_white","clicfg_appbrand_android_control_close_condom_white","clicfg_appbrand_android_use_game_delay_codecache","clicfg_appbrand_ios_game_shangcheng_kefu","clicfg_android_wagame_frontend_set_file_space_statistics_status","clicfg_appbrand_ios_force_enable_aiad","clicfg_appbrand_android_force_enable_aiad","clicfg_handle_reqresp_in_worker_android","clicfg_appbrand_enable_batch_load_sub_pkg","clicfg_appbrand_ios_enable_aiad_debug_button","clicfg_appbrand_android_enable_aiad_debug_button","clicfg_appbrand_ios_enable_aiad_tag","clicfg_appbrand_android_enable_aiad_tag","clicfg_appbrand_ios_force_use_audio_dynamic_new","clicfg_appbrand_android_force_use_audio_dynamic_new","clicfg_appbrand_ios_operatewxdata_quic_group_control","clicfg_appbrand_ios_operatewxdata_quic_grayrelease_v1","clicfg_appbrand_android_operatewxdata_quic_group_control","clicfg_appbrand_android_operatewxdata_quic_grayrelease_v1","clicfg_wxa_report_ssid","clicfg_miniprogram_global_translate_android","clicfg_miniprogram_global_translate_ios","clicfg_appbrand_android_ad_operatewxdata_batch","clicfg_appbrand_ios_ad_operatewxdata_batch","clicfg_appbrand_ios_operatewxdata_batch","clicfg_appbrand_android_operatewxdata_batch","clicfg_appbrand_ios_enable_jsopdata_mock","clicfg_appbrand_ios_android_aiad_interstitial_cache_time","clicfg_appbrand_ios_android_report_without_batch","clicfg_appbrand_ios_jsapi_nocallback","clicfg_appbrand_android_jsapi_nocallback","clicfg_appbrand_ios_operatewxdata_priority","clicfg_appbrand_android_operatewxdata_priority","clicfg_appbrand_ios_operatewxdata_priority_group_control","clicfg_appbrand_android_operatewxdata_priority_group_control","clicfg_enable_appbrand_downloadfile_enablequic_newcronet","clicfg_appbrand_android_operatewxdata_ipc_optimization","clicfg_appbrand_android_eventcallback_after_listen"],"exptNeedParams":["clicfg_miniprogram_adreport_use_kv"],"snapshotConfig":{"game:main":["WAGame.js"],"game:sub":["WAGameSubContext.js"]},"mayHaveSnapshot":["WAServiceMainContext.js","WASubContext.js","WARenderContext.js","WAGame.js","WAGameSubContext.js"],"pcSnapshotConfig":{"minigame":{"iframeDomain":{"mainContext":["WAGame.js"],"gameContext":["WAGameSubContext.js"]},"workerDomain":{}},"miniprogram":{"iframeDomain":{},"workerDomain":{"main_context":["WAServiceMainContext.js"],"sub_context":["WASubContext.js"]}}},"privacyApiVersion":3},"debugOptions":{"overwriteExpt":{},"enableFPSPanel":false}};
var __clientsubcontext = true;
var __Function__ = global.Function;
var Function = __Function__;
var Reporter; /* DECLARE_CLOSURE_VAR */
var Trace; /* DECLARE_CLOSURE_VAR */

var BabelRuntimeHelpers = {};/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 5803:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./applyDecoratedDescriptor": 7386,
	"./asyncToGenerator": 8921,
	"./initializerDefineProperty": 8704,
	"./initializerWarningHelper": 9651,
	"./objectSpread2": 8680
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 5803;

/***/ }),

/***/ 7386:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _applyDecoratedDescriptor)
/* harmony export */ });
function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
  var desc = {};
  Object.keys(descriptor).forEach(function (key) {
    desc[key] = descriptor[key];
  });
  desc.enumerable = !!desc.enumerable;
  desc.configurable = !!desc.configurable;
  if ('value' in desc || desc.initializer) {
    desc.writable = true;
  }
  desc = decorators.slice().reverse().reduce(function (desc, decorator) {
    return decorator(target, property, desc) || desc;
  }, desc);
  if (context && desc.initializer !== void 0) {
    desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
    desc.initializer = undefined;
  }
  if (desc.initializer === void 0) {
    Object.defineProperty(target, property, desc);
    desc = null;
  }
  return desc;
}

/***/ }),

/***/ 8921:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _asyncToGenerator)
/* harmony export */ });
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}
function _asyncToGenerator(fn) {
  return function () {
    var self = this,
      args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(undefined);
    });
  };
}

/***/ }),

/***/ 8704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _initializerDefineProperty)
/* harmony export */ });
function _initializerDefineProperty(target, property, descriptor, context) {
  if (!descriptor) return;
  Object.defineProperty(target, property, {
    enumerable: descriptor.enumerable,
    configurable: descriptor.configurable,
    writable: descriptor.writable,
    value: descriptor.initializer ? descriptor.initializer.call(context) : void 0
  });
}

/***/ }),

/***/ 9651:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _initializerWarningHelper)
/* harmony export */ });
function _initializerWarningHelper(descriptor, context) {
  throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.');
}

/***/ }),

/***/ 8680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _objectSpread2)
});

;// CONCATENATED MODULE: ../../node_modules/.pnpm/@babel+runtime@7.22.6/node_modules/@babel/runtime/helpers/esm/typeof.js
function _typeof(obj) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) {
    return typeof obj;
  } : function (obj) {
    return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
  }, _typeof(obj);
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@babel+runtime@7.22.6/node_modules/@babel/runtime/helpers/esm/toPrimitive.js

function _toPrimitive(input, hint) {
  if (_typeof(input) !== "object" || input === null) return input;
  var prim = input[Symbol.toPrimitive];
  if (prim !== undefined) {
    var res = prim.call(input, hint || "default");
    if (_typeof(res) !== "object") return res;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (hint === "string" ? String : Number)(input);
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@babel+runtime@7.22.6/node_modules/@babel/runtime/helpers/esm/toPropertyKey.js


function _toPropertyKey(arg) {
  var key = _toPrimitive(arg, "string");
  return _typeof(key) === "symbol" ? key : String(key);
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@babel+runtime@7.22.6/node_modules/@babel/runtime/helpers/esm/defineProperty.js

function _defineProperty(obj, key, value) {
  key = _toPropertyKey(key);
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@babel+runtime@7.22.6/node_modules/@babel/runtime/helpers/esm/objectSpread2.js

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);
  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }
  return keys;
}
function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      _defineProperty(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }
  return target;
}

/***/ }),

/***/ 9762:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var hasOwn = __webpack_require__(1551);
var isArray = __webpack_require__(4288);
var isForced = __webpack_require__(6124);
var shared = __webpack_require__(5517);
var data = isForced.data;
var normalize = isForced.normalize;
var USE_FUNCTION_CONSTRUCTOR = 'USE_FUNCTION_CONSTRUCTOR';
var ASYNC_ITERATOR_PROTOTYPE = 'AsyncIteratorPrototype';
var setAggressivenessLevel = function (object, constant) {
  if (isArray(object)) for (var i = 0; i < object.length; i++) data[normalize(object[i])] = constant;
};
module.exports = function (options) {
  if (typeof options == 'object') {
    setAggressivenessLevel(options.useNative, isForced.NATIVE);
    setAggressivenessLevel(options.usePolyfill, isForced.POLYFILL);
    setAggressivenessLevel(options.useFeatureDetection, null);
    if (hasOwn(options, USE_FUNCTION_CONSTRUCTOR)) {
      shared[USE_FUNCTION_CONSTRUCTOR] = !!options[USE_FUNCTION_CONSTRUCTOR];
    }
    if (hasOwn(options, ASYNC_ITERATOR_PROTOTYPE)) {
      shared[ASYNC_ITERATOR_PROTOTYPE] = options[ASYNC_ITERATOR_PROTOTYPE];
    }
  }
};

/***/ }),

/***/ 8117:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isCallable = __webpack_require__(8173);
var tryToString = __webpack_require__(7420);
var $TypeError = TypeError;

// `Assert: IsCallable(argument) is true`
module.exports = function (argument) {
  if (isCallable(argument)) return argument;
  throw new $TypeError(tryToString(argument) + ' is not a function');
};

/***/ }),

/***/ 6270:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isConstructor = __webpack_require__(4524);
var tryToString = __webpack_require__(7420);
var $TypeError = TypeError;

// `Assert: IsConstructor(argument) is true`
module.exports = function (argument) {
  if (isConstructor(argument)) return argument;
  throw new $TypeError(tryToString(argument) + ' is not a constructor');
};

/***/ }),

/***/ 8924:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isPossiblePrototype = __webpack_require__(4977);
var $String = String;
var $TypeError = TypeError;
module.exports = function (argument) {
  if (isPossiblePrototype(argument)) return argument;
  throw new $TypeError("Can't set " + $String(argument) + ' as a prototype');
};

/***/ }),

/***/ 6016:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var has = (__webpack_require__(3840).has);

// Perform ? RequireInternalSlot(M, [[SetData]])
module.exports = function (it) {
  has(it);
  return it;
};

/***/ }),

/***/ 7591:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var uncurryThis = __webpack_require__(3062);
var bind = __webpack_require__(2038);
var anObject = __webpack_require__(6469);
var aCallable = __webpack_require__(8117);
var isNullOrUndefined = __webpack_require__(1636);
var getMethod = __webpack_require__(3743);
var wellKnownSymbol = __webpack_require__(6387);
var ASYNC_DISPOSE = wellKnownSymbol('asyncDispose');
var DISPOSE = wellKnownSymbol('dispose');
var push = uncurryThis([].push);

// `GetDisposeMethod` abstract operation
// https://tc39.es/proposal-explicit-resource-management/#sec-getdisposemethod
var getDisposeMethod = function (V, hint) {
  if (hint === 'async-dispose') {
    var method = getMethod(V, ASYNC_DISPOSE);
    if (method !== undefined) return method;
    method = getMethod(V, DISPOSE);
    if (method === undefined) return method;
    return function () {
      call(method, this);
    };
  }
  return getMethod(V, DISPOSE);
};

// `CreateDisposableResource` abstract operation
// https://tc39.es/proposal-explicit-resource-management/#sec-createdisposableresource
var createDisposableResource = function (V, hint, method) {
  if (arguments.length < 3 && !isNullOrUndefined(V)) {
    method = aCallable(getDisposeMethod(anObject(V), hint));
  }
  return method === undefined ? function () {
    return undefined;
  } : bind(method, V);
};

// `AddDisposableResource` abstract operation
// https://tc39.es/proposal-explicit-resource-management/#sec-adddisposableresource
module.exports = function (disposable, V, hint, method) {
  var resource;
  if (arguments.length < 4) {
    // When `V`` is either `null` or `undefined` and hint is `async-dispose`,
    // we record that the resource was evaluated to ensure we will still perform an `Await` when resources are later disposed.
    if (isNullOrUndefined(V) && hint === 'sync-dispose') return;
    resource = createDisposableResource(V, hint);
  } else {
    resource = createDisposableResource(undefined, hint, method);
  }
  push(disposable.stack, resource);
};

/***/ }),

/***/ 2890:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var wellKnownSymbol = __webpack_require__(6387);
var create = __webpack_require__(9543);
var defineProperty = (__webpack_require__(615).f);
var UNSCOPABLES = wellKnownSymbol('unscopables');
var ArrayPrototype = Array.prototype;

// Array.prototype[@@unscopables]
// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
if (ArrayPrototype[UNSCOPABLES] === undefined) {
  defineProperty(ArrayPrototype, UNSCOPABLES, {
    configurable: true,
    value: create(null)
  });
}

// add a key to Array.prototype[@@unscopables]
module.exports = function (key) {
  ArrayPrototype[UNSCOPABLES][key] = true;
};

/***/ }),

/***/ 1747:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isPrototypeOf = __webpack_require__(6730);
var $TypeError = TypeError;
module.exports = function (it, Prototype) {
  if (isPrototypeOf(Prototype, it)) return it;
  throw new $TypeError('Incorrect invocation');
};

/***/ }),

/***/ 6469:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isObject = __webpack_require__(9693);
var $String = String;
var $TypeError = TypeError;

// `Assert: Type(argument) is Object`
module.exports = function (argument) {
  if (isObject(argument)) return argument;
  throw new $TypeError($String(argument) + ' is not an object');
};

/***/ }),

/***/ 5392:
/***/ ((module) => {

"use strict";


// eslint-disable-next-line es/no-typed-arrays -- safe
module.exports = typeof ArrayBuffer != 'undefined' && typeof DataView != 'undefined';

/***/ }),

/***/ 1759:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var NATIVE_ARRAY_BUFFER = __webpack_require__(5392);
var DESCRIPTORS = __webpack_require__(1923);
var globalThis = __webpack_require__(1848);
var isCallable = __webpack_require__(8173);
var isObject = __webpack_require__(9693);
var hasOwn = __webpack_require__(1551);
var classof = __webpack_require__(1465);
var tryToString = __webpack_require__(7420);
var createNonEnumerableProperty = __webpack_require__(1384);
var defineBuiltIn = __webpack_require__(5953);
var defineBuiltInAccessor = __webpack_require__(6248);
var isPrototypeOf = __webpack_require__(6730);
var getPrototypeOf = __webpack_require__(4483);
var setPrototypeOf = __webpack_require__(5273);
var wellKnownSymbol = __webpack_require__(6387);
var uid = __webpack_require__(4229);
var InternalStateModule = __webpack_require__(2417);
var enforceInternalState = InternalStateModule.enforce;
var getInternalState = InternalStateModule.get;
var Int8Array = globalThis.Int8Array;
var Int8ArrayPrototype = Int8Array && Int8Array.prototype;
var Uint8ClampedArray = globalThis.Uint8ClampedArray;
var Uint8ClampedArrayPrototype = Uint8ClampedArray && Uint8ClampedArray.prototype;
var TypedArray = Int8Array && getPrototypeOf(Int8Array);
var TypedArrayPrototype = Int8ArrayPrototype && getPrototypeOf(Int8ArrayPrototype);
var ObjectPrototype = Object.prototype;
var TypeError = globalThis.TypeError;
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var TYPED_ARRAY_TAG = uid('TYPED_ARRAY_TAG');
var TYPED_ARRAY_CONSTRUCTOR = 'TypedArrayConstructor';
// Fixing native typed arrays in Opera Presto crashes the browser, see #595
var NATIVE_ARRAY_BUFFER_VIEWS = NATIVE_ARRAY_BUFFER && !!setPrototypeOf && classof(globalThis.opera) !== 'Opera';
var TYPED_ARRAY_TAG_REQUIRED = false;
var NAME, Constructor, Prototype;
var TypedArrayConstructorsList = {
  Int8Array: 1,
  Uint8Array: 1,
  Uint8ClampedArray: 1,
  Int16Array: 2,
  Uint16Array: 2,
  Int32Array: 4,
  Uint32Array: 4,
  Float32Array: 4,
  Float64Array: 8
};
var BigIntArrayConstructorsList = {
  BigInt64Array: 8,
  BigUint64Array: 8
};
var isView = function isView(it) {
  if (!isObject(it)) return false;
  var klass = classof(it);
  return klass === 'DataView' || hasOwn(TypedArrayConstructorsList, klass) || hasOwn(BigIntArrayConstructorsList, klass);
};
var getTypedArrayConstructor = function (it) {
  var proto = getPrototypeOf(it);
  if (!isObject(proto)) return;
  var state = getInternalState(proto);
  return state && hasOwn(state, TYPED_ARRAY_CONSTRUCTOR) ? state[TYPED_ARRAY_CONSTRUCTOR] : getTypedArrayConstructor(proto);
};
var isTypedArray = function (it) {
  if (!isObject(it)) return false;
  var klass = classof(it);
  return hasOwn(TypedArrayConstructorsList, klass) || hasOwn(BigIntArrayConstructorsList, klass);
};
var aTypedArray = function (it) {
  if (isTypedArray(it)) return it;
  throw new TypeError('Target is not a typed array');
};
var aTypedArrayConstructor = function (C) {
  if (isCallable(C) && (!setPrototypeOf || isPrototypeOf(TypedArray, C))) return C;
  throw new TypeError(tryToString(C) + ' is not a typed array constructor');
};
var exportTypedArrayMethod = function (KEY, property, forced, options) {
  if (!DESCRIPTORS) return;
  if (forced) for (var ARRAY in TypedArrayConstructorsList) {
    var TypedArrayConstructor = globalThis[ARRAY];
    if (TypedArrayConstructor && hasOwn(TypedArrayConstructor.prototype, KEY)) try {
      delete TypedArrayConstructor.prototype[KEY];
    } catch (error) {
      // old WebKit bug - some methods are non-configurable
      try {
        TypedArrayConstructor.prototype[KEY] = property;
      } catch (error2) {/* empty */}
    }
  }
  if (!TypedArrayPrototype[KEY] || forced) {
    defineBuiltIn(TypedArrayPrototype, KEY, forced ? property : NATIVE_ARRAY_BUFFER_VIEWS && Int8ArrayPrototype[KEY] || property, options);
  }
};
var exportTypedArrayStaticMethod = function (KEY, property, forced) {
  var ARRAY, TypedArrayConstructor;
  if (!DESCRIPTORS) return;
  if (setPrototypeOf) {
    if (forced) for (ARRAY in TypedArrayConstructorsList) {
      TypedArrayConstructor = globalThis[ARRAY];
      if (TypedArrayConstructor && hasOwn(TypedArrayConstructor, KEY)) try {
        delete TypedArrayConstructor[KEY];
      } catch (error) {/* empty */}
    }
    if (!TypedArray[KEY] || forced) {
      // V8 ~ Chrome 49-50 `%TypedArray%` methods are non-writable non-configurable
      try {
        return defineBuiltIn(TypedArray, KEY, forced ? property : NATIVE_ARRAY_BUFFER_VIEWS && TypedArray[KEY] || property);
      } catch (error) {/* empty */}
    } else return;
  }
  for (ARRAY in TypedArrayConstructorsList) {
    TypedArrayConstructor = globalThis[ARRAY];
    if (TypedArrayConstructor && (!TypedArrayConstructor[KEY] || forced)) {
      defineBuiltIn(TypedArrayConstructor, KEY, property);
    }
  }
};
for (NAME in TypedArrayConstructorsList) {
  Constructor = globalThis[NAME];
  Prototype = Constructor && Constructor.prototype;
  if (Prototype) enforceInternalState(Prototype)[TYPED_ARRAY_CONSTRUCTOR] = Constructor;else NATIVE_ARRAY_BUFFER_VIEWS = false;
}
for (NAME in BigIntArrayConstructorsList) {
  Constructor = globalThis[NAME];
  Prototype = Constructor && Constructor.prototype;
  if (Prototype) enforceInternalState(Prototype)[TYPED_ARRAY_CONSTRUCTOR] = Constructor;
}

// WebKit bug - typed arrays constructors prototype is Object.prototype
if (!NATIVE_ARRAY_BUFFER_VIEWS || !isCallable(TypedArray) || TypedArray === Function.prototype) {
  // eslint-disable-next-line no-shadow -- safe
  TypedArray = function TypedArray() {
    throw new TypeError('Incorrect invocation');
  };
  if (NATIVE_ARRAY_BUFFER_VIEWS) for (NAME in TypedArrayConstructorsList) {
    if (globalThis[NAME]) setPrototypeOf(globalThis[NAME], TypedArray);
  }
}
if (!NATIVE_ARRAY_BUFFER_VIEWS || !TypedArrayPrototype || TypedArrayPrototype === ObjectPrototype) {
  TypedArrayPrototype = TypedArray.prototype;
  if (NATIVE_ARRAY_BUFFER_VIEWS) for (NAME in TypedArrayConstructorsList) {
    if (globalThis[NAME]) setPrototypeOf(globalThis[NAME].prototype, TypedArrayPrototype);
  }
}

// WebKit bug - one more object in Uint8ClampedArray prototype chain
if (NATIVE_ARRAY_BUFFER_VIEWS && getPrototypeOf(Uint8ClampedArrayPrototype) !== TypedArrayPrototype) {
  setPrototypeOf(Uint8ClampedArrayPrototype, TypedArrayPrototype);
}
if (DESCRIPTORS && !hasOwn(TypedArrayPrototype, TO_STRING_TAG)) {
  TYPED_ARRAY_TAG_REQUIRED = true;
  defineBuiltInAccessor(TypedArrayPrototype, TO_STRING_TAG, {
    configurable: true,
    get: function () {
      return isObject(this) ? this[TYPED_ARRAY_TAG] : undefined;
    }
  });
  for (NAME in TypedArrayConstructorsList) if (globalThis[NAME]) {
    createNonEnumerableProperty(globalThis[NAME], TYPED_ARRAY_TAG, NAME);
  }
}
module.exports = {
  NATIVE_ARRAY_BUFFER_VIEWS: NATIVE_ARRAY_BUFFER_VIEWS,
  TYPED_ARRAY_TAG: TYPED_ARRAY_TAG_REQUIRED && TYPED_ARRAY_TAG,
  aTypedArray: aTypedArray,
  aTypedArrayConstructor: aTypedArrayConstructor,
  exportTypedArrayMethod: exportTypedArrayMethod,
  exportTypedArrayStaticMethod: exportTypedArrayStaticMethod,
  getTypedArrayConstructor: getTypedArrayConstructor,
  isView: isView,
  isTypedArray: isTypedArray,
  TypedArray: TypedArray,
  TypedArrayPrototype: TypedArrayPrototype
};

/***/ }),

/***/ 1180:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toObject = __webpack_require__(3659);
var toAbsoluteIndex = __webpack_require__(3663);
var lengthOfArrayLike = __webpack_require__(9110);

// `Array.prototype.fill` method implementation
// https://tc39.es/ecma262/#sec-array.prototype.fill
module.exports = function fill(value /* , start = 0, end = @length */) {
  var O = toObject(this);
  var length = lengthOfArrayLike(O);
  var argumentsLength = arguments.length;
  var index = toAbsoluteIndex(argumentsLength > 1 ? arguments[1] : undefined, length);
  var end = argumentsLength > 2 ? arguments[2] : undefined;
  var endPos = end === undefined ? length : toAbsoluteIndex(end, length);
  while (endPos > index) O[index++] = value;
  return O;
};

/***/ }),

/***/ 4744:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var bind = __webpack_require__(2038);
var uncurryThis = __webpack_require__(3062);
var toObject = __webpack_require__(3659);
var isConstructor = __webpack_require__(4524);
var getAsyncIterator = __webpack_require__(2330);
var getIterator = __webpack_require__(9072);
var getIteratorDirect = __webpack_require__(8986);
var getIteratorMethod = __webpack_require__(2100);
var getMethod = __webpack_require__(3743);
var getBuiltIn = __webpack_require__(9406);
var getBuiltInPrototypeMethod = __webpack_require__(8168);
var wellKnownSymbol = __webpack_require__(6387);
var AsyncFromSyncIterator = __webpack_require__(147);
var toArray = (__webpack_require__(7163).toArray);
var ASYNC_ITERATOR = wellKnownSymbol('asyncIterator');
var arrayIterator = uncurryThis(getBuiltInPrototypeMethod('Array', 'values'));
var arrayIteratorNext = uncurryThis(arrayIterator([]).next);
var safeArrayIterator = function () {
  return new SafeArrayIterator(this);
};
var SafeArrayIterator = function (O) {
  this.iterator = arrayIterator(O);
};
SafeArrayIterator.prototype.next = function () {
  return arrayIteratorNext(this.iterator);
};

// `Array.fromAsync` method implementation
// https://github.com/tc39/proposal-array-from-async
module.exports = function fromAsync(asyncItems /* , mapfn = undefined, thisArg = undefined */) {
  var C = this;
  var argumentsLength = arguments.length;
  var mapfn = argumentsLength > 1 ? arguments[1] : undefined;
  var thisArg = argumentsLength > 2 ? arguments[2] : undefined;
  return new (getBuiltIn('Promise'))(function (resolve) {
    var O = toObject(asyncItems);
    if (mapfn !== undefined) mapfn = bind(mapfn, thisArg);
    var usingAsyncIterator = getMethod(O, ASYNC_ITERATOR);
    var usingSyncIterator = usingAsyncIterator ? undefined : getIteratorMethod(O) || safeArrayIterator;
    var A = isConstructor(C) ? new C() : [];
    var iterator = usingAsyncIterator ? getAsyncIterator(O, usingAsyncIterator) : new AsyncFromSyncIterator(getIteratorDirect(getIterator(O, usingSyncIterator)));
    resolve(toArray(iterator, mapfn, A));
  });
};

/***/ }),

/***/ 2239:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var lengthOfArrayLike = __webpack_require__(9110);
module.exports = function (Constructor, list, $length) {
  var index = 0;
  var length = arguments.length > 2 ? $length : lengthOfArrayLike(list);
  var result = new Constructor(length);
  while (length > index) result[index] = list[index++];
  return result;
};

/***/ }),

/***/ 3077:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var bind = __webpack_require__(2038);
var uncurryThis = __webpack_require__(3062);
var IndexedObject = __webpack_require__(2832);
var toObject = __webpack_require__(3659);
var lengthOfArrayLike = __webpack_require__(9110);
var MapHelpers = __webpack_require__(7741);
var Map = MapHelpers.Map;
var mapGet = MapHelpers.get;
var mapHas = MapHelpers.has;
var mapSet = MapHelpers.set;
var push = uncurryThis([].push);

// `Array.prototype.groupToMap` method
// https://github.com/tc39/proposal-array-grouping
module.exports = function groupToMap(callbackfn /* , thisArg */) {
  var O = toObject(this);
  var self = IndexedObject(O);
  var boundFunction = bind(callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  var map = new Map();
  var length = lengthOfArrayLike(self);
  var index = 0;
  var key, value;
  for (; length > index; index++) {
    value = self[index];
    key = boundFunction(value, index, O);
    if (mapHas(map, key)) push(mapGet(map, key), value);else mapSet(map, key, [value]);
  }
  return map;
};

/***/ }),

/***/ 6747:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var bind = __webpack_require__(2038);
var uncurryThis = __webpack_require__(3062);
var IndexedObject = __webpack_require__(2832);
var toObject = __webpack_require__(3659);
var toPropertyKey = __webpack_require__(7445);
var lengthOfArrayLike = __webpack_require__(9110);
var objectCreate = __webpack_require__(9543);
var arrayFromConstructorAndList = __webpack_require__(2239);
var $Array = Array;
var push = uncurryThis([].push);
module.exports = function ($this, callbackfn, that, specificConstructor) {
  var O = toObject($this);
  var self = IndexedObject(O);
  var boundFunction = bind(callbackfn, that);
  var target = objectCreate(null);
  var length = lengthOfArrayLike(self);
  var index = 0;
  var Constructor, key, value;
  for (; length > index; index++) {
    value = self[index];
    key = toPropertyKey(boundFunction(value, index, O));
    // in some IE versions, `hasOwnProperty` returns incorrect result on integer keys
    // but since it's a `null` prototype object, we can safely use `in`
    if (key in target) push(target[key], value);else target[key] = [value];
  }
  // TODO: Remove this block from `core-js@4`
  if (specificConstructor) {
    Constructor = specificConstructor(O);
    if (Constructor !== $Array) {
      for (key in target) target[key] = arrayFromConstructorAndList(Constructor, target[key]);
    }
  }
  return target;
};

/***/ }),

/***/ 4158:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toIndexedObject = __webpack_require__(8632);
var toAbsoluteIndex = __webpack_require__(3663);
var lengthOfArrayLike = __webpack_require__(9110);

// `Array.prototype.{ indexOf, includes }` methods implementation
var createMethod = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIndexedObject($this);
    var length = lengthOfArrayLike(O);
    if (length === 0) return !IS_INCLUDES && -1;
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare -- NaN check
    if (IS_INCLUDES && el !== el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare -- NaN check
      if (value !== value) return true;
      // Array#indexOf ignores holes, Array#includes - not
    } else for (; length > index; index++) {
      if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
    }
    return !IS_INCLUDES && -1;
  };
};
module.exports = {
  // `Array.prototype.includes` method
  // https://tc39.es/ecma262/#sec-array.prototype.includes
  includes: createMethod(true),
  // `Array.prototype.indexOf` method
  // https://tc39.es/ecma262/#sec-array.prototype.indexof
  indexOf: createMethod(false)
};

/***/ }),

/***/ 2008:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var bind = __webpack_require__(2038);
var IndexedObject = __webpack_require__(2832);
var toObject = __webpack_require__(3659);
var lengthOfArrayLike = __webpack_require__(9110);

// `Array.prototype.{ findLast, findLastIndex }` methods implementation
var createMethod = function (TYPE) {
  var IS_FIND_LAST_INDEX = TYPE === 1;
  return function ($this, callbackfn, that) {
    var O = toObject($this);
    var self = IndexedObject(O);
    var index = lengthOfArrayLike(self);
    var boundFunction = bind(callbackfn, that);
    var value, result;
    while (index-- > 0) {
      value = self[index];
      result = boundFunction(value, index, O);
      if (result) switch (TYPE) {
        case 0:
          return value;
        // findLast
        case 1:
          return index;
        // findLastIndex
      }
    }

    return IS_FIND_LAST_INDEX ? -1 : undefined;
  };
};
module.exports = {
  // `Array.prototype.findLast` method
  // https://github.com/tc39/proposal-array-find-from-last
  findLast: createMethod(0),
  // `Array.prototype.findLastIndex` method
  // https://github.com/tc39/proposal-array-find-from-last
  findLastIndex: createMethod(1)
};

/***/ }),

/***/ 7816:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var fails = __webpack_require__(8462);
module.exports = function (METHOD_NAME, argument) {
  var method = [][METHOD_NAME];
  return !!method && fails(function () {
    // eslint-disable-next-line no-useless-call -- required for testing
    method.call(null, argument || function () {
      return 1;
    }, 1);
  });
};

/***/ }),

/***/ 7826:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var DESCRIPTORS = __webpack_require__(1923);
var isArray = __webpack_require__(4288);
var $TypeError = TypeError;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// Safari < 13 does not throw an error in this case
var SILENT_ON_NON_WRITABLE_LENGTH_SET = DESCRIPTORS && !function () {
  // makes no sense without proper strict mode support
  if (this !== undefined) return true;
  try {
    // eslint-disable-next-line es/no-object-defineproperty -- safe
    Object.defineProperty([], 'length', {
      writable: false
    }).length = 1;
  } catch (error) {
    return error instanceof TypeError;
  }
}();
module.exports = SILENT_ON_NON_WRITABLE_LENGTH_SET ? function (O, length) {
  if (isArray(O) && !getOwnPropertyDescriptor(O, 'length').writable) {
    throw new $TypeError('Cannot set read only .length');
  }
  return O.length = length;
} : function (O, length) {
  return O.length = length;
};

/***/ }),

/***/ 7706:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
module.exports = uncurryThis([].slice);

/***/ }),

/***/ 9070:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var arraySlice = __webpack_require__(7706);
var floor = Math.floor;
var sort = function (array, comparefn) {
  var length = array.length;
  if (length < 8) {
    // insertion sort
    var i = 1;
    var element, j;
    while (i < length) {
      j = i;
      element = array[i];
      while (j && comparefn(array[j - 1], element) > 0) {
        array[j] = array[--j];
      }
      if (j !== i++) array[j] = element;
    }
  } else {
    // merge sort
    var middle = floor(length / 2);
    var left = sort(arraySlice(array, 0, middle), comparefn);
    var right = sort(arraySlice(array, middle), comparefn);
    var llength = left.length;
    var rlength = right.length;
    var lindex = 0;
    var rindex = 0;
    while (lindex < llength || rindex < rlength) {
      array[lindex + rindex] = lindex < llength && rindex < rlength ? comparefn(left[lindex], right[rindex]) <= 0 ? left[lindex++] : right[rindex++] : lindex < llength ? left[lindex++] : right[rindex++];
    }
  }
  return array;
};
module.exports = sort;

/***/ }),

/***/ 459:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var lengthOfArrayLike = __webpack_require__(9110);

// https://tc39.es/proposal-change-array-by-copy/#sec-array.prototype.toReversed
// https://tc39.es/proposal-change-array-by-copy/#sec-%typedarray%.prototype.toReversed
module.exports = function (O, C) {
  var len = lengthOfArrayLike(O);
  var A = new C(len);
  var k = 0;
  for (; k < len; k++) A[k] = O[len - k - 1];
  return A;
};

/***/ }),

/***/ 1403:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var lengthOfArrayLike = __webpack_require__(9110);
var toIntegerOrInfinity = __webpack_require__(6521);
var $RangeError = RangeError;

// https://tc39.es/proposal-change-array-by-copy/#sec-array.prototype.with
// https://tc39.es/proposal-change-array-by-copy/#sec-%typedarray%.prototype.with
module.exports = function (O, C, index, value) {
  var len = lengthOfArrayLike(O);
  var relativeIndex = toIntegerOrInfinity(index);
  var actualIndex = relativeIndex < 0 ? len + relativeIndex : relativeIndex;
  if (actualIndex >= len || actualIndex < 0) throw new $RangeError('Incorrect index');
  var A = new C(len);
  var k = 0;
  for (; k < len; k++) A[k] = k === actualIndex ? value : O[k];
  return A;
};

/***/ }),

/***/ 147:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var anObject = __webpack_require__(6469);
var create = __webpack_require__(9543);
var getMethod = __webpack_require__(3743);
var defineBuiltIns = __webpack_require__(8881);
var InternalStateModule = __webpack_require__(2417);
var getBuiltIn = __webpack_require__(9406);
var AsyncIteratorPrototype = __webpack_require__(2179);
var createIterResultObject = __webpack_require__(9462);
var Promise = getBuiltIn('Promise');
var ASYNC_FROM_SYNC_ITERATOR = 'AsyncFromSyncIterator';
var setInternalState = InternalStateModule.set;
var getInternalState = InternalStateModule.getterFor(ASYNC_FROM_SYNC_ITERATOR);
var asyncFromSyncIteratorContinuation = function (result, resolve, reject) {
  var done = result.done;
  Promise.resolve(result.value).then(function (value) {
    resolve(createIterResultObject(value, done));
  }, reject);
};
var AsyncFromSyncIterator = function AsyncIterator(iteratorRecord) {
  iteratorRecord.type = ASYNC_FROM_SYNC_ITERATOR;
  setInternalState(this, iteratorRecord);
};
AsyncFromSyncIterator.prototype = defineBuiltIns(create(AsyncIteratorPrototype), {
  next: function next() {
    var state = getInternalState(this);
    return new Promise(function (resolve, reject) {
      var result = anObject(call(state.next, state.iterator));
      asyncFromSyncIteratorContinuation(result, resolve, reject);
    });
  },
  'return': function () {
    var iterator = getInternalState(this).iterator;
    return new Promise(function (resolve, reject) {
      var $return = getMethod(iterator, 'return');
      if ($return === undefined) return resolve(createIterResultObject(undefined, true));
      var result = anObject(call($return, iterator));
      asyncFromSyncIteratorContinuation(result, resolve, reject);
    });
  }
});
module.exports = AsyncFromSyncIterator;

/***/ }),

/***/ 7897:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var getBuiltIn = __webpack_require__(9406);
var getMethod = __webpack_require__(3743);
module.exports = function (iterator, method, argument, reject) {
  try {
    var returnMethod = getMethod(iterator, 'return');
    if (returnMethod) {
      return getBuiltIn('Promise').resolve(call(returnMethod, iterator)).then(function () {
        method(argument);
      }, function (error) {
        reject(error);
      });
    }
  } catch (error2) {
    return reject(error2);
  }
  method(argument);
};

/***/ }),

/***/ 9296:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var perform = __webpack_require__(1689);
var anObject = __webpack_require__(6469);
var create = __webpack_require__(9543);
var createNonEnumerableProperty = __webpack_require__(1384);
var defineBuiltIns = __webpack_require__(8881);
var wellKnownSymbol = __webpack_require__(6387);
var InternalStateModule = __webpack_require__(2417);
var getBuiltIn = __webpack_require__(9406);
var getMethod = __webpack_require__(3743);
var AsyncIteratorPrototype = __webpack_require__(2179);
var createIterResultObject = __webpack_require__(9462);
var iteratorClose = __webpack_require__(9273);
var Promise = getBuiltIn('Promise');
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var ASYNC_ITERATOR_HELPER = 'AsyncIteratorHelper';
var WRAP_FOR_VALID_ASYNC_ITERATOR = 'WrapForValidAsyncIterator';
var setInternalState = InternalStateModule.set;
var createAsyncIteratorProxyPrototype = function (IS_ITERATOR) {
  var IS_GENERATOR = !IS_ITERATOR;
  var getInternalState = InternalStateModule.getterFor(IS_ITERATOR ? WRAP_FOR_VALID_ASYNC_ITERATOR : ASYNC_ITERATOR_HELPER);
  var getStateOrEarlyExit = function (that) {
    var stateCompletion = perform(function () {
      return getInternalState(that);
    });
    var stateError = stateCompletion.error;
    var state = stateCompletion.value;
    if (stateError || IS_GENERATOR && state.done) {
      return {
        exit: true,
        value: stateError ? Promise.reject(state) : Promise.resolve(createIterResultObject(undefined, true))
      };
    }
    return {
      exit: false,
      value: state
    };
  };
  return defineBuiltIns(create(AsyncIteratorPrototype), {
    next: function next() {
      var stateCompletion = getStateOrEarlyExit(this);
      var state = stateCompletion.value;
      if (stateCompletion.exit) return state;
      var handlerCompletion = perform(function () {
        return anObject(state.nextHandler(Promise));
      });
      var handlerError = handlerCompletion.error;
      var value = handlerCompletion.value;
      if (handlerError) state.done = true;
      return handlerError ? Promise.reject(value) : Promise.resolve(value);
    },
    'return': function () {
      var stateCompletion = getStateOrEarlyExit(this);
      var state = stateCompletion.value;
      if (stateCompletion.exit) return state;
      state.done = true;
      var iterator = state.iterator;
      var returnMethod, result;
      var completion = perform(function () {
        if (state.inner) try {
          iteratorClose(state.inner.iterator, 'normal');
        } catch (error) {
          return iteratorClose(iterator, 'throw', error);
        }
        return getMethod(iterator, 'return');
      });
      returnMethod = result = completion.value;
      if (completion.error) return Promise.reject(result);
      if (returnMethod === undefined) return Promise.resolve(createIterResultObject(undefined, true));
      completion = perform(function () {
        return call(returnMethod, iterator);
      });
      result = completion.value;
      if (completion.error) return Promise.reject(result);
      return IS_ITERATOR ? Promise.resolve(result) : Promise.resolve(result).then(function (resolved) {
        anObject(resolved);
        return createIterResultObject(undefined, true);
      });
    }
  });
};
var WrapForValidAsyncIteratorPrototype = createAsyncIteratorProxyPrototype(true);
var AsyncIteratorHelperPrototype = createAsyncIteratorProxyPrototype(false);
createNonEnumerableProperty(AsyncIteratorHelperPrototype, TO_STRING_TAG, 'Async Iterator Helper');
module.exports = function (nextHandler, IS_ITERATOR) {
  var AsyncIteratorProxy = function AsyncIterator(record, state) {
    if (state) {
      state.iterator = record.iterator;
      state.next = record.next;
    } else state = record;
    state.type = IS_ITERATOR ? WRAP_FOR_VALID_ASYNC_ITERATOR : ASYNC_ITERATOR_HELPER;
    state.nextHandler = nextHandler;
    state.counter = 0;
    state.done = false;
    setInternalState(this, state);
  };
  AsyncIteratorProxy.prototype = IS_ITERATOR ? WrapForValidAsyncIteratorPrototype : AsyncIteratorHelperPrototype;
  return AsyncIteratorProxy;
};

/***/ }),

/***/ 7163:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// https://github.com/tc39/proposal-iterator-helpers
// https://github.com/tc39/proposal-array-from-async
var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var isObject = __webpack_require__(9693);
var doesNotExceedSafeInteger = __webpack_require__(8475);
var getBuiltIn = __webpack_require__(9406);
var getIteratorDirect = __webpack_require__(8986);
var closeAsyncIteration = __webpack_require__(7897);
var createMethod = function (TYPE) {
  var IS_TO_ARRAY = TYPE === 0;
  var IS_FOR_EACH = TYPE === 1;
  var IS_EVERY = TYPE === 2;
  var IS_SOME = TYPE === 3;
  return function (object, fn, target) {
    anObject(object);
    var MAPPING = fn !== undefined;
    if (MAPPING || !IS_TO_ARRAY) aCallable(fn);
    var record = getIteratorDirect(object);
    var Promise = getBuiltIn('Promise');
    var iterator = record.iterator;
    var next = record.next;
    var counter = 0;
    return new Promise(function (resolve, reject) {
      var ifAbruptCloseAsyncIterator = function (error) {
        closeAsyncIteration(iterator, reject, error, reject);
      };
      var loop = function () {
        try {
          if (MAPPING) try {
            doesNotExceedSafeInteger(counter);
          } catch (error5) {
            ifAbruptCloseAsyncIterator(error5);
          }
          Promise.resolve(anObject(call(next, iterator))).then(function (step) {
            try {
              if (anObject(step).done) {
                if (IS_TO_ARRAY) {
                  target.length = counter;
                  resolve(target);
                } else resolve(IS_SOME ? false : IS_EVERY || undefined);
              } else {
                var value = step.value;
                try {
                  if (MAPPING) {
                    var result = fn(value, counter);
                    var handler = function ($result) {
                      if (IS_FOR_EACH) {
                        loop();
                      } else if (IS_EVERY) {
                        $result ? loop() : closeAsyncIteration(iterator, resolve, false, reject);
                      } else if (IS_TO_ARRAY) {
                        try {
                          target[counter++] = $result;
                          loop();
                        } catch (error4) {
                          ifAbruptCloseAsyncIterator(error4);
                        }
                      } else {
                        $result ? closeAsyncIteration(iterator, resolve, IS_SOME || value, reject) : loop();
                      }
                    };
                    if (isObject(result)) Promise.resolve(result).then(handler, ifAbruptCloseAsyncIterator);else handler(result);
                  } else {
                    target[counter++] = value;
                    loop();
                  }
                } catch (error3) {
                  ifAbruptCloseAsyncIterator(error3);
                }
              }
            } catch (error2) {
              reject(error2);
            }
          }, reject);
        } catch (error) {
          reject(error);
        }
      };
      loop();
    });
  };
};
module.exports = {
  toArray: createMethod(0),
  forEach: createMethod(1),
  every: createMethod(2),
  some: createMethod(3),
  find: createMethod(4)
};

/***/ }),

/***/ 7073:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var isObject = __webpack_require__(9693);
var getIteratorDirect = __webpack_require__(8986);
var createAsyncIteratorProxy = __webpack_require__(9296);
var createIterResultObject = __webpack_require__(9462);
var closeAsyncIteration = __webpack_require__(7897);
var AsyncIteratorProxy = createAsyncIteratorProxy(function (Promise) {
  var state = this;
  var iterator = state.iterator;
  var mapper = state.mapper;
  return new Promise(function (resolve, reject) {
    var doneAndReject = function (error) {
      state.done = true;
      reject(error);
    };
    var ifAbruptCloseAsyncIterator = function (error) {
      closeAsyncIteration(iterator, doneAndReject, error, doneAndReject);
    };
    Promise.resolve(anObject(call(state.next, iterator))).then(function (step) {
      try {
        if (anObject(step).done) {
          state.done = true;
          resolve(createIterResultObject(undefined, true));
        } else {
          var value = step.value;
          try {
            var result = mapper(value, state.counter++);
            var handler = function (mapped) {
              resolve(createIterResultObject(mapped, false));
            };
            if (isObject(result)) Promise.resolve(result).then(handler, ifAbruptCloseAsyncIterator);else handler(result);
          } catch (error2) {
            ifAbruptCloseAsyncIterator(error2);
          }
        }
      } catch (error) {
        doneAndReject(error);
      }
    }, doneAndReject);
  });
});

// `AsyncIterator.prototype.map` method
// https://github.com/tc39/proposal-iterator-helpers
module.exports = function map(mapper) {
  anObject(this);
  aCallable(mapper);
  return new AsyncIteratorProxy(getIteratorDirect(this), {
    mapper: mapper
  });
};

/***/ }),

/***/ 2179:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var shared = __webpack_require__(5517);
var isCallable = __webpack_require__(8173);
var create = __webpack_require__(9543);
var getPrototypeOf = __webpack_require__(4483);
var defineBuiltIn = __webpack_require__(5953);
var wellKnownSymbol = __webpack_require__(6387);
var IS_PURE = __webpack_require__(4151);
var USE_FUNCTION_CONSTRUCTOR = 'USE_FUNCTION_CONSTRUCTOR';
var ASYNC_ITERATOR = wellKnownSymbol('asyncIterator');
var AsyncIterator = globalThis.AsyncIterator;
var PassedAsyncIteratorPrototype = shared.AsyncIteratorPrototype;
var AsyncIteratorPrototype, prototype;
if (PassedAsyncIteratorPrototype) {
  AsyncIteratorPrototype = PassedAsyncIteratorPrototype;
} else if (isCallable(AsyncIterator)) {
  AsyncIteratorPrototype = AsyncIterator.prototype;
} else if (shared[USE_FUNCTION_CONSTRUCTOR] || globalThis[USE_FUNCTION_CONSTRUCTOR]) {
  try {
    // eslint-disable-next-line no-new-func -- we have no alternatives without usage of modern syntax
    prototype = getPrototypeOf(getPrototypeOf(getPrototypeOf(Function('return async function*(){}()')())));
    if (getPrototypeOf(prototype) === Object.prototype) AsyncIteratorPrototype = prototype;
  } catch (error) {/* empty */}
}
if (!AsyncIteratorPrototype) AsyncIteratorPrototype = {};else if (IS_PURE) AsyncIteratorPrototype = create(AsyncIteratorPrototype);
if (!isCallable(AsyncIteratorPrototype[ASYNC_ITERATOR])) {
  defineBuiltIn(AsyncIteratorPrototype, ASYNC_ITERATOR, function () {
    return this;
  });
}
module.exports = AsyncIteratorPrototype;

/***/ }),

/***/ 3525:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var createAsyncIteratorProxy = __webpack_require__(9296);
module.exports = createAsyncIteratorProxy(function () {
  return call(this.next, this.iterator);
}, true);

/***/ }),

/***/ 9832:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var anObject = __webpack_require__(6469);
var iteratorClose = __webpack_require__(9273);

// call something on iterator step with safe closing on error
module.exports = function (iterator, fn, value, ENTRIES) {
  try {
    return ENTRIES ? fn(anObject(value)[0], value[1]) : fn(value);
  } catch (error) {
    iteratorClose(iterator, 'throw', error);
  }
};

/***/ }),

/***/ 4912:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var wellKnownSymbol = __webpack_require__(6387);
var ITERATOR = wellKnownSymbol('iterator');
var SAFE_CLOSING = false;
try {
  var called = 0;
  var iteratorWithReturn = {
    next: function () {
      return {
        done: !!called++
      };
    },
    'return': function () {
      SAFE_CLOSING = true;
    }
  };
  iteratorWithReturn[ITERATOR] = function () {
    return this;
  };
  // eslint-disable-next-line es/no-array-from, no-throw-literal -- required for testing
  Array.from(iteratorWithReturn, function () {
    throw 2;
  });
} catch (error) {/* empty */}
module.exports = function (exec, SKIP_CLOSING) {
  try {
    if (!SKIP_CLOSING && !SAFE_CLOSING) return false;
  } catch (error) {
    return false;
  } // workaround of old WebKit + `eval` bug
  var ITERATION_SUPPORT = false;
  try {
    var object = {};
    object[ITERATOR] = function () {
      return {
        next: function () {
          return {
            done: ITERATION_SUPPORT = true
          };
        }
      };
    };
    exec(object);
  } catch (error) {/* empty */}
  return ITERATION_SUPPORT;
};

/***/ }),

/***/ 6892:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
var toString = uncurryThis({}.toString);
var stringSlice = uncurryThis(''.slice);
module.exports = function (it) {
  return stringSlice(toString(it), 8, -1);
};

/***/ }),

/***/ 1465:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var TO_STRING_TAG_SUPPORT = __webpack_require__(1326);
var isCallable = __webpack_require__(8173);
var classofRaw = __webpack_require__(6892);
var wellKnownSymbol = __webpack_require__(6387);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var $Object = Object;

// ES3 wrong here
var CORRECT_ARGUMENTS = classofRaw(function () {
  return arguments;
}()) === 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (error) {/* empty */}
};

// getting tag from ES6+ `Object.prototype.toString`
module.exports = TO_STRING_TAG_SUPPORT ? classofRaw : function (it) {
  var O, tag, result;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
  // @@toStringTag case
  : typeof (tag = tryGet(O = $Object(it), TO_STRING_TAG)) == 'string' ? tag
  // builtinTag case
  : CORRECT_ARGUMENTS ? classofRaw(O)
  // ES3 arguments fallback
  : (result = classofRaw(O)) === 'Object' && isCallable(O.callee) ? 'Arguments' : result;
};

/***/ }),

/***/ 744:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var hasOwn = __webpack_require__(1551);
var ownKeys = __webpack_require__(3349);
var getOwnPropertyDescriptorModule = __webpack_require__(5983);
var definePropertyModule = __webpack_require__(615);
module.exports = function (target, source, exceptions) {
  var keys = ownKeys(source);
  var defineProperty = definePropertyModule.f;
  var getOwnPropertyDescriptor = getOwnPropertyDescriptorModule.f;
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (!hasOwn(target, key) && !(exceptions && hasOwn(exceptions, key))) {
      defineProperty(target, key, getOwnPropertyDescriptor(source, key));
    }
  }
};

/***/ }),

/***/ 7712:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var fails = __webpack_require__(8462);
module.exports = !fails(function () {
  function F() {/* empty */}
  F.prototype.constructor = null;
  // eslint-disable-next-line es/no-object-getprototypeof -- required for testing
  return Object.getPrototypeOf(new F()) !== F.prototype;
});

/***/ }),

/***/ 9462:
/***/ ((module) => {

"use strict";


// `CreateIterResultObject` abstract operation
// https://tc39.es/ecma262/#sec-createiterresultobject
module.exports = function (value, done) {
  return {
    value: value,
    done: done
  };
};

/***/ }),

/***/ 1384:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var DESCRIPTORS = __webpack_require__(1923);
var definePropertyModule = __webpack_require__(615);
var createPropertyDescriptor = __webpack_require__(4127);
module.exports = DESCRIPTORS ? function (object, key, value) {
  return definePropertyModule.f(object, key, createPropertyDescriptor(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};

/***/ }),

/***/ 4127:
/***/ ((module) => {

"use strict";


module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};

/***/ }),

/***/ 4676:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var DESCRIPTORS = __webpack_require__(1923);
var definePropertyModule = __webpack_require__(615);
var createPropertyDescriptor = __webpack_require__(4127);
module.exports = function (object, key, value) {
  if (DESCRIPTORS) definePropertyModule.f(object, key, createPropertyDescriptor(0, value));else object[key] = value;
};

/***/ }),

/***/ 6248:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var makeBuiltIn = __webpack_require__(1704);
var defineProperty = __webpack_require__(615);
module.exports = function (target, name, descriptor) {
  if (descriptor.get) makeBuiltIn(descriptor.get, name, {
    getter: true
  });
  if (descriptor.set) makeBuiltIn(descriptor.set, name, {
    setter: true
  });
  return defineProperty.f(target, name, descriptor);
};

/***/ }),

/***/ 5953:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isCallable = __webpack_require__(8173);
var definePropertyModule = __webpack_require__(615);
var makeBuiltIn = __webpack_require__(1704);
var defineGlobalProperty = __webpack_require__(3958);
module.exports = function (O, key, value, options) {
  if (!options) options = {};
  var simple = options.enumerable;
  var name = options.name !== undefined ? options.name : key;
  if (isCallable(value)) makeBuiltIn(value, name, options);
  if (options.global) {
    if (simple) O[key] = value;else defineGlobalProperty(key, value);
  } else {
    try {
      if (!options.unsafe) delete O[key];else if (O[key]) simple = true;
    } catch (error) {/* empty */}
    if (simple) O[key] = value;else definePropertyModule.f(O, key, {
      value: value,
      enumerable: false,
      configurable: !options.nonConfigurable,
      writable: !options.nonWritable
    });
  }
  return O;
};

/***/ }),

/***/ 8881:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var defineBuiltIn = __webpack_require__(5953);
module.exports = function (target, src, options) {
  for (var key in src) defineBuiltIn(target, key, src[key], options);
  return target;
};

/***/ }),

/***/ 3958:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);

// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;
module.exports = function (key, value) {
  try {
    defineProperty(globalThis, key, {
      value: value,
      configurable: true,
      writable: true
    });
  } catch (error) {
    globalThis[key] = value;
  }
  return value;
};

/***/ }),

/***/ 5588:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var tryToString = __webpack_require__(7420);
var $TypeError = TypeError;
module.exports = function (O, P) {
  if (!delete O[P]) throw new $TypeError('Cannot delete property ' + tryToString(P) + ' of ' + tryToString(O));
};

/***/ }),

/***/ 1923:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var fails = __webpack_require__(8462);

// Detect IE8's incomplete defineProperty implementation
module.exports = !fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty({}, 1, {
    get: function () {
      return 7;
    }
  })[1] !== 7;
});

/***/ }),

/***/ 4446:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var isObject = __webpack_require__(9693);
var document = globalThis.document;
// typeof document.createElement is 'object' in old IE
var EXISTS = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return EXISTS ? document.createElement(it) : {};
};

/***/ }),

/***/ 8475:
/***/ ((module) => {

"use strict";


var $TypeError = TypeError;
var MAX_SAFE_INTEGER = 0x1FFFFFFFFFFFFF; // 2 ** 53 - 1 == 9007199254740991

module.exports = function (it) {
  if (it > MAX_SAFE_INTEGER) throw $TypeError('Maximum allowed index exceeded');
  return it;
};

/***/ }),

/***/ 7094:
/***/ ((module) => {

"use strict";


// IE8- don't enum bug keys
module.exports = ['constructor', 'hasOwnProperty', 'isPrototypeOf', 'propertyIsEnumerable', 'toLocaleString', 'toString', 'valueOf'];

/***/ }),

/***/ 9257:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var userAgent = __webpack_require__(8722);
var firefox = userAgent.match(/firefox\/(\d+)/i);
module.exports = !!firefox && +firefox[1];

/***/ }),

/***/ 1466:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var UA = __webpack_require__(8722);
module.exports = /MSIE|Trident/.test(UA);

/***/ }),

/***/ 9788:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var userAgent = __webpack_require__(8722);
module.exports = /ipad|iphone|ipod/i.test(userAgent) && typeof Pebble != 'undefined';

/***/ }),

/***/ 9823:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var userAgent = __webpack_require__(8722);

// eslint-disable-next-line redos/no-vulnerable -- safe
module.exports = /(?:ipad|iphone|ipod).*applewebkit/i.test(userAgent);

/***/ }),

/***/ 2409:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ENVIRONMENT = __webpack_require__(1558);
module.exports = ENVIRONMENT === 'NODE';

/***/ }),

/***/ 2027:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var userAgent = __webpack_require__(8722);
module.exports = /web0s(?!.*chrome)/i.test(userAgent);

/***/ }),

/***/ 8722:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var navigator = globalThis.navigator;
var userAgent = navigator && navigator.userAgent;
module.exports = userAgent ? String(userAgent) : '';

/***/ }),

/***/ 9255:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var userAgent = __webpack_require__(8722);
var process = globalThis.process;
var Deno = globalThis.Deno;
var versions = process && process.versions || Deno && Deno.version;
var v8 = versions && versions.v8;
var match, version;
if (v8) {
  match = v8.split('.');
  // in old Chrome, versions of V8 isn't V8 = Chrome / 10
  // but their correct versions are not interesting for us
  version = match[0] > 0 && match[0] < 4 ? 1 : +(match[0] + match[1]);
}

// BrowserFS NodeJS `process` polyfill incorrectly set `.v8` to `0.0`
// so check `userAgent` even if `.v8` exists, but 0
if (!version && userAgent) {
  match = userAgent.match(/Edge\/(\d+)/);
  if (!match || match[1] >= 74) {
    match = userAgent.match(/Chrome\/(\d+)/);
    if (match) version = +match[1];
  }
}
module.exports = version;

/***/ }),

/***/ 8560:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var userAgent = __webpack_require__(8722);
var webkit = userAgent.match(/AppleWebKit\/(\d+)\./);
module.exports = !!webkit && +webkit[1];

/***/ }),

/***/ 1558:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


/* global Bun, Deno -- detection */
var globalThis = __webpack_require__(1848);
var userAgent = __webpack_require__(8722);
var classof = __webpack_require__(6892);
var userAgentStartsWith = function (string) {
  return userAgent.slice(0, string.length) === string;
};
module.exports = function () {
  if (userAgentStartsWith('Bun/')) return 'BUN';
  if (userAgentStartsWith('Cloudflare-Workers')) return 'CLOUDFLARE';
  if (userAgentStartsWith('Deno/')) return 'DENO';
  if (userAgentStartsWith('Node.js/')) return 'NODE';
  if (globalThis.Bun && typeof Bun.version == 'string') return 'BUN';
  if (globalThis.Deno && typeof Deno.version == 'object') return 'DENO';
  if (classof(globalThis.process) === 'process') return 'NODE';
  if (globalThis.window && globalThis.document) return 'BROWSER';
  return 'REST';
}();

/***/ }),

/***/ 5290:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
var $Error = Error;
var replace = uncurryThis(''.replace);
var TEST = function (arg) {
  return String(new $Error(arg).stack);
}('zxcasd');
// eslint-disable-next-line redos/no-vulnerable -- safe
var V8_OR_CHAKRA_STACK_ENTRY = /\n\s*at [^:]*:[^\n]*/;
var IS_V8_OR_CHAKRA_STACK = V8_OR_CHAKRA_STACK_ENTRY.test(TEST);
module.exports = function (stack, dropEntries) {
  if (IS_V8_OR_CHAKRA_STACK && typeof stack == 'string' && !$Error.prepareStackTrace) {
    while (dropEntries--) stack = replace(stack, V8_OR_CHAKRA_STACK_ENTRY, '');
  }
  return stack;
};

/***/ }),

/***/ 2519:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var createNonEnumerableProperty = __webpack_require__(1384);
var clearErrorStack = __webpack_require__(5290);
var ERROR_STACK_INSTALLABLE = __webpack_require__(692);

// non-standard V8
var captureStackTrace = Error.captureStackTrace;
module.exports = function (error, C, stack, dropEntries) {
  if (ERROR_STACK_INSTALLABLE) {
    if (captureStackTrace) captureStackTrace(error, C);else createNonEnumerableProperty(error, 'stack', clearErrorStack(stack, dropEntries));
  }
};

/***/ }),

/***/ 692:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var fails = __webpack_require__(8462);
var createPropertyDescriptor = __webpack_require__(4127);
module.exports = !fails(function () {
  var error = new Error('a');
  if (!('stack' in error)) return true;
  // eslint-disable-next-line es/no-object-defineproperty -- safe
  Object.defineProperty(error, 'stack', createPropertyDescriptor(1, 7));
  return error.stack !== 7;
});

/***/ }),

/***/ 4395:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var getOwnPropertyDescriptor = (__webpack_require__(5983).f);
var createNonEnumerableProperty = __webpack_require__(1384);
var defineBuiltIn = __webpack_require__(5953);
var defineGlobalProperty = __webpack_require__(3958);
var copyConstructorProperties = __webpack_require__(744);
var isForced = __webpack_require__(6124);

/*
  options.target         - name of the target object
  options.global         - target is the global object
  options.stat           - export as static methods of target
  options.proto          - export as prototype methods of target
  options.real           - real prototype method for the `pure` version
  options.forced         - export even if the native feature is available
  options.bind           - bind methods to the target, required for the `pure` version
  options.wrap           - wrap constructors to preventing global pollution, required for the `pure` version
  options.unsafe         - use the simple assignment of property instead of delete + defineProperty
  options.sham           - add a flag to not completely full polyfills
  options.enumerable     - export as enumerable property
  options.dontCallGetSet - prevent calling a getter on target
  options.name           - the .name of the function if it does not match the key
*/
module.exports = function (options, source) {
  var TARGET = options.target;
  var GLOBAL = options.global;
  var STATIC = options.stat;
  var FORCED, target, key, targetProperty, sourceProperty, descriptor;
  if (GLOBAL) {
    target = globalThis;
  } else if (STATIC) {
    target = globalThis[TARGET] || defineGlobalProperty(TARGET, {});
  } else {
    target = globalThis[TARGET] && globalThis[TARGET].prototype;
  }
  if (target) for (key in source) {
    sourceProperty = source[key];
    if (options.dontCallGetSet) {
      descriptor = getOwnPropertyDescriptor(target, key);
      targetProperty = descriptor && descriptor.value;
    } else targetProperty = target[key];
    FORCED = isForced(GLOBAL ? key : TARGET + (STATIC ? '.' : '#') + key, options.forced);
    // contained in target
    if (!FORCED && targetProperty !== undefined) {
      if (typeof sourceProperty == typeof targetProperty) continue;
      copyConstructorProperties(sourceProperty, targetProperty);
    }
    // add a flag to not completely full polyfills
    if (options.sham || targetProperty && targetProperty.sham) {
      createNonEnumerableProperty(sourceProperty, 'sham', true);
    }
    defineBuiltIn(target, key, sourceProperty, options);
  }
};

/***/ }),

/***/ 8462:
/***/ ((module) => {

"use strict";


module.exports = function (exec) {
  try {
    return !!exec();
  } catch (error) {
    return true;
  }
};

/***/ }),

/***/ 3178:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var NATIVE_BIND = __webpack_require__(5020);
var FunctionPrototype = Function.prototype;
var apply = FunctionPrototype.apply;
var call = FunctionPrototype.call;

// eslint-disable-next-line es/no-reflect -- safe
module.exports = typeof Reflect == 'object' && Reflect.apply || (NATIVE_BIND ? call.bind(apply) : function () {
  return call.apply(apply, arguments);
});

/***/ }),

/***/ 2038:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(1992);
var aCallable = __webpack_require__(8117);
var NATIVE_BIND = __webpack_require__(5020);
var bind = uncurryThis(uncurryThis.bind);

// optional / simple context binding
module.exports = function (fn, that) {
  aCallable(fn);
  return that === undefined ? fn : NATIVE_BIND ? bind(fn, that) : function /* ...args */
  () {
    return fn.apply(that, arguments);
  };
};

/***/ }),

/***/ 5020:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var fails = __webpack_require__(8462);
module.exports = !fails(function () {
  // eslint-disable-next-line es/no-function-prototype-bind -- safe
  var test = function () {/* empty */}.bind();
  // eslint-disable-next-line no-prototype-builtins -- safe
  return typeof test != 'function' || test.hasOwnProperty('prototype');
});

/***/ }),

/***/ 7609:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var NATIVE_BIND = __webpack_require__(5020);
var call = Function.prototype.call;
module.exports = NATIVE_BIND ? call.bind(call) : function () {
  return call.apply(call, arguments);
};

/***/ }),

/***/ 63:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var DESCRIPTORS = __webpack_require__(1923);
var hasOwn = __webpack_require__(1551);
var FunctionPrototype = Function.prototype;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getDescriptor = DESCRIPTORS && Object.getOwnPropertyDescriptor;
var EXISTS = hasOwn(FunctionPrototype, 'name');
// additional protection from minified / mangled / dropped function names
var PROPER = EXISTS && function something() {/* empty */}.name === 'something';
var CONFIGURABLE = EXISTS && (!DESCRIPTORS || DESCRIPTORS && getDescriptor(FunctionPrototype, 'name').configurable);
module.exports = {
  EXISTS: EXISTS,
  PROPER: PROPER,
  CONFIGURABLE: CONFIGURABLE
};

/***/ }),

/***/ 252:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
var aCallable = __webpack_require__(8117);
module.exports = function (object, key, method) {
  try {
    // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
    return uncurryThis(aCallable(Object.getOwnPropertyDescriptor(object, key)[method]));
  } catch (error) {/* empty */}
};

/***/ }),

/***/ 1992:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var classofRaw = __webpack_require__(6892);
var uncurryThis = __webpack_require__(3062);
module.exports = function (fn) {
  // Nashorn bug:
  //   https://github.com/zloirock/core-js/issues/1128
  //   https://github.com/zloirock/core-js/issues/1130
  if (classofRaw(fn) === 'Function') return uncurryThis(fn);
};

/***/ }),

/***/ 3062:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var NATIVE_BIND = __webpack_require__(5020);
var FunctionPrototype = Function.prototype;
var call = FunctionPrototype.call;
var uncurryThisWithBind = NATIVE_BIND && FunctionPrototype.bind.bind(call, call);
module.exports = NATIVE_BIND ? uncurryThisWithBind : function (fn) {
  return function () {
    return call.apply(fn, arguments);
  };
};

/***/ }),

/***/ 1401:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var isCallable = __webpack_require__(8173);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);
var getIteratorMethod = __webpack_require__(2100);
var getMethod = __webpack_require__(3743);
var wellKnownSymbol = __webpack_require__(6387);
var AsyncFromSyncIterator = __webpack_require__(147);
var ASYNC_ITERATOR = wellKnownSymbol('asyncIterator');
module.exports = function (obj) {
  var object = anObject(obj);
  var alreadyAsync = true;
  var method = getMethod(object, ASYNC_ITERATOR);
  var iterator;
  if (!isCallable(method)) {
    method = getIteratorMethod(object);
    alreadyAsync = false;
  }
  if (method !== undefined) {
    iterator = call(method, object);
  } else {
    iterator = object;
    alreadyAsync = true;
  }
  anObject(iterator);
  return getIteratorDirect(alreadyAsync ? iterator : new AsyncFromSyncIterator(getIteratorDirect(iterator)));
};

/***/ }),

/***/ 2330:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var AsyncFromSyncIterator = __webpack_require__(147);
var anObject = __webpack_require__(6469);
var getIterator = __webpack_require__(9072);
var getIteratorDirect = __webpack_require__(8986);
var getMethod = __webpack_require__(3743);
var wellKnownSymbol = __webpack_require__(6387);
var ASYNC_ITERATOR = wellKnownSymbol('asyncIterator');
module.exports = function (it, usingIterator) {
  var method = arguments.length < 2 ? getMethod(it, ASYNC_ITERATOR) : usingIterator;
  return method ? anObject(call(method, it)) : new AsyncFromSyncIterator(getIteratorDirect(getIterator(it)));
};

/***/ }),

/***/ 8168:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
module.exports = function (CONSTRUCTOR, METHOD) {
  var Constructor = globalThis[CONSTRUCTOR];
  var Prototype = Constructor && Constructor.prototype;
  return Prototype && Prototype[METHOD];
};

/***/ }),

/***/ 9406:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var isCallable = __webpack_require__(8173);
var aFunction = function (argument) {
  return isCallable(argument) ? argument : undefined;
};
module.exports = function (namespace, method) {
  return arguments.length < 2 ? aFunction(globalThis[namespace]) : globalThis[namespace] && globalThis[namespace][method];
};

/***/ }),

/***/ 8986:
/***/ ((module) => {

"use strict";


// `GetIteratorDirect(obj)` abstract operation
// https://tc39.es/proposal-iterator-helpers/#sec-getiteratordirect
module.exports = function (obj) {
  return {
    iterator: obj,
    next: obj.next,
    done: false
  };
};

/***/ }),

/***/ 8304:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);
var getIteratorMethod = __webpack_require__(2100);
module.exports = function (obj, stringHandling) {
  if (!stringHandling || typeof obj !== 'string') anObject(obj);
  var method = getIteratorMethod(obj);
  return getIteratorDirect(anObject(method !== undefined ? call(method, obj) : obj));
};

/***/ }),

/***/ 2100:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var classof = __webpack_require__(1465);
var getMethod = __webpack_require__(3743);
var isNullOrUndefined = __webpack_require__(1636);
var Iterators = __webpack_require__(7343);
var wellKnownSymbol = __webpack_require__(6387);
var ITERATOR = wellKnownSymbol('iterator');
module.exports = function (it) {
  if (!isNullOrUndefined(it)) return getMethod(it, ITERATOR) || getMethod(it, '@@iterator') || Iterators[classof(it)];
};

/***/ }),

/***/ 9072:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var tryToString = __webpack_require__(7420);
var getIteratorMethod = __webpack_require__(2100);
var $TypeError = TypeError;
module.exports = function (argument, usingIterator) {
  var iteratorMethod = arguments.length < 2 ? getIteratorMethod(argument) : usingIterator;
  if (aCallable(iteratorMethod)) return anObject(call(iteratorMethod, argument));
  throw new $TypeError(tryToString(argument) + ' is not iterable');
};

/***/ }),

/***/ 3743:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aCallable = __webpack_require__(8117);
var isNullOrUndefined = __webpack_require__(1636);

// `GetMethod` abstract operation
// https://tc39.es/ecma262/#sec-getmethod
module.exports = function (V, P) {
  var func = V[P];
  return isNullOrUndefined(func) ? undefined : aCallable(func);
};

/***/ }),

/***/ 1998:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var call = __webpack_require__(7609);
var toIntegerOrInfinity = __webpack_require__(6521);
var getIteratorDirect = __webpack_require__(8986);
var INVALID_SIZE = 'Invalid size';
var $RangeError = RangeError;
var $TypeError = TypeError;
var max = Math.max;
var SetRecord = function (set, intSize) {
  this.set = set;
  this.size = max(intSize, 0);
  this.has = aCallable(set.has);
  this.keys = aCallable(set.keys);
};
SetRecord.prototype = {
  getIterator: function () {
    return getIteratorDirect(anObject(call(this.keys, this.set)));
  },
  includes: function (it) {
    return call(this.has, this.set, it);
  }
};

// `GetSetRecord` abstract operation
// https://tc39.es/proposal-set-methods/#sec-getsetrecord
module.exports = function (obj) {
  anObject(obj);
  var numSize = +obj.size;
  // NOTE: If size is undefined, then numSize will be NaN
  // eslint-disable-next-line no-self-compare -- NaN check
  if (numSize !== numSize) throw new $TypeError(INVALID_SIZE);
  var intSize = toIntegerOrInfinity(numSize);
  if (intSize < 0) throw new $RangeError(INVALID_SIZE);
  return new SetRecord(obj, intSize);
};

/***/ }),

/***/ 1848:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var check = function (it) {
  return it && it.Math === Math && it;
};

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
module.exports =
// eslint-disable-next-line es/no-global-this -- safe
check(typeof globalThis == 'object' && globalThis) || check(typeof window == 'object' && window) ||
// eslint-disable-next-line no-restricted-globals -- safe
check(typeof self == 'object' && self) || check(typeof __webpack_require__.g == 'object' && __webpack_require__.g) || check(typeof this == 'object' && this) ||
// eslint-disable-next-line no-new-func -- fallback
function () {
  return this;
}() || Function('return this')();

/***/ }),

/***/ 1551:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
var toObject = __webpack_require__(3659);
var hasOwnProperty = uncurryThis({}.hasOwnProperty);

// `HasOwnProperty` abstract operation
// https://tc39.es/ecma262/#sec-hasownproperty
// eslint-disable-next-line es/no-object-hasown -- safe
module.exports = Object.hasOwn || function hasOwn(it, key) {
  return hasOwnProperty(toObject(it), key);
};

/***/ }),

/***/ 7051:
/***/ ((module) => {

"use strict";


module.exports = {};

/***/ }),

/***/ 2157:
/***/ ((module) => {

"use strict";


module.exports = function (a, b) {
  try {
    // eslint-disable-next-line no-console -- safe
    arguments.length === 1 ? console.error(a) : console.error(a, b);
  } catch (error) {/* empty */}
};

/***/ }),

/***/ 2241:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var getBuiltIn = __webpack_require__(9406);
module.exports = getBuiltIn('document', 'documentElement');

/***/ }),

/***/ 1881:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var DESCRIPTORS = __webpack_require__(1923);
var fails = __webpack_require__(8462);
var createElement = __webpack_require__(4446);

// Thanks to IE8 for its funny defineProperty
module.exports = !DESCRIPTORS && !fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty(createElement('div'), 'a', {
    get: function () {
      return 7;
    }
  }).a !== 7;
});

/***/ }),

/***/ 2832:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
var fails = __webpack_require__(8462);
var classof = __webpack_require__(6892);
var $Object = Object;
var split = uncurryThis(''.split);

// fallback for non-array-like ES3 and non-enumerable old V8 strings
module.exports = fails(function () {
  // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
  // eslint-disable-next-line no-prototype-builtins -- safe
  return !$Object('z').propertyIsEnumerable(0);
}) ? function (it) {
  return classof(it) === 'String' ? split(it, '') : $Object(it);
} : $Object;

/***/ }),

/***/ 6339:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isCallable = __webpack_require__(8173);
var isObject = __webpack_require__(9693);
var setPrototypeOf = __webpack_require__(5273);

// makes subclassing work correct for wrapped built-ins
module.exports = function ($this, dummy, Wrapper) {
  var NewTarget, NewTargetPrototype;
  if (
  // it can work only with native `setPrototypeOf`
  setPrototypeOf &&
  // we haven't completely correct pre-ES6 way for getting `new.target`, so use this
  isCallable(NewTarget = dummy.constructor) && NewTarget !== Wrapper && isObject(NewTargetPrototype = NewTarget.prototype) && NewTargetPrototype !== Wrapper.prototype) setPrototypeOf($this, NewTargetPrototype);
  return $this;
};

/***/ }),

/***/ 5239:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
var isCallable = __webpack_require__(8173);
var store = __webpack_require__(5517);
var functionToString = uncurryThis(Function.toString);

// this helper broken in `core-js@3.4.1-3.4.4`, so we can't use `shared` helper
if (!isCallable(store.inspectSource)) {
  store.inspectSource = function (it) {
    return functionToString(it);
  };
}
module.exports = store.inspectSource;

/***/ }),

/***/ 6001:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isObject = __webpack_require__(9693);
var createNonEnumerableProperty = __webpack_require__(1384);

// `InstallErrorCause` abstract operation
// https://tc39.es/proposal-error-cause/#sec-errorobjects-install-error-cause
module.exports = function (O, options) {
  if (isObject(options) && 'cause' in options) {
    createNonEnumerableProperty(O, 'cause', options.cause);
  }
};

/***/ }),

/***/ 2417:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var NATIVE_WEAK_MAP = __webpack_require__(3721);
var globalThis = __webpack_require__(1848);
var isObject = __webpack_require__(9693);
var createNonEnumerableProperty = __webpack_require__(1384);
var hasOwn = __webpack_require__(1551);
var shared = __webpack_require__(5517);
var sharedKey = __webpack_require__(5612);
var hiddenKeys = __webpack_require__(7051);
var OBJECT_ALREADY_INITIALIZED = 'Object already initialized';
var TypeError = globalThis.TypeError;
var WeakMap = globalThis.WeakMap;
var set, get, has;
var enforce = function (it) {
  return has(it) ? get(it) : set(it, {});
};
var getterFor = function (TYPE) {
  return function (it) {
    var state;
    if (!isObject(it) || (state = get(it)).type !== TYPE) {
      throw new TypeError('Incompatible receiver, ' + TYPE + ' required');
    }
    return state;
  };
};
if (NATIVE_WEAK_MAP || shared.state) {
  var store = shared.state || (shared.state = new WeakMap());
  /* eslint-disable no-self-assign -- prototype methods protection */
  store.get = store.get;
  store.has = store.has;
  store.set = store.set;
  /* eslint-enable no-self-assign -- prototype methods protection */
  set = function (it, metadata) {
    if (store.has(it)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
    metadata.facade = it;
    store.set(it, metadata);
    return metadata;
  };
  get = function (it) {
    return store.get(it) || {};
  };
  has = function (it) {
    return store.has(it);
  };
} else {
  var STATE = sharedKey('state');
  hiddenKeys[STATE] = true;
  set = function (it, metadata) {
    if (hasOwn(it, STATE)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
    metadata.facade = it;
    createNonEnumerableProperty(it, STATE, metadata);
    return metadata;
  };
  get = function (it) {
    return hasOwn(it, STATE) ? it[STATE] : {};
  };
  has = function (it) {
    return hasOwn(it, STATE);
  };
}
module.exports = {
  set: set,
  get: get,
  has: has,
  enforce: enforce,
  getterFor: getterFor
};

/***/ }),

/***/ 9345:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var wellKnownSymbol = __webpack_require__(6387);
var Iterators = __webpack_require__(7343);
var ITERATOR = wellKnownSymbol('iterator');
var ArrayPrototype = Array.prototype;

// check on default Array iterator
module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayPrototype[ITERATOR] === it);
};

/***/ }),

/***/ 4288:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var classof = __webpack_require__(6892);

// `IsArray` abstract operation
// https://tc39.es/ecma262/#sec-isarray
// eslint-disable-next-line es/no-array-isarray -- safe
module.exports = Array.isArray || function isArray(argument) {
  return classof(argument) === 'Array';
};

/***/ }),

/***/ 4107:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var classof = __webpack_require__(1465);
module.exports = function (it) {
  var klass = classof(it);
  return klass === 'BigInt64Array' || klass === 'BigUint64Array';
};

/***/ }),

/***/ 8173:
/***/ ((module) => {

"use strict";


// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot
var documentAll = typeof document == 'object' && document.all;

// `IsCallable` abstract operation
// https://tc39.es/ecma262/#sec-iscallable
// eslint-disable-next-line unicorn/no-typeof-undefined -- required for testing
module.exports = typeof documentAll == 'undefined' && documentAll !== undefined ? function (argument) {
  return typeof argument == 'function' || argument === documentAll;
} : function (argument) {
  return typeof argument == 'function';
};

/***/ }),

/***/ 4524:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
var fails = __webpack_require__(8462);
var isCallable = __webpack_require__(8173);
var classof = __webpack_require__(1465);
var getBuiltIn = __webpack_require__(9406);
var inspectSource = __webpack_require__(5239);
var noop = function () {/* empty */};
var construct = getBuiltIn('Reflect', 'construct');
var constructorRegExp = /^\s*(?:class|function)\b/;
var exec = uncurryThis(constructorRegExp.exec);
var INCORRECT_TO_STRING = !constructorRegExp.test(noop);
var isConstructorModern = function isConstructor(argument) {
  if (!isCallable(argument)) return false;
  try {
    construct(noop, [], argument);
    return true;
  } catch (error) {
    return false;
  }
};
var isConstructorLegacy = function isConstructor(argument) {
  if (!isCallable(argument)) return false;
  switch (classof(argument)) {
    case 'AsyncFunction':
    case 'GeneratorFunction':
    case 'AsyncGeneratorFunction':
      return false;
  }
  try {
    // we can't check .prototype since constructors produced by .bind haven't it
    // `Function#toString` throws on some built-it function in some legacy engines
    // (for example, `DOMQuad` and similar in FF41-)
    return INCORRECT_TO_STRING || !!exec(constructorRegExp, inspectSource(argument));
  } catch (error) {
    return true;
  }
};
isConstructorLegacy.sham = true;

// `IsConstructor` abstract operation
// https://tc39.es/ecma262/#sec-isconstructor
module.exports = !construct || fails(function () {
  var called;
  return isConstructorModern(isConstructorModern.call) || !isConstructorModern(Object) || !isConstructorModern(function () {
    called = true;
  }) || called;
}) ? isConstructorLegacy : isConstructorModern;

/***/ }),

/***/ 6124:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var fails = __webpack_require__(8462);
var isCallable = __webpack_require__(8173);
var replacement = /#|\.prototype\./;
var isForced = function (feature, detection) {
  var value = data[normalize(feature)];
  return value === POLYFILL ? true : value === NATIVE ? false : isCallable(detection) ? fails(detection) : !!detection;
};
var normalize = isForced.normalize = function (string) {
  return String(string).replace(replacement, '.').toLowerCase();
};
var data = isForced.data = {};
var NATIVE = isForced.NATIVE = 'N';
var POLYFILL = isForced.POLYFILL = 'P';
module.exports = isForced;

/***/ }),

/***/ 1636:
/***/ ((module) => {

"use strict";


// we can't use just `it == null` since of `document.all` special case
// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot-aec
module.exports = function (it) {
  return it === null || it === undefined;
};

/***/ }),

/***/ 9693:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isCallable = __webpack_require__(8173);
module.exports = function (it) {
  return typeof it == 'object' ? it !== null : isCallable(it);
};

/***/ }),

/***/ 4977:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isObject = __webpack_require__(9693);
module.exports = function (argument) {
  return isObject(argument) || argument === null;
};

/***/ }),

/***/ 4151:
/***/ ((module) => {

"use strict";


module.exports = false;

/***/ }),

/***/ 9525:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var getBuiltIn = __webpack_require__(9406);
var isCallable = __webpack_require__(8173);
var isPrototypeOf = __webpack_require__(6730);
var USE_SYMBOL_AS_UID = __webpack_require__(5363);
var $Object = Object;
module.exports = USE_SYMBOL_AS_UID ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  var $Symbol = getBuiltIn('Symbol');
  return isCallable($Symbol) && isPrototypeOf($Symbol.prototype, $Object(it));
};

/***/ }),

/***/ 9806:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
module.exports = function (record, fn, ITERATOR_INSTEAD_OF_RECORD) {
  var iterator = ITERATOR_INSTEAD_OF_RECORD ? record : record.iterator;
  var next = record.next;
  var step, result;
  while (!(step = call(next, iterator)).done) {
    result = fn(step.value);
    if (result !== undefined) return result;
  }
};

/***/ }),

/***/ 2201:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var bind = __webpack_require__(2038);
var call = __webpack_require__(7609);
var anObject = __webpack_require__(6469);
var tryToString = __webpack_require__(7420);
var isArrayIteratorMethod = __webpack_require__(9345);
var lengthOfArrayLike = __webpack_require__(9110);
var isPrototypeOf = __webpack_require__(6730);
var getIterator = __webpack_require__(9072);
var getIteratorMethod = __webpack_require__(2100);
var iteratorClose = __webpack_require__(9273);
var $TypeError = TypeError;
var Result = function (stopped, result) {
  this.stopped = stopped;
  this.result = result;
};
var ResultPrototype = Result.prototype;
module.exports = function (iterable, unboundFunction, options) {
  var that = options && options.that;
  var AS_ENTRIES = !!(options && options.AS_ENTRIES);
  var IS_RECORD = !!(options && options.IS_RECORD);
  var IS_ITERATOR = !!(options && options.IS_ITERATOR);
  var INTERRUPTED = !!(options && options.INTERRUPTED);
  var fn = bind(unboundFunction, that);
  var iterator, iterFn, index, length, result, next, step;
  var stop = function (condition) {
    if (iterator) iteratorClose(iterator, 'normal', condition);
    return new Result(true, condition);
  };
  var callFn = function (value) {
    if (AS_ENTRIES) {
      anObject(value);
      return INTERRUPTED ? fn(value[0], value[1], stop) : fn(value[0], value[1]);
    }
    return INTERRUPTED ? fn(value, stop) : fn(value);
  };
  if (IS_RECORD) {
    iterator = iterable.iterator;
  } else if (IS_ITERATOR) {
    iterator = iterable;
  } else {
    iterFn = getIteratorMethod(iterable);
    if (!iterFn) throw new $TypeError(tryToString(iterable) + ' is not iterable');
    // optimisation for array iterators
    if (isArrayIteratorMethod(iterFn)) {
      for (index = 0, length = lengthOfArrayLike(iterable); length > index; index++) {
        result = callFn(iterable[index]);
        if (result && isPrototypeOf(ResultPrototype, result)) return result;
      }
      return new Result(false);
    }
    iterator = getIterator(iterable, iterFn);
  }
  next = IS_RECORD ? iterable.next : iterator.next;
  while (!(step = call(next, iterator)).done) {
    try {
      result = callFn(step.value);
    } catch (error) {
      iteratorClose(iterator, 'throw', error);
    }
    if (typeof result == 'object' && result && isPrototypeOf(ResultPrototype, result)) return result;
  }
  return new Result(false);
};

/***/ }),

/***/ 9273:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var anObject = __webpack_require__(6469);
var getMethod = __webpack_require__(3743);
module.exports = function (iterator, kind, value) {
  var innerResult, innerError;
  anObject(iterator);
  try {
    innerResult = getMethod(iterator, 'return');
    if (!innerResult) {
      if (kind === 'throw') throw value;
      return value;
    }
    innerResult = call(innerResult, iterator);
  } catch (error) {
    innerError = true;
    innerResult = error;
  }
  if (kind === 'throw') throw value;
  if (innerError) throw innerResult;
  anObject(innerResult);
  return value;
};

/***/ }),

/***/ 2160:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var create = __webpack_require__(9543);
var createNonEnumerableProperty = __webpack_require__(1384);
var defineBuiltIns = __webpack_require__(8881);
var wellKnownSymbol = __webpack_require__(6387);
var InternalStateModule = __webpack_require__(2417);
var getMethod = __webpack_require__(3743);
var IteratorPrototype = (__webpack_require__(7092).IteratorPrototype);
var createIterResultObject = __webpack_require__(9462);
var iteratorClose = __webpack_require__(9273);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var ITERATOR_HELPER = 'IteratorHelper';
var WRAP_FOR_VALID_ITERATOR = 'WrapForValidIterator';
var setInternalState = InternalStateModule.set;
var createIteratorProxyPrototype = function (IS_ITERATOR) {
  var getInternalState = InternalStateModule.getterFor(IS_ITERATOR ? WRAP_FOR_VALID_ITERATOR : ITERATOR_HELPER);
  return defineBuiltIns(create(IteratorPrototype), {
    next: function next() {
      var state = getInternalState(this);
      // for simplification:
      //   for `%WrapForValidIteratorPrototype%.next` our `nextHandler` returns `IterResultObject`
      //   for `%IteratorHelperPrototype%.next` - just a value
      if (IS_ITERATOR) return state.nextHandler();
      try {
        var result = state.done ? undefined : state.nextHandler();
        return createIterResultObject(result, state.done);
      } catch (error) {
        state.done = true;
        throw error;
      }
    },
    'return': function () {
      var state = getInternalState(this);
      var iterator = state.iterator;
      state.done = true;
      if (IS_ITERATOR) {
        var returnMethod = getMethod(iterator, 'return');
        return returnMethod ? call(returnMethod, iterator) : createIterResultObject(undefined, true);
      }
      if (state.inner) try {
        iteratorClose(state.inner.iterator, 'normal');
      } catch (error) {
        return iteratorClose(iterator, 'throw', error);
      }
      iteratorClose(iterator, 'normal');
      return createIterResultObject(undefined, true);
    }
  });
};
var WrapForValidIteratorPrototype = createIteratorProxyPrototype(true);
var IteratorHelperPrototype = createIteratorProxyPrototype(false);
createNonEnumerableProperty(IteratorHelperPrototype, TO_STRING_TAG, 'Iterator Helper');
module.exports = function (nextHandler, IS_ITERATOR) {
  var IteratorProxy = function Iterator(record, state) {
    if (state) {
      state.iterator = record.iterator;
      state.next = record.next;
    } else state = record;
    state.type = IS_ITERATOR ? WRAP_FOR_VALID_ITERATOR : ITERATOR_HELPER;
    state.nextHandler = nextHandler;
    state.counter = 0;
    state.done = false;
    setInternalState(this, state);
  };
  IteratorProxy.prototype = IS_ITERATOR ? WrapForValidIteratorPrototype : IteratorHelperPrototype;
  return IteratorProxy;
};

/***/ }),

/***/ 2563:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);
var createIteratorProxy = __webpack_require__(2160);
var callWithSafeIterationClosing = __webpack_require__(9832);
var IteratorProxy = createIteratorProxy(function () {
  var iterator = this.iterator;
  var result = anObject(call(this.next, iterator));
  var done = this.done = !!result.done;
  if (!done) return callWithSafeIterationClosing(iterator, this.mapper, [result.value, this.counter++], true);
});

// `Iterator.prototype.map` method
// https://github.com/tc39/proposal-iterator-helpers
module.exports = function map(mapper) {
  anObject(this);
  aCallable(mapper);
  return new IteratorProxy(getIteratorDirect(this), {
    mapper: mapper
  });
};

/***/ }),

/***/ 7092:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var fails = __webpack_require__(8462);
var isCallable = __webpack_require__(8173);
var isObject = __webpack_require__(9693);
var create = __webpack_require__(9543);
var getPrototypeOf = __webpack_require__(4483);
var defineBuiltIn = __webpack_require__(5953);
var wellKnownSymbol = __webpack_require__(6387);
var IS_PURE = __webpack_require__(4151);
var ITERATOR = wellKnownSymbol('iterator');
var BUGGY_SAFARI_ITERATORS = false;

// `%IteratorPrototype%` object
// https://tc39.es/ecma262/#sec-%iteratorprototype%-object
var IteratorPrototype, PrototypeOfArrayIteratorPrototype, arrayIterator;

/* eslint-disable es/no-array-prototype-keys -- safe */
if ([].keys) {
  arrayIterator = [].keys();
  // Safari 8 has buggy iterators w/o `next`
  if (!('next' in arrayIterator)) BUGGY_SAFARI_ITERATORS = true;else {
    PrototypeOfArrayIteratorPrototype = getPrototypeOf(getPrototypeOf(arrayIterator));
    if (PrototypeOfArrayIteratorPrototype !== Object.prototype) IteratorPrototype = PrototypeOfArrayIteratorPrototype;
  }
}
var NEW_ITERATOR_PROTOTYPE = !isObject(IteratorPrototype) || fails(function () {
  var test = {};
  // FF44- legacy iterators case
  return IteratorPrototype[ITERATOR].call(test) !== test;
});
if (NEW_ITERATOR_PROTOTYPE) IteratorPrototype = {};else if (IS_PURE) IteratorPrototype = create(IteratorPrototype);

// `%IteratorPrototype%[@@iterator]()` method
// https://tc39.es/ecma262/#sec-%iteratorprototype%-@@iterator
if (!isCallable(IteratorPrototype[ITERATOR])) {
  defineBuiltIn(IteratorPrototype, ITERATOR, function () {
    return this;
  });
}
module.exports = {
  IteratorPrototype: IteratorPrototype,
  BUGGY_SAFARI_ITERATORS: BUGGY_SAFARI_ITERATORS
};

/***/ }),

/***/ 7343:
/***/ ((module) => {

"use strict";


module.exports = {};

/***/ }),

/***/ 9110:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toLength = __webpack_require__(4233);

// `LengthOfArrayLike` abstract operation
// https://tc39.es/ecma262/#sec-lengthofarraylike
module.exports = function (obj) {
  return toLength(obj.length);
};

/***/ }),

/***/ 1704:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
var fails = __webpack_require__(8462);
var isCallable = __webpack_require__(8173);
var hasOwn = __webpack_require__(1551);
var DESCRIPTORS = __webpack_require__(1923);
var CONFIGURABLE_FUNCTION_NAME = (__webpack_require__(63).CONFIGURABLE);
var inspectSource = __webpack_require__(5239);
var InternalStateModule = __webpack_require__(2417);
var enforceInternalState = InternalStateModule.enforce;
var getInternalState = InternalStateModule.get;
var $String = String;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;
var stringSlice = uncurryThis(''.slice);
var replace = uncurryThis(''.replace);
var join = uncurryThis([].join);
var CONFIGURABLE_LENGTH = DESCRIPTORS && !fails(function () {
  return defineProperty(function () {/* empty */}, 'length', {
    value: 8
  }).length !== 8;
});
var TEMPLATE = String(String).split('String');
var makeBuiltIn = module.exports = function (value, name, options) {
  if (stringSlice($String(name), 0, 7) === 'Symbol(') {
    name = '[' + replace($String(name), /^Symbol\(([^)]*)\).*$/, '$1') + ']';
  }
  if (options && options.getter) name = 'get ' + name;
  if (options && options.setter) name = 'set ' + name;
  if (!hasOwn(value, 'name') || CONFIGURABLE_FUNCTION_NAME && value.name !== name) {
    if (DESCRIPTORS) defineProperty(value, 'name', {
      value: name,
      configurable: true
    });else value.name = name;
  }
  if (CONFIGURABLE_LENGTH && options && hasOwn(options, 'arity') && value.length !== options.arity) {
    defineProperty(value, 'length', {
      value: options.arity
    });
  }
  try {
    if (options && hasOwn(options, 'constructor') && options.constructor) {
      if (DESCRIPTORS) defineProperty(value, 'prototype', {
        writable: false
      });
      // in V8 ~ Chrome 53, prototypes of some methods, like `Array.prototype.values`, are non-writable
    } else if (value.prototype) value.prototype = undefined;
  } catch (error) {/* empty */}
  var state = enforceInternalState(value);
  if (!hasOwn(state, 'source')) {
    state.source = join(TEMPLATE, typeof name == 'string' ? name : '');
  }
  return value;
};

// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
// eslint-disable-next-line no-extend-native -- required
Function.prototype.toString = makeBuiltIn(function toString() {
  return isCallable(this) && getInternalState(this).source || inspectSource(this);
}, 'toString');

/***/ }),

/***/ 7741:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);

// eslint-disable-next-line es/no-map -- safe
var MapPrototype = Map.prototype;
module.exports = {
  // eslint-disable-next-line es/no-map -- safe
  Map: Map,
  set: uncurryThis(MapPrototype.set),
  get: uncurryThis(MapPrototype.get),
  has: uncurryThis(MapPrototype.has),
  remove: uncurryThis(MapPrototype['delete']),
  proto: MapPrototype
};

/***/ }),

/***/ 9344:
/***/ ((module) => {

"use strict";


var ceil = Math.ceil;
var floor = Math.floor;

// `Math.trunc` method
// https://tc39.es/ecma262/#sec-math.trunc
// eslint-disable-next-line es/no-math-trunc -- safe
module.exports = Math.trunc || function trunc(x) {
  var n = +x;
  return (n > 0 ? floor : ceil)(n);
};

/***/ }),

/***/ 5684:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var safeGetBuiltIn = __webpack_require__(5512);
var bind = __webpack_require__(2038);
var macrotask = (__webpack_require__(4320).set);
var Queue = __webpack_require__(5141);
var IS_IOS = __webpack_require__(9823);
var IS_IOS_PEBBLE = __webpack_require__(9788);
var IS_WEBOS_WEBKIT = __webpack_require__(2027);
var IS_NODE = __webpack_require__(2409);
var MutationObserver = globalThis.MutationObserver || globalThis.WebKitMutationObserver;
var document = globalThis.document;
var process = globalThis.process;
var Promise = globalThis.Promise;
var microtask = safeGetBuiltIn('queueMicrotask');
var notify, toggle, node, promise, then;

// modern engines have queueMicrotask method
if (!microtask) {
  var queue = new Queue();
  var flush = function () {
    var parent, fn;
    if (IS_NODE && (parent = process.domain)) parent.exit();
    while (fn = queue.get()) try {
      fn();
    } catch (error) {
      if (queue.head) notify();
      throw error;
    }
    if (parent) parent.enter();
  };

  // browsers with MutationObserver, except iOS - https://github.com/zloirock/core-js/issues/339
  // also except WebOS Webkit https://github.com/zloirock/core-js/issues/898
  if (!IS_IOS && !IS_NODE && !IS_WEBOS_WEBKIT && MutationObserver && document) {
    toggle = true;
    node = document.createTextNode('');
    new MutationObserver(flush).observe(node, {
      characterData: true
    });
    notify = function () {
      node.data = toggle = !toggle;
    };
    // environments with maybe non-completely correct, but existent Promise
  } else if (!IS_IOS_PEBBLE && Promise && Promise.resolve) {
    // Promise.resolve without an argument throws an error in LG WebOS 2
    promise = Promise.resolve(undefined);
    // workaround of WebKit ~ iOS Safari 10.1 bug
    promise.constructor = Promise;
    then = bind(promise.then, promise);
    notify = function () {
      then(flush);
    };
    // Node.js without promises
  } else if (IS_NODE) {
    notify = function () {
      process.nextTick(flush);
    };
    // for other environments - macrotask based on:
    // - setImmediate
    // - MessageChannel
    // - window.postMessage
    // - onreadystatechange
    // - setTimeout
  } else {
    // `webpack` dev server bug on IE global methods - use bind(fn, global)
    macrotask = bind(macrotask, globalThis);
    notify = function () {
      macrotask(flush);
    };
  }
  microtask = function (fn) {
    if (!queue.head) notify();
    queue.add(fn);
  };
}
module.exports = microtask;

/***/ }),

/***/ 8326:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aCallable = __webpack_require__(8117);
var $TypeError = TypeError;
var PromiseCapability = function (C) {
  var resolve, reject;
  this.promise = new C(function ($$resolve, $$reject) {
    if (resolve !== undefined || reject !== undefined) throw new $TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject = $$reject;
  });
  this.resolve = aCallable(resolve);
  this.reject = aCallable(reject);
};

// `NewPromiseCapability` abstract operation
// https://tc39.es/ecma262/#sec-newpromisecapability
module.exports.f = function (C) {
  return new PromiseCapability(C);
};

/***/ }),

/***/ 9766:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toString = __webpack_require__(5774);
module.exports = function (argument, $default) {
  return argument === undefined ? arguments.length < 2 ? '' : $default : toString(argument);
};

/***/ }),

/***/ 8428:
/***/ ((module) => {

"use strict";


var $RangeError = RangeError;
module.exports = function (it) {
  // eslint-disable-next-line no-self-compare -- NaN check
  if (it === it) return it;
  throw new $RangeError('NaN is not allowed');
};

/***/ }),

/***/ 9543:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


/* global ActiveXObject -- old IE, WSH */
var anObject = __webpack_require__(6469);
var definePropertiesModule = __webpack_require__(1981);
var enumBugKeys = __webpack_require__(7094);
var hiddenKeys = __webpack_require__(7051);
var html = __webpack_require__(2241);
var documentCreateElement = __webpack_require__(4446);
var sharedKey = __webpack_require__(5612);
var GT = '>';
var LT = '<';
var PROTOTYPE = 'prototype';
var SCRIPT = 'script';
var IE_PROTO = sharedKey('IE_PROTO');
var EmptyConstructor = function () {/* empty */};
var scriptTag = function (content) {
  return LT + SCRIPT + GT + content + LT + '/' + SCRIPT + GT;
};

// Create object with fake `null` prototype: use ActiveX Object with cleared prototype
var NullProtoObjectViaActiveX = function (activeXDocument) {
  activeXDocument.write(scriptTag(''));
  activeXDocument.close();
  var temp = activeXDocument.parentWindow.Object;
  // eslint-disable-next-line no-useless-assignment -- avoid memory leak
  activeXDocument = null;
  return temp;
};

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var NullProtoObjectViaIFrame = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = documentCreateElement('iframe');
  var JS = 'java' + SCRIPT + ':';
  var iframeDocument;
  iframe.style.display = 'none';
  html.appendChild(iframe);
  // https://github.com/zloirock/core-js/issues/475
  iframe.src = String(JS);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(scriptTag('document.F=Object'));
  iframeDocument.close();
  return iframeDocument.F;
};

// Check for document.domain and active x support
// No need to use active x approach when document.domain is not set
// see https://github.com/es-shims/es5-shim/issues/150
// variation of https://github.com/kitcambridge/es5-shim/commit/4f738ac066346
// avoid IE GC bug
var activeXDocument;
var NullProtoObject = function () {
  try {
    activeXDocument = new ActiveXObject('htmlfile');
  } catch (error) {/* ignore */}
  NullProtoObject = typeof document != 'undefined' ? document.domain && activeXDocument ? NullProtoObjectViaActiveX(activeXDocument) // old IE
  : NullProtoObjectViaIFrame() : NullProtoObjectViaActiveX(activeXDocument); // WSH
  var length = enumBugKeys.length;
  while (length--) delete NullProtoObject[PROTOTYPE][enumBugKeys[length]];
  return NullProtoObject();
};
hiddenKeys[IE_PROTO] = true;

// `Object.create` method
// https://tc39.es/ecma262/#sec-object.create
// eslint-disable-next-line es/no-object-create -- safe
module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    EmptyConstructor[PROTOTYPE] = anObject(O);
    result = new EmptyConstructor();
    EmptyConstructor[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = NullProtoObject();
  return Properties === undefined ? result : definePropertiesModule.f(result, Properties);
};

/***/ }),

/***/ 1981:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var DESCRIPTORS = __webpack_require__(1923);
var V8_PROTOTYPE_DEFINE_BUG = __webpack_require__(2552);
var definePropertyModule = __webpack_require__(615);
var anObject = __webpack_require__(6469);
var toIndexedObject = __webpack_require__(8632);
var objectKeys = __webpack_require__(5923);

// `Object.defineProperties` method
// https://tc39.es/ecma262/#sec-object.defineproperties
// eslint-disable-next-line es/no-object-defineproperties -- safe
exports.f = DESCRIPTORS && !V8_PROTOTYPE_DEFINE_BUG ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var props = toIndexedObject(Properties);
  var keys = objectKeys(Properties);
  var length = keys.length;
  var index = 0;
  var key;
  while (length > index) definePropertyModule.f(O, key = keys[index++], props[key]);
  return O;
};

/***/ }),

/***/ 615:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var DESCRIPTORS = __webpack_require__(1923);
var IE8_DOM_DEFINE = __webpack_require__(1881);
var V8_PROTOTYPE_DEFINE_BUG = __webpack_require__(2552);
var anObject = __webpack_require__(6469);
var toPropertyKey = __webpack_require__(7445);
var $TypeError = TypeError;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var $defineProperty = Object.defineProperty;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var ENUMERABLE = 'enumerable';
var CONFIGURABLE = 'configurable';
var WRITABLE = 'writable';

// `Object.defineProperty` method
// https://tc39.es/ecma262/#sec-object.defineproperty
exports.f = DESCRIPTORS ? V8_PROTOTYPE_DEFINE_BUG ? function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPropertyKey(P);
  anObject(Attributes);
  if (typeof O === 'function' && P === 'prototype' && 'value' in Attributes && WRITABLE in Attributes && !Attributes[WRITABLE]) {
    var current = $getOwnPropertyDescriptor(O, P);
    if (current && current[WRITABLE]) {
      O[P] = Attributes.value;
      Attributes = {
        configurable: CONFIGURABLE in Attributes ? Attributes[CONFIGURABLE] : current[CONFIGURABLE],
        enumerable: ENUMERABLE in Attributes ? Attributes[ENUMERABLE] : current[ENUMERABLE],
        writable: false
      };
    }
  }
  return $defineProperty(O, P, Attributes);
} : $defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPropertyKey(P);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return $defineProperty(O, P, Attributes);
  } catch (error) {/* empty */}
  if ('get' in Attributes || 'set' in Attributes) throw new $TypeError('Accessors not supported');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};

/***/ }),

/***/ 5983:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var DESCRIPTORS = __webpack_require__(1923);
var call = __webpack_require__(7609);
var propertyIsEnumerableModule = __webpack_require__(6146);
var createPropertyDescriptor = __webpack_require__(4127);
var toIndexedObject = __webpack_require__(8632);
var toPropertyKey = __webpack_require__(7445);
var hasOwn = __webpack_require__(1551);
var IE8_DOM_DEFINE = __webpack_require__(1881);

// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// `Object.getOwnPropertyDescriptor` method
// https://tc39.es/ecma262/#sec-object.getownpropertydescriptor
exports.f = DESCRIPTORS ? $getOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
  O = toIndexedObject(O);
  P = toPropertyKey(P);
  if (IE8_DOM_DEFINE) try {
    return $getOwnPropertyDescriptor(O, P);
  } catch (error) {/* empty */}
  if (hasOwn(O, P)) return createPropertyDescriptor(!call(propertyIsEnumerableModule.f, O, P), O[P]);
};

/***/ }),

/***/ 1010:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var internalObjectKeys = __webpack_require__(6866);
var enumBugKeys = __webpack_require__(7094);
var hiddenKeys = enumBugKeys.concat('length', 'prototype');

// `Object.getOwnPropertyNames` method
// https://tc39.es/ecma262/#sec-object.getownpropertynames
// eslint-disable-next-line es/no-object-getownpropertynames -- safe
exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return internalObjectKeys(O, hiddenKeys);
};

/***/ }),

/***/ 436:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


// eslint-disable-next-line es/no-object-getownpropertysymbols -- safe
exports.f = Object.getOwnPropertySymbols;

/***/ }),

/***/ 4483:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var hasOwn = __webpack_require__(1551);
var isCallable = __webpack_require__(8173);
var toObject = __webpack_require__(3659);
var sharedKey = __webpack_require__(5612);
var CORRECT_PROTOTYPE_GETTER = __webpack_require__(7712);
var IE_PROTO = sharedKey('IE_PROTO');
var $Object = Object;
var ObjectPrototype = $Object.prototype;

// `Object.getPrototypeOf` method
// https://tc39.es/ecma262/#sec-object.getprototypeof
// eslint-disable-next-line es/no-object-getprototypeof -- safe
module.exports = CORRECT_PROTOTYPE_GETTER ? $Object.getPrototypeOf : function (O) {
  var object = toObject(O);
  if (hasOwn(object, IE_PROTO)) return object[IE_PROTO];
  var constructor = object.constructor;
  if (isCallable(constructor) && object instanceof constructor) {
    return constructor.prototype;
  }
  return object instanceof $Object ? ObjectPrototype : null;
};

/***/ }),

/***/ 6730:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
module.exports = uncurryThis({}.isPrototypeOf);

/***/ }),

/***/ 6866:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
var hasOwn = __webpack_require__(1551);
var toIndexedObject = __webpack_require__(8632);
var indexOf = (__webpack_require__(4158).indexOf);
var hiddenKeys = __webpack_require__(7051);
var push = uncurryThis([].push);
module.exports = function (object, names) {
  var O = toIndexedObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) !hasOwn(hiddenKeys, key) && hasOwn(O, key) && push(result, key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (hasOwn(O, key = names[i++])) {
    ~indexOf(result, key) || push(result, key);
  }
  return result;
};

/***/ }),

/***/ 5923:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var internalObjectKeys = __webpack_require__(6866);
var enumBugKeys = __webpack_require__(7094);

// `Object.keys` method
// https://tc39.es/ecma262/#sec-object.keys
// eslint-disable-next-line es/no-object-keys -- safe
module.exports = Object.keys || function keys(O) {
  return internalObjectKeys(O, enumBugKeys);
};

/***/ }),

/***/ 6146:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


var $propertyIsEnumerable = {}.propertyIsEnumerable;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// Nashorn ~ JDK8 bug
var NASHORN_BUG = getOwnPropertyDescriptor && !$propertyIsEnumerable.call({
  1: 2
}, 1);

// `Object.prototype.propertyIsEnumerable` method implementation
// https://tc39.es/ecma262/#sec-object.prototype.propertyisenumerable
exports.f = NASHORN_BUG ? function propertyIsEnumerable(V) {
  var descriptor = getOwnPropertyDescriptor(this, V);
  return !!descriptor && descriptor.enumerable;
} : $propertyIsEnumerable;

/***/ }),

/***/ 5273:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


/* eslint-disable no-proto -- safe */
var uncurryThisAccessor = __webpack_require__(252);
var isObject = __webpack_require__(9693);
var requireObjectCoercible = __webpack_require__(170);
var aPossiblePrototype = __webpack_require__(8924);

// `Object.setPrototypeOf` method
// https://tc39.es/ecma262/#sec-object.setprototypeof
// Works with __proto__ only. Old v8 can't work with null proto objects.
// eslint-disable-next-line es/no-object-setprototypeof -- safe
module.exports = Object.setPrototypeOf || ('__proto__' in {} ? function () {
  var CORRECT_SETTER = false;
  var test = {};
  var setter;
  try {
    setter = uncurryThisAccessor(Object.prototype, '__proto__', 'set');
    setter(test, []);
    CORRECT_SETTER = test instanceof Array;
  } catch (error) {/* empty */}
  return function setPrototypeOf(O, proto) {
    requireObjectCoercible(O);
    aPossiblePrototype(proto);
    if (!isObject(O)) return O;
    if (CORRECT_SETTER) setter(O, proto);else O.__proto__ = proto;
    return O;
  };
}() : undefined);

/***/ }),

/***/ 3613:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var isCallable = __webpack_require__(8173);
var isObject = __webpack_require__(9693);
var $TypeError = TypeError;

// `OrdinaryToPrimitive` abstract operation
// https://tc39.es/ecma262/#sec-ordinarytoprimitive
module.exports = function (input, pref) {
  var fn, val;
  if (pref === 'string' && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
  if (isCallable(fn = input.valueOf) && !isObject(val = call(fn, input))) return val;
  if (pref !== 'string' && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
  throw new $TypeError("Can't convert object to primitive value");
};

/***/ }),

/***/ 3349:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var getBuiltIn = __webpack_require__(9406);
var uncurryThis = __webpack_require__(3062);
var getOwnPropertyNamesModule = __webpack_require__(1010);
var getOwnPropertySymbolsModule = __webpack_require__(436);
var anObject = __webpack_require__(6469);
var concat = uncurryThis([].concat);

// all object keys, includes non-enumerable and symbols
module.exports = getBuiltIn('Reflect', 'ownKeys') || function ownKeys(it) {
  var keys = getOwnPropertyNamesModule.f(anObject(it));
  var getOwnPropertySymbols = getOwnPropertySymbolsModule.f;
  return getOwnPropertySymbols ? concat(keys, getOwnPropertySymbols(it)) : keys;
};

/***/ }),

/***/ 3448:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
module.exports = globalThis;

/***/ }),

/***/ 1689:
/***/ ((module) => {

"use strict";


module.exports = function (exec) {
  try {
    return {
      error: false,
      value: exec()
    };
  } catch (error) {
    return {
      error: true,
      value: error
    };
  }
};

/***/ }),

/***/ 1495:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var NativePromiseConstructor = __webpack_require__(4243);
var isCallable = __webpack_require__(8173);
var isForced = __webpack_require__(6124);
var inspectSource = __webpack_require__(5239);
var wellKnownSymbol = __webpack_require__(6387);
var ENVIRONMENT = __webpack_require__(1558);
var IS_PURE = __webpack_require__(4151);
var V8_VERSION = __webpack_require__(9255);
var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;
var SPECIES = wellKnownSymbol('species');
var SUBCLASSING = false;
var NATIVE_PROMISE_REJECTION_EVENT = isCallable(globalThis.PromiseRejectionEvent);
var FORCED_PROMISE_CONSTRUCTOR = isForced('Promise', function () {
  var PROMISE_CONSTRUCTOR_SOURCE = inspectSource(NativePromiseConstructor);
  var GLOBAL_CORE_JS_PROMISE = PROMISE_CONSTRUCTOR_SOURCE !== String(NativePromiseConstructor);
  // V8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
  // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
  // We can't detect it synchronously, so just check versions
  if (!GLOBAL_CORE_JS_PROMISE && V8_VERSION === 66) return true;
  // We need Promise#{ catch, finally } in the pure version for preventing prototype pollution
  if (IS_PURE && !(NativePromisePrototype['catch'] && NativePromisePrototype['finally'])) return true;
  // We can't use @@species feature detection in V8 since it causes
  // deoptimization and performance degradation
  // https://github.com/zloirock/core-js/issues/679
  if (!V8_VERSION || V8_VERSION < 51 || !/native code/.test(PROMISE_CONSTRUCTOR_SOURCE)) {
    // Detect correctness of subclassing with @@species support
    var promise = new NativePromiseConstructor(function (resolve) {
      resolve(1);
    });
    var FakePromise = function (exec) {
      exec(function () {/* empty */}, function () {/* empty */});
    };
    var constructor = promise.constructor = {};
    constructor[SPECIES] = FakePromise;
    SUBCLASSING = promise.then(function () {/* empty */}) instanceof FakePromise;
    if (!SUBCLASSING) return true;
    // Unhandled rejections tracking support, NodeJS Promise without it fails @@species test
  }
  return !GLOBAL_CORE_JS_PROMISE && (ENVIRONMENT === 'BROWSER' || ENVIRONMENT === 'DENO') && !NATIVE_PROMISE_REJECTION_EVENT;
});
module.exports = {
  CONSTRUCTOR: FORCED_PROMISE_CONSTRUCTOR,
  REJECTION_EVENT: NATIVE_PROMISE_REJECTION_EVENT,
  SUBCLASSING: SUBCLASSING
};

/***/ }),

/***/ 4243:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
module.exports = globalThis.Promise;

/***/ }),

/***/ 1128:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var anObject = __webpack_require__(6469);
var isObject = __webpack_require__(9693);
var newPromiseCapability = __webpack_require__(8326);
module.exports = function (C, x) {
  anObject(C);
  if (isObject(x) && x.constructor === C) return x;
  var promiseCapability = newPromiseCapability.f(C);
  var resolve = promiseCapability.resolve;
  resolve(x);
  return promiseCapability.promise;
};

/***/ }),

/***/ 7019:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var NativePromiseConstructor = __webpack_require__(4243);
var checkCorrectnessOfIteration = __webpack_require__(4912);
var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(1495).CONSTRUCTOR);
module.exports = FORCED_PROMISE_CONSTRUCTOR || !checkCorrectnessOfIteration(function (iterable) {
  NativePromiseConstructor.all(iterable).then(undefined, function () {/* empty */});
});

/***/ }),

/***/ 4279:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var defineProperty = (__webpack_require__(615).f);
module.exports = function (Target, Source, key) {
  key in Target || defineProperty(Target, key, {
    configurable: true,
    get: function () {
      return Source[key];
    },
    set: function (it) {
      Source[key] = it;
    }
  });
};

/***/ }),

/***/ 5141:
/***/ ((module) => {

"use strict";


var Queue = function () {
  this.head = null;
  this.tail = null;
};
Queue.prototype = {
  add: function (item) {
    var entry = {
      item: item,
      next: null
    };
    var tail = this.tail;
    if (tail) tail.next = entry;else this.head = entry;
    this.tail = entry;
  },
  get: function () {
    var entry = this.head;
    if (entry) {
      var next = this.head = entry.next;
      if (next === null) this.tail = null;
      return entry.item;
    }
  }
};
module.exports = Queue;

/***/ }),

/***/ 7834:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var anObject = __webpack_require__(6469);

// `RegExp.prototype.flags` getter implementation
// https://tc39.es/ecma262/#sec-get-regexp.prototype.flags
module.exports = function () {
  var that = anObject(this);
  var result = '';
  if (that.hasIndices) result += 'd';
  if (that.global) result += 'g';
  if (that.ignoreCase) result += 'i';
  if (that.multiline) result += 'm';
  if (that.dotAll) result += 's';
  if (that.unicode) result += 'u';
  if (that.unicodeSets) result += 'v';
  if (that.sticky) result += 'y';
  return result;
};

/***/ }),

/***/ 170:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var isNullOrUndefined = __webpack_require__(1636);
var $TypeError = TypeError;

// `RequireObjectCoercible` abstract operation
// https://tc39.es/ecma262/#sec-requireobjectcoercible
module.exports = function (it) {
  if (isNullOrUndefined(it)) throw new $TypeError("Can't call method on " + it);
  return it;
};

/***/ }),

/***/ 5512:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var DESCRIPTORS = __webpack_require__(1923);

// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// Avoid NodeJS experimental warning
module.exports = function (name) {
  if (!DESCRIPTORS) return globalThis[name];
  var descriptor = getOwnPropertyDescriptor(globalThis, name);
  return descriptor && descriptor.value;
};

/***/ }),

/***/ 929:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var SetHelpers = __webpack_require__(3840);
var iterate = __webpack_require__(2745);
var Set = SetHelpers.Set;
var add = SetHelpers.add;
module.exports = function (set) {
  var result = new Set();
  iterate(set, function (it) {
    add(result, it);
  });
  return result;
};

/***/ }),

/***/ 9864:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(6016);
var SetHelpers = __webpack_require__(3840);
var clone = __webpack_require__(929);
var size = __webpack_require__(5179);
var getSetRecord = __webpack_require__(1998);
var iterateSet = __webpack_require__(2745);
var iterateSimple = __webpack_require__(9806);
var has = SetHelpers.has;
var remove = SetHelpers.remove;

// `Set.prototype.difference` method
// https://github.com/tc39/proposal-set-methods
module.exports = function difference(other) {
  var O = aSet(this);
  var otherRec = getSetRecord(other);
  var result = clone(O);
  if (size(O) <= otherRec.size) iterateSet(O, function (e) {
    if (otherRec.includes(e)) remove(result, e);
  });else iterateSimple(otherRec.getIterator(), function (e) {
    if (has(O, e)) remove(result, e);
  });
  return result;
};

/***/ }),

/***/ 3840:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);

// eslint-disable-next-line es/no-set -- safe
var SetPrototype = Set.prototype;
module.exports = {
  // eslint-disable-next-line es/no-set -- safe
  Set: Set,
  add: uncurryThis(SetPrototype.add),
  has: uncurryThis(SetPrototype.has),
  remove: uncurryThis(SetPrototype['delete']),
  proto: SetPrototype
};

/***/ }),

/***/ 374:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(6016);
var SetHelpers = __webpack_require__(3840);
var size = __webpack_require__(5179);
var getSetRecord = __webpack_require__(1998);
var iterateSet = __webpack_require__(2745);
var iterateSimple = __webpack_require__(9806);
var Set = SetHelpers.Set;
var add = SetHelpers.add;
var has = SetHelpers.has;

// `Set.prototype.intersection` method
// https://github.com/tc39/proposal-set-methods
module.exports = function intersection(other) {
  var O = aSet(this);
  var otherRec = getSetRecord(other);
  var result = new Set();
  if (size(O) > otherRec.size) {
    iterateSimple(otherRec.getIterator(), function (e) {
      if (has(O, e)) add(result, e);
    });
  } else {
    iterateSet(O, function (e) {
      if (otherRec.includes(e)) add(result, e);
    });
  }
  return result;
};

/***/ }),

/***/ 7735:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(6016);
var has = (__webpack_require__(3840).has);
var size = __webpack_require__(5179);
var getSetRecord = __webpack_require__(1998);
var iterateSet = __webpack_require__(2745);
var iterateSimple = __webpack_require__(9806);
var iteratorClose = __webpack_require__(9273);

// `Set.prototype.isDisjointFrom` method
// https://tc39.github.io/proposal-set-methods/#Set.prototype.isDisjointFrom
module.exports = function isDisjointFrom(other) {
  var O = aSet(this);
  var otherRec = getSetRecord(other);
  if (size(O) <= otherRec.size) return iterateSet(O, function (e) {
    if (otherRec.includes(e)) return false;
  }, true) !== false;
  var iterator = otherRec.getIterator();
  return iterateSimple(iterator, function (e) {
    if (has(O, e)) return iteratorClose(iterator, 'normal', false);
  }) !== false;
};

/***/ }),

/***/ 6274:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(6016);
var size = __webpack_require__(5179);
var iterate = __webpack_require__(2745);
var getSetRecord = __webpack_require__(1998);

// `Set.prototype.isSubsetOf` method
// https://tc39.github.io/proposal-set-methods/#Set.prototype.isSubsetOf
module.exports = function isSubsetOf(other) {
  var O = aSet(this);
  var otherRec = getSetRecord(other);
  if (size(O) > otherRec.size) return false;
  return iterate(O, function (e) {
    if (!otherRec.includes(e)) return false;
  }, true) !== false;
};

/***/ }),

/***/ 9749:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(6016);
var has = (__webpack_require__(3840).has);
var size = __webpack_require__(5179);
var getSetRecord = __webpack_require__(1998);
var iterateSimple = __webpack_require__(9806);
var iteratorClose = __webpack_require__(9273);

// `Set.prototype.isSupersetOf` method
// https://tc39.github.io/proposal-set-methods/#Set.prototype.isSupersetOf
module.exports = function isSupersetOf(other) {
  var O = aSet(this);
  var otherRec = getSetRecord(other);
  if (size(O) < otherRec.size) return false;
  var iterator = otherRec.getIterator();
  return iterateSimple(iterator, function (e) {
    if (!has(O, e)) return iteratorClose(iterator, 'normal', false);
  }) !== false;
};

/***/ }),

/***/ 2745:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
var iterateSimple = __webpack_require__(9806);
var SetHelpers = __webpack_require__(3840);
var Set = SetHelpers.Set;
var SetPrototype = SetHelpers.proto;
var forEach = uncurryThis(SetPrototype.forEach);
var keys = uncurryThis(SetPrototype.keys);
var next = keys(new Set()).next;
module.exports = function (set, fn, interruptible) {
  return interruptible ? iterateSimple({
    iterator: keys(set),
    next: next
  }, fn) : forEach(set, fn);
};

/***/ }),

/***/ 4435:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var getBuiltIn = __webpack_require__(9406);
var createSetLike = function (size) {
  return {
    size: size,
    has: function () {
      return false;
    },
    keys: function () {
      return {
        next: function () {
          return {
            done: true
          };
        }
      };
    }
  };
};
module.exports = function (name) {
  var Set = getBuiltIn('Set');
  try {
    new Set()[name](createSetLike(0));
    try {
      // late spec change, early WebKit ~ Safari 17.0 beta implementation does not pass it
      // https://github.com/tc39/proposal-set-methods/pull/88
      new Set()[name](createSetLike(-1));
      return false;
    } catch (error2) {
      return true;
    }
  } catch (error) {
    return false;
  }
};

/***/ }),

/***/ 5179:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThisAccessor = __webpack_require__(252);
var SetHelpers = __webpack_require__(3840);
module.exports = uncurryThisAccessor(SetHelpers.proto, 'size', 'get') || function (set) {
  return set.size;
};

/***/ }),

/***/ 5539:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var getBuiltIn = __webpack_require__(9406);
var defineBuiltInAccessor = __webpack_require__(6248);
var wellKnownSymbol = __webpack_require__(6387);
var DESCRIPTORS = __webpack_require__(1923);
var SPECIES = wellKnownSymbol('species');
module.exports = function (CONSTRUCTOR_NAME) {
  var Constructor = getBuiltIn(CONSTRUCTOR_NAME);
  if (DESCRIPTORS && Constructor && !Constructor[SPECIES]) {
    defineBuiltInAccessor(Constructor, SPECIES, {
      configurable: true,
      get: function () {
        return this;
      }
    });
  }
};

/***/ }),

/***/ 3285:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(6016);
var SetHelpers = __webpack_require__(3840);
var clone = __webpack_require__(929);
var getSetRecord = __webpack_require__(1998);
var iterateSimple = __webpack_require__(9806);
var add = SetHelpers.add;
var has = SetHelpers.has;
var remove = SetHelpers.remove;

// `Set.prototype.symmetricDifference` method
// https://github.com/tc39/proposal-set-methods
module.exports = function symmetricDifference(other) {
  var O = aSet(this);
  var keysIter = getSetRecord(other).getIterator();
  var result = clone(O);
  iterateSimple(keysIter, function (e) {
    if (has(O, e)) remove(result, e);else add(result, e);
  });
  return result;
};

/***/ }),

/***/ 6988:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var defineProperty = (__webpack_require__(615).f);
var hasOwn = __webpack_require__(1551);
var wellKnownSymbol = __webpack_require__(6387);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
module.exports = function (target, TAG, STATIC) {
  if (target && !STATIC) target = target.prototype;
  if (target && !hasOwn(target, TO_STRING_TAG)) {
    defineProperty(target, TO_STRING_TAG, {
      configurable: true,
      value: TAG
    });
  }
};

/***/ }),

/***/ 2394:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(6016);
var add = (__webpack_require__(3840).add);
var clone = __webpack_require__(929);
var getSetRecord = __webpack_require__(1998);
var iterateSimple = __webpack_require__(9806);

// `Set.prototype.union` method
// https://github.com/tc39/proposal-set-methods
module.exports = function union(other) {
  var O = aSet(this);
  var keysIter = getSetRecord(other).getIterator();
  var result = clone(O);
  iterateSimple(keysIter, function (it) {
    add(result, it);
  });
  return result;
};

/***/ }),

/***/ 5612:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var shared = __webpack_require__(6231);
var uid = __webpack_require__(4229);
var keys = shared('keys');
module.exports = function (key) {
  return keys[key] || (keys[key] = uid(key));
};

/***/ }),

/***/ 5517:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var IS_PURE = __webpack_require__(4151);
var globalThis = __webpack_require__(1848);
var defineGlobalProperty = __webpack_require__(3958);
var SHARED = '__core-js_shared__';
var store = module.exports = globalThis[SHARED] || defineGlobalProperty(SHARED, {});
(store.versions || (store.versions = [])).push({
  version: '3.38.1',
  mode: IS_PURE ? 'pure' : 'global',
  copyright: '© 2014-2024 Denis Pushkarev (zloirock.ru)',
  license: 'https://github.com/zloirock/core-js/blob/v3.38.1/LICENSE',
  source: 'https://github.com/zloirock/core-js'
});

/***/ }),

/***/ 6231:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var store = __webpack_require__(5517);
module.exports = function (key, value) {
  return store[key] || (store[key] = value || {});
};

/***/ }),

/***/ 9675:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var anObject = __webpack_require__(6469);
var aConstructor = __webpack_require__(6270);
var isNullOrUndefined = __webpack_require__(1636);
var wellKnownSymbol = __webpack_require__(6387);
var SPECIES = wellKnownSymbol('species');

// `SpeciesConstructor` abstract operation
// https://tc39.es/ecma262/#sec-speciesconstructor
module.exports = function (O, defaultConstructor) {
  var C = anObject(O).constructor;
  var S;
  return C === undefined || isNullOrUndefined(S = anObject(C)[SPECIES]) ? defaultConstructor : aConstructor(S);
};

/***/ }),

/***/ 444:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


/* eslint-disable es/no-symbol -- required for testing */
var V8_VERSION = __webpack_require__(9255);
var fails = __webpack_require__(8462);
var globalThis = __webpack_require__(1848);
var $String = globalThis.String;

// eslint-disable-next-line es/no-object-getownpropertysymbols -- required for testing
module.exports = !!Object.getOwnPropertySymbols && !fails(function () {
  var symbol = Symbol('symbol detection');
  // Chrome 38 Symbol has incorrect toString conversion
  // `get-own-property-symbols` polyfill symbols converted to object are not Symbol instances
  // nb: Do not call `String` directly to avoid this being optimized out to `symbol+''` which will,
  // of course, fail.
  return !$String(symbol) || !(Object(symbol) instanceof Symbol) ||
  // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
  !Symbol.sham && V8_VERSION && V8_VERSION < 41;
});

/***/ }),

/***/ 4320:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var apply = __webpack_require__(3178);
var bind = __webpack_require__(2038);
var isCallable = __webpack_require__(8173);
var hasOwn = __webpack_require__(1551);
var fails = __webpack_require__(8462);
var html = __webpack_require__(2241);
var arraySlice = __webpack_require__(7706);
var createElement = __webpack_require__(4446);
var validateArgumentsLength = __webpack_require__(4315);
var IS_IOS = __webpack_require__(9823);
var IS_NODE = __webpack_require__(2409);
var set = globalThis.setImmediate;
var clear = globalThis.clearImmediate;
var process = globalThis.process;
var Dispatch = globalThis.Dispatch;
var Function = globalThis.Function;
var MessageChannel = globalThis.MessageChannel;
var String = globalThis.String;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = 'onreadystatechange';
var $location, defer, channel, port;
fails(function () {
  // Deno throws a ReferenceError on `location` access without `--location` flag
  $location = globalThis.location;
});
var run = function (id) {
  if (hasOwn(queue, id)) {
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var runner = function (id) {
  return function () {
    run(id);
  };
};
var eventListener = function (event) {
  run(event.data);
};
var globalPostMessageDefer = function (id) {
  // old engines have not location.origin
  globalThis.postMessage(String(id), $location.protocol + '//' + $location.host);
};

// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if (!set || !clear) {
  set = function setImmediate(handler) {
    validateArgumentsLength(arguments.length, 1);
    var fn = isCallable(handler) ? handler : Function(handler);
    var args = arraySlice(arguments, 1);
    queue[++counter] = function () {
      apply(fn, undefined, args);
    };
    defer(counter);
    return counter;
  };
  clear = function clearImmediate(id) {
    delete queue[id];
  };
  // Node.js 0.8-
  if (IS_NODE) {
    defer = function (id) {
      process.nextTick(runner(id));
    };
    // Sphere (JS game engine) Dispatch API
  } else if (Dispatch && Dispatch.now) {
    defer = function (id) {
      Dispatch.now(runner(id));
    };
    // Browsers with MessageChannel, includes WebWorkers
    // except iOS - https://github.com/zloirock/core-js/issues/624
  } else if (MessageChannel && !IS_IOS) {
    channel = new MessageChannel();
    port = channel.port2;
    channel.port1.onmessage = eventListener;
    defer = bind(port.postMessage, port);
    // Browsers with postMessage, skip WebWorkers
    // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if (globalThis.addEventListener && isCallable(globalThis.postMessage) && !globalThis.importScripts && $location && $location.protocol !== 'file:' && !fails(globalPostMessageDefer)) {
    defer = globalPostMessageDefer;
    globalThis.addEventListener('message', eventListener, false);
    // IE8-
  } else if (ONREADYSTATECHANGE in createElement('script')) {
    defer = function (id) {
      html.appendChild(createElement('script'))[ONREADYSTATECHANGE] = function () {
        html.removeChild(this);
        run(id);
      };
    };
    // Rest old browsers
  } else {
    defer = function (id) {
      setTimeout(runner(id), 0);
    };
  }
}
module.exports = {
  set: set,
  clear: clear
};

/***/ }),

/***/ 3663:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toIntegerOrInfinity = __webpack_require__(6521);
var max = Math.max;
var min = Math.min;

// Helper for a popular repeating case of the spec:
// Let integer be ? ToInteger(index).
// If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
module.exports = function (index, length) {
  var integer = toIntegerOrInfinity(index);
  return integer < 0 ? max(integer + length, 0) : min(integer, length);
};

/***/ }),

/***/ 3442:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toPrimitive = __webpack_require__(5124);
var $TypeError = TypeError;

// `ToBigInt` abstract operation
// https://tc39.es/ecma262/#sec-tobigint
module.exports = function (argument) {
  var prim = toPrimitive(argument, 'number');
  if (typeof prim == 'number') throw new $TypeError("Can't convert number to bigint");
  // eslint-disable-next-line es/no-bigint -- safe
  return BigInt(prim);
};

/***/ }),

/***/ 8632:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// toObject with fallback for non-array-like ES3 strings
var IndexedObject = __webpack_require__(2832);
var requireObjectCoercible = __webpack_require__(170);
module.exports = function (it) {
  return IndexedObject(requireObjectCoercible(it));
};

/***/ }),

/***/ 6521:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var trunc = __webpack_require__(9344);

// `ToIntegerOrInfinity` abstract operation
// https://tc39.es/ecma262/#sec-tointegerorinfinity
module.exports = function (argument) {
  var number = +argument;
  // eslint-disable-next-line no-self-compare -- NaN check
  return number !== number || number === 0 ? 0 : trunc(number);
};

/***/ }),

/***/ 4233:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toIntegerOrInfinity = __webpack_require__(6521);
var min = Math.min;

// `ToLength` abstract operation
// https://tc39.es/ecma262/#sec-tolength
module.exports = function (argument) {
  var len = toIntegerOrInfinity(argument);
  return len > 0 ? min(len, 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
};

/***/ }),

/***/ 3659:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var requireObjectCoercible = __webpack_require__(170);
var $Object = Object;

// `ToObject` abstract operation
// https://tc39.es/ecma262/#sec-toobject
module.exports = function (argument) {
  return $Object(requireObjectCoercible(argument));
};

/***/ }),

/***/ 815:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toPositiveInteger = __webpack_require__(3657);
var $RangeError = RangeError;
module.exports = function (it, BYTES) {
  var offset = toPositiveInteger(it);
  if (offset % BYTES) throw new $RangeError('Wrong offset');
  return offset;
};

/***/ }),

/***/ 3657:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toIntegerOrInfinity = __webpack_require__(6521);
var $RangeError = RangeError;
module.exports = function (it) {
  var result = toIntegerOrInfinity(it);
  if (result < 0) throw new $RangeError("The argument can't be less than 0");
  return result;
};

/***/ }),

/***/ 5124:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(7609);
var isObject = __webpack_require__(9693);
var isSymbol = __webpack_require__(9525);
var getMethod = __webpack_require__(3743);
var ordinaryToPrimitive = __webpack_require__(3613);
var wellKnownSymbol = __webpack_require__(6387);
var $TypeError = TypeError;
var TO_PRIMITIVE = wellKnownSymbol('toPrimitive');

// `ToPrimitive` abstract operation
// https://tc39.es/ecma262/#sec-toprimitive
module.exports = function (input, pref) {
  if (!isObject(input) || isSymbol(input)) return input;
  var exoticToPrim = getMethod(input, TO_PRIMITIVE);
  var result;
  if (exoticToPrim) {
    if (pref === undefined) pref = 'default';
    result = call(exoticToPrim, input, pref);
    if (!isObject(result) || isSymbol(result)) return result;
    throw new $TypeError("Can't convert object to primitive value");
  }
  if (pref === undefined) pref = 'number';
  return ordinaryToPrimitive(input, pref);
};

/***/ }),

/***/ 7445:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toPrimitive = __webpack_require__(5124);
var isSymbol = __webpack_require__(9525);

// `ToPropertyKey` abstract operation
// https://tc39.es/ecma262/#sec-topropertykey
module.exports = function (argument) {
  var key = toPrimitive(argument, 'string');
  return isSymbol(key) ? key : key + '';
};

/***/ }),

/***/ 1326:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var wellKnownSymbol = __webpack_require__(6387);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var test = {};
test[TO_STRING_TAG] = 'z';
module.exports = String(test) === '[object z]';

/***/ }),

/***/ 5774:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var classof = __webpack_require__(1465);
var $String = String;
module.exports = function (argument) {
  if (classof(argument) === 'Symbol') throw new TypeError('Cannot convert a Symbol value to a string');
  return $String(argument);
};

/***/ }),

/***/ 7420:
/***/ ((module) => {

"use strict";


var $String = String;
module.exports = function (argument) {
  try {
    return $String(argument);
  } catch (error) {
    return 'Object';
  }
};

/***/ }),

/***/ 4229:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var uncurryThis = __webpack_require__(3062);
var id = 0;
var postfix = Math.random();
var toString = uncurryThis(1.0.toString);
module.exports = function (key) {
  return 'Symbol(' + (key === undefined ? '' : key) + ')_' + toString(++id + postfix, 36);
};

/***/ }),

/***/ 5363:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


/* eslint-disable es/no-symbol -- required for testing */
var NATIVE_SYMBOL = __webpack_require__(444);
module.exports = NATIVE_SYMBOL && !Symbol.sham && typeof Symbol.iterator == 'symbol';

/***/ }),

/***/ 2552:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var DESCRIPTORS = __webpack_require__(1923);
var fails = __webpack_require__(8462);

// V8 ~ Chrome 36-
// https://bugs.chromium.org/p/v8/issues/detail?id=3334
module.exports = DESCRIPTORS && fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty(function () {/* empty */}, 'prototype', {
    value: 42,
    writable: false
  }).prototype !== 42;
});

/***/ }),

/***/ 4315:
/***/ ((module) => {

"use strict";


var $TypeError = TypeError;
module.exports = function (passed, required) {
  if (passed < required) throw new $TypeError('Not enough arguments');
  return passed;
};

/***/ }),

/***/ 3721:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var isCallable = __webpack_require__(8173);
var WeakMap = globalThis.WeakMap;
module.exports = isCallable(WeakMap) && /native code/.test(String(WeakMap));

/***/ }),

/***/ 6220:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var path = __webpack_require__(3448);
var hasOwn = __webpack_require__(1551);
var wrappedWellKnownSymbolModule = __webpack_require__(294);
var defineProperty = (__webpack_require__(615).f);
module.exports = function (NAME) {
  var Symbol = path.Symbol || (path.Symbol = {});
  if (!hasOwn(Symbol, NAME)) defineProperty(Symbol, NAME, {
    value: wrappedWellKnownSymbolModule.f(NAME)
  });
};

/***/ }),

/***/ 294:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


var wellKnownSymbol = __webpack_require__(6387);
exports.f = wellKnownSymbol;

/***/ }),

/***/ 6387:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var shared = __webpack_require__(6231);
var hasOwn = __webpack_require__(1551);
var uid = __webpack_require__(4229);
var NATIVE_SYMBOL = __webpack_require__(444);
var USE_SYMBOL_AS_UID = __webpack_require__(5363);
var Symbol = globalThis.Symbol;
var WellKnownSymbolsStore = shared('wks');
var createWellKnownSymbol = USE_SYMBOL_AS_UID ? Symbol['for'] || Symbol : Symbol && Symbol.withoutSetter || uid;
module.exports = function (name) {
  if (!hasOwn(WellKnownSymbolsStore, name)) {
    WellKnownSymbolsStore[name] = NATIVE_SYMBOL && hasOwn(Symbol, name) ? Symbol[name] : createWellKnownSymbol('Symbol.' + name);
  }
  return WellKnownSymbolsStore[name];
};

/***/ }),

/***/ 3649:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var getBuiltIn = __webpack_require__(9406);
var hasOwn = __webpack_require__(1551);
var createNonEnumerableProperty = __webpack_require__(1384);
var isPrototypeOf = __webpack_require__(6730);
var setPrototypeOf = __webpack_require__(5273);
var copyConstructorProperties = __webpack_require__(744);
var proxyAccessor = __webpack_require__(4279);
var inheritIfRequired = __webpack_require__(6339);
var normalizeStringArgument = __webpack_require__(9766);
var installErrorCause = __webpack_require__(6001);
var installErrorStack = __webpack_require__(2519);
var DESCRIPTORS = __webpack_require__(1923);
var IS_PURE = __webpack_require__(4151);
module.exports = function (FULL_NAME, wrapper, FORCED, IS_AGGREGATE_ERROR) {
  var STACK_TRACE_LIMIT = 'stackTraceLimit';
  var OPTIONS_POSITION = IS_AGGREGATE_ERROR ? 2 : 1;
  var path = FULL_NAME.split('.');
  var ERROR_NAME = path[path.length - 1];
  var OriginalError = getBuiltIn.apply(null, path);
  if (!OriginalError) return;
  var OriginalErrorPrototype = OriginalError.prototype;

  // V8 9.3- bug https://bugs.chromium.org/p/v8/issues/detail?id=12006
  if (!IS_PURE && hasOwn(OriginalErrorPrototype, 'cause')) delete OriginalErrorPrototype.cause;
  if (!FORCED) return OriginalError;
  var BaseError = getBuiltIn('Error');
  var WrappedError = wrapper(function (a, b) {
    var message = normalizeStringArgument(IS_AGGREGATE_ERROR ? b : a, undefined);
    var result = IS_AGGREGATE_ERROR ? new OriginalError(a) : new OriginalError();
    if (message !== undefined) createNonEnumerableProperty(result, 'message', message);
    installErrorStack(result, WrappedError, result.stack, 2);
    if (this && isPrototypeOf(OriginalErrorPrototype, this)) inheritIfRequired(result, this, WrappedError);
    if (arguments.length > OPTIONS_POSITION) installErrorCause(result, arguments[OPTIONS_POSITION]);
    return result;
  });
  WrappedError.prototype = OriginalErrorPrototype;
  if (ERROR_NAME !== 'Error') {
    if (setPrototypeOf) setPrototypeOf(WrappedError, BaseError);else copyConstructorProperties(WrappedError, BaseError, {
      name: true
    });
  } else if (DESCRIPTORS && STACK_TRACE_LIMIT in OriginalError) {
    proxyAccessor(WrappedError, OriginalError, STACK_TRACE_LIMIT);
    proxyAccessor(WrappedError, OriginalError, 'prepareStackTrace');
  }
  copyConstructorProperties(WrappedError, OriginalError);
  if (!IS_PURE) try {
    // Safari 13- bug: WebAssembly errors does not have a proper `.name`
    if (OriginalErrorPrototype.name !== ERROR_NAME) {
      createNonEnumerableProperty(OriginalErrorPrototype, 'name', ERROR_NAME);
    }
    OriginalErrorPrototype.constructor = WrappedError;
  } catch (error) {/* empty */}
  return WrappedError;
};

/***/ }),

/***/ 7311:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var getBuiltIn = __webpack_require__(9406);
var apply = __webpack_require__(3178);
var fails = __webpack_require__(8462);
var wrapErrorConstructorWithCause = __webpack_require__(3649);
var AGGREGATE_ERROR = 'AggregateError';
var $AggregateError = getBuiltIn(AGGREGATE_ERROR);
var FORCED = !fails(function () {
  return $AggregateError([1]).errors[0] !== 1;
}) && fails(function () {
  return $AggregateError([1], AGGREGATE_ERROR, {
    cause: 7
  }).cause !== 7;
});

// https://tc39.es/ecma262/#sec-aggregate-error
$({
  global: true,
  constructor: true,
  arity: 2,
  forced: FORCED
}, {
  AggregateError: wrapErrorConstructorWithCause(AGGREGATE_ERROR, function (init) {
    // eslint-disable-next-line no-unused-vars -- required for functions `.length`
    return function AggregateError(errors, message) {
      return apply(init, this, arguments);
    };
  }, FORCED, true)
});

/***/ }),

/***/ 4240:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var toObject = __webpack_require__(3659);
var lengthOfArrayLike = __webpack_require__(9110);
var toIntegerOrInfinity = __webpack_require__(6521);
var addToUnscopables = __webpack_require__(2890);

// `Array.prototype.at` method
// https://tc39.es/ecma262/#sec-array.prototype.at
$({
  target: 'Array',
  proto: true
}, {
  at: function at(index) {
    var O = toObject(this);
    var len = lengthOfArrayLike(O);
    var relativeIndex = toIntegerOrInfinity(index);
    var k = relativeIndex >= 0 ? relativeIndex : len + relativeIndex;
    return k < 0 || k >= len ? undefined : O[k];
  }
});
addToUnscopables('at');

/***/ }),

/***/ 3509:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var $findLastIndex = (__webpack_require__(2008).findLastIndex);
var addToUnscopables = __webpack_require__(2890);

// `Array.prototype.findLastIndex` method
// https://tc39.es/ecma262/#sec-array.prototype.findlastindex
$({
  target: 'Array',
  proto: true
}, {
  findLastIndex: function findLastIndex(callbackfn /* , that = undefined */) {
    return $findLastIndex(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
addToUnscopables('findLastIndex');

/***/ }),

/***/ 7119:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var $findLast = (__webpack_require__(2008).findLast);
var addToUnscopables = __webpack_require__(2890);

// `Array.prototype.findLast` method
// https://tc39.es/ecma262/#sec-array.prototype.findlast
$({
  target: 'Array',
  proto: true
}, {
  findLast: function findLast(callbackfn /* , that = undefined */) {
    return $findLast(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
addToUnscopables('findLast');

/***/ }),

/***/ 2004:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var toObject = __webpack_require__(3659);
var lengthOfArrayLike = __webpack_require__(9110);
var setArrayLength = __webpack_require__(7826);
var doesNotExceedSafeInteger = __webpack_require__(8475);
var fails = __webpack_require__(8462);
var INCORRECT_TO_LENGTH = fails(function () {
  return [].push.call({
    length: 0x100000000
  }, 1) !== 4294967297;
});

// V8 <= 121 and Safari <= 15.4; FF < 23 throws InternalError
// https://bugs.chromium.org/p/v8/issues/detail?id=12681
var properErrorOnNonWritableLength = function () {
  try {
    // eslint-disable-next-line es/no-object-defineproperty -- safe
    Object.defineProperty([], 'length', {
      writable: false
    }).push();
  } catch (error) {
    return error instanceof TypeError;
  }
};
var FORCED = INCORRECT_TO_LENGTH || !properErrorOnNonWritableLength();

// `Array.prototype.push` method
// https://tc39.es/ecma262/#sec-array.prototype.push
$({
  target: 'Array',
  proto: true,
  arity: 1,
  forced: FORCED
}, {
  // eslint-disable-next-line no-unused-vars -- required for `.length`
  push: function push(item) {
    var O = toObject(this);
    var len = lengthOfArrayLike(O);
    var argCount = arguments.length;
    doesNotExceedSafeInteger(len + argCount);
    for (var i = 0; i < argCount; i++) {
      O[len] = arguments[i];
      len++;
    }
    setArrayLength(O, len);
    return len;
  }
});

/***/ }),

/***/ 7855:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var arrayToReversed = __webpack_require__(459);
var toIndexedObject = __webpack_require__(8632);
var addToUnscopables = __webpack_require__(2890);
var $Array = Array;

// `Array.prototype.toReversed` method
// https://tc39.es/ecma262/#sec-array.prototype.toreversed
$({
  target: 'Array',
  proto: true
}, {
  toReversed: function toReversed() {
    return arrayToReversed(toIndexedObject(this), $Array);
  }
});
addToUnscopables('toReversed');

/***/ }),

/***/ 2665:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var uncurryThis = __webpack_require__(3062);
var aCallable = __webpack_require__(8117);
var toIndexedObject = __webpack_require__(8632);
var arrayFromConstructorAndList = __webpack_require__(2239);
var getBuiltInPrototypeMethod = __webpack_require__(8168);
var addToUnscopables = __webpack_require__(2890);
var $Array = Array;
var sort = uncurryThis(getBuiltInPrototypeMethod('Array', 'sort'));

// `Array.prototype.toSorted` method
// https://tc39.es/ecma262/#sec-array.prototype.tosorted
$({
  target: 'Array',
  proto: true
}, {
  toSorted: function toSorted(compareFn) {
    if (compareFn !== undefined) aCallable(compareFn);
    var O = toIndexedObject(this);
    var A = arrayFromConstructorAndList($Array, O);
    return sort(A, compareFn);
  }
});
addToUnscopables('toSorted');

/***/ }),

/***/ 9772:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var addToUnscopables = __webpack_require__(2890);
var doesNotExceedSafeInteger = __webpack_require__(8475);
var lengthOfArrayLike = __webpack_require__(9110);
var toAbsoluteIndex = __webpack_require__(3663);
var toIndexedObject = __webpack_require__(8632);
var toIntegerOrInfinity = __webpack_require__(6521);
var $Array = Array;
var max = Math.max;
var min = Math.min;

// `Array.prototype.toSpliced` method
// https://tc39.es/ecma262/#sec-array.prototype.tospliced
$({
  target: 'Array',
  proto: true
}, {
  toSpliced: function toSpliced(start, deleteCount /* , ...items */) {
    var O = toIndexedObject(this);
    var len = lengthOfArrayLike(O);
    var actualStart = toAbsoluteIndex(start, len);
    var argumentsLength = arguments.length;
    var k = 0;
    var insertCount, actualDeleteCount, newLen, A;
    if (argumentsLength === 0) {
      insertCount = actualDeleteCount = 0;
    } else if (argumentsLength === 1) {
      insertCount = 0;
      actualDeleteCount = len - actualStart;
    } else {
      insertCount = argumentsLength - 2;
      actualDeleteCount = min(max(toIntegerOrInfinity(deleteCount), 0), len - actualStart);
    }
    newLen = doesNotExceedSafeInteger(len + insertCount - actualDeleteCount);
    A = $Array(newLen);
    for (; k < actualStart; k++) A[k] = O[k];
    for (; k < actualStart + insertCount; k++) A[k] = arguments[k - actualStart + 2];
    for (; k < newLen; k++) A[k] = O[k + actualDeleteCount - insertCount];
    return A;
  }
});
addToUnscopables('toSpliced');

/***/ }),

/***/ 8971:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var toObject = __webpack_require__(3659);
var lengthOfArrayLike = __webpack_require__(9110);
var setArrayLength = __webpack_require__(7826);
var deletePropertyOrThrow = __webpack_require__(5588);
var doesNotExceedSafeInteger = __webpack_require__(8475);

// IE8-
var INCORRECT_RESULT = [].unshift(0) !== 1;

// V8 ~ Chrome < 71 and Safari <= 15.4, FF < 23 throws InternalError
var properErrorOnNonWritableLength = function () {
  try {
    // eslint-disable-next-line es/no-object-defineproperty -- safe
    Object.defineProperty([], 'length', {
      writable: false
    }).unshift();
  } catch (error) {
    return error instanceof TypeError;
  }
};
var FORCED = INCORRECT_RESULT || !properErrorOnNonWritableLength();

// `Array.prototype.unshift` method
// https://tc39.es/ecma262/#sec-array.prototype.unshift
$({
  target: 'Array',
  proto: true,
  arity: 1,
  forced: FORCED
}, {
  // eslint-disable-next-line no-unused-vars -- required for `.length`
  unshift: function unshift(item) {
    var O = toObject(this);
    var len = lengthOfArrayLike(O);
    var argCount = arguments.length;
    if (argCount) {
      doesNotExceedSafeInteger(len + argCount);
      var k = len;
      while (k--) {
        var to = k + argCount;
        if (k in O) O[to] = O[k];else deletePropertyOrThrow(O, to);
      }
      for (var j = 0; j < argCount; j++) {
        O[j] = arguments[j];
      }
    }
    return setArrayLength(O, len + argCount);
  }
});

/***/ }),

/***/ 8135:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var arrayWith = __webpack_require__(1403);
var toIndexedObject = __webpack_require__(8632);
var $Array = Array;

// `Array.prototype.with` method
// https://tc39.es/ecma262/#sec-array.prototype.with
$({
  target: 'Array',
  proto: true
}, {
  'with': function (index, value) {
    return arrayWith(toIndexedObject(this), $Array, index, value);
  }
});

/***/ }),

/***/ 1474:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


/* eslint-disable no-unused-vars -- required for functions `.length` */
var $ = __webpack_require__(4395);
var globalThis = __webpack_require__(1848);
var apply = __webpack_require__(3178);
var wrapErrorConstructorWithCause = __webpack_require__(3649);
var WEB_ASSEMBLY = 'WebAssembly';
var WebAssembly = globalThis[WEB_ASSEMBLY];

// eslint-disable-next-line es/no-error-cause -- feature detection
var FORCED = new Error('e', {
  cause: 7
}).cause !== 7;
var exportGlobalErrorCauseWrapper = function (ERROR_NAME, wrapper) {
  var O = {};
  O[ERROR_NAME] = wrapErrorConstructorWithCause(ERROR_NAME, wrapper, FORCED);
  $({
    global: true,
    constructor: true,
    arity: 1,
    forced: FORCED
  }, O);
};
var exportWebAssemblyErrorCauseWrapper = function (ERROR_NAME, wrapper) {
  if (WebAssembly && WebAssembly[ERROR_NAME]) {
    var O = {};
    O[ERROR_NAME] = wrapErrorConstructorWithCause(WEB_ASSEMBLY + '.' + ERROR_NAME, wrapper, FORCED);
    $({
      target: WEB_ASSEMBLY,
      stat: true,
      constructor: true,
      arity: 1,
      forced: FORCED
    }, O);
  }
};

// https://tc39.es/ecma262/#sec-nativeerror
exportGlobalErrorCauseWrapper('Error', function (init) {
  return function Error(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('EvalError', function (init) {
  return function EvalError(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('RangeError', function (init) {
  return function RangeError(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('ReferenceError', function (init) {
  return function ReferenceError(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('SyntaxError', function (init) {
  return function SyntaxError(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('TypeError', function (init) {
  return function TypeError(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('URIError', function (init) {
  return function URIError(message) {
    return apply(init, this, arguments);
  };
});
exportWebAssemblyErrorCauseWrapper('CompileError', function (init) {
  return function CompileError(message) {
    return apply(init, this, arguments);
  };
});
exportWebAssemblyErrorCauseWrapper('LinkError', function (init) {
  return function LinkError(message) {
    return apply(init, this, arguments);
  };
});
exportWebAssemblyErrorCauseWrapper('RuntimeError', function (init) {
  return function RuntimeError(message) {
    return apply(init, this, arguments);
  };
});

/***/ }),

/***/ 8140:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var hasOwn = __webpack_require__(1551);

// `Object.hasOwn` method
// https://tc39.es/ecma262/#sec-object.hasown
$({
  target: 'Object',
  stat: true
}, {
  hasOwn: hasOwn
});

/***/ }),

/***/ 5164:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var newPromiseCapabilityModule = __webpack_require__(8326);
var perform = __webpack_require__(1689);
var iterate = __webpack_require__(2201);
var PROMISE_STATICS_INCORRECT_ITERATION = __webpack_require__(7019);

// `Promise.allSettled` method
// https://tc39.es/ecma262/#sec-promise.allsettled
$({
  target: 'Promise',
  stat: true,
  forced: PROMISE_STATICS_INCORRECT_ITERATION
}, {
  allSettled: function allSettled(iterable) {
    var C = this;
    var capability = newPromiseCapabilityModule.f(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var promiseResolve = aCallable(C.resolve);
      var values = [];
      var counter = 0;
      var remaining = 1;
      iterate(iterable, function (promise) {
        var index = counter++;
        var alreadyCalled = false;
        remaining++;
        call(promiseResolve, C, promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[index] = {
            status: 'fulfilled',
            value: value
          };
          --remaining || resolve(values);
        }, function (error) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[index] = {
            status: 'rejected',
            reason: error
          };
          --remaining || resolve(values);
        });
      });
      --remaining || resolve(values);
    });
    if (result.error) reject(result.value);
    return capability.promise;
  }
});

/***/ }),

/***/ 4125:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var newPromiseCapabilityModule = __webpack_require__(8326);
var perform = __webpack_require__(1689);
var iterate = __webpack_require__(2201);
var PROMISE_STATICS_INCORRECT_ITERATION = __webpack_require__(7019);

// `Promise.all` method
// https://tc39.es/ecma262/#sec-promise.all
$({
  target: 'Promise',
  stat: true,
  forced: PROMISE_STATICS_INCORRECT_ITERATION
}, {
  all: function all(iterable) {
    var C = this;
    var capability = newPromiseCapabilityModule.f(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var $promiseResolve = aCallable(C.resolve);
      var values = [];
      var counter = 0;
      var remaining = 1;
      iterate(iterable, function (promise) {
        var index = counter++;
        var alreadyCalled = false;
        remaining++;
        call($promiseResolve, C, promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if (result.error) reject(result.value);
    return capability.promise;
  }
});

/***/ }),

/***/ 6406:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var getBuiltIn = __webpack_require__(9406);
var newPromiseCapabilityModule = __webpack_require__(8326);
var perform = __webpack_require__(1689);
var iterate = __webpack_require__(2201);
var PROMISE_STATICS_INCORRECT_ITERATION = __webpack_require__(7019);
var PROMISE_ANY_ERROR = 'No one promise resolved';

// `Promise.any` method
// https://tc39.es/ecma262/#sec-promise.any
$({
  target: 'Promise',
  stat: true,
  forced: PROMISE_STATICS_INCORRECT_ITERATION
}, {
  any: function any(iterable) {
    var C = this;
    var AggregateError = getBuiltIn('AggregateError');
    var capability = newPromiseCapabilityModule.f(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var promiseResolve = aCallable(C.resolve);
      var errors = [];
      var counter = 0;
      var remaining = 1;
      var alreadyResolved = false;
      iterate(iterable, function (promise) {
        var index = counter++;
        var alreadyRejected = false;
        remaining++;
        call(promiseResolve, C, promise).then(function (value) {
          if (alreadyRejected || alreadyResolved) return;
          alreadyResolved = true;
          resolve(value);
        }, function (error) {
          if (alreadyRejected || alreadyResolved) return;
          alreadyRejected = true;
          errors[index] = error;
          --remaining || reject(new AggregateError(errors, PROMISE_ANY_ERROR));
        });
      });
      --remaining || reject(new AggregateError(errors, PROMISE_ANY_ERROR));
    });
    if (result.error) reject(result.value);
    return capability.promise;
  }
});

/***/ }),

/***/ 8525:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var IS_PURE = __webpack_require__(4151);
var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(1495).CONSTRUCTOR);
var NativePromiseConstructor = __webpack_require__(4243);
var getBuiltIn = __webpack_require__(9406);
var isCallable = __webpack_require__(8173);
var defineBuiltIn = __webpack_require__(5953);
var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;

// `Promise.prototype.catch` method
// https://tc39.es/ecma262/#sec-promise.prototype.catch
$({
  target: 'Promise',
  proto: true,
  forced: FORCED_PROMISE_CONSTRUCTOR,
  real: true
}, {
  'catch': function (onRejected) {
    return this.then(undefined, onRejected);
  }
});

// makes sure that native promise-based APIs `Promise#catch` properly works with patched `Promise#then`
if (!IS_PURE && isCallable(NativePromiseConstructor)) {
  var method = getBuiltIn('Promise').prototype['catch'];
  if (NativePromisePrototype['catch'] !== method) {
    defineBuiltIn(NativePromisePrototype, 'catch', method, {
      unsafe: true
    });
  }
}

/***/ }),

/***/ 1382:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var IS_PURE = __webpack_require__(4151);
var IS_NODE = __webpack_require__(2409);
var globalThis = __webpack_require__(1848);
var call = __webpack_require__(7609);
var defineBuiltIn = __webpack_require__(5953);
var setPrototypeOf = __webpack_require__(5273);
var setToStringTag = __webpack_require__(6988);
var setSpecies = __webpack_require__(5539);
var aCallable = __webpack_require__(8117);
var isCallable = __webpack_require__(8173);
var isObject = __webpack_require__(9693);
var anInstance = __webpack_require__(1747);
var speciesConstructor = __webpack_require__(9675);
var task = (__webpack_require__(4320).set);
var microtask = __webpack_require__(5684);
var hostReportErrors = __webpack_require__(2157);
var perform = __webpack_require__(1689);
var Queue = __webpack_require__(5141);
var InternalStateModule = __webpack_require__(2417);
var NativePromiseConstructor = __webpack_require__(4243);
var PromiseConstructorDetection = __webpack_require__(1495);
var newPromiseCapabilityModule = __webpack_require__(8326);
var PROMISE = 'Promise';
var FORCED_PROMISE_CONSTRUCTOR = PromiseConstructorDetection.CONSTRUCTOR;
var NATIVE_PROMISE_REJECTION_EVENT = PromiseConstructorDetection.REJECTION_EVENT;
var NATIVE_PROMISE_SUBCLASSING = PromiseConstructorDetection.SUBCLASSING;
var getInternalPromiseState = InternalStateModule.getterFor(PROMISE);
var setInternalState = InternalStateModule.set;
var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;
var PromiseConstructor = NativePromiseConstructor;
var PromisePrototype = NativePromisePrototype;
var TypeError = globalThis.TypeError;
var document = globalThis.document;
var process = globalThis.process;
var newPromiseCapability = newPromiseCapabilityModule.f;
var newGenericPromiseCapability = newPromiseCapability;
var DISPATCH_EVENT = !!(document && document.createEvent && globalThis.dispatchEvent);
var UNHANDLED_REJECTION = 'unhandledrejection';
var REJECTION_HANDLED = 'rejectionhandled';
var PENDING = 0;
var FULFILLED = 1;
var REJECTED = 2;
var HANDLED = 1;
var UNHANDLED = 2;
var Internal, OwnPromiseCapability, PromiseWrapper, nativeThen;

// helpers
var isThenable = function (it) {
  var then;
  return isObject(it) && isCallable(then = it.then) ? then : false;
};
var callReaction = function (reaction, state) {
  var value = state.value;
  var ok = state.state === FULFILLED;
  var handler = ok ? reaction.ok : reaction.fail;
  var resolve = reaction.resolve;
  var reject = reaction.reject;
  var domain = reaction.domain;
  var result, then, exited;
  try {
    if (handler) {
      if (!ok) {
        if (state.rejection === UNHANDLED) onHandleUnhandled(state);
        state.rejection = HANDLED;
      }
      if (handler === true) result = value;else {
        if (domain) domain.enter();
        result = handler(value); // can throw
        if (domain) {
          domain.exit();
          exited = true;
        }
      }
      if (result === reaction.promise) {
        reject(new TypeError('Promise-chain cycle'));
      } else if (then = isThenable(result)) {
        call(then, result, resolve, reject);
      } else resolve(result);
    } else reject(value);
  } catch (error) {
    if (domain && !exited) domain.exit();
    reject(error);
  }
};
var notify = function (state, isReject) {
  if (state.notified) return;
  state.notified = true;
  microtask(function () {
    var reactions = state.reactions;
    var reaction;
    while (reaction = reactions.get()) {
      callReaction(reaction, state);
    }
    state.notified = false;
    if (isReject && !state.rejection) onUnhandled(state);
  });
};
var dispatchEvent = function (name, promise, reason) {
  var event, handler;
  if (DISPATCH_EVENT) {
    event = document.createEvent('Event');
    event.promise = promise;
    event.reason = reason;
    event.initEvent(name, false, true);
    globalThis.dispatchEvent(event);
  } else event = {
    promise: promise,
    reason: reason
  };
  if (!NATIVE_PROMISE_REJECTION_EVENT && (handler = globalThis['on' + name])) handler(event);else if (name === UNHANDLED_REJECTION) hostReportErrors('Unhandled promise rejection', reason);
};
var onUnhandled = function (state) {
  call(task, globalThis, function () {
    var promise = state.facade;
    var value = state.value;
    var IS_UNHANDLED = isUnhandled(state);
    var result;
    if (IS_UNHANDLED) {
      result = perform(function () {
        if (IS_NODE) {
          process.emit('unhandledRejection', value, promise);
        } else dispatchEvent(UNHANDLED_REJECTION, promise, value);
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      state.rejection = IS_NODE || isUnhandled(state) ? UNHANDLED : HANDLED;
      if (result.error) throw result.value;
    }
  });
};
var isUnhandled = function (state) {
  return state.rejection !== HANDLED && !state.parent;
};
var onHandleUnhandled = function (state) {
  call(task, globalThis, function () {
    var promise = state.facade;
    if (IS_NODE) {
      process.emit('rejectionHandled', promise);
    } else dispatchEvent(REJECTION_HANDLED, promise, state.value);
  });
};
var bind = function (fn, state, unwrap) {
  return function (value) {
    fn(state, value, unwrap);
  };
};
var internalReject = function (state, value, unwrap) {
  if (state.done) return;
  state.done = true;
  if (unwrap) state = unwrap;
  state.value = value;
  state.state = REJECTED;
  notify(state, true);
};
var internalResolve = function (state, value, unwrap) {
  if (state.done) return;
  state.done = true;
  if (unwrap) state = unwrap;
  try {
    if (state.facade === value) throw new TypeError("Promise can't be resolved itself");
    var then = isThenable(value);
    if (then) {
      microtask(function () {
        var wrapper = {
          done: false
        };
        try {
          call(then, value, bind(internalResolve, wrapper, state), bind(internalReject, wrapper, state));
        } catch (error) {
          internalReject(wrapper, error, state);
        }
      });
    } else {
      state.value = value;
      state.state = FULFILLED;
      notify(state, false);
    }
  } catch (error) {
    internalReject({
      done: false
    }, error, state);
  }
};

// constructor polyfill
if (FORCED_PROMISE_CONSTRUCTOR) {
  // 25.4.3.1 Promise(executor)
  PromiseConstructor = function Promise(executor) {
    anInstance(this, PromisePrototype);
    aCallable(executor);
    call(Internal, this);
    var state = getInternalPromiseState(this);
    try {
      executor(bind(internalResolve, state), bind(internalReject, state));
    } catch (error) {
      internalReject(state, error);
    }
  };
  PromisePrototype = PromiseConstructor.prototype;

  // eslint-disable-next-line no-unused-vars -- required for `.length`
  Internal = function Promise(executor) {
    setInternalState(this, {
      type: PROMISE,
      done: false,
      notified: false,
      parent: false,
      reactions: new Queue(),
      rejection: false,
      state: PENDING,
      value: null
    });
  };

  // `Promise.prototype.then` method
  // https://tc39.es/ecma262/#sec-promise.prototype.then
  Internal.prototype = defineBuiltIn(PromisePrototype, 'then', function then(onFulfilled, onRejected) {
    var state = getInternalPromiseState(this);
    var reaction = newPromiseCapability(speciesConstructor(this, PromiseConstructor));
    state.parent = true;
    reaction.ok = isCallable(onFulfilled) ? onFulfilled : true;
    reaction.fail = isCallable(onRejected) && onRejected;
    reaction.domain = IS_NODE ? process.domain : undefined;
    if (state.state === PENDING) state.reactions.add(reaction);else microtask(function () {
      callReaction(reaction, state);
    });
    return reaction.promise;
  });
  OwnPromiseCapability = function () {
    var promise = new Internal();
    var state = getInternalPromiseState(promise);
    this.promise = promise;
    this.resolve = bind(internalResolve, state);
    this.reject = bind(internalReject, state);
  };
  newPromiseCapabilityModule.f = newPromiseCapability = function (C) {
    return C === PromiseConstructor || C === PromiseWrapper ? new OwnPromiseCapability(C) : newGenericPromiseCapability(C);
  };
  if (!IS_PURE && isCallable(NativePromiseConstructor) && NativePromisePrototype !== Object.prototype) {
    nativeThen = NativePromisePrototype.then;
    if (!NATIVE_PROMISE_SUBCLASSING) {
      // make `Promise#then` return a polyfilled `Promise` for native promise-based APIs
      defineBuiltIn(NativePromisePrototype, 'then', function then(onFulfilled, onRejected) {
        var that = this;
        return new PromiseConstructor(function (resolve, reject) {
          call(nativeThen, that, resolve, reject);
        }).then(onFulfilled, onRejected);
        // https://github.com/zloirock/core-js/issues/640
      }, {
        unsafe: true
      });
    }

    // make `.constructor === Promise` work for native promise-based APIs
    try {
      delete NativePromisePrototype.constructor;
    } catch (error) {/* empty */}

    // make `instanceof Promise` work for native promise-based APIs
    if (setPrototypeOf) {
      setPrototypeOf(NativePromisePrototype, PromisePrototype);
    }
  }
}
$({
  global: true,
  constructor: true,
  wrap: true,
  forced: FORCED_PROMISE_CONSTRUCTOR
}, {
  Promise: PromiseConstructor
});
setToStringTag(PromiseConstructor, PROMISE, false, true);
setSpecies(PROMISE);

/***/ }),

/***/ 1410:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var IS_PURE = __webpack_require__(4151);
var NativePromiseConstructor = __webpack_require__(4243);
var fails = __webpack_require__(8462);
var getBuiltIn = __webpack_require__(9406);
var isCallable = __webpack_require__(8173);
var speciesConstructor = __webpack_require__(9675);
var promiseResolve = __webpack_require__(1128);
var defineBuiltIn = __webpack_require__(5953);
var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;

// Safari bug https://bugs.webkit.org/show_bug.cgi?id=200829
var NON_GENERIC = !!NativePromiseConstructor && fails(function () {
  // eslint-disable-next-line unicorn/no-thenable -- required for testing
  NativePromisePrototype['finally'].call({
    then: function () {/* empty */}
  }, function () {/* empty */});
});

// `Promise.prototype.finally` method
// https://tc39.es/ecma262/#sec-promise.prototype.finally
$({
  target: 'Promise',
  proto: true,
  real: true,
  forced: NON_GENERIC
}, {
  'finally': function (onFinally) {
    var C = speciesConstructor(this, getBuiltIn('Promise'));
    var isFunction = isCallable(onFinally);
    return this.then(isFunction ? function (x) {
      return promiseResolve(C, onFinally()).then(function () {
        return x;
      });
    } : onFinally, isFunction ? function (e) {
      return promiseResolve(C, onFinally()).then(function () {
        throw e;
      });
    } : onFinally);
  }
});

// makes sure that native promise-based APIs `Promise#finally` properly works with patched `Promise#then`
if (!IS_PURE && isCallable(NativePromiseConstructor)) {
  var method = getBuiltIn('Promise').prototype['finally'];
  if (NativePromisePrototype['finally'] !== method) {
    defineBuiltIn(NativePromisePrototype, 'finally', method, {
      unsafe: true
    });
  }
}

/***/ }),

/***/ 7788:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove this module from `core-js@4` since it's split to modules listed below
__webpack_require__(1382);
__webpack_require__(4125);
__webpack_require__(8525);
__webpack_require__(4832);
__webpack_require__(1050);
__webpack_require__(2529);

/***/ }),

/***/ 4832:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var newPromiseCapabilityModule = __webpack_require__(8326);
var perform = __webpack_require__(1689);
var iterate = __webpack_require__(2201);
var PROMISE_STATICS_INCORRECT_ITERATION = __webpack_require__(7019);

// `Promise.race` method
// https://tc39.es/ecma262/#sec-promise.race
$({
  target: 'Promise',
  stat: true,
  forced: PROMISE_STATICS_INCORRECT_ITERATION
}, {
  race: function race(iterable) {
    var C = this;
    var capability = newPromiseCapabilityModule.f(C);
    var reject = capability.reject;
    var result = perform(function () {
      var $promiseResolve = aCallable(C.resolve);
      iterate(iterable, function (promise) {
        call($promiseResolve, C, promise).then(capability.resolve, reject);
      });
    });
    if (result.error) reject(result.value);
    return capability.promise;
  }
});

/***/ }),

/***/ 1050:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var newPromiseCapabilityModule = __webpack_require__(8326);
var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(1495).CONSTRUCTOR);

// `Promise.reject` method
// https://tc39.es/ecma262/#sec-promise.reject
$({
  target: 'Promise',
  stat: true,
  forced: FORCED_PROMISE_CONSTRUCTOR
}, {
  reject: function reject(r) {
    var capability = newPromiseCapabilityModule.f(this);
    var capabilityReject = capability.reject;
    capabilityReject(r);
    return capability.promise;
  }
});

/***/ }),

/***/ 2529:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var getBuiltIn = __webpack_require__(9406);
var IS_PURE = __webpack_require__(4151);
var NativePromiseConstructor = __webpack_require__(4243);
var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(1495).CONSTRUCTOR);
var promiseResolve = __webpack_require__(1128);
var PromiseConstructorWrapper = getBuiltIn('Promise');
var CHECK_WRAPPER = IS_PURE && !FORCED_PROMISE_CONSTRUCTOR;

// `Promise.resolve` method
// https://tc39.es/ecma262/#sec-promise.resolve
$({
  target: 'Promise',
  stat: true,
  forced: IS_PURE || FORCED_PROMISE_CONSTRUCTOR
}, {
  resolve: function resolve(x) {
    return promiseResolve(CHECK_WRAPPER && this === PromiseConstructorWrapper ? NativePromiseConstructor : this, x);
  }
});

/***/ }),

/***/ 7638:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var DESCRIPTORS = __webpack_require__(1923);
var defineBuiltInAccessor = __webpack_require__(6248);
var regExpFlags = __webpack_require__(7834);
var fails = __webpack_require__(8462);

// babel-minify and Closure Compiler transpiles RegExp('.', 'd') -> /./d and it causes SyntaxError
var RegExp = globalThis.RegExp;
var RegExpPrototype = RegExp.prototype;
var FORCED = DESCRIPTORS && fails(function () {
  var INDICES_SUPPORT = true;
  try {
    RegExp('.', 'd');
  } catch (error) {
    INDICES_SUPPORT = false;
  }
  var O = {};
  // modern V8 bug
  var calls = '';
  var expected = INDICES_SUPPORT ? 'dgimsy' : 'gimsy';
  var addGetter = function (key, chr) {
    // eslint-disable-next-line es/no-object-defineproperty -- safe
    Object.defineProperty(O, key, {
      get: function () {
        calls += chr;
        return true;
      }
    });
  };
  var pairs = {
    dotAll: 's',
    global: 'g',
    ignoreCase: 'i',
    multiline: 'm',
    sticky: 'y'
  };
  if (INDICES_SUPPORT) pairs.hasIndices = 'd';
  for (var key in pairs) addGetter(key, pairs[key]);

  // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
  var result = Object.getOwnPropertyDescriptor(RegExpPrototype, 'flags').get.call(O);
  return result !== expected || calls !== expected;
});

// `RegExp.prototype.flags` getter
// https://tc39.es/ecma262/#sec-get-regexp.prototype.flags
if (FORCED) defineBuiltInAccessor(RegExpPrototype, 'flags', {
  configurable: true,
  get: regExpFlags
});

/***/ }),

/***/ 9983:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var difference = __webpack_require__(9864);
var setMethodAcceptSetLike = __webpack_require__(4435);

// `Set.prototype.difference` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('difference')
}, {
  difference: difference
});

/***/ }),

/***/ 6276:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var fails = __webpack_require__(8462);
var intersection = __webpack_require__(374);
var setMethodAcceptSetLike = __webpack_require__(4435);
var INCORRECT = !setMethodAcceptSetLike('intersection') || fails(function () {
  // eslint-disable-next-line es/no-array-from, es/no-set -- testing
  return String(Array.from(new Set([1, 2, 3]).intersection(new Set([3, 2])))) !== '3,2';
});

// `Set.prototype.intersection` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: INCORRECT
}, {
  intersection: intersection
});

/***/ }),

/***/ 9297:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var isDisjointFrom = __webpack_require__(7735);
var setMethodAcceptSetLike = __webpack_require__(4435);

// `Set.prototype.isDisjointFrom` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('isDisjointFrom')
}, {
  isDisjointFrom: isDisjointFrom
});

/***/ }),

/***/ 6816:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var isSubsetOf = __webpack_require__(6274);
var setMethodAcceptSetLike = __webpack_require__(4435);

// `Set.prototype.isSubsetOf` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('isSubsetOf')
}, {
  isSubsetOf: isSubsetOf
});

/***/ }),

/***/ 6756:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var isSupersetOf = __webpack_require__(9749);
var setMethodAcceptSetLike = __webpack_require__(4435);

// `Set.prototype.isSupersetOf` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('isSupersetOf')
}, {
  isSupersetOf: isSupersetOf
});

/***/ }),

/***/ 960:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var symmetricDifference = __webpack_require__(3285);
var setMethodAcceptSetLike = __webpack_require__(4435);

// `Set.prototype.symmetricDifference` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('symmetricDifference')
}, {
  symmetricDifference: symmetricDifference
});

/***/ }),

/***/ 9301:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var union = __webpack_require__(2394);
var setMethodAcceptSetLike = __webpack_require__(4435);

// `Set.prototype.union` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('union')
}, {
  union: union
});

/***/ }),

/***/ 6303:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var uncurryThis = __webpack_require__(3062);
var requireObjectCoercible = __webpack_require__(170);
var toIntegerOrInfinity = __webpack_require__(6521);
var toString = __webpack_require__(5774);
var fails = __webpack_require__(8462);
var charAt = uncurryThis(''.charAt);
var FORCED = fails(function () {
  // eslint-disable-next-line es/no-string-prototype-at -- safe
  return '𠮷'.at(-2) !== '\uD842';
});

// `String.prototype.at` method
// https://tc39.es/ecma262/#sec-string.prototype.at
$({
  target: 'String',
  proto: true,
  forced: FORCED
}, {
  at: function at(index) {
    var S = toString(requireObjectCoercible(this));
    var len = S.length;
    var relativeIndex = toIntegerOrInfinity(index);
    var k = relativeIndex >= 0 ? relativeIndex : len + relativeIndex;
    return k < 0 || k >= len ? undefined : charAt(S, k);
  }
});

/***/ }),

/***/ 1516:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var uncurryThis = __webpack_require__(3062);
var requireObjectCoercible = __webpack_require__(170);
var toString = __webpack_require__(5774);
var charCodeAt = uncurryThis(''.charCodeAt);

// `String.prototype.isWellFormed` method
// https://github.com/tc39/proposal-is-usv-string
$({
  target: 'String',
  proto: true
}, {
  isWellFormed: function isWellFormed() {
    var S = toString(requireObjectCoercible(this));
    var length = S.length;
    for (var i = 0; i < length; i++) {
      var charCode = charCodeAt(S, i);
      // single UTF-16 code unit
      if ((charCode & 0xF800) !== 0xD800) continue;
      // unpaired surrogate
      if (charCode >= 0xDC00 || ++i >= length || (charCodeAt(S, i) & 0xFC00) !== 0xDC00) return false;
    }
    return true;
  }
});

/***/ }),

/***/ 705:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var uncurryThis = __webpack_require__(3062);
var requireObjectCoercible = __webpack_require__(170);
var toString = __webpack_require__(5774);
var fails = __webpack_require__(8462);
var $Array = Array;
var charAt = uncurryThis(''.charAt);
var charCodeAt = uncurryThis(''.charCodeAt);
var join = uncurryThis([].join);
// eslint-disable-next-line es/no-string-prototype-towellformed -- safe
var $toWellFormed = ''.toWellFormed;
var REPLACEMENT_CHARACTER = '\uFFFD';

// Safari bug
var TO_STRING_CONVERSION_BUG = $toWellFormed && fails(function () {
  return call($toWellFormed, 1) !== '1';
});

// `String.prototype.toWellFormed` method
// https://github.com/tc39/proposal-is-usv-string
$({
  target: 'String',
  proto: true,
  forced: TO_STRING_CONVERSION_BUG
}, {
  toWellFormed: function toWellFormed() {
    var S = toString(requireObjectCoercible(this));
    if (TO_STRING_CONVERSION_BUG) return call($toWellFormed, S);
    var length = S.length;
    var result = $Array(length);
    for (var i = 0; i < length; i++) {
      var charCode = charCodeAt(S, i);
      // single UTF-16 code unit
      if ((charCode & 0xF800) !== 0xD800) result[i] = charAt(S, i);
      // unpaired surrogate
      else if (charCode >= 0xDC00 || i + 1 >= length || (charCodeAt(S, i + 1) & 0xFC00) !== 0xDC00) result[i] = REPLACEMENT_CHARACTER;
      // surrogate pair
      else {
        result[i] = charAt(S, i);
        result[++i] = charAt(S, i);
      }
    }
    return join(result, '');
  }
});

/***/ }),

/***/ 1825:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ArrayBufferViewCore = __webpack_require__(1759);
var lengthOfArrayLike = __webpack_require__(9110);
var toIntegerOrInfinity = __webpack_require__(6521);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;

// `%TypedArray%.prototype.at` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.at
exportTypedArrayMethod('at', function at(index) {
  var O = aTypedArray(this);
  var len = lengthOfArrayLike(O);
  var relativeIndex = toIntegerOrInfinity(index);
  var k = relativeIndex >= 0 ? relativeIndex : len + relativeIndex;
  return k < 0 || k >= len ? undefined : O[k];
});

/***/ }),

/***/ 2220:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ArrayBufferViewCore = __webpack_require__(1759);
var $fill = __webpack_require__(1180);
var toBigInt = __webpack_require__(3442);
var classof = __webpack_require__(1465);
var call = __webpack_require__(7609);
var uncurryThis = __webpack_require__(3062);
var fails = __webpack_require__(8462);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var slice = uncurryThis(''.slice);

// V8 ~ Chrome < 59, Safari < 14.1, FF < 55, Edge <=18
var CONVERSION_BUG = fails(function () {
  var count = 0;
  // eslint-disable-next-line es/no-typed-arrays -- safe
  new Int8Array(2).fill({
    valueOf: function () {
      return count++;
    }
  });
  return count !== 1;
});

// `%TypedArray%.prototype.fill` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.fill
exportTypedArrayMethod('fill', function fill(value /* , start, end */) {
  var length = arguments.length;
  aTypedArray(this);
  var actualValue = slice(classof(this), 0, 3) === 'Big' ? toBigInt(value) : +value;
  return call($fill, this, actualValue, length > 1 ? arguments[1] : undefined, length > 2 ? arguments[2] : undefined);
}, CONVERSION_BUG);

/***/ }),

/***/ 4774:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ArrayBufferViewCore = __webpack_require__(1759);
var $findLastIndex = (__webpack_require__(2008).findLastIndex);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;

// `%TypedArray%.prototype.findLastIndex` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.findlastindex
exportTypedArrayMethod('findLastIndex', function findLastIndex(predicate /* , thisArg */) {
  return $findLastIndex(aTypedArray(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
});

/***/ }),

/***/ 1519:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ArrayBufferViewCore = __webpack_require__(1759);
var $findLast = (__webpack_require__(2008).findLast);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;

// `%TypedArray%.prototype.findLast` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.findlast
exportTypedArrayMethod('findLast', function findLast(predicate /* , thisArg */) {
  return $findLast(aTypedArray(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
});

/***/ }),

/***/ 1520:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var call = __webpack_require__(7609);
var ArrayBufferViewCore = __webpack_require__(1759);
var lengthOfArrayLike = __webpack_require__(9110);
var toOffset = __webpack_require__(815);
var toIndexedObject = __webpack_require__(3659);
var fails = __webpack_require__(8462);
var RangeError = globalThis.RangeError;
var Int8Array = globalThis.Int8Array;
var Int8ArrayPrototype = Int8Array && Int8Array.prototype;
var $set = Int8ArrayPrototype && Int8ArrayPrototype.set;
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS = !fails(function () {
  // eslint-disable-next-line es/no-typed-arrays -- required for testing
  var array = new Uint8ClampedArray(2);
  call($set, array, {
    length: 1,
    0: 3
  }, 1);
  return array[1] !== 3;
});

// https://bugs.chromium.org/p/v8/issues/detail?id=11294 and other
var TO_OBJECT_BUG = WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS && ArrayBufferViewCore.NATIVE_ARRAY_BUFFER_VIEWS && fails(function () {
  var array = new Int8Array(2);
  array.set(1);
  array.set('2', 1);
  return array[0] !== 0 || array[1] !== 2;
});

// `%TypedArray%.prototype.set` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.set
exportTypedArrayMethod('set', function set(arrayLike /* , offset */) {
  aTypedArray(this);
  var offset = toOffset(arguments.length > 1 ? arguments[1] : undefined, 1);
  var src = toIndexedObject(arrayLike);
  if (WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS) return call($set, this, src, offset);
  var length = this.length;
  var len = lengthOfArrayLike(src);
  var index = 0;
  if (len + offset > length) throw new RangeError('Wrong length');
  while (index < len) this[offset + index] = src[index++];
}, !WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS || TO_OBJECT_BUG);

/***/ }),

/***/ 2663:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var uncurryThis = __webpack_require__(1992);
var fails = __webpack_require__(8462);
var aCallable = __webpack_require__(8117);
var internalSort = __webpack_require__(9070);
var ArrayBufferViewCore = __webpack_require__(1759);
var FF = __webpack_require__(9257);
var IE_OR_EDGE = __webpack_require__(1466);
var V8 = __webpack_require__(9255);
var WEBKIT = __webpack_require__(8560);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var Uint16Array = globalThis.Uint16Array;
var nativeSort = Uint16Array && uncurryThis(Uint16Array.prototype.sort);

// WebKit
var ACCEPT_INCORRECT_ARGUMENTS = !!nativeSort && !(fails(function () {
  nativeSort(new Uint16Array(2), null);
}) && fails(function () {
  nativeSort(new Uint16Array(2), {});
}));
var STABLE_SORT = !!nativeSort && !fails(function () {
  // feature detection can be too slow, so check engines versions
  if (V8) return V8 < 74;
  if (FF) return FF < 67;
  if (IE_OR_EDGE) return true;
  if (WEBKIT) return WEBKIT < 602;
  var array = new Uint16Array(516);
  var expected = Array(516);
  var index, mod;
  for (index = 0; index < 516; index++) {
    mod = index % 4;
    array[index] = 515 - index;
    expected[index] = index - 2 * mod + 3;
  }
  nativeSort(array, function (a, b) {
    return (a / 4 | 0) - (b / 4 | 0);
  });
  for (index = 0; index < 516; index++) {
    if (array[index] !== expected[index]) return true;
  }
});
var getSortCompare = function (comparefn) {
  return function (x, y) {
    if (comparefn !== undefined) return +comparefn(x, y) || 0;
    // eslint-disable-next-line no-self-compare -- NaN check
    if (y !== y) return -1;
    // eslint-disable-next-line no-self-compare -- NaN check
    if (x !== x) return 1;
    if (x === 0 && y === 0) return 1 / x > 0 && 1 / y < 0 ? 1 : -1;
    return x > y;
  };
};

// `%TypedArray%.prototype.sort` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.sort
exportTypedArrayMethod('sort', function sort(comparefn) {
  if (comparefn !== undefined) aCallable(comparefn);
  if (STABLE_SORT) return nativeSort(this, comparefn);
  return internalSort(aTypedArray(this), getSortCompare(comparefn));
}, !STABLE_SORT || ACCEPT_INCORRECT_ARGUMENTS);

/***/ }),

/***/ 8348:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var arrayToReversed = __webpack_require__(459);
var ArrayBufferViewCore = __webpack_require__(1759);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var getTypedArrayConstructor = ArrayBufferViewCore.getTypedArrayConstructor;

// `%TypedArray%.prototype.toReversed` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.toreversed
exportTypedArrayMethod('toReversed', function toReversed() {
  return arrayToReversed(aTypedArray(this), getTypedArrayConstructor(this));
});

/***/ }),

/***/ 3457:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ArrayBufferViewCore = __webpack_require__(1759);
var uncurryThis = __webpack_require__(3062);
var aCallable = __webpack_require__(8117);
var arrayFromConstructorAndList = __webpack_require__(2239);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var getTypedArrayConstructor = ArrayBufferViewCore.getTypedArrayConstructor;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var sort = uncurryThis(ArrayBufferViewCore.TypedArrayPrototype.sort);

// `%TypedArray%.prototype.toSorted` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.tosorted
exportTypedArrayMethod('toSorted', function toSorted(compareFn) {
  if (compareFn !== undefined) aCallable(compareFn);
  var O = aTypedArray(this);
  var A = arrayFromConstructorAndList(getTypedArrayConstructor(O), O);
  return sort(A, compareFn);
});

/***/ }),

/***/ 6939:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var arrayWith = __webpack_require__(1403);
var ArrayBufferViewCore = __webpack_require__(1759);
var isBigIntArray = __webpack_require__(4107);
var toIntegerOrInfinity = __webpack_require__(6521);
var toBigInt = __webpack_require__(3442);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var getTypedArrayConstructor = ArrayBufferViewCore.getTypedArrayConstructor;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var PROPER_ORDER = !!function () {
  try {
    // eslint-disable-next-line no-throw-literal, es/no-typed-arrays, es/no-array-prototype-with -- required for testing
    new Int8Array(1)['with'](2, {
      valueOf: function () {
        throw 8;
      }
    });
  } catch (error) {
    // some early implementations, like WebKit, does not follow the final semantic
    // https://github.com/tc39/proposal-change-array-by-copy/pull/86
    return error === 8;
  }
}();

// `%TypedArray%.prototype.with` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.with
exportTypedArrayMethod('with', {
  'with': function (index, value) {
    var O = aTypedArray(this);
    var relativeIndex = toIntegerOrInfinity(index);
    var actualValue = isBigIntArray(O) ? toBigInt(value) : +value;
    return arrayWith(O, getTypedArrayConstructor(O), relativeIndex, actualValue);
  }
}['with'], !PROPER_ORDER);

/***/ }),

/***/ 5388:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(4240);

/***/ }),

/***/ 1034:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(3509);

/***/ }),

/***/ 5601:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(7119);

/***/ }),

/***/ 5794:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var fromAsync = __webpack_require__(4744);
var fails = __webpack_require__(8462);
var nativeFromAsync = Array.fromAsync;
// https://bugs.webkit.org/show_bug.cgi?id=271703
var INCORRECT_CONSTRUCTURING = !nativeFromAsync || fails(function () {
  var counter = 0;
  nativeFromAsync.call(function () {
    counter++;
    return [];
  }, {
    length: 0
  });
  return counter !== 1;
});

// `Array.fromAsync` method
// https://github.com/tc39/proposal-array-from-async
$({
  target: 'Array',
  stat: true,
  forced: INCORRECT_CONSTRUCTURING
}, {
  fromAsync: fromAsync
});

/***/ }),

/***/ 1772:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
var $ = __webpack_require__(4395);
var arrayMethodIsStrict = __webpack_require__(7816);
var addToUnscopables = __webpack_require__(2890);
var $groupToMap = __webpack_require__(3077);
var IS_PURE = __webpack_require__(4151);

// `Array.prototype.groupByToMap` method
// https://github.com/tc39/proposal-array-grouping
// https://bugs.webkit.org/show_bug.cgi?id=236541
$({
  target: 'Array',
  proto: true,
  name: 'groupToMap',
  forced: IS_PURE || !arrayMethodIsStrict('groupByToMap')
}, {
  groupByToMap: $groupToMap
});
addToUnscopables('groupByToMap');

/***/ }),

/***/ 6384:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
var $ = __webpack_require__(4395);
var $group = __webpack_require__(6747);
var arrayMethodIsStrict = __webpack_require__(7816);
var addToUnscopables = __webpack_require__(2890);

// `Array.prototype.groupBy` method
// https://github.com/tc39/proposal-array-grouping
// https://bugs.webkit.org/show_bug.cgi?id=236541
$({
  target: 'Array',
  proto: true,
  forced: !arrayMethodIsStrict('groupBy')
}, {
  groupBy: function groupBy(callbackfn /* , thisArg */) {
    var thisArg = arguments.length > 1 ? arguments[1] : undefined;
    return $group(this, callbackfn, thisArg);
  }
});
addToUnscopables('groupBy');

/***/ }),

/***/ 2802:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var addToUnscopables = __webpack_require__(2890);
var $groupToMap = __webpack_require__(3077);
var IS_PURE = __webpack_require__(4151);

// `Array.prototype.groupToMap` method
// https://github.com/tc39/proposal-array-grouping
$({
  target: 'Array',
  proto: true,
  forced: IS_PURE
}, {
  groupToMap: $groupToMap
});
addToUnscopables('groupToMap');

/***/ }),

/***/ 2985:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var $group = __webpack_require__(6747);
var addToUnscopables = __webpack_require__(2890);

// `Array.prototype.group` method
// https://github.com/tc39/proposal-array-grouping
$({
  target: 'Array',
  proto: true
}, {
  group: function group(callbackfn /* , thisArg */) {
    var thisArg = arguments.length > 1 ? arguments[1] : undefined;
    return $group(this, callbackfn, thisArg);
  }
});
addToUnscopables('group');

/***/ }),

/***/ 69:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(7855);

/***/ }),

/***/ 6750:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(2665);

/***/ }),

/***/ 6062:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(9772);

/***/ }),

/***/ 3131:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(8135);

/***/ }),

/***/ 4752:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var anInstance = __webpack_require__(1747);
var getPrototypeOf = __webpack_require__(4483);
var createNonEnumerableProperty = __webpack_require__(1384);
var hasOwn = __webpack_require__(1551);
var wellKnownSymbol = __webpack_require__(6387);
var AsyncIteratorPrototype = __webpack_require__(2179);
var IS_PURE = __webpack_require__(4151);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var $TypeError = TypeError;
var AsyncIteratorConstructor = function AsyncIterator() {
  anInstance(this, AsyncIteratorPrototype);
  if (getPrototypeOf(this) === AsyncIteratorPrototype) throw new $TypeError('Abstract class AsyncIterator not directly constructable');
};
AsyncIteratorConstructor.prototype = AsyncIteratorPrototype;
if (!hasOwn(AsyncIteratorPrototype, TO_STRING_TAG)) {
  createNonEnumerableProperty(AsyncIteratorPrototype, TO_STRING_TAG, 'AsyncIterator');
}
if (IS_PURE || !hasOwn(AsyncIteratorPrototype, 'constructor') || AsyncIteratorPrototype.constructor === Object) {
  createNonEnumerableProperty(AsyncIteratorPrototype, 'constructor', AsyncIteratorConstructor);
}

// `AsyncIterator` constructor
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  global: true,
  constructor: true,
  forced: IS_PURE
}, {
  AsyncIterator: AsyncIteratorConstructor
});

/***/ }),

/***/ 9435:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);
var notANaN = __webpack_require__(8428);
var toPositiveInteger = __webpack_require__(3657);
var createAsyncIteratorProxy = __webpack_require__(9296);
var createIterResultObject = __webpack_require__(9462);
var IS_PURE = __webpack_require__(4151);
var AsyncIteratorProxy = createAsyncIteratorProxy(function (Promise) {
  var state = this;
  return new Promise(function (resolve, reject) {
    var doneAndReject = function (error) {
      state.done = true;
      reject(error);
    };
    var loop = function () {
      try {
        Promise.resolve(anObject(call(state.next, state.iterator))).then(function (step) {
          try {
            if (anObject(step).done) {
              state.done = true;
              resolve(createIterResultObject(undefined, true));
            } else if (state.remaining) {
              state.remaining--;
              loop();
            } else resolve(createIterResultObject(step.value, false));
          } catch (err) {
            doneAndReject(err);
          }
        }, doneAndReject);
      } catch (error) {
        doneAndReject(error);
      }
    };
    loop();
  });
});

// `AsyncIterator.prototype.drop` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true,
  forced: IS_PURE
}, {
  drop: function drop(limit) {
    anObject(this);
    var remaining = toPositiveInteger(notANaN(+limit));
    return new AsyncIteratorProxy(getIteratorDirect(this), {
      remaining: remaining
    });
  }
});

/***/ }),

/***/ 2886:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var $every = (__webpack_require__(7163).every);

// `AsyncIterator.prototype.every` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  every: function every(predicate) {
    return $every(this, predicate);
  }
});

/***/ }),

/***/ 1139:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var isObject = __webpack_require__(9693);
var getIteratorDirect = __webpack_require__(8986);
var createAsyncIteratorProxy = __webpack_require__(9296);
var createIterResultObject = __webpack_require__(9462);
var closeAsyncIteration = __webpack_require__(7897);
var IS_PURE = __webpack_require__(4151);
var AsyncIteratorProxy = createAsyncIteratorProxy(function (Promise) {
  var state = this;
  var iterator = state.iterator;
  var predicate = state.predicate;
  return new Promise(function (resolve, reject) {
    var doneAndReject = function (error) {
      state.done = true;
      reject(error);
    };
    var ifAbruptCloseAsyncIterator = function (error) {
      closeAsyncIteration(iterator, doneAndReject, error, doneAndReject);
    };
    var loop = function () {
      try {
        Promise.resolve(anObject(call(state.next, iterator))).then(function (step) {
          try {
            if (anObject(step).done) {
              state.done = true;
              resolve(createIterResultObject(undefined, true));
            } else {
              var value = step.value;
              try {
                var result = predicate(value, state.counter++);
                var handler = function (selected) {
                  selected ? resolve(createIterResultObject(value, false)) : loop();
                };
                if (isObject(result)) Promise.resolve(result).then(handler, ifAbruptCloseAsyncIterator);else handler(result);
              } catch (error3) {
                ifAbruptCloseAsyncIterator(error3);
              }
            }
          } catch (error2) {
            doneAndReject(error2);
          }
        }, doneAndReject);
      } catch (error) {
        doneAndReject(error);
      }
    };
    loop();
  });
});

// `AsyncIterator.prototype.filter` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true,
  forced: IS_PURE
}, {
  filter: function filter(predicate) {
    anObject(this);
    aCallable(predicate);
    return new AsyncIteratorProxy(getIteratorDirect(this), {
      predicate: predicate
    });
  }
});

/***/ }),

/***/ 6108:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var $find = (__webpack_require__(7163).find);

// `AsyncIterator.prototype.find` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  find: function find(predicate) {
    return $find(this, predicate);
  }
});

/***/ }),

/***/ 3115:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var isObject = __webpack_require__(9693);
var getIteratorDirect = __webpack_require__(8986);
var createAsyncIteratorProxy = __webpack_require__(9296);
var createIterResultObject = __webpack_require__(9462);
var getAsyncIteratorFlattenable = __webpack_require__(1401);
var closeAsyncIteration = __webpack_require__(7897);
var IS_PURE = __webpack_require__(4151);
var AsyncIteratorProxy = createAsyncIteratorProxy(function (Promise) {
  var state = this;
  var iterator = state.iterator;
  var mapper = state.mapper;
  return new Promise(function (resolve, reject) {
    var doneAndReject = function (error) {
      state.done = true;
      reject(error);
    };
    var ifAbruptCloseAsyncIterator = function (error) {
      closeAsyncIteration(iterator, doneAndReject, error, doneAndReject);
    };
    var outerLoop = function () {
      try {
        Promise.resolve(anObject(call(state.next, iterator))).then(function (step) {
          try {
            if (anObject(step).done) {
              state.done = true;
              resolve(createIterResultObject(undefined, true));
            } else {
              var value = step.value;
              try {
                var result = mapper(value, state.counter++);
                var handler = function (mapped) {
                  try {
                    state.inner = getAsyncIteratorFlattenable(mapped);
                    innerLoop();
                  } catch (error4) {
                    ifAbruptCloseAsyncIterator(error4);
                  }
                };
                if (isObject(result)) Promise.resolve(result).then(handler, ifAbruptCloseAsyncIterator);else handler(result);
              } catch (error3) {
                ifAbruptCloseAsyncIterator(error3);
              }
            }
          } catch (error2) {
            doneAndReject(error2);
          }
        }, doneAndReject);
      } catch (error) {
        doneAndReject(error);
      }
    };
    var innerLoop = function () {
      var inner = state.inner;
      if (inner) {
        try {
          Promise.resolve(anObject(call(inner.next, inner.iterator))).then(function (result) {
            try {
              if (anObject(result).done) {
                state.inner = null;
                outerLoop();
              } else resolve(createIterResultObject(result.value, false));
            } catch (error1) {
              ifAbruptCloseAsyncIterator(error1);
            }
          }, ifAbruptCloseAsyncIterator);
        } catch (error) {
          ifAbruptCloseAsyncIterator(error);
        }
      } else outerLoop();
    };
    innerLoop();
  });
});

// `AsyncIterator.prototype.flaMap` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true,
  forced: IS_PURE
}, {
  flatMap: function flatMap(mapper) {
    anObject(this);
    aCallable(mapper);
    return new AsyncIteratorProxy(getIteratorDirect(this), {
      mapper: mapper,
      inner: null
    });
  }
});

/***/ }),

/***/ 7389:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var $forEach = (__webpack_require__(7163).forEach);

// `AsyncIterator.prototype.forEach` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  forEach: function forEach(fn) {
    return $forEach(this, fn);
  }
});

/***/ }),

/***/ 4085:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var toObject = __webpack_require__(3659);
var isPrototypeOf = __webpack_require__(6730);
var getAsyncIteratorFlattenable = __webpack_require__(1401);
var AsyncIteratorPrototype = __webpack_require__(2179);
var WrapAsyncIterator = __webpack_require__(3525);
var IS_PURE = __webpack_require__(4151);

// `AsyncIterator.from` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  stat: true,
  forced: IS_PURE
}, {
  from: function from(O) {
    var iteratorRecord = getAsyncIteratorFlattenable(typeof O == 'string' ? toObject(O) : O);
    return isPrototypeOf(AsyncIteratorPrototype, iteratorRecord.iterator) ? iteratorRecord.iterator : new WrapAsyncIterator(iteratorRecord);
  }
});

/***/ }),

/***/ 2392:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var map = __webpack_require__(7073);
var IS_PURE = __webpack_require__(4151);

// `AsyncIterator.prototype.map` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true,
  forced: IS_PURE
}, {
  map: map
});

/***/ }),

/***/ 2625:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var isObject = __webpack_require__(9693);
var getBuiltIn = __webpack_require__(9406);
var getIteratorDirect = __webpack_require__(8986);
var closeAsyncIteration = __webpack_require__(7897);
var Promise = getBuiltIn('Promise');
var $TypeError = TypeError;

// `AsyncIterator.prototype.reduce` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  reduce: function reduce(reducer /* , initialValue */) {
    anObject(this);
    aCallable(reducer);
    var record = getIteratorDirect(this);
    var iterator = record.iterator;
    var next = record.next;
    var noInitial = arguments.length < 2;
    var accumulator = noInitial ? undefined : arguments[1];
    var counter = 0;
    return new Promise(function (resolve, reject) {
      var ifAbruptCloseAsyncIterator = function (error) {
        closeAsyncIteration(iterator, reject, error, reject);
      };
      var loop = function () {
        try {
          Promise.resolve(anObject(call(next, iterator))).then(function (step) {
            try {
              if (anObject(step).done) {
                noInitial ? reject(new $TypeError('Reduce of empty iterator with no initial value')) : resolve(accumulator);
              } else {
                var value = step.value;
                if (noInitial) {
                  noInitial = false;
                  accumulator = value;
                  loop();
                } else try {
                  var result = reducer(accumulator, value, counter);
                  var handler = function ($result) {
                    accumulator = $result;
                    loop();
                  };
                  if (isObject(result)) Promise.resolve(result).then(handler, ifAbruptCloseAsyncIterator);else handler(result);
                } catch (error3) {
                  ifAbruptCloseAsyncIterator(error3);
                }
              }
              counter++;
            } catch (error2) {
              reject(error2);
            }
          }, reject);
        } catch (error) {
          reject(error);
        }
      };
      loop();
    });
  }
});

/***/ }),

/***/ 7740:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var $some = (__webpack_require__(7163).some);

// `AsyncIterator.prototype.some` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  some: function some(predicate) {
    return $some(this, predicate);
  }
});

/***/ }),

/***/ 4342:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);
var notANaN = __webpack_require__(8428);
var toPositiveInteger = __webpack_require__(3657);
var createAsyncIteratorProxy = __webpack_require__(9296);
var createIterResultObject = __webpack_require__(9462);
var IS_PURE = __webpack_require__(4151);
var AsyncIteratorProxy = createAsyncIteratorProxy(function (Promise) {
  var state = this;
  var iterator = state.iterator;
  var returnMethod;
  if (!state.remaining--) {
    var resultDone = createIterResultObject(undefined, true);
    state.done = true;
    returnMethod = iterator['return'];
    if (returnMethod !== undefined) {
      return Promise.resolve(call(returnMethod, iterator, undefined)).then(function () {
        return resultDone;
      });
    }
    return resultDone;
  }
  return Promise.resolve(call(state.next, iterator)).then(function (step) {
    if (anObject(step).done) {
      state.done = true;
      return createIterResultObject(undefined, true);
    }
    return createIterResultObject(step.value, false);
  }).then(null, function (error) {
    state.done = true;
    throw error;
  });
});

// `AsyncIterator.prototype.take` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true,
  forced: IS_PURE
}, {
  take: function take(limit) {
    anObject(this);
    var remaining = toPositiveInteger(notANaN(+limit));
    return new AsyncIteratorProxy(getIteratorDirect(this), {
      remaining: remaining
    });
  }
});

/***/ }),

/***/ 2767:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var $toArray = (__webpack_require__(7163).toArray);

// `AsyncIterator.prototype.toArray` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  toArray: function toArray() {
    return $toArray(this, undefined, []);
  }
});

/***/ }),

/***/ 585:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// https://github.com/tc39/proposal-explicit-resource-management
var $ = __webpack_require__(4395);
var DESCRIPTORS = __webpack_require__(1923);
var getBuiltIn = __webpack_require__(9406);
var aCallable = __webpack_require__(8117);
var anInstance = __webpack_require__(1747);
var defineBuiltIn = __webpack_require__(5953);
var defineBuiltIns = __webpack_require__(8881);
var defineBuiltInAccessor = __webpack_require__(6248);
var wellKnownSymbol = __webpack_require__(6387);
var InternalStateModule = __webpack_require__(2417);
var addDisposableResource = __webpack_require__(7591);
var SuppressedError = getBuiltIn('SuppressedError');
var $ReferenceError = ReferenceError;
var DISPOSE = wellKnownSymbol('dispose');
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var DISPOSABLE_STACK = 'DisposableStack';
var setInternalState = InternalStateModule.set;
var getDisposableStackInternalState = InternalStateModule.getterFor(DISPOSABLE_STACK);
var HINT = 'sync-dispose';
var DISPOSED = 'disposed';
var PENDING = 'pending';
var getPendingDisposableStackInternalState = function (stack) {
  var internalState = getDisposableStackInternalState(stack);
  if (internalState.state === DISPOSED) throw new $ReferenceError(DISPOSABLE_STACK + ' already disposed');
  return internalState;
};
var $DisposableStack = function DisposableStack() {
  setInternalState(anInstance(this, DisposableStackPrototype), {
    type: DISPOSABLE_STACK,
    state: PENDING,
    stack: []
  });
  if (!DESCRIPTORS) this.disposed = false;
};
var DisposableStackPrototype = $DisposableStack.prototype;
defineBuiltIns(DisposableStackPrototype, {
  dispose: function dispose() {
    var internalState = getDisposableStackInternalState(this);
    if (internalState.state === DISPOSED) return;
    internalState.state = DISPOSED;
    if (!DESCRIPTORS) this.disposed = true;
    var stack = internalState.stack;
    var i = stack.length;
    var thrown = false;
    var suppressed;
    while (i) {
      var disposeMethod = stack[--i];
      stack[i] = null;
      try {
        disposeMethod();
      } catch (errorResult) {
        if (thrown) {
          suppressed = new SuppressedError(errorResult, suppressed);
        } else {
          thrown = true;
          suppressed = errorResult;
        }
      }
    }
    internalState.stack = null;
    if (thrown) throw suppressed;
  },
  use: function use(value) {
    addDisposableResource(getPendingDisposableStackInternalState(this), value, HINT);
    return value;
  },
  adopt: function adopt(value, onDispose) {
    var internalState = getPendingDisposableStackInternalState(this);
    aCallable(onDispose);
    addDisposableResource(internalState, undefined, HINT, function () {
      onDispose(value);
    });
    return value;
  },
  defer: function defer(onDispose) {
    var internalState = getPendingDisposableStackInternalState(this);
    aCallable(onDispose);
    addDisposableResource(internalState, undefined, HINT, onDispose);
  },
  move: function move() {
    var internalState = getPendingDisposableStackInternalState(this);
    var newDisposableStack = new $DisposableStack();
    getDisposableStackInternalState(newDisposableStack).stack = internalState.stack;
    internalState.stack = [];
    internalState.state = DISPOSED;
    if (!DESCRIPTORS) this.disposed = true;
    return newDisposableStack;
  }
});
if (DESCRIPTORS) defineBuiltInAccessor(DisposableStackPrototype, 'disposed', {
  configurable: true,
  get: function disposed() {
    return getDisposableStackInternalState(this).state === DISPOSED;
  }
});
defineBuiltIn(DisposableStackPrototype, DISPOSE, DisposableStackPrototype.dispose, {
  name: 'dispose'
});
defineBuiltIn(DisposableStackPrototype, TO_STRING_TAG, DISPOSABLE_STACK, {
  nonWritable: true
});
$({
  global: true,
  constructor: true
}, {
  DisposableStack: $DisposableStack
});

/***/ }),

/***/ 6508:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var globalThis = __webpack_require__(1848);
var anInstance = __webpack_require__(1747);
var anObject = __webpack_require__(6469);
var isCallable = __webpack_require__(8173);
var getPrototypeOf = __webpack_require__(4483);
var defineBuiltInAccessor = __webpack_require__(6248);
var createProperty = __webpack_require__(4676);
var fails = __webpack_require__(8462);
var hasOwn = __webpack_require__(1551);
var wellKnownSymbol = __webpack_require__(6387);
var IteratorPrototype = (__webpack_require__(7092).IteratorPrototype);
var DESCRIPTORS = __webpack_require__(1923);
var IS_PURE = __webpack_require__(4151);
var CONSTRUCTOR = 'constructor';
var ITERATOR = 'Iterator';
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var $TypeError = TypeError;
var NativeIterator = globalThis[ITERATOR];

// FF56- have non-standard global helper `Iterator`
var FORCED = IS_PURE || !isCallable(NativeIterator) || NativeIterator.prototype !== IteratorPrototype
// FF44- non-standard `Iterator` passes previous tests
|| !fails(function () {
  NativeIterator({});
});
var IteratorConstructor = function Iterator() {
  anInstance(this, IteratorPrototype);
  if (getPrototypeOf(this) === IteratorPrototype) throw new $TypeError('Abstract class Iterator not directly constructable');
};
var defineIteratorPrototypeAccessor = function (key, value) {
  if (DESCRIPTORS) {
    defineBuiltInAccessor(IteratorPrototype, key, {
      configurable: true,
      get: function () {
        return value;
      },
      set: function (replacement) {
        anObject(this);
        if (this === IteratorPrototype) throw new $TypeError("You can't redefine this property");
        if (hasOwn(this, key)) this[key] = replacement;else createProperty(this, key, replacement);
      }
    });
  } else IteratorPrototype[key] = value;
};
if (!hasOwn(IteratorPrototype, TO_STRING_TAG)) defineIteratorPrototypeAccessor(TO_STRING_TAG, ITERATOR);
if (FORCED || !hasOwn(IteratorPrototype, CONSTRUCTOR) || IteratorPrototype[CONSTRUCTOR] === Object) {
  defineIteratorPrototypeAccessor(CONSTRUCTOR, IteratorConstructor);
}
IteratorConstructor.prototype = IteratorPrototype;

// `Iterator` constructor
// https://github.com/tc39/proposal-iterator-helpers
$({
  global: true,
  constructor: true,
  forced: FORCED
}, {
  Iterator: IteratorConstructor
});

/***/ }),

/***/ 7255:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// https://github.com/tc39/proposal-explicit-resource-management
var call = __webpack_require__(7609);
var defineBuiltIn = __webpack_require__(5953);
var getMethod = __webpack_require__(3743);
var hasOwn = __webpack_require__(1551);
var wellKnownSymbol = __webpack_require__(6387);
var IteratorPrototype = (__webpack_require__(7092).IteratorPrototype);
var DISPOSE = wellKnownSymbol('dispose');
if (!hasOwn(IteratorPrototype, DISPOSE)) {
  defineBuiltIn(IteratorPrototype, DISPOSE, function () {
    var $return = getMethod(this, 'return');
    if ($return) call($return, this);
  });
}

/***/ }),

/***/ 3086:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);
var notANaN = __webpack_require__(8428);
var toPositiveInteger = __webpack_require__(3657);
var createIteratorProxy = __webpack_require__(2160);
var IS_PURE = __webpack_require__(4151);
var IteratorProxy = createIteratorProxy(function () {
  var iterator = this.iterator;
  var next = this.next;
  var result, done;
  while (this.remaining) {
    this.remaining--;
    result = anObject(call(next, iterator));
    done = this.done = !!result.done;
    if (done) return;
  }
  result = anObject(call(next, iterator));
  done = this.done = !!result.done;
  if (!done) return result.value;
});

// `Iterator.prototype.drop` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true,
  forced: IS_PURE
}, {
  drop: function drop(limit) {
    anObject(this);
    var remaining = toPositiveInteger(notANaN(+limit));
    return new IteratorProxy(getIteratorDirect(this), {
      remaining: remaining
    });
  }
});

/***/ }),

/***/ 7439:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var iterate = __webpack_require__(2201);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);

// `Iterator.prototype.every` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  every: function every(predicate) {
    anObject(this);
    aCallable(predicate);
    var record = getIteratorDirect(this);
    var counter = 0;
    return !iterate(record, function (value, stop) {
      if (!predicate(value, counter++)) return stop();
    }, {
      IS_RECORD: true,
      INTERRUPTED: true
    }).stopped;
  }
});

/***/ }),

/***/ 1408:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);
var createIteratorProxy = __webpack_require__(2160);
var callWithSafeIterationClosing = __webpack_require__(9832);
var IS_PURE = __webpack_require__(4151);
var IteratorProxy = createIteratorProxy(function () {
  var iterator = this.iterator;
  var predicate = this.predicate;
  var next = this.next;
  var result, done, value;
  while (true) {
    result = anObject(call(next, iterator));
    done = this.done = !!result.done;
    if (done) return;
    value = result.value;
    if (callWithSafeIterationClosing(iterator, predicate, [value, this.counter++], true)) return value;
  }
});

// `Iterator.prototype.filter` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true,
  forced: IS_PURE
}, {
  filter: function filter(predicate) {
    anObject(this);
    aCallable(predicate);
    return new IteratorProxy(getIteratorDirect(this), {
      predicate: predicate
    });
  }
});

/***/ }),

/***/ 674:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var iterate = __webpack_require__(2201);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);

// `Iterator.prototype.find` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  find: function find(predicate) {
    anObject(this);
    aCallable(predicate);
    var record = getIteratorDirect(this);
    var counter = 0;
    return iterate(record, function (value, stop) {
      if (predicate(value, counter++)) return stop(value);
    }, {
      IS_RECORD: true,
      INTERRUPTED: true
    }).result;
  }
});

/***/ }),

/***/ 7471:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);
var getIteratorFlattenable = __webpack_require__(8304);
var createIteratorProxy = __webpack_require__(2160);
var iteratorClose = __webpack_require__(9273);
var IS_PURE = __webpack_require__(4151);
var IteratorProxy = createIteratorProxy(function () {
  var iterator = this.iterator;
  var mapper = this.mapper;
  var result, inner;
  while (true) {
    if (inner = this.inner) try {
      result = anObject(call(inner.next, inner.iterator));
      if (!result.done) return result.value;
      this.inner = null;
    } catch (error) {
      iteratorClose(iterator, 'throw', error);
    }
    result = anObject(call(this.next, iterator));
    if (this.done = !!result.done) return;
    try {
      this.inner = getIteratorFlattenable(mapper(result.value, this.counter++), false);
    } catch (error) {
      iteratorClose(iterator, 'throw', error);
    }
  }
});

// `Iterator.prototype.flatMap` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true,
  forced: IS_PURE
}, {
  flatMap: function flatMap(mapper) {
    anObject(this);
    aCallable(mapper);
    return new IteratorProxy(getIteratorDirect(this), {
      mapper: mapper,
      inner: null
    });
  }
});

/***/ }),

/***/ 9397:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var iterate = __webpack_require__(2201);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);

// `Iterator.prototype.forEach` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  forEach: function forEach(fn) {
    anObject(this);
    aCallable(fn);
    var record = getIteratorDirect(this);
    var counter = 0;
    iterate(record, function (value) {
      fn(value, counter++);
    }, {
      IS_RECORD: true
    });
  }
});

/***/ }),

/***/ 2426:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var toObject = __webpack_require__(3659);
var isPrototypeOf = __webpack_require__(6730);
var IteratorPrototype = (__webpack_require__(7092).IteratorPrototype);
var createIteratorProxy = __webpack_require__(2160);
var getIteratorFlattenable = __webpack_require__(8304);
var IS_PURE = __webpack_require__(4151);
var IteratorProxy = createIteratorProxy(function () {
  return call(this.next, this.iterator);
}, true);

// `Iterator.from` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  stat: true,
  forced: IS_PURE
}, {
  from: function from(O) {
    var iteratorRecord = getIteratorFlattenable(typeof O == 'string' ? toObject(O) : O, true);
    return isPrototypeOf(IteratorPrototype, iteratorRecord.iterator) ? iteratorRecord.iterator : new IteratorProxy(iteratorRecord);
  }
});

/***/ }),

/***/ 6806:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var map = __webpack_require__(2563);
var IS_PURE = __webpack_require__(4151);

// `Iterator.prototype.map` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true,
  forced: IS_PURE
}, {
  map: map
});

/***/ }),

/***/ 1978:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var iterate = __webpack_require__(2201);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);
var $TypeError = TypeError;

// `Iterator.prototype.reduce` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  reduce: function reduce(reducer /* , initialValue */) {
    anObject(this);
    aCallable(reducer);
    var record = getIteratorDirect(this);
    var noInitial = arguments.length < 2;
    var accumulator = noInitial ? undefined : arguments[1];
    var counter = 0;
    iterate(record, function (value) {
      if (noInitial) {
        noInitial = false;
        accumulator = value;
      } else {
        accumulator = reducer(accumulator, value, counter);
      }
      counter++;
    }, {
      IS_RECORD: true
    });
    if (noInitial) throw new $TypeError('Reduce of empty iterator with no initial value');
    return accumulator;
  }
});

/***/ }),

/***/ 8245:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var iterate = __webpack_require__(2201);
var aCallable = __webpack_require__(8117);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);

// `Iterator.prototype.some` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  some: function some(predicate) {
    anObject(this);
    aCallable(predicate);
    var record = getIteratorDirect(this);
    var counter = 0;
    return iterate(record, function (value, stop) {
      if (predicate(value, counter++)) return stop();
    }, {
      IS_RECORD: true,
      INTERRUPTED: true
    }).stopped;
  }
});

/***/ }),

/***/ 7331:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var call = __webpack_require__(7609);
var anObject = __webpack_require__(6469);
var getIteratorDirect = __webpack_require__(8986);
var notANaN = __webpack_require__(8428);
var toPositiveInteger = __webpack_require__(3657);
var createIteratorProxy = __webpack_require__(2160);
var iteratorClose = __webpack_require__(9273);
var IS_PURE = __webpack_require__(4151);
var IteratorProxy = createIteratorProxy(function () {
  var iterator = this.iterator;
  if (!this.remaining--) {
    this.done = true;
    return iteratorClose(iterator, 'normal', undefined);
  }
  var result = anObject(call(this.next, iterator));
  var done = this.done = !!result.done;
  if (!done) return result.value;
});

// `Iterator.prototype.take` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true,
  forced: IS_PURE
}, {
  take: function take(limit) {
    anObject(this);
    var remaining = toPositiveInteger(notANaN(+limit));
    return new IteratorProxy(getIteratorDirect(this), {
      remaining: remaining
    });
  }
});

/***/ }),

/***/ 6496:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var anObject = __webpack_require__(6469);
var iterate = __webpack_require__(2201);
var getIteratorDirect = __webpack_require__(8986);
var push = [].push;

// `Iterator.prototype.toArray` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  toArray: function toArray() {
    var result = [];
    iterate(getIteratorDirect(anObject(this)), push, {
      that: result,
      IS_RECORD: true
    });
    return result;
  }
});

/***/ }),

/***/ 1166:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var anObject = __webpack_require__(6469);
var AsyncFromSyncIterator = __webpack_require__(147);
var WrapAsyncIterator = __webpack_require__(3525);
var getIteratorDirect = __webpack_require__(8986);
var IS_PURE = __webpack_require__(4151);

// `Iterator.prototype.toAsync` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true,
  forced: IS_PURE
}, {
  toAsync: function toAsync() {
    return new WrapAsyncIterator(getIteratorDirect(new AsyncFromSyncIterator(getIteratorDirect(anObject(this)))));
  }
});

/***/ }),

/***/ 2359:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(8140);

/***/ }),

/***/ 7472:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(9983);

/***/ }),

/***/ 7322:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(6276);

/***/ }),

/***/ 6539:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(9297);

/***/ }),

/***/ 8866:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(6816);

/***/ }),

/***/ 9701:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(6756);

/***/ }),

/***/ 5102:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(960);

/***/ }),

/***/ 2373:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(9301);

/***/ }),

/***/ 1853:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(1516);

/***/ }),

/***/ 5030:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(705);

/***/ }),

/***/ 8855:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4395);
var globalThis = __webpack_require__(1848);
var isPrototypeOf = __webpack_require__(6730);
var getPrototypeOf = __webpack_require__(4483);
var setPrototypeOf = __webpack_require__(5273);
var copyConstructorProperties = __webpack_require__(744);
var create = __webpack_require__(9543);
var createNonEnumerableProperty = __webpack_require__(1384);
var createPropertyDescriptor = __webpack_require__(4127);
var installErrorStack = __webpack_require__(2519);
var normalizeStringArgument = __webpack_require__(9766);
var wellKnownSymbol = __webpack_require__(6387);
var fails = __webpack_require__(8462);
var IS_PURE = __webpack_require__(4151);
var NativeSuppressedError = globalThis.SuppressedError;
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var $Error = Error;

// https://github.com/oven-sh/bun/issues/9282
var WRONG_ARITY = !!NativeSuppressedError && NativeSuppressedError.length !== 3;

// https://github.com/oven-sh/bun/issues/9283
var EXTRA_ARGS_SUPPORT = !!NativeSuppressedError && fails(function () {
  return new NativeSuppressedError(1, 2, 3, {
    cause: 4
  }).cause === 4;
});
var PATCH = WRONG_ARITY || EXTRA_ARGS_SUPPORT;
var $SuppressedError = function SuppressedError(error, suppressed, message) {
  var isInstance = isPrototypeOf(SuppressedErrorPrototype, this);
  var that;
  if (setPrototypeOf) {
    that = PATCH && (!isInstance || getPrototypeOf(this) === SuppressedErrorPrototype) ? new NativeSuppressedError() : setPrototypeOf(new $Error(), isInstance ? getPrototypeOf(this) : SuppressedErrorPrototype);
  } else {
    that = isInstance ? this : create(SuppressedErrorPrototype);
    createNonEnumerableProperty(that, TO_STRING_TAG, 'Error');
  }
  if (message !== undefined) createNonEnumerableProperty(that, 'message', normalizeStringArgument(message));
  installErrorStack(that, $SuppressedError, that.stack, 1);
  createNonEnumerableProperty(that, 'error', error);
  createNonEnumerableProperty(that, 'suppressed', suppressed);
  return that;
};
if (setPrototypeOf) setPrototypeOf($SuppressedError, $Error);else copyConstructorProperties($SuppressedError, $Error, {
  name: true
});
var SuppressedErrorPrototype = $SuppressedError.prototype = PATCH ? NativeSuppressedError.prototype : create($Error.prototype, {
  constructor: createPropertyDescriptor(1, $SuppressedError),
  message: createPropertyDescriptor(1, ''),
  name: createPropertyDescriptor(1, 'SuppressedError')
});
if (PATCH && !IS_PURE) SuppressedErrorPrototype.constructor = $SuppressedError;

// `SuppressedError` constructor
// https://github.com/tc39/proposal-explicit-resource-management
$({
  global: true,
  constructor: true,
  arity: 3,
  forced: PATCH
}, {
  SuppressedError: $SuppressedError
});

/***/ }),

/***/ 6845:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var globalThis = __webpack_require__(1848);
var defineWellKnownSymbol = __webpack_require__(6220);
var defineProperty = (__webpack_require__(615).f);
var getOwnPropertyDescriptor = (__webpack_require__(5983).f);
var Symbol = globalThis.Symbol;

// `Symbol.dispose` well-known symbol
// https://github.com/tc39/proposal-explicit-resource-management
defineWellKnownSymbol('dispose');
if (Symbol) {
  var descriptor = getOwnPropertyDescriptor(Symbol, 'dispose');
  // workaround of NodeJS 20.4 bug
  // https://github.com/nodejs/node/issues/48699
  // and incorrect descriptor from some transpilers and userland helpers
  if (descriptor.enumerable && descriptor.configurable && descriptor.writable) {
    defineProperty(Symbol, 'dispose', {
      value: descriptor.value,
      enumerable: false,
      configurable: false,
      writable: false
    });
  }
}

/***/ }),

/***/ 1085:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(1825);

/***/ }),

/***/ 7594:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(4774);

/***/ }),

/***/ 1374:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(1519);

/***/ }),

/***/ 8471:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(8348);

/***/ }),

/***/ 2539:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(3457);

/***/ }),

/***/ 9235:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
var ArrayBufferViewCore = __webpack_require__(1759);
var lengthOfArrayLike = __webpack_require__(9110);
var isBigIntArray = __webpack_require__(4107);
var toAbsoluteIndex = __webpack_require__(3663);
var toBigInt = __webpack_require__(3442);
var toIntegerOrInfinity = __webpack_require__(6521);
var fails = __webpack_require__(8462);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var getTypedArrayConstructor = ArrayBufferViewCore.getTypedArrayConstructor;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var max = Math.max;
var min = Math.min;

// some early implementations, like WebKit, does not follow the final semantic
var PROPER_ORDER = !fails(function () {
  // eslint-disable-next-line es/no-typed-arrays -- required for testing
  var array = new Int8Array([1]);
  var spliced = array.toSpliced(1, 0, {
    valueOf: function () {
      array[0] = 2;
      return 3;
    }
  });
  return spliced[0] !== 2 || spliced[1] !== 3;
});

// `%TypedArray%.prototype.toSpliced` method
// https://tc39.es/proposal-change-array-by-copy/#sec-%typedarray%.prototype.toSpliced
exportTypedArrayMethod('toSpliced', function toSpliced(start, deleteCount /* , ...items */) {
  var O = aTypedArray(this);
  var C = getTypedArrayConstructor(O);
  var len = lengthOfArrayLike(O);
  var actualStart = toAbsoluteIndex(start, len);
  var argumentsLength = arguments.length;
  var k = 0;
  var insertCount, actualDeleteCount, thisIsBigIntArray, convertedItems, value, newLen, A;
  if (argumentsLength === 0) {
    insertCount = actualDeleteCount = 0;
  } else if (argumentsLength === 1) {
    insertCount = 0;
    actualDeleteCount = len - actualStart;
  } else {
    actualDeleteCount = min(max(toIntegerOrInfinity(deleteCount), 0), len - actualStart);
    insertCount = argumentsLength - 2;
    if (insertCount) {
      convertedItems = new C(insertCount);
      thisIsBigIntArray = isBigIntArray(convertedItems);
      for (var i = 2; i < argumentsLength; i++) {
        value = arguments[i];
        // FF30- typed arrays doesn't properly convert objects to typed array values
        convertedItems[i - 2] = thisIsBigIntArray ? toBigInt(value) : +value;
      }
    }
  }
  newLen = len + insertCount - actualDeleteCount;
  A = new C(newLen);
  for (; k < actualStart; k++) A[k] = O[k];
  for (; k < actualStart + insertCount; k++) A[k] = convertedItems[k - actualStart];
  for (; k < newLen; k++) A[k] = O[k + actualDeleteCount - insertCount];
  return A;
}, !PROPER_ORDER);

/***/ }),

/***/ 7209:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
__webpack_require__(6939);

/***/ }),

/***/ 4844:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var context = __webpack_require__(5803);

// 将 @babel/runtime 下的方法都写入到 BabelRuntimeHelpers
context.keys().forEach(name => {
  BabelRuntimeHelpers[name.substr(2)] = context(name);
});
var wxRunOnDebug = fn => fn();
wxRunOnDebug(() => {
  BabelRuntimeHelpers = new Proxy(BabelRuntimeHelpers, {
    get(obj, prop) {
      if (!obj[prop]) {
        console.error(`尝试读取未定义 BabelRuntimeHelpers.${prop}，请确保 weapp-polyfill 为最新。`);
        console.error('若确认最新版存在问题，则请尝试在 weapp-polyfill 下执行 node getBabelHelpers');
      }
      return obj[prop];
    }
  });
});

/***/ }),

/***/ 8071:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1474);
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_aggregate_error_cause_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7311);
/* harmony import */ var core_js_modules_es_aggregate_error_cause_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_aggregate_error_cause_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_at_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4240);
/* harmony import */ var core_js_modules_es_array_at_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_at_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_last_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7119);
/* harmony import */ var core_js_modules_es_array_find_last_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_last_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3509);
/* harmony import */ var core_js_modules_es_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2004);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_unshift_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8971);
/* harmony import */ var core_js_modules_es_array_unshift_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_unshift_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_object_has_own_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8140);
/* harmony import */ var core_js_modules_es_object_has_own_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_has_own_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7788);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5164);
/* harmony import */ var core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_promise_any_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6406);
/* harmony import */ var core_js_modules_es_promise_any_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_any_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1410);
/* harmony import */ var core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_regexp_flags_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7638);
/* harmony import */ var core_js_modules_es_regexp_flags_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_flags_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_string_at_alternative_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6303);
/* harmony import */ var core_js_modules_es_string_at_alternative_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_at_alternative_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1825);
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2220);
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1519);
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4774);
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1520);
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2663);
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_esnext_array_at_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(5388);
/* harmony import */ var core_js_modules_esnext_array_at_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_at_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_esnext_array_find_last_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(5601);
/* harmony import */ var core_js_modules_esnext_array_find_last_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_find_last_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_esnext_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(1034);
/* harmony import */ var core_js_modules_esnext_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_esnext_object_has_own_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(2359);
/* harmony import */ var core_js_modules_esnext_object_has_own_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_object_has_own_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_esnext_typed_array_at_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(1085);
/* harmony import */ var core_js_modules_esnext_typed_array_at_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_at_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_esnext_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(1374);
/* harmony import */ var core_js_modules_esnext_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_esnext_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(7594);
/* harmony import */ var core_js_modules_esnext_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_esnext_suppressed_error_constructor_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(8855);
/* harmony import */ var core_js_modules_esnext_suppressed_error_constructor_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_suppressed_error_constructor_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_esnext_array_from_async_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(5794);
/* harmony import */ var core_js_modules_esnext_array_from_async_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_from_async_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_esnext_array_group_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(2985);
/* harmony import */ var core_js_modules_esnext_array_group_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_group_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_esnext_array_group_by_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(6384);
/* harmony import */ var core_js_modules_esnext_array_group_by_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_group_by_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_esnext_array_group_by_to_map_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(1772);
/* harmony import */ var core_js_modules_esnext_array_group_by_to_map_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_group_by_to_map_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_esnext_array_group_to_map_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(2802);
/* harmony import */ var core_js_modules_esnext_array_group_to_map_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_group_to_map_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_esnext_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(69);
/* harmony import */ var core_js_modules_esnext_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var core_js_modules_esnext_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(6750);
/* harmony import */ var core_js_modules_esnext_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var core_js_modules_esnext_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(6062);
/* harmony import */ var core_js_modules_esnext_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var core_js_modules_esnext_array_with_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(3131);
/* harmony import */ var core_js_modules_esnext_array_with_js__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_with_js__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var core_js_modules_esnext_async_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(4752);
/* harmony import */ var core_js_modules_esnext_async_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var core_js_modules_esnext_async_iterator_drop_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(9435);
/* harmony import */ var core_js_modules_esnext_async_iterator_drop_js__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_drop_js__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var core_js_modules_esnext_async_iterator_every_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(2886);
/* harmony import */ var core_js_modules_esnext_async_iterator_every_js__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_every_js__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var core_js_modules_esnext_async_iterator_filter_js__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(1139);
/* harmony import */ var core_js_modules_esnext_async_iterator_filter_js__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_filter_js__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var core_js_modules_esnext_async_iterator_find_js__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(6108);
/* harmony import */ var core_js_modules_esnext_async_iterator_find_js__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_find_js__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var core_js_modules_esnext_async_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(3115);
/* harmony import */ var core_js_modules_esnext_async_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var core_js_modules_esnext_async_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(7389);
/* harmony import */ var core_js_modules_esnext_async_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var core_js_modules_esnext_async_iterator_from_js__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(4085);
/* harmony import */ var core_js_modules_esnext_async_iterator_from_js__WEBPACK_IMPORTED_MODULE_44___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_from_js__WEBPACK_IMPORTED_MODULE_44__);
/* harmony import */ var core_js_modules_esnext_async_iterator_map_js__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(2392);
/* harmony import */ var core_js_modules_esnext_async_iterator_map_js__WEBPACK_IMPORTED_MODULE_45___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_map_js__WEBPACK_IMPORTED_MODULE_45__);
/* harmony import */ var core_js_modules_esnext_async_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(2625);
/* harmony import */ var core_js_modules_esnext_async_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_46___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_46__);
/* harmony import */ var core_js_modules_esnext_async_iterator_some_js__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(7740);
/* harmony import */ var core_js_modules_esnext_async_iterator_some_js__WEBPACK_IMPORTED_MODULE_47___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_some_js__WEBPACK_IMPORTED_MODULE_47__);
/* harmony import */ var core_js_modules_esnext_async_iterator_take_js__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(4342);
/* harmony import */ var core_js_modules_esnext_async_iterator_take_js__WEBPACK_IMPORTED_MODULE_48___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_take_js__WEBPACK_IMPORTED_MODULE_48__);
/* harmony import */ var core_js_modules_esnext_async_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(2767);
/* harmony import */ var core_js_modules_esnext_async_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_49___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_49__);
/* harmony import */ var core_js_modules_esnext_disposable_stack_constructor_js__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(585);
/* harmony import */ var core_js_modules_esnext_disposable_stack_constructor_js__WEBPACK_IMPORTED_MODULE_50___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_disposable_stack_constructor_js__WEBPACK_IMPORTED_MODULE_50__);
/* harmony import */ var core_js_modules_esnext_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(6508);
/* harmony import */ var core_js_modules_esnext_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_51___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_51__);
/* harmony import */ var core_js_modules_esnext_iterator_dispose_js__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(7255);
/* harmony import */ var core_js_modules_esnext_iterator_dispose_js__WEBPACK_IMPORTED_MODULE_52___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_dispose_js__WEBPACK_IMPORTED_MODULE_52__);
/* harmony import */ var core_js_modules_esnext_iterator_drop_js__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(3086);
/* harmony import */ var core_js_modules_esnext_iterator_drop_js__WEBPACK_IMPORTED_MODULE_53___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_drop_js__WEBPACK_IMPORTED_MODULE_53__);
/* harmony import */ var core_js_modules_esnext_iterator_every_js__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(7439);
/* harmony import */ var core_js_modules_esnext_iterator_every_js__WEBPACK_IMPORTED_MODULE_54___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_every_js__WEBPACK_IMPORTED_MODULE_54__);
/* harmony import */ var core_js_modules_esnext_iterator_filter_js__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(1408);
/* harmony import */ var core_js_modules_esnext_iterator_filter_js__WEBPACK_IMPORTED_MODULE_55___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_filter_js__WEBPACK_IMPORTED_MODULE_55__);
/* harmony import */ var core_js_modules_esnext_iterator_find_js__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(674);
/* harmony import */ var core_js_modules_esnext_iterator_find_js__WEBPACK_IMPORTED_MODULE_56___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_find_js__WEBPACK_IMPORTED_MODULE_56__);
/* harmony import */ var core_js_modules_esnext_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(7471);
/* harmony import */ var core_js_modules_esnext_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_57___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_57__);
/* harmony import */ var core_js_modules_esnext_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(9397);
/* harmony import */ var core_js_modules_esnext_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_58___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_58__);
/* harmony import */ var core_js_modules_esnext_iterator_from_js__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(2426);
/* harmony import */ var core_js_modules_esnext_iterator_from_js__WEBPACK_IMPORTED_MODULE_59___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_from_js__WEBPACK_IMPORTED_MODULE_59__);
/* harmony import */ var core_js_modules_esnext_iterator_map_js__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(6806);
/* harmony import */ var core_js_modules_esnext_iterator_map_js__WEBPACK_IMPORTED_MODULE_60___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_map_js__WEBPACK_IMPORTED_MODULE_60__);
/* harmony import */ var core_js_modules_esnext_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(1978);
/* harmony import */ var core_js_modules_esnext_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_61___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_61__);
/* harmony import */ var core_js_modules_esnext_iterator_some_js__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(8245);
/* harmony import */ var core_js_modules_esnext_iterator_some_js__WEBPACK_IMPORTED_MODULE_62___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_some_js__WEBPACK_IMPORTED_MODULE_62__);
/* harmony import */ var core_js_modules_esnext_iterator_take_js__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(7331);
/* harmony import */ var core_js_modules_esnext_iterator_take_js__WEBPACK_IMPORTED_MODULE_63___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_take_js__WEBPACK_IMPORTED_MODULE_63__);
/* harmony import */ var core_js_modules_esnext_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(6496);
/* harmony import */ var core_js_modules_esnext_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_64___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_64__);
/* harmony import */ var core_js_modules_esnext_iterator_to_async_js__WEBPACK_IMPORTED_MODULE_65__ = __webpack_require__(1166);
/* harmony import */ var core_js_modules_esnext_iterator_to_async_js__WEBPACK_IMPORTED_MODULE_65___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_to_async_js__WEBPACK_IMPORTED_MODULE_65__);
/* harmony import */ var core_js_modules_esnext_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_66__ = __webpack_require__(7472);
/* harmony import */ var core_js_modules_esnext_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_66___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_66__);
/* harmony import */ var core_js_modules_esnext_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_67__ = __webpack_require__(7322);
/* harmony import */ var core_js_modules_esnext_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_67___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_67__);
/* harmony import */ var core_js_modules_esnext_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_68__ = __webpack_require__(6539);
/* harmony import */ var core_js_modules_esnext_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_68___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_68__);
/* harmony import */ var core_js_modules_esnext_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_69__ = __webpack_require__(8866);
/* harmony import */ var core_js_modules_esnext_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_69___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_69__);
/* harmony import */ var core_js_modules_esnext_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_70__ = __webpack_require__(9701);
/* harmony import */ var core_js_modules_esnext_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_70___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_70__);
/* harmony import */ var core_js_modules_esnext_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_71__ = __webpack_require__(5102);
/* harmony import */ var core_js_modules_esnext_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_71___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_71__);
/* harmony import */ var core_js_modules_esnext_set_union_v2_js__WEBPACK_IMPORTED_MODULE_72__ = __webpack_require__(2373);
/* harmony import */ var core_js_modules_esnext_set_union_v2_js__WEBPACK_IMPORTED_MODULE_72___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_union_v2_js__WEBPACK_IMPORTED_MODULE_72__);
/* harmony import */ var core_js_modules_esnext_string_is_well_formed_js__WEBPACK_IMPORTED_MODULE_73__ = __webpack_require__(1853);
/* harmony import */ var core_js_modules_esnext_string_is_well_formed_js__WEBPACK_IMPORTED_MODULE_73___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_string_is_well_formed_js__WEBPACK_IMPORTED_MODULE_73__);
/* harmony import */ var core_js_modules_esnext_string_to_well_formed_js__WEBPACK_IMPORTED_MODULE_74__ = __webpack_require__(5030);
/* harmony import */ var core_js_modules_esnext_string_to_well_formed_js__WEBPACK_IMPORTED_MODULE_74___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_string_to_well_formed_js__WEBPACK_IMPORTED_MODULE_74__);
/* harmony import */ var core_js_modules_esnext_symbol_dispose_js__WEBPACK_IMPORTED_MODULE_75__ = __webpack_require__(6845);
/* harmony import */ var core_js_modules_esnext_symbol_dispose_js__WEBPACK_IMPORTED_MODULE_75___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_symbol_dispose_js__WEBPACK_IMPORTED_MODULE_75__);
/* harmony import */ var core_js_modules_esnext_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_76__ = __webpack_require__(8471);
/* harmony import */ var core_js_modules_esnext_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_76___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_76__);
/* harmony import */ var core_js_modules_esnext_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_77__ = __webpack_require__(2539);
/* harmony import */ var core_js_modules_esnext_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_77___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_77__);
/* harmony import */ var core_js_modules_esnext_typed_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_78__ = __webpack_require__(9235);
/* harmony import */ var core_js_modules_esnext_typed_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_78___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_78__);
/* harmony import */ var core_js_modules_esnext_typed_array_with_js__WEBPACK_IMPORTED_MODULE_79__ = __webpack_require__(7209);
/* harmony import */ var core_js_modules_esnext_typed_array_with_js__WEBPACK_IMPORTED_MODULE_79___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_with_js__WEBPACK_IMPORTED_MODULE_79__);



















 // 拆分为新文件的原因：@babel/preset-env 要求 core-js 导入语句必须在文件最顶部
// 以下 import 语句会在 @babel/preset-env 中根据 browserslist 中声明的浏览器列表，自动修改为导入需要的 polyfill




























































// 新版 core-js 会替换掉这些 TypedArray 并且被 uglify 去掉 name
// 为了对齐旧版 core-js 行为，给他们强制设置 name
var TYPED_ARRAY_NAMES = ['Int8Array', 'Uint8Array', 'Uint8ClampedArray', 'Int16Array', 'Uint16Array', 'Int32Array', 'Uint32Array', 'Float32Array', 'Float64Array'];
TYPED_ARRAY_NAMES.forEach(CONSTRUCTOR_NAME => {
  var CONSTRUCTOR = globalThis[CONSTRUCTOR_NAME];
  if (CONSTRUCTOR && CONSTRUCTOR.name !== CONSTRUCTOR_NAME) {
    Object.defineProperty(CONSTRUCTOR, 'name', {
      value: CONSTRUCTOR_NAME
    });
  }
});

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
__webpack_require__.g.__polyfill_injecting = true;

// 预加载情况下调用 getSystemInfo，客户端不会马上返回结果，因此从 __wxConfig 上取 platform 字段
var isIOS = false;
var iOSVersion = null;
if (__webpack_require__.g.__wxConfig && typeof __webpack_require__.g.__wxConfig.platform === 'string') {
  if (__webpack_require__.g.__wxConfig.platform.toLowerCase() === 'ios') {
    isIOS = true;
    var system = __webpack_require__.g.__wxConfig.system || '';
    iOSVersion = system.startsWith('iOS ') ? system.substr(4) : null;
  }
} else if (typeof navigator !== 'undefined' && typeof navigator.userAgent === 'string') {
  var ua = navigator.userAgent.toLowerCase();
  if (ua.indexOf('iphone') >= 0 || ua.indexOf('ipad') >= 0) {
    isIOS = true;
    var match = /iphone os ([\d_]+)/.exec(ua);
    iOSVersion = match ? match[1].replace(/_/g, '.') : null;
  }
}

// 强制 core-js 使用 polyfill 的特性列表
var usePolyfill = [];
var useNative = ['WeakMap'];
function isIOS16Above() {
  var majorVersion = iOSVersion.split('.')[0];
  return parseInt(majorVersion, 10) >= 16;
}

// iOS 强制使用 Promise polyfill，为了 onUnhandledRejection 能正常工作
if (isIOS) {
  // 强制让 core-js 用 macroTask 模拟 Promise
  if (iOSVersion === null || !isIOS16Above()) {
    // iOS 16 以下不能使用微任务 https://git.woa.com/wxweb/design/issues/5723
    __webpack_require__.g.Promise = undefined;
  }
  usePolyfill.push('Promise');
}

// 配置 core-js
__webpack_require__(9762)({
  usePolyfill,
  useNative
});

// 引入 core-js polyfill
__webpack_require__(8071);
__webpack_require__(4844);
delete __webpack_require__.g.__polyfill_injecting;
})();

/******/ })()
;
var __wxTest__ = false;
var wxRunOnDebug = function (fun) {fun()};
var __wxConfig;
var Foundation;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it declares 'Foundation' on top-level, which conflicts with the current library output.
(() => {

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ src_Foundation)
});

// NAMESPACE OBJECT: ./src/Foundation/errorHandler.ts
var errorHandler_namespaceObject = {};
__webpack_require__.r(errorHandler_namespaceObject);
__webpack_require__.d(errorHandler_namespaceObject, {
  convertToErrorObj: () => (convertToErrorObj),
  emitFrameworkError: () => (emitFrameworkError),
  emitUnhandledError: () => (emitUnhandledError),
  emitUnhandledRejection: () => (emitUnhandledRejection),
  onFrameworkError: () => (onFrameworkError),
  onUnhandledError: () => (onUnhandledError),
  onUnhandledRejection: () => (onUnhandledRejection)
});

;// CONCATENATED MODULE: ./src/Foundation/env.ts
var wxLibrary = __webpack_require__.g.__wxLibrary;
var wxConfig = __webpack_require__.g.__wxConfig;
var envType = wxLibrary.envType;
var contextType = wxLibrary.contextType;
var isService = envType === 'Service';
var isWebView = envType === 'WebView';
var isWorker = envType === 'Worker';
var isApp = isWebView || isService && contextType.indexOf('App:') === 0;
var isGame = isService && contextType.indexOf('Game:') === 0;
var isMagicBrushFrameEnv = contextType.indexOf('MagicBrush:') === 0;
var _isSupportIsolateContext = !!wxConfig.isIsolateContext;
var isMainContext = _isSupportIsolateContext && isService && contextType.indexOf('MainContext') >= 0;
var isSubContext = _isSupportIsolateContext && isService && contextType.indexOf('SubContext') >= 0;
var isSafeSubContext = isSubContext && contextType.indexOf('Safe') >= 0;
var isIsolateContext = isMainContext || isSubContext;
var isWXLibWorker = wxConfig.workerContentType === 'wxlib';
var isSafeEnv = isWebView || isMainContext || isSafeSubContext || isWXLibWorker;
var platform = function (_window$navigator) {
  var platform = wxConfig.platform;
  if (!platform && typeof window === 'object' && typeof ((_window$navigator = window.navigator) === null || _window$navigator === void 0 ? void 0 : _window$navigator.userAgent) === 'string') {
    var ua = window.navigator.userAgent.toLowerCase();
    if (ua.indexOf('devtools') >= 0) {
      platform = 'devtools';
    } else if (ua.indexOf('miniprogramenv/windows') >= 0) {
      platform = 'windows';
    } else if (ua.indexOf('miniprogramenv/mac') >= 0) {
      platform = 'mac';
    } else if (ua.indexOf('miniprogramenv/mina') >= 0) {
      platform = 'mina';
    } else if (ua.indexOf('iphone') >= 0 || ua.indexOf('ipad') >= 0) {
      platform = 'ios';
    } else if (ua.indexOf('android') >= 0) {
      platform = 'android';
    }
  }
  return (platform || 'unknown').toLowerCase();
}();
var libVersionInfo = __libVersionInfo__;
var SDKVersion = typeof libVersionInfo === 'undefined' || libVersionInfo.version === 'develop' ? '9.9.9' : libVersionInfo.version;
var contextName = '';
var mayHaveSnapShot = !!wxLibrary.mayHaveSnapshot;
var WK_RENDERER_H5 = /* #__PURE__ */(() => typeof __webpack_require__.g === 'object' && __webpack_require__.g && __webpack_require__.g.__wkrenderer_h5)();
/* harmony default export */ const env = ({
  platform,
  SDKVersion,
  isIsolateContext,
  isGame,
  isApp,
  isMainContext,
  isSubContext,
  isSafeEnv,
  isService,
  isWebView,
  isWorker,
  isWidget: false,
  typeStr: isSubContext ? 'SubContext' : envType,
  fileName: wxLibrary.fileName,
  isWXLibWorker,
  workerType: 'user',
  contextName,
  mayHaveSnapShot,
  isWKGame: !!WK_RENDERER_H5,
  isMagicBrushFrameEnv
});
;// CONCATENATED MODULE: ./src/Foundation/console/utils.ts

var EMPTY = () => {};
var IS_DEVTOOLS = env.platform === 'devtools';
var hasPerformance = typeof performance !== 'undefined' && typeof performance.now === 'function';
function now() {
  if (hasPerformance) {
    return performance.now() + (performance.timeOrigin || performance.timing.navigationStart);
  } else {
    return Date.now();
  }
}
function consoleFactory(props, fn = () => EMPTY) {
  return props.reduce((obj, prop) => {
    obj[prop] = fn(prop);
    return obj;
  }, {});
}
function debugEnabled() {
  var wxConfig = __wxConfig || __webpack_require__.g.__wxConfig;
  if (!wxConfig || !('debug' in wxConfig) || typeof wxConfig.debug === 'undefined') return undefined;
  return !!wxConfig.debug;
}
function sinceTimeOrigin(time) {
  var timeOrigin = __wxConfig.coldLaunchTime || 0;
  if (timeOrigin > 1000) {
    return time - timeOrigin;
  } else {
    return time % 100000;
  }
}
var noop = () => {};

;// CONCATENATED MODULE: ./src/Foundation/console/wxConsole.ts

var props = ['log', 'info', 'warn', 'error', 'debug'];
var wxConsole = (() => {
  var ret = consoleFactory(props);
  wxRunOnDebug(() => {
    var getLineNumber = function () {
      var initiator = '';
      var e = new Error();
      if (typeof e.stack === 'string') {
        var isFirst = 0;
        var lines = e.stack.split('\n');
        for (var line of lines) {
          var matches = line.match(/^\s+at\s+(.*)/);
          if (matches) {
            if (isFirst++ === 3) {
              initiator = matches[1];
              break;
            }
          }
        }
      }
      return ' --> ' + (initiator.split(' ')[1] || initiator.split(' ')[0]);
    };
    ret = consoleFactory(props, method => function (...args) {
      if (IS_DEVTOOLS) {
        args.push(getLineNumber());
      }
      console[method]('[system]', ...args);
    });
  });
  return ret;
})();
/* harmony default export */ const console_wxConsole = (wxConsole);
;// CONCATENATED MODULE: ./src/Foundation/console/wxPerfConsole.ts


var wxPerfConsole_props = ['log', 'info', 'warn', 'error', 'profile', 'profileSync', 'traceBegin', 'traceEnd'];
var config = {
  longTaskThreshold: 50,
  verboseTrace: false
};
var wxPerfConsole = (() => {
  var ret = consoleFactory(wxPerfConsole_props);
  wxRunOnDebug(() => {
    var _log = function (method) {
      return function (...args) {
        console[method]('[perf]', env.typeStr, ...args);
      };
    };
    var userTimingSupportted = typeof performance !== 'undefined' && typeof performance.mark === 'function';
    var mark = function () {};
    var measure = function () {};
    if (userTimingSupportted) {
      mark = performance.mark.bind(performance);
      measure = performance.measure.bind(performance);
    }
    var innerId = 0;
    var traceEvents = [];
    function genTraceStack() {
      return traceEvents.map(evt => `[${evt.category}] ${evt.label}`).join('\n');
    }
    var perfConsole = {
      log: _log('log'),
      info: _log('info'),
      warn: _log('warn'),
      error: _log('error'),
      traceBegin(category, label, args) {
        traceEvents.push({
          category,
          label,
          args,
          t: now()
        });
      },
      traceEnd() {
        var endTime = now();
        var evt = traceEvents.pop();
        if (!evt) {
          perfConsole.error('Must call traceBegin before traceEnd', JSON.stringify(traceEvents));
          return;
        }
        var cost = endTime - evt.t;
        var logStr = `[profile][${evt.category}] ${evt.label} cost ${cost.toFixed(0)} ms (${sinceTimeOrigin(evt.t).toFixed(0)} ~ ${sinceTimeOrigin(endTime).toFixed(0)})`;
        if (cost >= config.longTaskThreshold) {
          perfConsole.warn(logStr, evt.args || '', `\n${genTraceStack()}`);
        } else if (config.verboseTrace) {
          perfConsole.log(logStr, evt.args || '');
        }
      },
      profile(tag, fun) {
        var id = tag + innerId++;
        mark(id + '_start');
        var start = now();
        fun();
        function done() {
          var end = now();
          mark(id + '_end');
          measure(tag, id + '_start', id + '_end');
          var cost = end - start;
          return Number.isInteger(cost) ? cost : parseFloat(cost.toFixed(2));
        }
        return done;
      },
      profileSync(tag, fun) {
        var id = tag + innerId++;
        mark(id + '_start');
        var start = now();
        var ret = fun();
        var end = now();
        mark(id + '_end');
        measure(tag, id + '_start', id + '_end');
        var cost = end - start;
        return {
          ret,
          cost: Number.isInteger(cost) ? cost : parseFloat(cost.toFixed(2))
        };
      }
    };
    ret = perfConsole;
  });
  return ret;
})();
/* harmony default export */ const console_wxPerfConsole = (wxPerfConsole);
;// CONCATENATED MODULE: ./src/Foundation/EventEmitter.ts
var EVT_ERR = Symbol('error');
var EVT_SLOW = Symbol('slow');
class EventEmitter {
  constructor() {
    this.$ = Object.create(null);
    this.$$ = Object.create(null);
  }
  onInternalEvent(event, cb) {
    var listeners = this.$$[event];
    if (listeners) {
      listeners.push(cb);
    } else {
      this.$$[event] = [cb];
    }
    return this;
  }
  emitPrivate(event, ...args) {
    var listeners = this.$$[event];
    if (listeners && listeners.length > 0) {
      listeners.forEach(cb => {
        try {
          cb(...args);
        } catch (e) {
          console.error('EventEmitter error:', e);
        }
      });
      return true;
    }
    return false;
  }
  onError(cb) {
    this.onInternalEvent(EVT_ERR, cb);
    return this;
  }
  onSlow(cb) {
    this.onInternalEvent(EVT_SLOW, cb);
    return this;
  }
  _privEmit(event, eventOptions, ...args) {
    var listeners = this.$[event];
    if (listeners && listeners.length > 0) {
      var needClean = false;
      var ret;
      for (var listener of listeners) {
        if (listener.count !== 0) {
          try {
            var t1 = Date.now(); // #@snapshot-ignore Date.now
            ret = listener.cb(...args);
            var t2 = Date.now(); // #@snapshot-ignore Date.now
            if (t2 - t1 > EventEmitter.SLOW_CALLBACK_THRESHOLD) {
              this.emitPrivate(EVT_SLOW, event, t1, t2, listener.cb);
            }
          } catch (e) {
            if (!this.emitPrivate(EVT_ERR, event, e)) {
              throw e;
            }
          }
        }
        if (listener.count > 0) listener.count--;
        if (listener.count === 0) needClean = true;
        if (ret === false && eventOptions.cancelable) break;
      }
      if (needClean) {
        this.$[event] = listeners.filter(l => l.count !== 0);
      }
      return true;
    }
    return false;
  }
  emit(event, ...args) {
    return this._privEmit(event, {}, ...args);
  }
  emitCancelable(event, ...args) {
    return this._privEmit(event, {
      cancelable: true
    }, ...args);
  }
  many(event, cb, count, options = {}) {
    if (!cb) return this;
    var listener = {
      count,
      cb
    };
    var listeners = this.$[event];
    if (listeners) {
      if (options.prepend) {
        listeners.unshift(listener);
      } else {
        listeners.push(listener);
      }
    } else {
      this.$[event] = [listener];
    }
    return this;
  }
  on(event, cb, options) {
    return this.many(event, cb, -1, options);
  }
  once(event, cb, options) {
    return this.many(event, cb, 1, options);
  }
  off(event, cb) {
    var listeners = this.$[event];
    if (!listeners) return false;
    var index = listeners.findIndex(it => it.cb === cb);
    if (index < 0) return false;
    listeners.splice(index, 1);
    return true;
  }
}
EventEmitter.SLOW_CALLBACK_THRESHOLD = 50;
;// CONCATENATED MODULE: ./src/Foundation/errorHandler.ts



var errorEmitter = new EventEmitter();
var EVT_UNHANDLED_ERROR = 'unhandlederror';
var EVT_UNHANDLED_REJ = 'unhandledrejection';
var EVT_FRAMEWORK_ERROR = 'frameworkerror';
var promiseMap = new WeakMap();
function processUnhandledRejectionNextTick(event) {
  var promise = event.promise;
  if (!promise) return;
  if (!promiseMap.has(promise)) {
    setTimeout(() => {
      var event = promiseMap.get(promise);
      if ((event === null || event === void 0 ? void 0 : event.type) === 0) {
        emitUnhandledRejection(event.reason, event.promise);
      }
      promiseMap.delete(promise);
    }, 0);
  }
  promiseMap.set(promise, event);
}
var hasOwn = Object.prototype.hasOwnProperty;
function convertToErrorObj(e) {
  var _e$constructor;
  if (e && ((_e$constructor = e.constructor) === null || _e$constructor === void 0 ? void 0 : _e$constructor.name) === 'Object') {
    if (typeof e.message === 'string' && typeof e.stack === 'string') {
      var error = new Error(e.message);
      Object.assign(error, e);
      return error;
    }
  }
  return e;
}
function emitUnhandledRejection(reason, promise) {
  reason = convertToErrorObj(reason);
  lifeCycle.onLoad(() => {
    if (!errorEmitter.emit(EVT_UNHANDLED_REJ, {
      reason,
      promise
    })) {
      console.error('Uncaught (in promise)', reason);
    }
  });
}
var inFrameworkErrorHandler = false;
var inUncaughtErrorHandler = false;
function emitFrameworkError(e, messagePrefix) {
  if (e instanceof Error && messagePrefix) {
    e.message = `${messagePrefix} fail: ${e.message}`;
  }
  e = convertToErrorObj(e);
  if (__wxConfig.isSnapshoting) {
    throw e;
  }
  lifeCycle.onLoad(() => {
    if (inFrameworkErrorHandler) {
      console.error('[ErrorHandler] recursive framework error detected.', e);
      return;
    }
    inFrameworkErrorHandler = true;
    try {
      if (!errorEmitter.emit(EVT_FRAMEWORK_ERROR, e)) {
        emitUnhandledError(e);
      }
    } catch (e) {
      console.error('Framework', e);
    }
    inFrameworkErrorHandler = false;
  });
}
function emitUnhandledError(e) {
  e = convertToErrorObj(e);
  if (__wxConfig.isSnapshoting) {
    throw e;
  }
  lifeCycle.onLoad(() => {
    if (inUncaughtErrorHandler) {
      console.error('[ErrorHandler] recursive uncaught error detected.', e);
      return;
    }
    inUncaughtErrorHandler = true;
    try {
      if (!errorEmitter.emit(EVT_UNHANDLED_ERROR, e)) {
        if ((__wxConfig.platform === 'windows' || __wxConfig.platform === 'mac') && typeof WORKER_RUNTIME !== 'undefined' && WORKER_RUNTIME && __wxConfig.appType === 4) {} else {
          console.error('Uncaught', e);
        }
      }
    } catch (e) {
      console.error('Uncaught', e);
    }
    inUncaughtErrorHandler = false;
  });
}
function onUnhandledRejection(cb) {
  errorEmitter.on(EVT_UNHANDLED_REJ, cb);
}
function onFrameworkError(cb) {
  errorEmitter.on(EVT_FRAMEWORK_ERROR, cb);
}
function onUnhandledError(cb) {
  errorEmitter.on(EVT_UNHANDLED_ERROR, cb);
}
;
(function bindErrorListener(global) {
  // #9307
  if (typeof global === 'object' && typeof global.addEventListener === 'function' && env.platform !== 'ios') {
    global.addEventListener('unhandledrejection', e => {
      emitUnhandledRejection(e.reason, e.promise);
      if (e.reason) e.preventDefault();
    });
    global.addEventListener('error', e => {
      var _global$navigator, _global$navigator$use;
      var error = e.error || {
        message: e.message,
        stack: `${e.message}\nEmpty stack, maybe muted error. (xweb=${((_global$navigator = global.navigator) === null || _global$navigator === void 0 ? void 0 : (_global$navigator$use = _global$navigator.userAgent) === null || _global$navigator$use === void 0 ? void 0 : _global$navigator$use.toUpperCase().indexOf('XWEB')) >= 0})`
      };
      emitUnhandledError(error);
      if (e.error) e.preventDefault();
    });
  } else if (typeof global.onunhandledrejection === 'undefined') {
    Object.defineProperty(global, 'onunhandledrejection', {
      value(e = {}) {
        if (hasOwn.call(e, 'type')) {
          processUnhandledRejectionNextTick({
            type: e.type,
            reason: e.reason,
            promise: e.promise
          });
        } else {
          emitUnhandledRejection(e.reason, e.promise);
        }
      }
    });
  }
})(__webpack_require__.g);

;// CONCATENATED MODULE: ./src/Foundation/wxConfig/utils.ts
var JSONParse = JSON.parse;
var JSONStringify = JSON.stringify;
var TIMESTAMP_OF_2001 = 978278400000;
function deepCopy(obj) {
  return JSONParse(JSONStringify(obj));
}
function convertToUnixTimestamp(time) {
  if (!time) return 0;
  var currentTimeZoneOffsetInHours = new Date().getTimezoneOffset() / 60;
  return time + TIMESTAMP_OF_2001 - currentTimeZoneOffsetInHours * 3600 * 1000;
}
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/filter.ts




function filterPropertiesOnCreate(wxConfig) {
  wxConfig.platform = env.platform;
  if (!wxConfig.brand && wxConfig.platform === 'ios') wxConfig.brand = 'iPhone';
  wxConfig.sdkVersion = wxConfig.SDKVersion = env.SDKVersion;
  wxConfig.isReady = false;
  wxConfig.onReady = lifeCycle.onStart;
}
function filterPropertiesOnLoad(wxConfig) {
  var _libVersionInfo__$de;
  filterPropertiesOnCreate(wxConfig);
  if (!env.isSubContext) wxConfig.preload = wxConfig.preload === true;
  if (typeof wxConfig.pixelRatio === 'number') {
    wxConfig.devicePixelRatio = wxConfig.pixelRatio;
  } else if (typeof wxConfig.devicePixelRatio === 'number') {
    wxConfig.pixelRatio = wxConfig.devicePixelRatio;
  }
  var overwriteExpt = (_libVersionInfo__$de = __libVersionInfo__.debugOptions) === null || _libVersionInfo__$de === void 0 ? void 0 : _libVersionInfo__$de['overwriteExpt'];
  if (overwriteExpt) {
    wxConfig.expt = Object.assign(wxConfig.expt || {}, overwriteExpt);
  } else {
    wxConfig.expt = wxConfig.expt || {};
  }
}
function filterPropertiesOnStart(wxConfig) {
  filterPropertiesOnLoad(wxConfig);
  wxConfig.isReady = true;
  wxConfig.appLaunchInfo = wxConfig.appLaunchInfo || {};
  wxConfig.preloadType = wxConfig.preloadType || wxConfig.appLaunchInfo.preloadType || wxConfig.preload;
  if (wxConfig.platform === 'ios') {
    var t1 = convertToUnixTimestamp(wxConfig.appLaunchInfo.clickTimestampInMs);
    var t2 = Number.MAX_SAFE_INTEGER;
    var instanceId = wxConfig.instanceId;
    if (instanceId) {
      try {
        var tsItems = instanceId.split('&').filter(item => item.indexOf('ts=') === 0);
        if (tsItems.length > 0) {
          t2 = parseInt(tsItems[0].slice(3), 10);
        }
      } catch (e) {
        emitFrameworkError(e, 'parseInstanceId');
      }
    }
    wxConfig.coldLaunchTime = Math.min(t1, t2);
  } else {
    wxConfig.coldLaunchTime = wxConfig.appLaunchInfo.clickTimestamp || 0;
  }
}
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/features.ts
var _libVersionInfo$featu;
var features_libVersionInfo = __libVersionInfo__;
var pruneWxConfigByPage = !!((_libVersionInfo$featu = features_libVersionInfo.features) !== null && _libVersionInfo$featu !== void 0 && _libVersionInfo$featu.pruneWxConfigByPage);
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/mockGlobal.ts


var defineProperty = Object.defineProperty;
var whiteList = ['env', 'appLaunchInfo', 'ext', 'wxAppInfo', 'debug', 'entryPagePath', 'envVersion', 'tabBar', 'pages', 'page', 'accountInfo', 'global', 'platform', 'system', 'appType', 'networkTimeout', 'navigateToMiniProgramAppIdList', 'plugins', 'extAppid', 'host', 'prerender'];
function defineWxConfigProperty(obj, _obj, key, value) {
  defineProperty(obj, key, {
    configurable: true,
    enumerable: true,
    get() {
      if (key in _obj) return _obj[key];
      try {
        if (typeof value !== 'function') return value;else return value();
      } catch (e) {
        emitFrameworkError(e, `read mock wxConfig.${key}`);
        return undefined;
      }
    },
    set(v) {
      _obj[key] = v;
    }
  });
}
function mockGloablWxConfig() {
  var originWxConfig = __webpack_require__.g.__wxConfig;
  var _safeWxConfig = {};
  var safeWxConfig = {};
  var publicPage = pruneWxConfigByPage ? {} : originWxConfig.page || {};
  try {
    defineWxConfigProperty(safeWxConfig, _safeWxConfig, 'deprecated', true);
    whiteList.forEach(key => {
      if (!(key in originWxConfig)) return;
      var value = originWxConfig[key];
      switch (key) {
        case 'page':
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, publicPage);
            break;
          }
        case 'env':
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, () => {
              console.warn('[Deprecation] __wxConfig.env is deprecated, please use wx.env instead.');
              return {
                USER_DATA_PATH: value.USER_DATA_PATH
              };
            });
            break;
          }
        case 'accountInfo':
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, {
              appId: value.appId,
              icon: value.icon,
              nickname: value.nickname
            });
            break;
          }
        case 'appLaunchInfo':
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, () => {
              console.warn('[Deprecation] __wxConfig.appLaunchInfo is deprecated, please use wx.getLaunchOptionsSync() instead.');
              if (wx && typeof wx.getLaunchOptionsSync === 'function') {
                return wx.getLaunchOptionsSync();
              } else {
                return {};
              }
            });
            break;
          }
        case 'wxAppInfo':
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, {
              maxRequestConcurrent: value.maxRequestConcurrent,
              maxUploadConcurrent: value.maxUploadConcurrent,
              maxDownloadConcurrent: value.maxDownloadConcurrent,
              maxWorkerConcurrent: value.maxWorkerConcurrent,
              maxWebsocketConnect: value.maxWebsocketConnect
            });
            break;
          }
        default:
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, value);
          }
      }
    });
    __webpack_require__.g.__wxConfig = safeWxConfig;
  } catch (e) {
    emitFrameworkError(e, 'mockGloablWxConfig');
    __webpack_require__.g.__wxConfig = originWxConfig;
  }
  return publicPage;
}
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/proxy.ts




var onLoadPattern = /^(.*XWeb.*|insert.*ToWebLayer|.*Skia.*)$/;
var allowLists = /* #__PURE__ */(() => {
  var onCreateAllowList = ['platform', 'brand', 'model', 'nativeBufferEnabled', 'isIsolateContext', 'workerContentType', 'isSnapshoting', 'host', 'SDKVersion', 'sdkVersion', 'isReady', 'debug', 'toJSON', 'supportWorkerMultiContext', 'supoortWorkerMultiContext', 'exportBaseMethods'];
  var onLoadAllowList = onCreateAllowList.concat(['JSEngineName', 'clientVersion', 'pixelRatio', 'devicePixelRatio', 'system', 'version', 'language', 'snapshotMetaInfo', 'preload', 'envPreloadType', 'env', 'clientDebug', 'jitMode', 'isWK', 'wmpfDirectInvokeJs']);
  return {
    onCreate: new Set(onCreateAllowList),
    onLoad: new Set(onLoadAllowList)
  };
})();
function useAccessProxy(wxConfig) {
  var enabled = true;
  return {
    proxy: new Proxy(wxConfig, {
      get(target, prop, receiver) {
        var value = Reflect.get(target, prop, receiver);
        if (!enabled || typeof prop !== 'string' || typeof value === 'function') return value;
        var currentPhase = target.currentPhase;
        if (currentPhase !== 'onCreate' && currentPhase !== 'onLoad') return value;
        var regardPhase = env.mayHaveSnapShot ? currentPhase : 'onLoad';
        if (allowLists[regardPhase].has(prop) || regardPhase === 'onLoad' && onLoadPattern.test(prop)) {
          return value;
        }
        var err = new Error(`[${env.typeStr}](TO:基础库开发同学) 在 ${currentPhase} 阶段访问 __wxConfig.${prop} 可能取不到值`); // #@exclude-stack-frame
        if (__wxConfig.platform === 'android' && err.stack && err.stack.split('\n').length <= 2) {
          return value;
        }
        if (typeof WORKER_RUNTIME !== 'undefined' && WORKER_RUNTIME) {
          return value;
        }
        emitFrameworkError(err);
        return undefined;
      }
    }),
    setEnabled(val) {
      enabled = val;
    },
    clone(obj) {
      var ret;
      if (enabled) {
        enabled = false;
        ret = deepCopy(obj);
        enabled = true;
      } else {
        ret = deepCopy(obj);
      }
      return ret;
    }
  };
}
var Array$isArray = Array.isArray;
var Reflect$set = Reflect.set;
var Reflect$get = Reflect.get;
function useSyncProxy(wxConfig) {
  return new Proxy(wxConfig, {
    set(target, prop, value, receiver) {
      if (prop === '__siblings__') {
        return Reflect$set(target, prop, value, receiver);
      }
      var siblings = Reflect$get(target, '__siblings__', receiver);
      if (Array$isArray(siblings)) {
        if (siblings.length > 1) {
          console_wxConsole.log(`[WXConfig] write __wxConfig.${prop.toString()}, sync to all contexts.`);
        }
        for (var i = 0; i < siblings.length; i++) {
          var obj = siblings[i];
          Reflect$set(obj, prop, value);
        }
        return true;
      } else {
        return Reflect$set(target, prop, value, receiver);
      }
    }
  });
}
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/trim.ts


function trimProperties(wxConfig, updatePage) {
  var _wxConfig$tabBar;
  if (Array.isArray(wxConfig === null || wxConfig === void 0 ? void 0 : (_wxConfig$tabBar = wxConfig.tabBar) === null || _wxConfig$tabBar === void 0 ? void 0 : _wxConfig$tabBar.list)) {
    wxConfig.tabBar.list.forEach(item => {
      delete item.iconData;
      delete item.selectedIconData;
    });
  }
  delete wxConfig.permission; // #5330 移除掉这个字段

  var subPackages = wxConfig.subPackages || wxConfig.subpackages;
  if (Array.isArray(subPackages) && subPackages.length > 0) {
    subPackages.forEach(pkg => {
      delete pkg.pages;
    });
    wxConfig.subPackages = wxConfig.subpackages = subPackages;
  }
  if (wxConfig.platform === 'devtools') {
    wxConfig.__globalComponentsCount = Object.keys(wxConfig.usingComponents || {}).length;
  }
  if (pruneWxConfigByPage) {
    if (!env.isSubContext) {
      delete wxConfig.usingComponents;
      Object.values(wxConfig.page || {}).forEach(value => {
        if (value !== null && value !== void 0 && value.window) delete value.window.usingComponents;
      });
      wxConfig._preloadRule = wxConfig.preloadRule || {};
      wxConfig._page = wxConfig.page || {};
      delete wxConfig.preloadRule;
      delete wxConfig.page;
    }
    wxConfig.updatePage = function (key, value) {
      if (value !== null && value !== void 0 && value.window) delete value.window.usingComponents;
      updatePage(key, value);
    };
    wxConfig.updatePreloadRule = function (key, value) {
      wxConfig.preloadRule = wxConfig.preloadRule || {};
      wxConfig.preloadRule[key] = value;
    };
  }
  __webpack_require__.g.__wxConfig.page = __webpack_require__.g.__wxConfig.page || {};
  wxConfig.page = wxConfig.page || {};
}
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/index.ts







var wxConfig_isSafeEnv = env.isSafeEnv;
var localWXConfig = Object.create(null);
var localWXConfigProxy = env.isService ? useSyncProxy(localWXConfig) : localWXConfig;
var setValidate = _val => {};
var _copyWXConfig = deepCopy;
wxRunOnDebug(() => {
  var {
    proxy,
    setEnabled,
    clone
  } = useAccessProxy(localWXConfigProxy);
  localWXConfigProxy = proxy;
  setValidate = setEnabled;
  _copyWXConfig = clone;
});
var EVT_UPDATE_PAGE = 'wxConfig:updatePage';
function handleWXConfigOnCreate(outerWxConfig) {
  localWXConfig.currentPhase = 'onCreate';
  if (typeof outerWxConfig === 'undefined') return localWXConfigProxy;
  setValidate(false);
  Object.assign(localWXConfig, wxConfig_isSafeEnv ? outerWxConfig : deepCopy(outerWxConfig));
  filterPropertiesOnCreate(localWXConfig);
  setValidate(true);
  return localWXConfigProxy;
}
function handleWXConfigOnLoad(outerWxConfig) {
  localWXConfig.currentPhase = 'onLoad';
  if (typeof outerWxConfig === 'undefined') return localWXConfigProxy;
  setValidate(false);
  Object.assign(localWXConfig, wxConfig_isSafeEnv ? outerWxConfig : deepCopy(outerWxConfig));
  localWXConfig.onPageUpdate = lifeCycle.on.bind(null, EVT_UPDATE_PAGE);
  filterPropertiesOnLoad(localWXConfig);
  setValidate(true);
  return localWXConfigProxy;
}
function handleWXConfigOnStart(outerWxConfig, useOuterWxConfig = false) {
  setValidate(false);
  localWXConfig.currentPhase = 'onStart';
  if (typeof outerWxConfig === 'undefined') return localWXConfigProxy;
  if (useOuterWxConfig) {
    Object.assign(localWXConfig, outerWxConfig);
    Object.defineProperty(localWXConfig, '__siblings__', {
      value: outerWxConfig.__siblings__,
      enumerable: false,
      writable: false,
      configurable: false
    });
  } else {
    Object.assign(localWXConfig, wxConfig_isSafeEnv ? outerWxConfig : deepCopy(outerWxConfig));
    filterPropertiesOnStart(localWXConfig);
    trimProperties(localWXConfig, (key, value) => {
      lifeCycle.emit(EVT_UPDATE_PAGE, {
        key,
        value
      });
    });
    Object.defineProperty(localWXConfig, '__siblings__', {
      value: [],
      enumerable: false,
      writable: false,
      configurable: false
    });
  }
  if (Array.isArray(localWXConfig.__siblings__)) {
    localWXConfig.__siblings__.push(localWXConfig);
  }
  var publicPage;
  localWXConfig.onPageUpdate(({
    key,
    value
  }) => {
    localWXConfig.page = localWXConfig.page || {};
    localWXConfig.page[key] = localWXConfig.page[key + '.html'] = value;
    if (publicPage) publicPage[key + '.html'] = deepCopy(value);
  });
  if (!wxConfig_isSafeEnv) {
    publicPage = mockGloablWxConfig();
  }
  return localWXConfigProxy;
}
function copyWXConfig(wxConfig) {
  return _copyWXConfig(wxConfig);
}
;// CONCATENATED MODULE: ./src/Foundation/lifeCycle.ts






var globalInnerEmitter = new EventEmitter();
var lifecycleEmitter = new EventEmitter();
var lifeCycleState = {};
var PHASE_BRIDGE_READY = 'WeixinJSBridgeReady';
var PHASE_LIBRARY_END = 'libraryEnd';
var PHASE_LIBRARY_LOAD = 'load';
var PHASE_LIBRARY_POST_LOAD = 'postLoad';
var PHASE_LIBRARY_START = 'start';
var PHASE_LIBRARY_POST_START = 'postStart';
function onLifeCycle(name, fun) {
  var doTrace = typeof Trace !== 'undefined';
  var fn = () => {
    try {
      if (doTrace) Trace.traceBegin('Framework', `LibLifeCycle.${name} @ ${env.fileName}`);
      fun(lifeCycleState[name]);
    } catch (e) {
      emitFrameworkError(e, 'LifeCycle.' + name);
    } finally {
      if (doTrace) Trace.traceEnd();
    }
  };
  if (name in lifeCycleState) fn();else lifecycleEmitter.once(name, fn);
}
function emitLifeCycle(name, data) {
  var _wxNativeConsole, _wxNativeConsole2;
  if (name in lifeCycleState) return false;
  lifeCycleState[name] = data;
  (_wxNativeConsole = wxNativeConsole) === null || _wxNativeConsole === void 0 ? void 0 : _wxNativeConsole.info(`[LifeCycle] emit ${name} for ${env.fileName}`);
  var ret = lifecycleEmitter.emit(name, data);
  (_wxNativeConsole2 = wxNativeConsole) === null || _wxNativeConsole2 === void 0 ? void 0 : _wxNativeConsole2.info(`[LifeCycle] finish ${name} for ${env.fileName}`);
  return ret;
}
var onLoad = cb => {
  if (!env.mayHaveSnapShot) {
    cb();
  } else {
    onLifeCycle(PHASE_LIBRARY_LOAD, cb);
  }
};
var lifeCycle = {
  EventEmitter: EventEmitter,
  on: globalInnerEmitter.on.bind(globalInnerEmitter),
  emit: globalInnerEmitter.emit.bind(globalInnerEmitter),
  once: globalInnerEmitter.once.bind(globalInnerEmitter),
  off: globalInnerEmitter.off.bind(globalInnerEmitter),
  getIsLoaded() {
    return PHASE_LIBRARY_LOAD in lifeCycleState;
  },
  getIsStarted() {
    return PHASE_LIBRARY_START in lifeCycleState;
  },
  onBridgeReady(cb) {
    onLifeCycle(PHASE_BRIDGE_READY, cb);
  },
  setWeixinJSBridge(WeixinJSBridge) {
    emitLifeCycle(PHASE_BRIDGE_READY, WeixinJSBridge);
  },
  onLibraryEnd: onLifeCycle.bind(null, PHASE_LIBRARY_END),
  onCreate(cb) {
    cb();
  },
  onLoadInstant: onLoad,
  onLoad,
  _onPostLoad: onLifeCycle.bind(null, PHASE_LIBRARY_POST_LOAD),
  onStart: onLifeCycle.bind(null, PHASE_LIBRARY_START),
  onPostStart: onLifeCycle.bind(null, PHASE_LIBRARY_POST_START)
};
lifecycleEmitter.onError((event, e) => {
  console_wxConsole.error(`[LifeCycle/${env.typeStr}] ${event.toString()} failed: `, e);
  emitFrameworkError(e, 'LifeCycle.' + event.toString());
}).onSlow((event, t1, t2, fun) => {
  console_wxPerfConsole.warn(`[LifeCycle/${env.typeStr}] slow ${event.toString()} callback (${t2 - t1}ms)\n${fun + ''}`);
});
__webpack_require__.g.__wxLibrary.onEnd = function () {
  emitLifeCycle(PHASE_LIBRARY_END);
  if (!env.mayHaveSnapShot) {
    emitOnLoad();
  }
};
__wxConfig = handleWXConfigOnCreate(__webpack_require__.g.__wxConfig);
var devLogWXConfig = [];
var isLoad = false;
var isStart = false;
function emitOnLoad() {
  if (!isLoad && !isStart) {
    isLoad = true;
    __wxConfig = handleWXConfigOnLoad(__webpack_require__.g.__wxConfig);
    wxRunOnDebug(() => {
      devLogWXConfig.push(['onLoad', copyWXConfig(__wxConfig)]);
    });
    emitLifeCycle(PHASE_LIBRARY_LOAD, __wxConfig);
    initOnStartEmitter();
    emitLifeCycle(PHASE_LIBRARY_POST_LOAD, __wxConfig);
  } else {
    emitFrameworkError(new Error(`LifeCycle error: undesired onLoad(${isLoad}/${isStart})`));
  }
}
function emitOnStart(outerWxConfig, useOuter = false) {
  if (isLoad && !isStart) {
    isStart = true;
    var readyStart = Date.now();
    __wxConfig = handleWXConfigOnStart(outerWxConfig, useOuter);
    if (!('onReadyStart' in __wxConfig)) {
      ;
      __wxConfig.onReadyStart = readyStart;
    }
    wxRunOnDebug(() => {
      devLogWXConfig.push(['onStart', useOuter ? '<use others>' : copyWXConfig(__wxConfig)]);
    });
    emitLifeCycle(PHASE_LIBRARY_START, __wxConfig);
    __wxConfig.onReadyEnd = Date.now();
    wxRunOnDebug(() => {
      devLogWXConfig.forEach(([tag, wxConfig]) => {
        console_wxConsole.info(`[wxConfig] ${env.typeStr}/${tag}\n`, wxConfig);
      });
      devLogWXConfig = [];
    });
    emitLifeCycle(PHASE_LIBRARY_POST_START, __wxConfig);
  } else {
    emitFrameworkError(new Error(`LifeCycle error: undesired onStart(${isLoad}/${isStart})`));
  }
}
function initOnStartEmitter() {
  if (env.isSubContext) {
    ;
    __wxConfig.__readyHandler = mainContextWxConfig => {
      emitOnStart(mainContextWxConfig, true);
    };
  } else if (__wxConfig.preload === true) {
    lifeCycle.onBridgeReady(bridge => {
      bridge.on('onWxConfigReady', () => {
        emitOnStart(__webpack_require__.g.__wxConfig);
      });
    });
  } else {
    lifeCycle.onLibraryEnd(() => {
      emitOnStart(__webpack_require__.g.__wxConfig);
    });
  }
}
if (__wxConfig.isSnapshoting) {
  if (!env.mayHaveSnapShot) {}
  ;
  __webpack_require__.g.WeixinSnapshot = {
    snapshotContextReady() {
      delete __webpack_require__.g.WeixinSnapshot;
      __wxConfig.isSnapshoting = false;
      emitOnLoad();
    }
  };
  wxRunOnDebug(() => {
    devLogWXConfig.push(['onCreate', copyWXConfig(__wxConfig)]);
  });
} else {
  if (env.mayHaveSnapShot) {
    lifeCycle.onLibraryEnd(emitOnLoad);
  }
}
;// CONCATENATED MODULE: ./src/Foundation/console/wxNativeConsole.ts




class Level {
  constructor(num, type, fn) {
    this.num = num;
    this.type = type;
    this.bindingFn = void 0;
    this.bindingFn = typeof fn === 'function' ? fn : noop;
  }
}
var LEVEL = {
  ALL: new Level(Number.MIN_VALUE, 'ALL'),
  DEBUG: new Level(5000, 'DEBUG', console.debug),
  LOG: new Level(10000, 'LOG', console.log),
  INFO: new Level(20000, 'INFO', console.info),
  WARN: new Level(30000, 'WARN', console.warn),
  ERROR: new Level(40000, 'ERROR', console.error),
  OFF: new Level(Number.MAX_VALUE, 'OFF')
};
var loggerFactory = (logFunc, category) => ({
  debug: logFunc(LEVEL.DEBUG, category),
  log: logFunc(LEVEL.LOG, category),
  info: logFunc(LEVEL.INFO, category),
  warn: logFunc(LEVEL.WARN, category),
  error: logFunc(LEVEL.ERROR, category)
});
var globalLogLevel = LEVEL.INFO;
wxRunOnDebug(() => {
  globalLogLevel = LEVEL.ALL;
});
var runOnMainContext = () => {
  var platform = env.platform;
  var LOG_INTERVAL = 4000;
  var LOG_LIMIT = 1024;
  var ENABLE_LOG_CACHE = platform !== 'android';
  var logCache = [];
  var _formatTime = function (d) {
    var M = ('0' + (d.getMonth() + 1)).slice(-2);
    var D = ('0' + d.getDate()).slice(-2);
    var h = ('0' + d.getHours()).slice(-2);
    var m = ('0' + d.getMinutes()).slice(-2);
    var s = ('0' + d.getSeconds()).slice(-2);
    var ms = ('00' + d.getMilliseconds()).slice(-3);
    var date = d.getFullYear() + '-' + M + '-' + D;
    var time = h + ':' + m + ':' + s + '.' + ms;
    if (platform === 'ios') {
      var offset = (d.getTimezoneOffset() / 6000 * -1).toFixed(4).replace(/^0\./, '+').replace(/-0\./, '-');
      return date + ' ' + time + '000' + offset;
    } else {
      var _offset = (d.getTimezoneOffset() / 60 * -1).toFixed(1).replace(/^(\d)/, '+$1');
      return date + ' ' + _offset + ' ' + time;
    }
  };
  var _systemLog = function (logs) {
    if (platform !== 'android') {
      WeixinJSBridge.invoke('systemLog', {
        dataArray: logs.map(item => ({
          message: `\n${_formatTime(item.date)} [${item.level.type[0].toUpperCase()}][wxapplib]] ${item.content}`
        })),
        noCallback: true
      });
    } else {
      logs.forEach(item => {
        item.level.bindingFn('[wxapplib]] ' + item.content);
      });
    }
  };
  var transformArg = item => {
    if (item instanceof Error) {
      return `${item.message}\n${item.stack}`;
    } else if (item && typeof item.stack === 'string' && typeof item.message === 'string') {
      return `${item.message}\n${item.stack}`;
    }
    switch (typeof item) {
      case 'bigint':
        return item.toString();
      case 'boolean':
        return item.toString();
      case 'function':
        return item.toString();
      case 'number':
        return item.toString();
      case 'string':
        return item;
      case 'symbol':
        return item.toString();
      case 'undefined':
        return 'undefined';
      case 'object':
        {
          var json;
          try {
            json = JSON.stringify(item);
          } catch (err) {
            json = '[对象含有循环引用]';
          }
          return json;
        }
      default:
        return undefined;
    }
  };
  var _log = function (level, category) {
    return function (...args) {
      if (category) {
        Array.prototype.unshift.call(args, '[' + category + ']');
      }
      if (debugEnabled() || level.num >= LEVEL.WARN.num) {
        var _level$type$toLowerCa;
        ;
        (_level$type$toLowerCa = console_wxConsole[level.type.toLowerCase()]) === null || _level$type$toLowerCa === void 0 ? void 0 : _level$type$toLowerCa.call(console_wxConsole, ...args);
      }
      if (level.num >= globalLogLevel.num) {
        var logData = Array.prototype.slice.call(args);
        var content = logData.map(transformArg).join(' ');
        if (ENABLE_LOG_CACHE) {
          var date = new Date();
          if (logCache && logCache.length > LOG_LIMIT) {
            logCache.shift();
          }
          logCache.push({
            date,
            level,
            content
          });
        } else {
          _systemLog([{
            level,
            content
          }]);
        }
      }
    };
  };
  lifeCycle.onStart(() => {
    setTimeout(function _submitLogs() {
      setTimeout(_submitLogs, LOG_INTERVAL);
      if (logCache.length === 0) {
        return;
      }
      _systemLog(logCache);
      logCache = [];
    }, LOG_INTERVAL);
  });
  function createLogger(category) {
    var cate = typeof category === 'string' ? category : 'default';
    return loggerFactory(_log, cate);
  }
  var __mergeSubContextLogs = logTasks => {
    if (!Array.isArray(logTasks)) {
      return;
    }
    logTasks.forEach(logTask => {
      var {
        level,
        logs,
        category
      } = logTask;
      _log(level, category)(...logs);
    });
  };
  return {
    ...loggerFactory(_log),
    createLogger,
    __mergeSubContextLogs,
    __isFromMainContext: true
  };
};
var runOnSubContext = () => {
  var penddingLogCache = [];
  var _penddingLog = (level, category) => (...logs) => {
    penddingLogCache.push({
      level,
      logs,
      category
    });
  };
  var createLogger = category => {
    var cate = typeof category === 'string' ? category : 'default';
    return loggerFactory(_penddingLog, cate);
  };
  var loopToMergeLogs = () => {
    var delayTime = 1000;
    var loopFunc = () => {
      var mergeLogs = wxNativeConsole.__isFromMainContext ? wxNativeConsole.__mergeSubContextLogs : null;
      if (mergeLogs) {
        mergeLogs(penddingLogCache);
        penddingLogCache = [];
      } else {
        loopToMergeLogs();
      }
    };
    setTimeout(loopFunc, delayTime);
  };
  lifeCycle.onStart(loopToMergeLogs);
  return {
    ...loggerFactory(_penddingLog),
    createLogger,
    __isFromMainContext: false
  };
};
var res = (() => {
  if (env.isWorker || env.isWidget || env.isMagicBrushFrameEnv) {
    var createLogger = function () {
      return console_wxConsole;
    };
    return Object.assign({
      createLogger
    }, console_wxConsole);
  } else if (!env.isSubContext || !env.isIsolateContext) {
    return runOnMainContext();
  } else {
    return runOnSubContext();
  }
})();
lifeCycle.onLoad(() => {
  res.info(`[BaseLibVersion] ${env.fileName}: ${__libVersionInfo__.version} (${__libVersionInfo__.updateTime})}`);
});
/* harmony default export */ const console_wxNativeConsole = (res);
;// CONCATENATED MODULE: ./src/Foundation/console/libConsole.ts

var libConsole_props = ['log', 'info', 'warn', 'error'];
var libConsole = consoleFactory(libConsole_props, method => function (...args) {
  if (!IS_DEVTOOLS && !debugEnabled()) return;
  console[method]('[system]', ...args);
});
/* harmony default export */ const console_libConsole = (libConsole);
;// CONCATENATED MODULE: ./src/Foundation/libGlobal/WebAssambly.ts

var wasm;
function getWebAssembly() {
  if (wasm) return wasm;
  if (typeof NativeGlobal !== 'undefined' && typeof NativeGlobal.WebAssembly !== 'undefined') {
    return NativeGlobal.WebAssembly;
  } else if (typeof globalThis.WebAssembly !== 'undefined') {
    return globalThis.WebAssembly;
  }
  return undefined;
}
lifeCycle.onLoad(() => {
  wasm = getWebAssembly();
});

;// CONCATENATED MODULE: ./src/Foundation/libGlobal/index.ts

var libGlobal = Object.create(null);
Object.defineProperty(libGlobal, 'WebAssembly', {
  enumerable: true,
  get: getWebAssembly
});
/* harmony default export */ const Foundation_libGlobal = (libGlobal);
;// CONCATENATED MODULE: ./src/Foundation/index.ts








var __global = __webpack_require__.g;
var Foundation = {
  env: env,
  global: __global,
  get isConfigReady() {
    return lifeCycle.getIsStarted();
  },
  get isStarted() {
    return lifeCycle.getIsStarted();
  },
  get isLoaded() {
    return lifeCycle.getIsLoaded();
  },
  ...lifeCycle,
  ...errorHandler_namespaceObject,
  wxConsole: console_wxConsole,
  wxPerfConsole: console_wxPerfConsole,
  wxNativeConsole: console_wxNativeConsole,
  libConsole: console_libConsole,
  libGlobal: Foundation_libGlobal,
  globalShare: {},
  callbackReporter: {}
};
if (typeof __Function__ !== 'undefined') {
  ;
  Function = function () {
    if (arguments[arguments.length - 1] === 'return this') return function () {
      return __global;
    };else return new __Function__(...arguments);
  };
  Function.prototype = __Function__.prototype;
}
/* harmony default export */ const src_Foundation = (Foundation);
})();

Foundation = __webpack_exports__["default"];
/******/ })()

var wxConsole = Foundation.wxConsole;
var wxPerfConsole = Foundation.wxPerfConsole;
var wxNativeConsole = Foundation.wxNativeConsole;
var libConsole = Foundation.libConsole;
var libGlobal = Foundation.libGlobal;;
var regeneratorRuntime;/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 26:
/***/ ((module) => {

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var runtime = function (exports) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
  function define(obj, key, value) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
    return obj[key];
  }
  try {
    // IE 8 has a broken Object.defineProperty that only works on DOM objects.
    define({}, "");
  } catch (err) {
    define = function (obj, key, value) {
      return obj[key] = value;
    };
  }
  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);
    return generator;
  }
  exports.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return {
        type: "normal",
        arg: fn.call(obj, arg)
      };
    } catch (err) {
      return {
        type: "throw",
        arg: err
      };
    }
  }
  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };
  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }
  var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction");

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function (method) {
      define(prototype, method, function (arg) {
        return this._invoke(method, arg);
      });
    });
  }
  exports.isGeneratorFunction = function (genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor ? ctor === GeneratorFunction ||
    // For the native GeneratorFunction constructor, the best we can
    // do is to check its .name property.
    (ctor.displayName || ctor.name) === "GeneratorFunction" : false;
  };
  exports.mark = function (genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      define(genFun, toStringTagSymbol, "GeneratorFunction");
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  exports.awrap = function (arg) {
    return {
      __await: arg
    };
  };
  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value && typeof value === "object" && hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function (value) {
            invoke("next", value, resolve, reject);
          }, function (err) {
            invoke("throw", err, resolve, reject);
          });
        }
        return PromiseImpl.resolve(value).then(function (unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function (error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }
    var previousPromise;
    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function (resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }
      return previousPromise =
      // If enqueue has been called before, then we want to wait until
      // all previous Promises have been resolved before calling invoke,
      // so that results are always delivered in the correct order. If
      // enqueue has not been called before, then it is important to
      // call invoke immediately, without waiting on a callback to fire,
      // so that the async generator function has the opportunity to do
      // any necessary setup in a predictable way. This predictability
      // is why the Promise constructor synchronously invokes its
      // executor callback, and why async functions synchronously
      // execute code before the first await. Since we implement simple
      // async functions in terms of async generators, it is especially
      // important to get this right, even though it requires care.
      previousPromise ? previousPromise.then(callInvokeWithMethodAndArg,
      // Avoid propagating failures to Promises returned by later
      // invocations of the iterator.
      callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }
  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  exports.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0) PromiseImpl = Promise;
    var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
    return exports.isGeneratorFunction(outerFn) ? iter // If outerFn is a generator, return the full iterator.
    : iter.next().then(function (result) {
      return result.done ? result.value : iter.next();
    });
  };
  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;
    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }
      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }
      context.method = method;
      context.arg = arg;
      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }
        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;
        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }
          context.dispatchException(context.arg);
        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }
        state = GenStateExecuting;
        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done ? GenStateCompleted : GenStateSuspendedYield;
          if (record.arg === ContinueSentinel) {
            continue;
          }
          return {
            value: record.arg,
            done: context.done
          };
        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;
      if (context.method === "throw") {
        // Note: ["return"] must be used for ES3 parsing compatibility.
        if (delegate.iterator["return"]) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);
          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }
        context.method = "throw";
        context.arg = new TypeError("The iterator does not provide a 'throw' method");
      }
      return ContinueSentinel;
    }
    var record = tryCatch(method, delegate.iterator, context.arg);
    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }
    var info = record.arg;
    if (!info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }
    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }
    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);
  define(Gp, toStringTagSymbol, "Generator");

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function () {
    return this;
  };
  Gp.toString = function () {
    return "[object Generator]";
  };
  function pushTryEntry(locs) {
    var entry = {
      tryLoc: locs[0]
    };
    if (1 in locs) {
      entry.catchLoc = locs[1];
    }
    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }
    this.tryEntries.push(entry);
  }
  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }
  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{
      tryLoc: "root"
    }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }
  exports.keys = function (object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };
  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }
      if (typeof iterable.next === "function") {
        return iterable;
      }
      if (!isNaN(iterable.length)) {
        var i = -1,
          next = function next() {
            while (++i < iterable.length) {
              if (hasOwn.call(iterable, i)) {
                next.value = iterable[i];
                next.done = false;
                return next;
              }
            }
            next.value = undefined;
            next.done = true;
            return next;
          };
        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return {
      next: doneResult
    };
  }
  exports.values = values;
  function doneResult() {
    return {
      value: undefined,
      done: true
    };
  }
  Context.prototype = {
    constructor: Context,
    reset: function (skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;
      this.method = "next";
      this.arg = undefined;
      this.tryEntries.forEach(resetTryEntry);
      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" && hasOwn.call(this, name) && !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },
    stop: function () {
      this.done = true;
      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }
      return this.rval;
    },
    dispatchException: function (exception) {
      if (this.done) {
        throw exception;
      }
      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;
        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }
        return !!caught;
      }
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;
        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }
        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");
          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }
          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }
          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }
          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },
    abrupt: function (type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }
      if (finallyEntry && (type === "break" || type === "continue") && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }
      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;
      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }
      return this.complete(record);
    },
    complete: function (record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }
      if (record.type === "break" || record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }
      return ContinueSentinel;
    },
    finish: function (finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },
    "catch": function (tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },
    delegateYield: function (iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };
      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }
      return ContinueSentinel;
    }
  };

  // Regardless of whether this script is executing as a CommonJS module
  // or not, return the runtime object so that we can declare the variable
  // regeneratorRuntime in the outer scope, which allows this module to be
  // injected easily by `bin/regenerator --include-runtime script.js`.
  return exports;
}(
// If this script is executing as a CommonJS module, use module.exports
// as the regeneratorRuntime namespace. Otherwise create a new empty
// object. Either way, the resulting object will be used to initialize
// the regeneratorRuntime variable at the top of this file.
 true ? module.exports : 0);
try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  // This module should not be running in strict mode, so the above
  // assignment should always work unless something is misconfigured. Just
  // in case runtime.js accidentally runs in strict mode, we can escape
  // strict mode using a global Function call. This could conceivably fail
  // if a Content Security Policy forbids using Function, but in that case
  // the proper solution is to fix the accidental strict mode problem. If
  // you've misconfigured your bundler to force strict mode and applied a
  // CSP to forbid Function, and you're not willing to fix either of those
  // problems, please detail your unique predicament in a GitHub issue.
  Function("r", "regeneratorRuntime = r")(runtime);
}

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/* global regeneratorRuntime, __wxConfig */
/**
 * 由于基础库在某个版本误将 regenerator-runtime 暴露给了开发者，且线上有小程序使用
 * 因此限制 regenerator-runtime 的使用，但不破坏线上小程序
 */
__webpack_require__(26);
var exportRegeneratorRuntime = () => {
  // 由于旧版 regenerator-runtime 会尝试直接使用全局挂载的 regeneratorRuntime，这里不能加上报和报错 TAT
  var r = {};
  Object.keys(regeneratorRuntime).forEach(e => {
    Object.defineProperty(r, e, {
      configurable: true,
      enumerable: true,
      get() {
        return regeneratorRuntime[e];
      },
      set(t) {
        delete r[e];
        r[e] = t;
      }
    });
  });
  globalThis.regeneratorRuntime = r;
};
if (typeof __wxConfig.onReady === 'function') {
  __wxConfig.onReady(config => {
    if (config.platform === 'devtools' || ['develop', 'trial'].includes(config.envVersion)) {
      // 工具以及体验版、开发版小程序，不提供 regeneratorRuntime
      // 由于本文件的 regeneratorRuntime 来自于编译时注入的闭包变量，不挂到 globalThis 上就行了
    } else {
      // 正式版小程序，regenerator-runtime 正常提供
      exportRegeneratorRuntime();
    }
  });
} else {
  exportRegeneratorRuntime();
}
})();

/******/ })()
;
var __wxModule__;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  define: () => (/* reexport */ define_mini_define),
  require: () => (/* reexport */ require_require),
  requireOnce: () => (/* reexport */ requireOnce)
});

;// CONCATENATED MODULE: ./src/external.js
var getGlassEaselAdapter = () => __glassEaselAdapter__;
;// CONCATENATED MODULE: ./src/utils.ts

var extendedLibs = ['wx0354ba48aadc0ab2', 'wxfa43a4a7041a84de'];
var isDevTool = () => __wxConfig.platform === 'devtools';
var loadSubPackage = (subPackage, cb) => {
  var isMainPackage = subPackage === '__APP__';
  if (!isMainPackage && subPackage.slice(-1) !== '/') subPackage += '/';
  if (isDevTool()) {
    setTimeout(() => {
      wxNativeConsole.info(`[WxModule] injectSubPackages: ${subPackage}`);
      WeixinJSBridge.invoke('injectSubPackages', {
        subPackages: [subPackage]
      }, cb);
    });
  } else {
    wxNativeConsole.info(`[WxModule] loadSubpackage: ${subPackage}`);
    __appServiceSDK__.loadSubpackage({
      name: subPackage,
      success() {
        var config = __wxConfig.subPackages.find(p => p.root === subPackage || p.root === subPackage.slice(0, -1));
        var plugins = Object.assign({}, config === null || config === void 0 ? void 0 : config.plugins);
        isMainPackage && Object.assign(plugins, __wxConfig.plugins);
        var separatedPlugins = Object.keys(plugins || {}).map(k => {
          var pluginId = plugins[k].provider;
          var prefix = '__plugin__/' + pluginId;
          return {
            plugin_id: pluginId,
            prefix_path: extendedLibs.includes(pluginId) ? null : prefix
          };
        });
        __subContextEngine__.injectEntryFile(isMainPackage ? '' : subPackage, separatedPlugins);
        var env = getGlassEaselAdapter().getEnv();
        env.codeManager.setSubPackageLoaded([subPackage]);
        env.afterPackageCommonEvaluation();
        cb({
          errMsg: 'loadSubPackage:ok',
          loaded: true
        });
      },
      fail() {
        wxNativeConsole.error(`[WxModule] loadSubPackage fail ${subPackage}`);
        cb({
          errMsg: 'loadSubPackage:false',
          loaded: false
        });
      }
    });
  }
};
var matchSubPackageByPlugin = pluginId => {
  var subPackages = __wxConfig.subPackages || [];
  var _loop = function (i) {
    if (!subPackages[i].plugins) return "continue";
    var pluginAlias = Object.keys(subPackages[i].plugins).find(alias => subPackages[i].plugins[alias].provider === pluginId);
    if (pluginAlias) {
      var prefix = subPackages[i].root || '';
      if (prefix && prefix.slice(-1) !== '/') {
        prefix += '/';
      }
      return {
        v: prefix
      };
    }
  };
  for (var i = 0; i < subPackages.length; ++i) {
    var _ret = _loop(i);
    if (_ret === "continue") continue;
    if (typeof _ret === "object") return _ret.v;
  }
  return '__APP__';
};
var matchSubPackageByPath = route => {
  var _wxConfig$subPackage, _wxConfig;
  var subPackages = (_wxConfig$subPackage = (_wxConfig = __wxConfig) === null || _wxConfig === void 0 ? void 0 : _wxConfig.subPackages) !== null && _wxConfig$subPackage !== void 0 ? _wxConfig$subPackage : [];
  for (var i = 0; i < subPackages.length; ++i) {
    var prefix = subPackages[i].root || '';
    if (prefix && prefix.slice(-1) !== '/') {
      prefix += '/';
    }
    if (route.slice(0, prefix.length) === prefix) {
      return {
        subPackage: prefix,
        independent: !!subPackages[i].independent
      };
    }
  }
  return {
    subPackage: '__APP__',
    independent: false
  };
};
var isAppId = schema => schema.match(/^wx[0-9a-f]{16}$/) !== null;
var splitPath = path => {
  var realPath = [];
  var paths = path.split('/');
  for (var i = 0, len = paths.length; i < len; ++i) {
    var pathItem = paths[i];
    if (pathItem === '' || pathItem === '.') {
      continue;
    }
    if (pathItem === '..') {
      if (realPath.length === 0) {
        realPath = [];
        break;
      }
      realPath.pop();
    } else if (i + 1 < len && paths[i + 1] === '..') {
      i++;
    } else {
      realPath.push(pathItem);
    }
  }
  return realPath;
};
var cacheResult = fn => {
  var res;
  var executed = false;
  return (...args) => {
    if (!executed) {
      res = fn(...args);
      executed = true;
    }
    return res;
  };
};
;// CONCATENATED MODULE: ./src/Constants.ts
var ModuleLoadStatus = {
  UNLOAD: 1,
  LOADED: 2
};

;// CONCATENATED MODULE: ./src/modules.ts
var modules = {};
var setModule = (pluginId, module) => {
  modules[pluginId] = module;
};
var getModule = pluginId => modules[pluginId];
var getAllModules = () => Object.keys(modules);
;// CONCATENATED MODULE: ./src/require-block.ts

class RequireBlocker {
  constructor(scope) {
    this._$requireQueues = null;
    this._$blockingStatus = 0;
    this._$scope = void 0;
    this._$err = msg => new Error(`Framework inner error: ${msg} (scope: ${this._$scope}, status: ${this._$blockingStatus})`);
    this._$scope = scope;
  }
  isBlocking() {
    return this._$blockingStatus === 1;
  }
  block() {
    if (isDevTool()) return;
    if (this._$blockingStatus === 0) {
      this._$requireQueues = [];
      this._$blockingStatus = 1;
    } else if (this._$blockingStatus === 2) {
      this._$blockingStatus = 1;
    } else throw this._$err('trying to block require at wrong time');
  }
  queue(fn, args) {
    if (!this.isBlocking()) throw this._$err('trying to queue an require when not blocking');
    this._$requireQueues.push([fn, args]);
  }
  unblock() {
    if (isDevTool()) return;
    if (!this.isBlocking()) throw this._$err('trying to unblock require queue when not blocking');
    this._$blockingStatus = 2;
  }
  flushQueue() {
    if (isDevTool()) return;
    if (this._$blockingStatus !== 2) throw this._$err('require queue flushing must be unblocked');
    var queue = this._$requireQueues;
    this._$blockingStatus = 0;
    this._$requireQueues = null;
    queue.forEach(entry => {
      try {
        entry[0].apply(null, entry[1]);
      } catch (e) {
        console.error(`Error during evaluating file "${entry[1][0]}": `);
        console.error(e.message);
        console.error(e.stack);
      }
    });
  }
}
var globalRequireBlocker = new RequireBlocker('/');
;// CONCATENATED MODULE: ./src/alias.ts
var WX_MODULE_VERSION = 2;
if (globalThis.wxModuleVersion) {
  var prevVersion = ~~globalThis.wxModuleVersion;
  globalThis.enableWxModule = WX_MODULE_VERSION > prevVersion;
} else {
  globalThis.wxModuleVersion = WX_MODULE_VERSION;
  globalThis.enableWxModule = true;
}
var useAlias = false;
var aliasConfig = [];
var normalizeAlias = aliasMap => {
  Object.keys(aliasMap).forEach(key => {
    var normalizedKey = key;
    if (key.endsWith('*')) {
      normalizedKey = normalizedKey.slice(0, -1);
    }
    var normalizedValue = aliasMap[key];
    if (aliasMap[key].endsWith('*')) {
      normalizedValue = normalizedValue.slice(0, -1);
    }
    aliasConfig.push({
      key: normalizedKey,
      value: normalizedValue
    });
  });
};
if (typeof __wxConfig.onReady === 'function') {
  __wxConfig.onReady(() => {
    if (typeof __wxConfig.resolveAlias === 'object') {
      useAlias = !!Object.keys(__wxConfig.resolveAlias).length;
      useAlias && normalizeAlias(__wxConfig.resolveAlias);
    }
  });
} else {
  if (typeof __wxConfig.resolveAlias === 'object') {
    useAlias = !!Object.keys(__wxConfig.resolveAlias).length;
    useAlias && normalizeAlias(__wxConfig.resolveAlias);
  }
}
var isUsingAlias = () => useAlias;
var resolveAlias = requireId => {
  var longestMatched = {
    key: '',
    value: ''
  };
  var matched = false;
  aliasConfig.forEach(item => {
    if (requireId.startsWith(item.key) && longestMatched.key.length < item.key.length) {
      longestMatched = item;
      matched = true;
    }
  });
  if (!matched) {
    return;
  }
  var ret = requireId.replace(longestMatched.key, longestMatched.value);
  if (ret[0] === '/') {
    ret = ret.slice(1);
  }
  return ret;
};
;// CONCATENATED MODULE: ./src/global-flags.ts
class GlobalFlagsManager {
  constructor(flagGlobal) {
    this._$flags = {};
    this._$global = void 0;
    this.fileStacks = [];
    this._$global = flagGlobal;
  }
  current() {
    return {
      __wxRoute: this._$global.__wxRoute,
      __wxAppCurrentFile__: this._$global.__wxAppCurrentFile__,
      __wxRouteBegin: this._$global.__wxRouteBegin
    };
  }
  restore(flag) {
    if (flag === undefined) return;
    this._$global.__wxRoute = flag.__wxRoute;
    this._$global.__wxAppCurrentFile__ = flag.__wxAppCurrentFile__;
    this._$global.__wxRouteBegin = flag.__wxRouteBegin;
  }
  saveAndClear(path) {
    if (this._$flags[path] !== undefined) return;
    this._$flags[path] = this.current();
    this._$global.__wxRoute = '';
    this._$global.__wxAppCurrentFile__ = '';
    this._$global.__wxRouteBegin = '';
  }
  runWith(path, fn) {
    this.restore(this._$flags[path]);
    this.fileStacks.push(this._$flags[path]);
    var hasErr = false;
    var err;
    try {
      fn();
    } catch (e) {
      hasErr = true;
      err = e;
    }
    this.fileStacks.pop();
    this.restore(this.fileStacks[this.fileStacks.length - 1]);
    if (hasErr) throw err;
  }
}
;// CONCATENATED MODULE: ./src/require.ts






var notCacheScripts = {};
var getModDir = modId => {
  var match = modId.match(/(.*)\/([^/]+)?$/);
  return !(match !== null && match !== void 0 && match[1]) ? './' : match[1];
};
var getSubPackageConfig = dir => {
  if (!dir) {
    return undefined;
  }
  if (__wxConfig.subPackages) {
    for (var i = 0, len = __wxConfig.subPackages.length; i < len; i++) {
      if (dir.indexOf(__wxConfig.subPackages[i].root) === 0) {
        return __wxConfig.subPackages[i];
      }
    }
  }
  return undefined;
};
var checkNodeModulesFile = dirPath => {
  var requirePath = splitPath(dirPath + '/index.js').join('/');
  if (getModule(requirePath)) return requirePath;
  requirePath = splitPath(dirPath).join('/');
  if (!/\.js$/.test(requirePath)) requirePath += '.js';
  if (getModule(requirePath)) return requirePath;
  return '';
};
var checkNodeModules = (modId, modDir, requireId) => {
  var id = modId;
  if (!/\.js$/.test(id)) id += '.js';
  if (typeof id === 'string' && getModule(id)) return id;
  var realDirpath = splitPath(modDir);
  if (!realDirpath) throw new Error('can not find module : ' + requireId);
  var modRelativePath = modId.substring(realDirpath.join('/').length);
  var requirePath;
  var dirPath;
  while (realDirpath.length) {
    dirPath = realDirpath.join('/') + '/miniprogram_npm' + modRelativePath;
    requirePath = checkNodeModulesFile(dirPath);
    if (requirePath) break;
    realDirpath.pop();
  }
  if (!requirePath) {
    modRelativePath = modRelativePath[0] === '/' ? modRelativePath : '/' + modRelativePath;
    dirPath = 'miniprogram_npm' + modRelativePath;
    requirePath = checkNodeModulesFile(dirPath);
  }
  return requirePath || modId;
};
var _require = modId => {
  var modDir = getModDir(modId);
  var innerRequire = function (requireId, resolveCb, rejectCb) {
    var _modDir = modDir;
    if (typeof requireId !== 'string') {
      throw new Error('require args must be a string');
    }
    var realFilepath;
    if (requireId === '/__wx__/private-api') {
      realFilepath = splitPath(requireId).join('/');
    } else {
      if (isUsingAlias()) {
        realFilepath = resolveAlias(requireId);
      }
      if (realFilepath !== undefined) {
        _modDir = '';
        realFilepath = splitPath(realFilepath).join('/');
      } else {
        realFilepath = splitPath(_modDir + '/' + requireId).join('/');
      }
    }
    if (!realFilepath) throw new Error(`can not find module : ${realFilepath}, require args is ${requireId}`);
    try {
      var id = checkNodeModules(realFilepath, _modDir, requireId);
      var inFunctionalPage = id => splitPath(id)[0] === 'functional-pages';
      if (inFunctionalPage(id) !== inFunctionalPage(modId)) {
        Reporter.thirdErrorReport({
          error: new Error(`should not require across "functional-pages" folder, at require("${requireId}") in ${modId}`)
        });
      }
      if (__wxConfig.platform === 'devtools' && __wxConfig.subPackages && resolveCb === undefined) {
        var distConfig = getSubPackageConfig(id);
        var srcConfig = getSubPackageConfig(modId);
        if (distConfig && distConfig !== srcConfig) {
          console.warn(`Requires "${requireId}" from "${modId}" without a callback may fail in production, since they are in different subPackages`);
        }
      }
      return require_require(id, undefined, resolveCb, requireId, modDir, rejectCb);
    } catch (e) {
      throw e;
    }
  };
  innerRequire.async = requireId => new Promise((resolve, reject) => {
    try {
      innerRequire(requireId, resolve, reject);
    } catch (e) {
      reject(e);
    }
  });
  return innerRequire;
};
var globalFlagManager = new GlobalFlagsManager(globalThis);
function require_require(modId, cache, resolveCb, alias = '', modDir, rejectCb) {
  if (!isDevTool() && globalRequireBlocker.isBlocking()) {
    globalFlagManager.saveAndClear(modId);
    globalRequireBlocker.queue(require_require, [modId, cache, resolveCb, alias, modDir, rejectCb]);
    return;
  }
  if (typeof cache === 'undefined') {
    cache = true;
  }
  if (typeof modId !== 'string') {
    throw new Error('require args must be a string');
  }
  var mod = getModule(modId);
  if (!mod) {
    var rootModId = modId.indexOf('/') === -1 ? modId + '/index.js' : modId;
    rootModId = 'miniprogram_npm/' + rootModId;
    if (!/\.js$/.test(rootModId)) rootModId += '.js';
    mod = getModule(rootModId);
  }
  if (!modId.endsWith('.js')) modId += '.js';
  if (!mod && __wxConfig.platform !== 'devtools' && typeof __subContextEngine__ !== 'undefined' && __wxConfig.isLazyLoad) {
    var component = modId.slice(0, modId.length - 3);
    var chunk = typeof __LAZY_CODE_LOADING_CHUNK_MAP__ !== 'undefined' && typeof __LAZY_CODE_LOADING_CHUNK_MAP__[component] === 'string' ? __LAZY_CODE_LOADING_CHUNK_MAP__[component] : component;
    var fileName = `${chunk}.appservice.js`;
    var resultReporter = __subContextEngine__.loadJsFiles([fileName], null, {
      waitResult: true,
      reportKey: `webnode-require-${modId.slice(0, modId.length - 3)}`
    });
    mod = getModule(modId);
    resultReporter === null || resultReporter === void 0 ? void 0 : resultReporter(!!mod);
  }
  if (typeof resolveCb === 'function') {
    var rejectCbWrapper = e => {
      var errMsg = 'async require: fail';
      if (typeof e === 'object' && e && e.message) {
        errMsg = e.message;
      }
      rejectCb === null || rejectCb === void 0 ? void 0 : rejectCb({
        errMsg,
        mod: modId
      });
    };
    var requireSurroundError = function (...args) {
      try {
        var _ret = require_require(...args);
        resolveCb(_ret);
      } catch (e) {
        rejectCbWrapper(e);
      }
    };
    if (mod) {
      setTimeout(() => requireSurroundError(modId));
    } else {
      var selfIsIndependent = typeof modDir === 'string' ? matchSubPackageByPath(modDir).independent : false;
      var {
        subPackage,
        independent
      } = matchSubPackageByPath(modId);
      if (!independent && selfIsIndependent) {
        loadSubPackage('__APP__', res => {
          if (res && res.loaded === false) {
            rejectCbWrapper(new Error(`loadSubPackage: fail, subPackage: __APP__`));
            return;
          }
          if (subPackage === '__APP__') {
            resolveCb(requireSurroundError(modId));
            return;
          }
          loadSubPackage(subPackage, res => {
            if (res && res.loaded === false) {
              rejectCbWrapper(new Error(`loadSubPackage: fail, subPackage: ${subPackage}`));
            } else {
              requireSurroundError(modId);
            }
          });
        });
      } else {
        loadSubPackage(subPackage, res => {
          if (res && res.loaded === false) {
            rejectCbWrapper(new Error(`loadSubPackage: fail, subPackage: ${subPackage}`));
          } else {
            requireSurroundError(modId);
          }
        });
      }
    }
    return;
  }
  if (!mod) {
    var errMsg = `module '${modId}' is not defined, require args is '${alias === '' ? modId : alias}'`;
    throw new Error(errMsg);
  }
  var mModule = {
    exports: {}
  };
  var factory = mod.factory;
  if (!cache || notCacheScripts[modId]) {
    delete mod.exports;
    mod.status = ModuleLoadStatus.UNLOAD;
    notCacheScripts[modId] = true;
    if (isDevTool()) globalFlagManager.saveAndClear(modId);
    globalFlagManager.runWith(modId, () => {
      factory === null || factory === void 0 ? void 0 : factory(_require(modId), mModule, mModule.exports);
    });
    return mModule.exports;
  }
  if (mod.status === ModuleLoadStatus.UNLOAD) {
    mod.exports = mModule.exports;
    mod.status = ModuleLoadStatus.LOADED;
    if (isDevTool()) globalFlagManager.saveAndClear(modId);
    var _ret2;
    try {
      globalFlagManager.runWith(modId, () => {
        factory && (_ret2 = factory(_require(modId), mModule, mModule.exports));
      });
    } catch (e) {
      mod.status = ModuleLoadStatus.UNLOAD;
      throw e;
    }
    mod.exports = mModule.exports !== undefined ? mModule.exports : _ret2;
  }
  return mod.exports;
}
function requireOnce(modId) {
  return require_require(modId, false);
}
;// CONCATENATED MODULE: ./src/define-mini.ts


function define_mini_define(modId, factory) {
  var factoryExists = getModule(modId) && !!getModule(modId).factory;
  if (factoryExists) {
    var oldFactory = getModule(modId).factory;
    if (factory.toString() === oldFactory.toString()) return;
  }
  setModule(modId, {
    status: ModuleLoadStatus.UNLOAD,
    factory
  });
}
;// CONCATENATED MODULE: ./src/index-mini.ts


__wxModule__ = __webpack_exports__;
/******/ })()
;var defineMiniProgramFile = globalThis.define = __wxModule__.define;var requireMiniProgramFile = globalThis.require = __wxModule__.require;globalThis.requireOnce = __wxModule__.requireOnce;;
var JSContext;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ index_sub)
});

;// CONCATENATED MODULE: ./src/Utils.js
var ObjToString = Object.prototype.toString;
var ObjGetProto = Object.getPrototypeOf;
var ObjGetPropNames = Object.getOwnPropertyNames;
var ObjGetPropDesc = Object.getOwnPropertyDescriptor;
var ObjDefProp = Object.defineProperty;
var getDataType = data => ObjToString.call(data).split(' ')[1].split(']')[0];
var getAllPropertyDescs = obj => {
  var properties = [];
  var _loop = function (o) {
    var props = ObjGetPropNames(o);
    props.forEach(prop => {
      var desc = ObjGetPropDesc(o, prop);
      if (desc !== undefined) {
        desc.name = prop;
        properties.push(desc);
      }
    });
  };
  for (var o = obj; o; o = ObjGetProto(o)) {
    _loop(o);
  }
  return properties;
};
;// CONCATENATED MODULE: ./src/Context/SubJSContext.js

var subscribeCbs = Object.create(null);
var jsContext;
var crossVMContext;
var subContextId;
var Array$isArray = Array.isArray;
var Array$$push = Function.prototype.call.bind(Array.prototype.push);
var subscribeHandler = (token, event, result = {}) => {
  if (token === undefined || token !== jsContext) {
    return undefined;
  }
  if (Array$isArray(subscribeCbs[event])) {
    if (crossVMContext) {
      setTimeout(() => {
        for (var i = 0; i < subscribeCbs[event].length; i++) {
          subscribeCbs[event][i](result);
        }
      });
      return;
    }
    for (var i = 0; i < subscribeCbs[event].length; i++) {
      subscribeCbs[event][i](result);
    }
  }
  return undefined;
};
var innerContext = {
  subscribeHandler
};
Foundation.onLoadInstant(() => {
  subContextId = __webpack_require__.g.WeixinJSContextId; // #@snapshot-ignore WeixinJSContextId
});

var __init__ = (context, contextId) => {
  if (jsContext !== undefined || context === undefined) {
    return;
  }
  jsContext = context;
  jsContext.register(context, innerContext, contextId);
  crossVMContext = jsContext.crossVMContext;
};
var publish = (event, params = {}) => {
  var dataType = getDataType(params);
  if (dataType !== 'Object' && dataType !== 'Undefined') {
    throw new Error('params should be an object.');
  }
  var _event = event.valueOf();
  var _params = params || {};
  if (jsContext && typeof jsContext.subscribeHandler === 'function') {
    return jsContext.subscribeHandler(jsContext, innerContext, _event, _params);
  }
  return undefined;
};
var subscribe = (event, callback) => {
  var _jsContext, _jsContext2;
  if (!Array$isArray(subscribeCbs[event])) subscribeCbs[event] = [];
  Array$$push(subscribeCbs[event], callback);
  if ((_jsContext = jsContext) !== null && _jsContext !== void 0 && _jsContext.waitingChannel && (_jsContext2 = jsContext) !== null && _jsContext2 !== void 0 && _jsContext2.waitingChannel[subContextId]) {
    var newWaitingChannel = [];
    jsContext.waitingChannel[subContextId].forEach(ev => {
      var {
        event: e,
        params
      } = ev;
      if (e === event) {
        callback(params);
      } else {
        newWaitingChannel.push(ev);
      }
    });
    jsContext.waitingChannel[subContextId] = newWaitingChannel;
  }
};
var exportContext = {
  __init__,
  publish,
  subscribe
};
if (false) {}
/* harmony default export */ const SubJSContext = (exportContext);
;// CONCATENATED MODULE: ./src/index-sub.js

var index_sub_jsContext = SubJSContext;
Foundation.onLoad(() => {
  if (typeof WeixinJSContext === 'undefined') {
    return;
  }
  index_sub_jsContext.__init__(WeixinJSContext, __webpack_require__.g.WeixinJSContextId);
  delete index_sub_jsContext.__init__;
  delete __webpack_require__.g.WeixinJSContext;
  delete __webpack_require__.g.WeixinJSContextId;
});
/* harmony default export */ const index_sub = (index_sub_jsContext);
JSContext = __webpack_exports__["default"];
/******/ })()
;
var Protect;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 342:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EnvPreloadType: () => (/* binding */ EnvPreloadType),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   updateConfig: () => (/* binding */ updateConfig)
/* harmony export */ });
var EnvPreloadType = {
  None: 0,
  BeforeLaunch: 1,
  AfterLaunch: 2
};
var updateConfig = () => {
  if (WXConfig !== __wxConfig && typeof WXConfig !== 'undefined') {
    Object.assign(WXConfig, __wxConfig);
  }
};
var WXConfig = /* #__PURE__ */(() => {
  __wxConfig.onReady(updateConfig);
  return __wxConfig;
})();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WXConfig);

/***/ }),

/***/ 476:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  reportDeprecatedAPI: () => (/* binding */ reportDeprecatedAPI)
});

// EXTERNAL MODULE: ./src/base/WXConfig.ts
var WXConfig = __webpack_require__(342);
;// CONCATENATED MODULE: ./src/base/lib.js
var libVersion = typeof __libVersionInfo__ !== 'undefined' && __libVersionInfo__ ? __libVersionInfo__.version : 'unknown';
var libUpdateTime = typeof __libVersionInfo__ !== 'undefined' && __libVersionInfo__ ? __libVersionInfo__.updateTime : 'unknown';
if (typeof libVersion === 'string') {
  libVersion = libVersion.replace(' ', '');
}
if (typeof libUpdateTime === 'string') {
  libUpdateTime = libUpdateTime.replace(' ', '-');
}
var getLibVersionStr = () => libVersion;
var getLibUpdateTimeStr = () => libUpdateTime;

;// CONCATENATED MODULE: ./src/baseService/report/reportDeprecatedAPI.js


var reportDeprecatedAPI = (name = '') => {
  name = name.replace(/,/g, ';');
  var LibVersion = getLibVersionStr() + ' ' + getLibUpdateTimeStr();
  var AppType = WXConfig["default"].appType;
  Reporter.reportKeyValue({
    key: 'DeprecatedAPI',
    value: [name, LibVersion, AppType].join(',')
  });
};


/***/ }),

/***/ 996:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var {
  reportDeprecatedAPI
} = __webpack_require__(476);
var {
  default: WXConfig
} = __webpack_require__(342);
function hijackWasm() {
  if (typeof WebAssembly !== 'undefined') {
    var FIELDS_NEED_HOOK = ['compile', 'compileStreaming', 'instantiate', 'instantiateStreaming', 'validate', 'Module'];
    FIELDS_NEED_HOOK.forEach(fieldName => {
      if (typeof WebAssembly[fieldName] === 'undefined') return;
      var ori = WebAssembly[fieldName];
      Object.defineProperty(WebAssembly, fieldName, {
        get: () => {
          reportDeprecatedAPI('globalWa');
          return ori;
        },
        set: value => {
          Object.defineProperty(WebAssembly, fieldName, {
            value,
            writable: true,
            configurable: true,
            enumerable: true
          });
        },
        configurable: true,
        enumerable: true
      });
    });
  }
}
function hijackFunction(global = globalThis) {
  if (typeof globalThis.Function !== 'function' || false) return;
  function FakeFunction() {
    if (arguments.length > 0) {
      if (arguments[arguments.length - 1] === 'return this') {
        return function () {
          return global;
        };
      }
    }
  }
  FakeFunction.prototype = globalThis.Function.prototype;
  FakeFunction.prototype.constructor = FakeFunction;
  globalThis.Function = FakeFunction;
}
function hijackEval() {
  if (typeof eval === 'undefined') return;
  if (WXConfig.platform === 'ios' && __webpack_require__.g.__isAppServiceRemoteDebugMode__) return;
  if (WXConfig.debug) return;
  globalThis.eval = undefined;
}
function hijackTimer() {
  if (typeof setTimeout === 'undefined') return;
  var _setTimeout = setTimeout;
  globalThis.setTimeout = function (func, timeout = 0) {
    if (typeof func !== 'function') {
      throw new TypeError(`setTimeout expects a function as first argument but got ${typeof func}.`);
    }
    var _fn = __errorTracer__.surroundThirdByTryCatch(func, 'at setTimeout callback function');
    var restArgs = [].slice.call(arguments, 2);
    return _setTimeout(() => {
      _fn.apply(globalThis, restArgs);
    }, timeout);
  };
  var _setInterval = setInterval;
  globalThis.setInterval = function (func, interval) {
    if (typeof func !== 'function') {
      throw new TypeError(`setInterval expects a function as first argument but got ${typeof func}.`);
    }
    var _fn = __errorTracer__.surroundThirdByTryCatch(func, 'at setInterval callback function');
    var restArgs = [].slice.call(arguments, 2);
    return _setInterval(() => {
      _fn.apply(globalThis, restArgs);
    }, interval);
  };
}
function hijack(hookTimer = true, global = globalThis) {
  hijackFunction(global);
  hijackEval();
  if (hookTimer) hijackTimer();
  hijackWasm();
}
module.exports = {
  hijack,
  hijackFunction
};

/***/ }),

/***/ 585:
/***/ (() => {

// 这个问题只在 iOS 里面处理
if (typeof navigator === 'undefined') {
  /* eslint-disable no-new-func */
  // 因为包含 esnext 语法，真机解析可能出错，所以包在 Function 里面
  try {
    new Function(
      'var GeneratorFunctionProto = Object.getPrototypeOf(function* () {});' +
        'var FakeGeneratorFunction = function () {};' +
        'FakeGeneratorFunction.prototype = GeneratorFunctionProto;' +
        'Object.defineProperty(GeneratorFunctionProto, "constructor", { value: FakeGeneratorFunction });',
    )()
  } catch (e) {
    /* empty */
  }
  try {
    new Function(
      'var AsyncFunctionProto = Object.getPrototypeOf(async function () {});' +
        'var FakeAsyncFunction = function () {};' +
        'FakeAsyncFunction.prototype = AsyncFunctionProto;' +
        'Object.defineProperty(AsyncFunctionProto, "constructor", { value: FakeAsyncFunction });',
    )()
  } catch (e) {
    /* empty */
  }
  try {
    new Function(
      'var AsyncGeneratorFunctionProto = Object.getPrototypeOf(async function* () {});' +
        'var FakeAsyncGeneratorFunction = function () {};' +
        'FakeAsyncGeneratorFunction.prototype = AsyncGeneratorFunctionProto;' +
        'Object.defineProperty(AsyncGeneratorFunctionProto, "constructor", { value: FakeAsyncGeneratorFunction });',
    )()
  } catch (e) {
    /* empty */
  }
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  bridgeGlobalInstanceOf: () => (/* reexport */ bridgeGlobalInstanceOf),
  deepFreezeGlobalObjs: () => (/* reexport */ deepFreezeGlobalObjs),
  deepFreezeObj: () => (/* reexport */ deepFreezeObj),
  deepFreezeObjProperty: () => (/* reexport */ deepFreezeObjProperty),
  doNotWriteGlobalObjs: () => (/* reexport */ doNotWriteGlobalObjs),
  doNotWriteObj: () => (/* reexport */ doNotWriteObj),
  doNotWriteObjProperty: () => (/* reexport */ doNotWriteObjProperty),
  globalEsHiddenObjs: () => (/* reexport */ GlobalEsHiddenObjs),
  globalEsObjs: () => (/* reexport */ GlobalEsObjs),
  hijack: () => (/* reexport */ protect_Hijack.hijack),
  hijackFunction: () => (/* reexport */ protect_Hijack.hijackFunction),
  overwriteSetPrototypeOf: () => (/* reexport */ overwriteSetPrototypeOf)
});

// EXTERNAL MODULE: ./src/protect/Hijack.es6
var Hijack = __webpack_require__(585);
;// CONCATENATED MODULE: ./src/protect/GlobalObjects.js
var RealFunction = globalThis.Function;
var GlobalEsHiddenObjs = [() => Object.getPrototypeOf(Uint8Array.prototype).constructor, () => new RealFunction('return Object.getPrototypeOf((function* () {})()).constructor')(), () => new RealFunction('return Object.getPrototypeOf(function* () {}).constructor')(), () => new RealFunction('return Object.getPrototypeOf(async function () {}).constructor')(), () => new RealFunction('return Object.getPrototypeOf(async function* () {}).constructor')()].map(func => {
  try {
    return func();
  } catch (e) {}
  return undefined;
}).filter(Boolean);
var GlobalEsObjs = ['AggregateError', 'Array', 'ArrayBuffer', 'Atomics', 'BigInt', 'BigInt64Array', 'BigUint64Array', 'Boolean', 'DataView', 'Date', 'Error', 'EvalError', 'FinalizationRegistry', 'Float32Array', 'Float64Array', 'Function', 'globalThis', 'Infinity', 'Int16Array', 'Int32Array', 'Int8Array', 'Intl', 'JSON', 'Map', 'Math', 'NaN', 'Number', 'Object', 'Promise', 'Proxy', 'RangeError', 'ReferenceError', 'Reflect', 'RegExp', 'Set', 'SharedArrayBuffer', 'String', 'Symbol', 'SyntaxError', 'TypeError', 'URIError', 'Uint16Array', 'Uint32Array', 'Uint8Array', 'Uint8ClampedArray', 'WeakMap', 'WeakSet', 'WebAssembly', 'decodeURI', 'decodeURIComponent', 'encodeURI', 'encodeURIComponent', 'escape', 'eval', 'isFinite', 'isNaN', 'null', 'parseFloat', 'parseInt', 'undefined', 'unescape', 'uneval'];
var GlobalWAObjs = ['getApp', 'getCurrentPages', 'define', 'require', 'Reporter', 'Protect', 'requirePlugin', 'definePlugin'];
var global = globalThis;
// EXTERNAL MODULE: ./src/base/WXConfig.ts
var base_WXConfig = __webpack_require__(342);
;// CONCATENATED MODULE: ./src/base/env.ts

var PLATFORM = /* #__PURE__ */(() => base_WXConfig["default"].platform)();
var IS_DEVTOOLS = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'devtools')()));
var IS_ANDROID = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'android')()));
var IS_IOS = /* #__PURE__ */(() => PLATFORM === 'ios')();
var IS_WINDOWS = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'windows')()));
var IS_MAC = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'mac')()));
var IS_MINA = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'mina')()));
var IS_PC = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => IS_WINDOWS || IS_MAC)()));
function debugEnabled() {
  if (!WXConfig || !('debug' in WXConfig) || typeof WXConfig.debug === 'undefined') return undefined;
  return !!WXConfig.debug;
}
var ENV = /* #__PURE__ */(/* unused pure expression or super */ null && ((_WXConfig$host => (_WXConfig$host = WXConfig.host) === null || _WXConfig$host === void 0 ? void 0 : _WXConfig$host.env)()));
var IS_HOST_SDK = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'SDK')()));
var IS_HOST_SAAA_SDK = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'SAAASDK')()));
var IS_HOST_WMPF = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'WMPF')()));
var IS_HOST_WECHAT = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'WeChat')()));
var IS_USE_NATIVE_MAP = /* #__PURE__ */(/* unused pure expression or super */ null && ((_WXConfig$host2 => ((_WXConfig$host2 = WXConfig.host) === null || _WXConfig$host2 === void 0 ? void 0 : _WXConfig$host2.forceUseNativeMap) || false)()));
var WK_RENDERER_H5 = /* #__PURE__ */(/* unused pure expression or super */ null && (function isRenderH5() {
  if (typeof WORKER_RUNTIME !== 'undefined' && WORKER_RUNTIME) {
    if (typeof self !== 'undefined') {
      return self && self.__wkrenderer_h5;
    }
  }
  return typeof window === 'object' && window && window.__wkrenderer_h5;
}()));
function isWkGameNativeRender() {
  return typeof window === 'object' && window && window.__wkrenderer_h5 && (window.__featBit & 0x2) > 0;
}
function isRemoteDebugEnabled() {
  return __webpack_require__.g.__isAppServiceRemoteDebugMode__ || typeof __initHelper !== 'undefined' && __initHelper === 1;
}
function isIn3rdApp() {
  var host = WXConfig.host;
  return host && host.env !== 'WeChat' && host.env !== 'WMPF';
}
function isReleaseBuild() {
  var release = true;
  typeof wxRunOnDebug !== 'undefined' && wxRunOnDebug(() => {
    release = false;
  });
  return release;
}
function isGame() {
  return typeof IS_WAGAME === 'boolean' ? IS_WAGAME : WXConfig.appType === 4 || WXConfig.appType === 19;
}
function isAppServiceOrWebView() {
  var _Foundation;
  return  true ? true : 0;
}
var isAppService = /* #__PURE__ */(/* unused pure expression or super */ null && ((() =>  true && true)()));
function isNormalApp() {
  return WXConfig.appType === 0;
}
var thirdPartyAppType = (/* unused pure expression or super */ null && ([0, 1, 2, 3, 5, 6, 8, 9, 10, 11, 12, 13]));
function isThirdPartyApp() {
  return thirdPartyAppType.includes(WXConfig.appType);
}
function isFakeNativeApp() {
  return WXConfig.appType === 7;
}
function isPhysicalStoresApp() {
  return WXConfig.appType === 2;
}
function isWXStoreApp() {
  return WXConfig.appType === 10;
}
function isAppBasedOnGameEnv() {
  return WXConfig.appType === 19;
}
;// CONCATENATED MODULE: ./src/protect/errorStackParser.js

var CHROME_STACK_REGEXP = /^\s*at .*(\S+:\d+|\(native\))/m;
var SAFARI_NATIVE_CODE_REGEXP = /^(eval@)?(\[native code\])?$/;
function parseErrorStack(error, count = Infinity) {
  if (typeof error.stack !== 'string') throw new Error('Cannot parse given Error object');
  var errorStack = error.stack;
  if (IS_IOS) {
    return parseJSCErrorStack(errorStack, count);
  } else {
    return parseV8ErrorStack(errorStack, count);
  }
}
function extractLocation(urlLike) {
  var match = /(?::(\d+))?(?::(\d+))?$/.exec(urlLike);
  if (!match) {
    return {
      URI: urlLike
    };
  }
  return {
    URI: urlLike.substring(0, urlLike.length - match[0].length),
    line: match[1],
    column: match[2]
  };
}
function parseV8ErrorStack(errorStack, count) {
  var filtered = [];
  var errorStackLines = errorStack.split('\n');
  for (var i = 0, c = 0; i < errorStackLines.length && c < count; ++i) {
    var line = errorStackLines[i];
    if (CHROME_STACK_REGEXP.test(line)) {
      filtered.push(line);
      ++c;
    }
  }
  return filtered.map(line => {
    if (line.indexOf('(eval ') > -1) {
      line = line.replace(/eval code/g, 'eval').replace(/(\(eval at [^()]*)|(\),.*$)/g, '');
    }
    var sanitizedLine = line.replace(/^\s+/, '').replace(/\(eval code/g, '(');
    var location = sanitizedLine.match(/ (\((.+):(\d+):(\d+)\)$)/);
    sanitizedLine = location ? sanitizedLine.replace(location[0], '') : sanitizedLine;
    var tokens = sanitizedLine.split(/\s+/).slice(1);
    var locationParts = extractLocation(location ? location[1] : tokens.pop());
    var functionName = tokens.join(' ') || undefined;
    var fileName = ['eval', '<anonymous>'].indexOf(locationParts[0]) > -1 ? undefined : locationParts[0];
    return {
      functionName,
      fileName,
      lineNumber: locationParts[1],
      columnNumber: locationParts[2],
      source: line
    };
  });
}
function parseJSCErrorStack(errorStack, count) {
  var result = [];
  var errorStackLines = errorStack.split('\n');
  for (var i = 0, c = 0; i < errorStackLines.length && c < count; ++i) {
    var line = errorStackLines[i];
    if (SAFARI_NATIVE_CODE_REGEXP.test(line)) continue;
    ++c;
    var indexOfAt = line.indexOf('@');
    if (indexOfAt === -1) {
      var locationParts = extractLocation(line);
      result.push({
        fileName: locationParts.URI,
        lineNumber: locationParts.line,
        columnNumber: locationParts.column,
        source: line
      });
    } else {
      var functionName = line.substring(0, indexOfAt);
      var _locationParts = extractLocation(line.substr(indexOfAt + 1));
      result.push({
        functionName,
        fileName: _locationParts.URI,
        lineNumber: _locationParts.line,
        columnNumber: _locationParts.column,
        source: line
      });
    }
  }
  return result;
}
;// CONCATENATED MODULE: ./src/protect/util.js

var freeze = Object.freeze;
var setPrototypeOf = Object.setPrototypeOf;
var defineProperty = Object.defineProperty;
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var getOwnPropertyNames = Object.getOwnPropertyNames;
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var getPrototypeOf = Object.getPrototypeOf;
var preventExtensions = Object.preventExtensions;
function setObjectInPlace(obj, property, value) {
  try {
    if (property === '__proto__') {
      setPrototypeOf(obj, value);
    } else {
      defineProperty(obj, property, {
        value,
        writable: true,
        enumerable: true,
        configurable: true
      });
    }
  } catch (e) {}
}
var SAME_CONTEXT_FILES = [[s => !/(WAServiceMainContext|WAGame)\.js/.test(s)]];
function isSameContext(fileName1, fileName2) {
  return SAME_CONTEXT_FILES.some(fileRegexps => fileRegexps.some(exp => exp(fileName1)) && fileRegexps.some(exp => exp(fileName2)));
}
var isCallFromCurrentContextCost = 0;
var getIsCallFromCurrentContextCost = () => isCallFromCurrentContextCost;
function isCallFromCurrentContext() {
  var start = Date.now();
  var stackFrames = parseErrorStack(new Error(), 3);
  var currentFrame = stackFrames[1];
  var callerFrame = stackFrames[2];
  var result = !(currentFrame.fileName && callerFrame.fileName && callerFrame.fileName !== currentFrame.fileName && !isSameContext(callerFrame.fileName, currentFrame.fileName));
  isCallFromCurrentContextCost += Date.now() - start;
  return result;
}
function freezeObjPrototype(obj, allowSelfModify = false) {
  if (typeof obj !== 'function' && (typeof obj !== 'object' || obj === null)) return;
  var descriptor = getOwnPropertyDescriptor(obj, '__proto__');
  if (descriptor && !descriptor.configurable) return;
  if (!descriptor && !Object.isExtensible(obj)) return;
  defineProperty(obj, '__proto__', {
    get() {
      return getPrototypeOf(this);
    },
    set(newVal) {
      if (this !== obj) {
        if (typeof this !== 'function' && (typeof this !== 'object' || obj === null)) return;
        setPrototypeOf(this, newVal);
        return;
      }
      if (!allowSelfModify) return;
      if (!isCallFromCurrentContext()) return;
      setPrototypeOf(obj, newVal);
    },
    enumerable: false,
    configurable: false
  });
}
var DoNotWriteDescriptorMap = new Map();
var updateDoNotWriteDescriptor = (obj, property, descriptor) => {
  if (!DoNotWriteDescriptorMap.has(obj)) DoNotWriteDescriptorMap.set(obj, new Map());
  var objMap = DoNotWriteDescriptorMap.get(obj);
  if (objMap.has(property)) {
    Object.assign(objMap.get(property), descriptor);
  } else {
    objMap.set(property, descriptor);
  }
};
function freezeObjProperty(obj, propName, allowSelfModify = false) {
  if (typeof obj !== 'function' && (typeof obj !== 'object' || obj === null)) return false;
  try {
    var descriptor = getOwnPropertyDescriptor(obj, propName);
    if (!descriptor) return false;
    if (descriptor.configurable) {
      defineProperty(obj, propName, {
        get: descriptor.get || (() => descriptor.value),
        set(newValue) {
          if (this !== obj) {
            if (typeof this !== 'function' && typeof this !== 'object') return;
            setObjectInPlace(this, propName, newValue);
            return;
          }
          if (!allowSelfModify) return;
          if (!isCallFromCurrentContext()) return;
          if (descriptor.set) {
            descriptor.set.call(this, newValue);
          } else if (descriptor.writable) {
            descriptor.value = newValue;
          }
        },
        enumerable: descriptor.enumerable,
        configurable: false
      });
      if (allowSelfModify) updateDoNotWriteDescriptor(obj, propName, descriptor);
    }
    return !descriptor.get && (typeof descriptor.value === 'function' || typeof descriptor.value === 'object' && descriptor.value !== null);
  } catch (e) {
    wxConsole.error(propName, allowSelfModify, e.message);
    throw e;
  }
}
var FROZEN_SET = new WeakSet();
function setFrozen(obj) {
  FROZEN_SET.add(obj);
}
function isFrozen(obj) {
  return FROZEN_SET.has(obj);
}
function deepFreezeObjProperty(obj, property, preventExtension) {
  if (freezeObjProperty(obj, property)) {
    deepFreezeObj(obj[property], preventExtension);
  }
}
function deepFreezeObj(obj, preventExtension) {
  if (!obj || isFrozen(obj) || typeof obj !== 'function' && typeof obj !== 'object' || obj === globalThis) return;
  if (obj === Error) {
    if (preventExtension) {
      var deepFreezeRecursive = obj => {
        if (!obj || isFrozen(obj) || typeof obj !== 'function' && typeof obj !== 'object' || obj === globalThis) return;
        setFrozen(obj);
        freeze(obj);
        var allProps = getOwnPropertyNames(obj);
        var allSymbols = getOwnPropertySymbols(obj);
        for (var i = 0; i < allProps.length; ++i) {
          deepFreezeRecursive(obj[allProps[i]]);
        }
        for (var _i = 0; _i < allSymbols.length; ++_i) {
          deepFreezeRecursive(obj[allSymbols[_i]]);
        }
      };
      deepFreezeRecursive(Error);
    }
    return;
  }
  setFrozen(obj);
  var allProps = getOwnPropertyNames(obj);
  var allSymbols = getOwnPropertySymbols(obj);
  for (var i = 0; i < allProps.length; ++i) {
    deepFreezeObjProperty(obj, allProps[i], preventExtension);
  }
  for (var _i2 = 0; _i2 < allSymbols.length; ++_i2) {
    deepFreezeObjProperty(obj, allSymbols[_i2], preventExtension);
  }
  if (preventExtension) {
    preventExtensions(obj);
  } else {
    freezeObjPrototype(obj, false);
  }
}
function doNotWriteObjProperty(obj, property) {
  if (freezeObjProperty(obj, property, true)) {
    doNotWriteObj(obj[property]);
  }
}
var DO_NOT_WRITE_SET = new WeakSet();
function setDoNotWrite(obj) {
  DO_NOT_WRITE_SET.add(obj);
}
function isDoNotWrite(obj) {
  return DO_NOT_WRITE_SET.has(obj);
}
function doNotWriteObj(obj) {
  if (!obj || isDoNotWrite(obj) || typeof obj !== 'function' && typeof obj !== 'object' || obj === globalThis) return;
  setDoNotWrite(obj);
  var allProps = getOwnPropertyNames(obj);
  var allSymbols = getOwnPropertySymbols(obj);
  for (var i = 0; i < allProps.length; ++i) {
    doNotWriteObjProperty(obj, allProps[i]);
  }
  for (var _i3 = 0; _i3 < allSymbols.length; ++_i3) {
    doNotWriteObjProperty(obj, allSymbols[_i3]);
  }
  freezeObjPrototype(obj, true);
}
;// CONCATENATED MODULE: ./src/protect/globalRO.js


var globalRO_hasOwnProperty = Object.prototype.hasOwnProperty;
var globalRO_defineProperty = Object.defineProperty;
var defineProperties = Object.defineProperties;
var globalRO_getOwnPropertyNames = Object.getOwnPropertyNames;
var globalRO_getOwnPropertySymbols = Object.getOwnPropertySymbols;
var globalRO_getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var hasOverwriteSetPrototypeOf = false;
var overwriteSetPrototypeOf = function () {
  if (hasOverwriteSetPrototypeOf) return;
  hasOverwriteSetPrototypeOf = true;
  globalRO_defineProperty(global.Object, 'setPrototypeOf', {
    value(obj, proto) {
      obj.__proto__ = proto;
      return obj;
    },
    configurable: true
  });
  globalRO_defineProperty(global.Object, 'defineProperty', {
    value(obj, property, descriptor) {
      if (!isDoNotWrite(obj)) return globalRO_defineProperty(obj, property, descriptor);
      if (!isCallFromCurrentContext()) return descriptor;
      var currentDescriptor = globalRO_getOwnPropertyDescriptor(obj, property);
      if (!currentDescriptor || currentDescriptor.configurable) {
        var result = globalRO_defineProperty(obj, property, descriptor);
        doNotWriteObjProperty(obj, property);
        return result;
      } else {
        updateDoNotWriteDescriptor(obj, property, descriptor);
        return descriptor;
      }
    },
    configurable: true
  });
  globalRO_defineProperty(global.Object, 'defineProperties', {
    value(obj, props) {
      if (!isDoNotWrite(obj)) return defineProperties(obj, props);
      if (!isCallFromCurrentContext()) return props;
      var propertyHandler = property => {
        var currentDescriptor = globalRO_getOwnPropertyDescriptor(obj, property);
        if (!currentDescriptor || currentDescriptor.configurable) {
          var result = globalRO_defineProperty(obj, property, props[property]);
          doNotWriteObjProperty(obj, property);
          return result;
        } else {
          updateDoNotWriteDescriptor(obj, property, props[property]);
          return props[property];
        }
      };
      globalRO_getOwnPropertyNames(props).forEach(propertyHandler);
      globalRO_getOwnPropertySymbols(props).forEach(propertyHandler);
      return props;
    },
    configurable: true
  });
};
var doNotWriteGlobalObjs = function (additionalGlobals = []) {
  try {
    var allGlobals = [...GlobalEsObjs, ...GlobalWAObjs, ...GlobalEsHiddenObjs, ...additionalGlobals];
    var start = Date.now();
    for (var i = 0; i < allGlobals.length; ++i) {
      var globalItem = allGlobals[i];
      var globalItemType = typeof globalItem;
      if (globalItemType === 'string') {
        if (globalRO_hasOwnProperty.call(global, globalItem)) {
          doNotWriteObjProperty(global, globalItem);
        } else {}
      } else if (globalItemType === 'function' || globalItemType === 'object') {
        doNotWriteObj(globalItem);
      }
    }
    wxConsole.log(`doNotWriteObj cost: ${Date.now() - start} ms.`);
  } catch (e) {
    wxConsole.error('doNotWriteObj got error', e);
  }
};
var deepFreezeGlobalObjs = function (additionalGlobals = [], preventExtension = false) {
  try {
    var allGlobals = [...GlobalEsObjs, ...GlobalWAObjs, ...GlobalEsHiddenObjs, ...additionalGlobals];
    var start = Date.now();
    for (var i = 0; i < allGlobals.length; ++i) {
      var globalItem = allGlobals[i];
      var globalItemType = typeof globalItem;
      if (globalItemType === 'string') {
        if (globalRO_hasOwnProperty.call(global, globalItem)) {
          deepFreezeObjProperty(global, globalItem, preventExtension);
        } else {}
      } else if (globalItemType === 'function' || globalItemType === 'object') {
        deepFreezeObj(globalItem, preventExtension);
      }
    }
    wxConsole.log(`deepFreeze cost: ${Date.now() - start} ms.`);
  } catch (e) {
    wxConsole.error('deepFreeze got error', e);
  }
};
// EXTERNAL MODULE: ./src/protect/Hijack.js
var protect_Hijack = __webpack_require__(996);
;// CONCATENATED MODULE: ./src/protect/globalHasInstance.js
var globalHasInstance_isPrototypeOf = Object.prototype.isPrototypeOf;
var globalHasInstance_defineProperty = Object.defineProperty;
var globalHasInstance_hasOwnProperty = Object.prototype.hasOwnProperty;
var SymbolHasInstance = Symbol.hasInstance;
var isInstanceOf = (obj, constructor) => globalHasInstance_isPrototypeOf.call(constructor.prototype, obj);
var originalHasInstance = function (obj) {
  if (typeof this !== 'function' || !isObject(obj)) return false;
  return isInstanceOf(obj, this);
};
var isObject = obj => typeof obj === 'object' ? obj !== null : typeof obj === 'function';
function bridgeGlobalInstanceOf(currentGlobals, remoteGlobals, propertyNames = {}) {
  var _loop = function (i) {
    var currentGlobal = currentGlobals[i];
    var remoteGlobal = remoteGlobals[i];
    if (!currentGlobal || !remoteGlobal) return "continue";
    if (typeof currentGlobal !== 'function') return "continue";
    var currentOriginalHasInstance = globalHasInstance_hasOwnProperty.call(currentGlobal, SymbolHasInstance) ? currentGlobal[SymbolHasInstance] : originalHasInstance;
    var remoteOriginalHasInstance = globalHasInstance_hasOwnProperty.call(remoteGlobal, SymbolHasInstance) ? remoteGlobal[SymbolHasInstance] : originalHasInstance;
    globalHasInstance_defineProperty(currentGlobal, SymbolHasInstance, {
      value(obj) {
        return currentOriginalHasInstance.call(this, obj) || remoteOriginalHasInstance.call(remoteGlobal, obj);
      },
      writable: true,
      enumerable: false,
      configurable: true
    });
    globalHasInstance_defineProperty(remoteGlobal, SymbolHasInstance, {
      value(obj) {
        if (propertyNames[i] !== undefined && propertyNames[i] === 'Object' && (obj === null || obj === void 0 ? void 0 : obj._compressed) !== undefined && (obj === null || obj === void 0 ? void 0 : obj._data) !== undefined && (obj === null || obj === void 0 ? void 0 : obj.height) !== undefined && (obj === null || obj === void 0 ? void 0 : obj.width) !== undefined) {
          return remoteOriginalHasInstance.call(this, obj);
        }
        return remoteOriginalHasInstance.call(this, obj) || currentOriginalHasInstance.call(currentGlobal, obj);
      },
      writable: true,
      enumerable: false,
      configurable: true
    });
  };
  for (var i = 0; i < currentGlobals.length; ++i) {
    var _ret = _loop(i);
    if (_ret === "continue") continue;
  }
}
;// CONCATENATED MODULE: ./src/protect/index.js






})();

Protect = __webpack_exports__;
/******/ })()
;
var __errorTracer__;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   callMiniProgramOrPluginFunction: () => (/* binding */ callMiniProgramOrPluginFunction),
/* harmony export */   callSystemFunction: () => (/* binding */ callSystemFunction),
/* harmony export */   callThirdPartyFunction: () => (/* binding */ callThirdPartyFunction),
/* harmony export */   convertStack: () => (/* binding */ convertStack),
/* harmony export */   endSystemFunctionCall: () => (/* binding */ endSystemFunctionCall),
/* harmony export */   findCurrentSource: () => (/* binding */ findCurrentSource),
/* harmony export */   startSystemFunctionCall: () => (/* binding */ startSystemFunctionCall),
/* harmony export */   surroundThirdByTryCatch: () => (/* binding */ surroundThirdByTryCatch),
/* harmony export */   wrapMiniProgramOrPluginFunction: () => (/* binding */ wrapMiniProgramOrPluginFunction),
/* harmony export */   wrapSystemFunction: () => (/* binding */ wrapSystemFunction),
/* harmony export */   wrapThirdPartyFunction: () => (/* binding */ wrapThirdPartyFunction),
/* harmony export */   wrapperStack: () => (/* binding */ wrapperStack)
/* harmony export */ });
var STACK_LINE_REGEX = /[ (@]*https?:\/\/([^/]*)\/+(.*?):(\d+):(\d+)/;
var wrapperStack = [];
function convertStack(error) {
  if (!error || error.__wxOriginalStack__) {
    return false;
  }
  var originalStack = error.stack;
  if (typeof originalStack === 'undefined') {
    return false;
  }
  var convertedStack = originalStack;
  var stackPos = wrapperStack.length - 1;
  var pos = 0;
  while (pos >= 0 && stackPos >= 0) {
    var nextPos = convertedStack.length;
    var nextLen = 0;
    for (var name in stackPositions) {
      if (!stackPositions[name]) continue;
      var nextPosIndex = convertedStack.indexOf(stackPositions[name], pos);
      if (nextPosIndex < 0 || nextPos <= nextPosIndex) continue;
      nextPos = nextPosIndex;
      nextLen = stackPositions[name].length;
    }
    if (nextPos >= convertedStack.length) break;
    var newLine = `at <${wrapperStack[stackPos--].description}>`;
    convertedStack = convertedStack.slice(0, nextPos) + newLine + convertedStack.slice(nextPos + nextLen);
    pos = nextPos + newLine.length;
  }
  Object.defineProperties(error, {
    __wxOriginalStack__: {
      value: originalStack,
      writable: true,
      configurable: true
    },
    stack: {
      value: convertedStack,
      writable: true,
      enumerable: true,
      configurable: true
    }
  });
  return true;
}
var stackPositions = {
  wrapSystemFunction: null,
  wrapMiniProgramOrPluginFunction: null
};
function detectStackPosition(name) {
  var stack = new Error().stack || '';
  var lines = stack.match(/.+/gm);
  var stackLine = '';
  var atCount = 0;
  if (lines) {
    lines.forEach(line => {
      if (STACK_LINE_REGEX.test(line)) {
        atCount += 1;
        if (atCount === 2) {
          var atMatch = line.match(/^(\s*)at /);
          var atMatchLen = atMatch ? atMatch[1].length : 0;
          stackLine = line.slice(atMatchLen);
          return false;
        }
      }
      return true;
    });
  }
  stackPositions[name] = stackLine;
}
function findCurrentSource() {
  var source = '';
  for (var i = wrapperStack.length - 1; i >= 0; i--) {
    if (wrapperStack[i].pluginAppId) {
      source = wrapperStack[i].pluginAppId;
    }
  }
  return source;
}
var startSystemFunctionCall = description => {
  if (stackPositions.wrapSystemFunction === null) {
    stackPositions.wrapSystemFunction = '';
    wrapSystemFunction('', '', detectStackPosition)('wrapSystemFunction');
  }
  wrapperStack.push({
    description
  });
};
var endSystemFunctionCall = () => {
  wrapperStack.pop();
};
function callSystemFunction(errorType, description, func, caller, args, throwOut = false) {
  if (stackPositions.wrapSystemFunction === null) {
    stackPositions.wrapSystemFunction = '';
    wrapSystemFunction('', '', detectStackPosition)('wrapSystemFunction');
  }
  wrapperStack.push({
    description
  });
  var ret;
  try {
    ret = func.apply(caller, args);
  } catch (e) {
    if (convertStack(e)) {
      if (e.type === 'AppServiceSdkKnownError') {
        wrapperStack.pop();
        throw e;
      } else if (e.type === 'ThirdScriptError') {
        var source = findCurrentSource();
        Reporter.thirdErrorReport({
          error: e,
          source,
          triggerErrorCallback: !throwOut
        });
      } else {
        Reporter.errorReport({
          key: errorType,
          error: e,
          triggerErrorCallback: !throwOut
        });
      }
    }
    if (throwOut) {
      wrapperStack.pop();
      throw e;
    }
  }
  wrapperStack.pop();
  return ret;
}
function wrapSystemFunction(errorType, description, func, throwOut = false) {
  return function callSystemFn(...args) {
    return callSystemFunction(errorType, description, func, this, args, throwOut);
  };
}
function callMiniProgramOrPluginFunction(pluginAppId, description, func, caller, args, throwOut = false) {
  if (stackPositions.wrapMiniProgramOrPluginFunction === null) {
    stackPositions.wrapMiniProgramOrPluginFunction = '';
    wrapMiniProgramOrPluginFunction('', '', detectStackPosition)('wrapMiniProgramOrPluginFunction');
  }
  wrapperStack.push({
    description,
    pluginAppId
  });
  var ret;
  try {
    ret = func.apply(caller, args);
  } catch (e) {
    if (convertStack(e)) {
      Reporter.thirdErrorReport({
        error: e,
        source: pluginAppId || '',
        triggerErrorCallback: !throwOut
      });
    }
    if (throwOut) {
      wrapperStack.pop();
      throw e;
    }
  }
  wrapperStack.pop();
  return ret;
}
function callThirdPartyFunction(description, func, caller, args, throwOut = false) {
  return callMiniProgramOrPluginFunction(findCurrentSource(), description, func, caller, args, throwOut);
}
function wrapMiniProgramOrPluginFunction(pluginAppId, description, func, throwOut = false) {
  return function callFn(...args) {
    return callMiniProgramOrPluginFunction(pluginAppId, description, func, this, args, throwOut);
  };
}
function wrapThirdPartyFunction(description, func, throwOut = false) {
  return function callFn(...args) {
    return callMiniProgramOrPluginFunction(findCurrentSource(), description, func, this, args, throwOut);
  };
}
function surroundThirdByTryCatch(fn, extend) {
  var descriptionMatch = (extend || '').match(/^\s*(?:at )?([\s\S]*)$/);
  var description = descriptionMatch ? descriptionMatch[1] : '';
  var fnNonNull = fn || function () {};
  return function callFn(...args) {
    return callMiniProgramOrPluginFunction(findCurrentSource(), description, fnNonNull, fnNonNull, args, false);
  };
}
__errorTracer__ = __webpack_exports__;
/******/ })()
;
var __gameOpenDataSDK__;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  init: () => (/* binding */ gameopendataSubContext_init)
});

;// CONCATENATED MODULE: ./src/base/type.js
var Object$$toString = /* #__PURE__ */(() => Object.prototype.toString)();
var TO_STRING = /* #__PURE__ */Function.prototype.call.bind(Object$$toString);
function getDataType(data) {
  return TO_STRING(data).slice(8, -1);
}
function safeInstanceOf(x, constructor) {
  if (x == null) return false;
  return x instanceof constructor || x.constructor != null && x.constructor.name === constructor.name;
}
var isString = x => getDataType(x) === 'String';
var type_isNumber = x => getDataType(x) === 'Number';
var isBoolean = x => x === true || x === false || getDataType(x) === 'Boolean';
var isUndefined = x => x === undefined;
var isNull = x => x === null;
var type_isNaN = /* #__PURE__ */(() => Number.isNaN || (x => x !== x))();
var type_isFinite = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Number.isFinite || (x => type_isNumber(x) && __webpack_require__.g.isFinite(x)))()));
var isInfinity = x => type_isNumber(x) && Math.abs(x) === Infinity;
var isInteger = value => type_isFinite(value) && Math.floor(value) === value;
var isBasicValue = x => ['string', 'number', 'boolean', 'undefined'].includes(typeof x);
var isObject = x => getDataType(x) === 'Object';
var isNonNullObject = x => isObject(x) && !isNull(x);
var isJustObject = x => getDataType(x) === 'Object';
var isArray = /* #__PURE__ */(() => Array.isArray || (x => getDataType(x) === 'Array'))();
var isFunction = x => typeof x === 'function';
var isDate = x => getDataType(x) === 'Date';
var isRegExp = x => getDataType(x) === 'RegExp';
var isError = x => getDataType(x) === 'Error';
var isSymbol = x => getDataType(x) === 'Symbol';
var isMap = x => getDataType(x) === 'Map';
var isWeakMap = x => getDataType(x) === 'WeakMap';
var isSet = x => getDataType(x) === 'Set';
var isWeakSet = x => getDataType(x) === 'WeakSet';
var isPromise = x => getDataType(x) === 'Promise';
var isEmptyObject = x => {
  for (var p in x) return false;
  return true;
};
var isArrayBuffer = x => getDataType(x) === 'ArrayBuffer';
var isDataView = x => getDataType(x) === 'DataView';
var isTypedArray = x => ArrayBuffer.isView(x) && !isDataView(x);
var isVirtualNode = x => x && x.type === 'WxVirtualNode';
var isVirtualText = x => x && x.type === 'WxVirtualText';
function paramCheck(value, expect, dept = 'parameter') {
  var type = getDataType(expect);
  var valueType = getDataType(value);
  if (valueType !== type) {
    return `${dept} should be ${type} instead of ${valueType};`;
  }
  var result = '';
  switch (type) {
    case 'Object':
      Object.keys(expect).forEach(key => {
        result += paramCheck(value[key], expect[key], `${dept}.${key}`);
      });
      break;
    case 'Array':
      if (value.length < expect.length) {
        return `${dept} should have at least ${expect.length} item;`;
      }
      for (var i = 0; i < expect.length; ++i) {
        result += paramCheck(value[i], expect[i], `${dept}[${i}]`);
      }
      break;
    case 'String':
      if (expect.length > 0 && value.length === 0) {
        return `${dept} should be not empty string`;
      }
      break;
    default:
      break;
  }
  return result;
}
function safelyToString(value) {
  try {
    return JSON.stringify(value);
  } catch (e) {
    wxConsole.error(`safelyToString fail: '${e.message}'`);
    return '';
  }
}
function noop() {}
;// CONCATENATED MODULE: ./src/base/util/log.js

function getTypeKey(val) {
  var dataType = getDataType(val);
  if (dataType === 'Number') {
    if (type_isNaN(val)) return 'NaN';else if (isInfinity(val)) return 'Infinity';
  } else if (dataType === 'Object') {
    if (isNull(val)) return 'Null';
  } else if (dataType.endsWith('Array') && dataType !== 'Array' && isTypedArray(val)) {
    return 'TypedArray';
  }
  return dataType;
}
var mapping = {
  String: 0,
  NaN: '<NaN>',
  Infinity: val => val > 0 ? '<Infinity>' : '<-Infinity>',
  Number: 0,
  Boolean: 0,
  Null: 0,
  Undefined: '<Undefined>',
  Function: val => val.name === '' ? '<Function>' : `<Function: ${val.name}>`,
  Date: val => `<Date: ${val.toJSON()}>`,
  RegExp: val => `<RegExp: ${val.toString()}>`,
  Error: val => `<${val.name}: ${val.message}>${val.stack ? '\n' + val.stack : ''}`,
  Symbol: val => `<Symbol: ${val.toString()}>`,
  Promise: '<Promise>',
  Map: val => `<Map: size=${val.size}>`,
  WeakMap: '<WeakMap>',
  Set: val => `<Set: size=${val.size}>`,
  WeakSet: '<WeakSet>',
  ArrayBuffer: val => `<ArrayBuffer: byteLength=${val.byteLength}>`,
  DataView: val => `<DataView: byteLength=${val.byteLength}, byteOffset=${val.byteOffset}>`,
  TypedArray: val => `<${val.constructor && val.constructor.name ? val.constructor.name : 'TypedArray'}: byteLength=${val.byteLength}, length=${val.length}>`,
  BigInt: val => `<BigInt: ${val.toString()}>`
};
function getMappedValue(val) {
  var typeKey = getTypeKey(val);
  if (typeKey in mapping) {
    if (!mapping[typeKey]) return [val, true];else if (!isFunction(mapping[typeKey])) return [mapping[typeKey], true];else return [mapping[typeKey](val), true];
  }
  return [null, false];
}
function decycleAndToJSONable(object) {
  var refs = new WeakMap();
  var refsSize = 0;
  return function derez(val, path) {
    var res;
    var [mappedVal, isMapped] = getMappedValue(val);
    if (!isMapped) {
      if (refsSize > 3000) {
        return '<Hidden>';
      }
      if (refs.has(val)) {
        return `<Circular: ${refs.get(val)}>`;
      }
      refs.set(val, path);
      refsSize++;
      if (isArray(val)) return val.map((ele, i) => derez(ele, `${path}[${i}]`));
      res = {};
      Object.keys(val).forEach(key => {
        res[key] = derez(val[key], `${path}.${key}`);
      });
      return res;
    } else {
      return mappedVal;
    }
  }(object, '@');
}
function transformLogArgs(args, rawConsole) {
  try {
    args = Array.prototype.slice.call(args);
    return args.map(decycleAndToJSONable);
  } catch (e) {
    if (typeof inSnapshotCheck !== 'undefined' && inSnapshotCheck) {
      if (typeof rawConsole === 'function') rawConsole('[snapshot check] transformLogArgs error: ', e);
    }
    return undefined;
  }
}
var LOG_LEVEL = {
  LOG: 0,
  INFO: 1,
  WARNING: 2,
  ERROR: 3,
  DEBUG: 4,
  TIME: 5,
  TIME_END: 5
};
var LOG_LEVEL_TEXT = (/* unused pure expression or super */ null && ({
  LOG: 'log',
  INFO: 'info',
  WARNING: 'warn',
  ERROR: 'error',
  DEBUG: 'debug',
  TIME: 'time',
  TIME_END: 'timeEnd'
}));
var MAX_LOG_LENGTH = 1024 * 1024;
var MAX_LOG_LENGTH_DEBUG = 2 * 1024 * 1024;
function getNativeGlobalLog(level, args, isDebugOn = true) {
  if (!isDebugOn && level !== LOG_LEVEL.WARNING && level !== LOG_LEVEL.ERROR) return undefined;
  try {
    var logs = transformLogArgs(args);
    if (typeof logs === 'undefined') return undefined;
    var result = JSON.stringify({
      level,
      logs
    });
    if (result.length > MAX_LOG_LENGTH && !isDebugOn) {
      return JSON.stringify({
        level,
        logs: ['<LOG_EXCEED_MAX_LENGTH>']
      });
    } else if (result.length > MAX_LOG_LENGTH_DEBUG && isDebugOn) {
      return JSON.stringify({
        level,
        logs: ['<LOG_EXCEED_MAX_LENGTH>']
      });
    } else {
      return result;
    }
  } catch (e) {
    console.warn('[console] This object can not be logged');
    return undefined;
  }
}
function getWorkerLog(level, args, isDebugOn = true) {
  if (!isDebugOn && level !== LOG_LEVEL_TEXT.WARNING && level !== LOG_LEVEL_TEXT.ERROR) return undefined;
  var logs = transformLogArgs(args);
  if (typeof logs === 'undefined') return undefined;
  return {
    level,
    logs
  };
}
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/SharedEnv.js
var SharedEnv = {};
var onReadyCbs = [];
SharedEnv.ready = false;
SharedEnv.onReady = cb => {
  if (typeof cb !== 'function') {
    return;
  }
  if (SharedEnv.ready) {
    cb();
  } else {
    onReadyCbs.push(cb);
  }
};
SharedEnv.update = _env => {
  for (var key in _env) {
    if (SharedEnv[key] === undefined) {
      SharedEnv[key] = _env[key];
    }
  }
  SharedEnv.ready = true;
  onReadyCbs.forEach(cb => {
    typeof cb === 'function' && cb();
  });
  onReadyCbs = [];
};
/* harmony default export */ const gameopendataSubContext_SharedEnv = (SharedEnv);
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/console.js


var initConsole = (logFunc, isDebugOn) => {
  var _log = function (level, args) {
    if (isDebugOn) {
      var logData = getNativeGlobalLog(level, args, true);
      if (logData) logFunc(logData);
    }
  };
  console = {
    log() {
      _log(LOG_LEVEL.LOG, arguments);
    },
    info() {
      _log(LOG_LEVEL.INFO, arguments);
    },
    warn() {
      _log(LOG_LEVEL.WARNING, arguments);
    },
    error() {
      _log(LOG_LEVEL.ERROR, arguments);
    },
    debug() {
      _log(LOG_LEVEL.DEBUG, arguments);
    },
    time() {
      _log(LOG_LEVEL.TIME, arguments);
    },
    timeEnd() {
      _log(LOG_LEVEL.TIME_END, arguments);
    },
    group() {},
    groupEnd() {}
  };
};
gameopendataSubContext_SharedEnv.onReady(() => {
  if (gameopendataSubContext_SharedEnv.log && gameopendataSubContext_SharedEnv.WXConfig.platform !== 'devtools') {
    initConsole(gameopendataSubContext_SharedEnv.log, gameopendataSubContext_SharedEnv.WXConfig.debug);
  }
});
;// CONCATENATED MODULE: ./src/base/eventemitter2.js
var eventemitter2_isArray = Array.isArray ? Array.isArray : function _isArray(obj) {
  return Object.prototype.toString.call(obj) === '[object Array]';
};
var defaultMaxListeners = 20;
function init() {
  this._events = {};
  if (this._conf) {
    configure.call(this, this._conf);
  }
}
function configure(conf) {
  if (conf) {
    this._conf = conf;
    conf.delimiter && (this.delimiter = conf.delimiter);
    this._maxListeners = conf.maxListeners !== undefined ? conf.maxListeners : defaultMaxListeners;
    conf.newListener && (this._newListener = conf.newListener);
    conf.removeListener && (this._removeListener = conf.removeListener);
  } else {
    this._maxListeners = defaultMaxListeners;
  }
}
function logPossibleMemoryLeak(count, eventName) {
  console.warn(`[Event] ${count} listeners of event ${eventName} have been added, possibly causing memory leak.`);
}
function EventEmitter(conf) {
  this._events = {};
  this._newListener = false;
  this._removeListener = false;
  configure.call(this, conf);
}
EventEmitter.prototype.delimiter = '.';
EventEmitter.prototype.setMaxListeners = function (n) {
  if (n !== undefined) {
    this._maxListeners = n;
    if (!this._conf) this._conf = {};
    this._conf.maxListeners = n;
  }
};
EventEmitter.prototype.event = '';
EventEmitter.prototype.once = function (event, fn) {
  return this._once(event, fn, false);
};
EventEmitter.prototype.prependOnceListener = function (event, fn) {
  return this._once(event, fn, true);
};
EventEmitter.prototype._once = function (event, fn, prepend) {
  this._many(event, 1, fn, prepend);
  return this;
};
EventEmitter.prototype.many = function (event, ttl, fn) {
  return this._many(event, ttl, fn, false);
};
EventEmitter.prototype.prependMany = function (event, ttl, fn) {
  return this._many(event, ttl, fn, true);
};
EventEmitter.prototype._many = function (event, ttl, fn, prepend) {
  var self = this;
  if (typeof fn !== 'function') {
    throw new Error('many only accepts instances of Function');
  }
  function listener() {
    if (--ttl === 0) {
      self.off(event, listener);
    }
    return fn.apply(this, arguments);
  }
  listener._origin = fn;
  this._on(event, listener, prepend);
  return self;
};
EventEmitter.prototype.emit = function () {
  this._events || init.call(this);
  var type = arguments[0];
  if (type === 'newListener' && !this._newListener) {
    if (!this._events.newListener) {
      return false;
    }
  }
  var al = arguments.length;
  var args, l, i, j;
  var handler;
  if (this._all && this._all.length) {
    handler = this._all.slice();
    if (al > 3) {
      args = new Array(al);
      for (j = 0; j < al; j++) args[j] = arguments[j];
    }
    for (i = 0, l = handler.length; i < l; i++) {
      this.event = type;
      switch (al) {
        case 1:
          handler[i].call(this, type);
          break;
        case 2:
          handler[i].call(this, type, arguments[1]);
          break;
        case 3:
          handler[i].call(this, type, arguments[1], arguments[2]);
          break;
        default:
          handler[i].apply(this, args);
      }
    }
  }
  handler = this._events[type];
  if (typeof handler === 'function') {
    this.event = type;
    switch (al) {
      case 1:
        handler.call(this);
        break;
      case 2:
        handler.call(this, arguments[1]);
        break;
      case 3:
        handler.call(this, arguments[1], arguments[2]);
        break;
      default:
        args = new Array(al - 1);
        for (j = 1; j < al; j++) args[j - 1] = arguments[j];
        handler.apply(this, args);
    }
    return true;
  } else if (handler) {
    handler = handler.slice();
  }
  if (handler && handler.length) {
    if (al > 3) {
      args = new Array(al - 1);
      for (j = 1; j < al; j++) args[j - 1] = arguments[j];
    }
    for (i = 0, l = handler.length; i < l; i++) {
      this.event = type;
      switch (al) {
        case 1:
          handler[i].call(this);
          break;
        case 2:
          handler[i].call(this, arguments[1]);
          break;
        case 3:
          handler[i].call(this, arguments[1], arguments[2]);
          break;
        default:
          handler[i].apply(this, args);
      }
    }
    return true;
  } else if (!this._all && type === 'error') {
    if (arguments[1] instanceof Error) {
      throw arguments[1];
    } else {
      throw new Error("Uncaught, unspecified 'error' event.");
    }
  }
  return !!this._all;
};
EventEmitter.prototype.emitAsync = function () {
  this._events || init.call(this);
  var type = arguments[0];
  if (type === 'newListener' && !this._newListener) {
    if (!this._events.newListener) {
      return Promise.resolve([false]);
    }
  }
  var promises = [];
  var al = arguments.length;
  var args, l, i, j;
  var handler;
  if (this._all) {
    if (al > 3) {
      args = new Array(al);
      for (j = 1; j < al; j++) args[j] = arguments[j];
    }
    for (i = 0, l = this._all.length; i < l; i++) {
      this.event = type;
      switch (al) {
        case 1:
          promises.push(this._all[i].call(this, type));
          break;
        case 2:
          promises.push(this._all[i].call(this, type, arguments[1]));
          break;
        case 3:
          promises.push(this._all[i].call(this, type, arguments[1], arguments[2]));
          break;
        default:
          promises.push(this._all[i].apply(this, args));
      }
    }
  }
  handler = this._events[type];
  if (typeof handler === 'function') {
    this.event = type;
    switch (al) {
      case 1:
        promises.push(handler.call(this));
        break;
      case 2:
        promises.push(handler.call(this, arguments[1]));
        break;
      case 3:
        promises.push(handler.call(this, arguments[1], arguments[2]));
        break;
      default:
        args = new Array(al - 1);
        for (j = 1; j < al; j++) args[j - 1] = arguments[j];
        promises.push(handler.apply(this, args));
    }
  } else if (handler && handler.length) {
    handler = handler.slice();
    if (al > 3) {
      args = new Array(al - 1);
      for (j = 1; j < al; j++) args[j - 1] = arguments[j];
    }
    for (i = 0, l = handler.length; i < l; i++) {
      this.event = type;
      switch (al) {
        case 1:
          promises.push(handler[i].call(this));
          break;
        case 2:
          promises.push(handler[i].call(this, arguments[1]));
          break;
        case 3:
          promises.push(handler[i].call(this, arguments[1], arguments[2]));
          break;
        default:
          promises.push(handler[i].apply(this, args));
      }
    }
  } else if (!this._all && type === 'error') {
    if (arguments[1] instanceof Error) {
      return Promise.reject(arguments[1]);
    } else {
      return Promise.reject("Uncaught, unspecified 'error' event.");
    }
  }
  return Promise.all(promises);
};
EventEmitter.prototype.on = function (type, listener) {
  return this._on(type, listener, false);
};
EventEmitter.prototype.prependListener = function (type, listener) {
  return this._on(type, listener, true);
};
EventEmitter.prototype.onAny = function (fn) {
  return this._onAny(fn, false);
};
EventEmitter.prototype.prependAny = function (fn) {
  return this._onAny(fn, true);
};
EventEmitter.prototype.addListener = EventEmitter.prototype.on;
EventEmitter.prototype._onAny = function (fn, prepend) {
  if (typeof fn !== 'function') {
    throw new Error('onAny only accepts instances of Function');
  }
  if (!this._all) {
    this._all = [];
  }
  if (prepend) {
    this._all.unshift(fn);
  } else {
    this._all.push(fn);
  }
  return this;
};
EventEmitter.prototype._on = function (type, listener, prepend) {
  if (typeof type === 'function') {
    this._onAny(type, listener);
    return this;
  }
  if (typeof listener !== 'function') {
    throw new Error('on only accepts instances of Function');
  }
  this._events || init.call(this);
  if (this._newListener) {
    this.emit('newListener', type, listener);
  }
  if (!this._events[type]) {
    this._events[type] = listener;
  } else {
    if (typeof this._events[type] === 'function') {
      this._events[type] = [this._events[type]];
    }
    if (prepend) {
      this._events[type].unshift(listener);
    } else {
      this._events[type].push(listener);
    }
    if (!this._events[type].warned && this._maxListeners > 0 && this._events[type].length > this._maxListeners) {
      this._events[type].warned = true;
      logPossibleMemoryLeak.call(this, this._events[type].length, type);
    }
  }
  return this;
};
EventEmitter.prototype.off = function (type, listener) {
  if (typeof listener !== 'function') {
    throw new Error('removeListener only takes instances of Function');
  }
  var handlers,
    leafs = [];
  if (!this._events[type]) return this;
  handlers = this._events[type];
  leafs.push({
    _listeners: handlers
  });
  for (var iLeaf = 0; iLeaf < leafs.length; iLeaf++) {
    var leaf = leafs[iLeaf];
    handlers = leaf._listeners;
    if (eventemitter2_isArray(handlers)) {
      var position = -1;
      for (var i = 0, length = handlers.length; i < length; i++) {
        if (handlers[i] === listener || handlers[i].listener && handlers[i].listener === listener || handlers[i]._origin && handlers[i]._origin === listener) {
          position = i;
          break;
        }
      }
      if (position < 0) {
        continue;
      }
      this._events[type].splice(position, 1);
      if (handlers.length === 0) {
        delete this._events[type];
      }
      if (this._removeListener) {
        this.emit('removeListener', type, listener);
      }
      return this;
    } else if (handlers === listener || handlers.listener && handlers.listener === listener || handlers._origin && handlers._origin === listener) {
      delete this._events[type];
      if (this._removeListener) {
        this.emit('removeListener', type, listener);
      }
    }
  }
  function recursivelyGarbageCollect(root) {
    if (root === undefined) {
      return;
    }
    var keys = Object.keys(root);
    for (var i in keys) {
      var key = keys[i];
      var obj = root[key];
      if (obj instanceof Function || typeof obj !== 'object' || obj === null) {
        continue;
      }
      if (Object.keys(obj).length > 0) {
        recursivelyGarbageCollect(root[key]);
      }
      if (Object.keys(obj).length === 0) {
        delete root[key];
      }
    }
  }
  recursivelyGarbageCollect(this.listenerTree);
  return this;
};
EventEmitter.prototype.offAny = function (fn) {
  var i = 0,
    l = 0,
    fns;
  if (fn && this._all && this._all.length > 0) {
    fns = this._all;
    for (i = 0, l = fns.length; i < l; i++) {
      if (fn === fns[i]) {
        fns.splice(i, 1);
        if (this._removeListener) {
          this.emit('removeListenerAny', fn);
        }
        return this;
      }
    }
  } else {
    fns = this._all;
    if (this._removeListener) {
      for (i = 0, l = fns.length; i < l; i++) {
        this.emit('removeListenerAny', fns[i]);
      }
    }
    this._all = [];
  }
  return this;
};
EventEmitter.prototype.removeListener = EventEmitter.prototype.off;
EventEmitter.prototype.removeAllListeners = function (type) {
  if (type === undefined) {
    !this._events || init.call(this);
    return this;
  }
  if (this._events) {
    delete this._events[type];
  }
  return this;
};
EventEmitter.prototype.listeners = function (type) {
  this._events || init.call(this);
  if (!this._events[type]) this._events[type] = [];
  if (!eventemitter2_isArray(this._events[type])) {
    this._events[type] = [this._events[type]];
  }
  return this._events[type];
};
EventEmitter.prototype.eventNames = function () {
  return Object.keys(this._events);
};
EventEmitter.prototype.listenerCount = function (type) {
  return this.listeners(type).length;
};
EventEmitter.prototype.listenersAny = function () {
  if (this._all) {
    return this._all;
  } else {
    return [];
  }
};
/* harmony default export */ const eventemitter2 = (EventEmitter);

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/utils.js

var __isIOS = false;
var __isDevTools = false;
var __isWkRendererH5 = false;
gameopendataSubContext_SharedEnv.onReady(() => {
  __isIOS = gameopendataSubContext_SharedEnv.WXConfig.platform.toLowerCase() === 'ios';
  __isDevTools = gameopendataSubContext_SharedEnv.WXConfig.platform.toLowerCase() === 'devtools';
  __isWkRendererH5 = !!gameopendataSubContext_SharedEnv.WXConfig.__wkrenderer_h5;
});
var isIOS = () => __isIOS;
var isDevTools = () => __isDevTools;
var isWKRendererH5 = () => __isWkRendererH5;
var objDefProp = Object.defineProperty;
var _defineGetter = Object.prototype.__defineGetter__;
var _defineSetter = Object.prototype.__defineSetter__;
var defineGetter = (target, prop, getter) => {
  _defineGetter.call(target, prop, getter);
};
var defineSetter = (target, prop, setter) => {
  _defineSetter.call(target, prop, setter);
};
var surroundThirdByTryCatch = (fn, msg) => __subContextEngine__.surroundThirdByTryCatch(fn, msg);
var surroundByTryCatch = (fn, msg) => __subContextEngine__.surroundByTryCatch(fn, msg);
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/BaseMethods.js



function BaseMethods_noop() {}
var BaseMethods_invokeSharedMethod = function (name, args = {}) {
  if (!gameopendataSubContext_SharedEnv.APIs || typeof gameopendataSubContext_SharedEnv.APIs[name] !== 'function') {
    return undefined;
  }
  Object.keys(args).forEach(key => {
    if (typeof args[key] === 'function') {
      args[key] = surroundThirdByTryCatch(args[key], `at api ${name} ${key} callback function`);
    }
  });
  return gameopendataSubContext_SharedEnv.APIs[name](args);
};
function beforeInvokeFail(name, args = {}, err, errCode) {
  var useErrno = isNumber(err);
  beforeInvokeCallback({
    name,
    args,
    errno: useErrno && err,
    errMsg: useErrno || err,
    errCode: useErrno || errCode,
    success: false
  });
}
function beforeInvokeCallback({
  name,
  args = {},
  success = true,
  errno,
  errMsg = '',
  errCode,
  res = {}
}) {
  args = args || {};
  var callback = __errorTracer__.surroundThirdByTryCatch((success ? args.success : args.fail) || BaseMethods_noop, `at api ${name} ${success ? 'success' : 'fail'} callback function`);
  var complete = __errorTracer__.surroundThirdByTryCatch(args.complete || BaseMethods_noop, `at api ${name} complete callback function`);
  if (isNumber(errno)) {
    res.errno = errno;
    res.errMsg = `${name}:fail`;
  } else {
    res.errMsg = success ? `${name}:ok` : `${name}:fail ${errMsg}`;
    if (isNumber(errCode)) {
      res.errCode = errCode;
    }
  }
  callback(res);
  complete(res);
}
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/message.js




var pendingMessageArray = [];
var parse = JSON.parse;
var emitter = new eventemitter2({
  maxListeners: 2000
});
var MESSAGE_EVENT = 'mainContextMessage';
var postMessage = ({
  content = '确认发送数据吗?',
  openId,
  action
}) => {
  var obj = {};
  var dataCache = invokeSharedMethod('getGroupDataCache').concat(invokeSharedMethod('getFriendDataCache'));
  var dataIndex = dataCache.findIndex(item => item.openId === openId);
  if (dataIndex === -1) {
    throw new Error('不存在该 openId 对应的数据。openId 必须是最近一次调用 wx.getFriendUserGameData 或 wx.getGroupUserGameData 所获取的某个数据的 openId');
  }
  obj.data = Object.assign({}, dataCache[dataIndex]);
  if (action) {
    var validActions = WXConfig.platform === 'devtools' ? WXConfig.appConfig.actions : WXConfig.actions;
    if (!validActions) {
      throw new Error('game.json 缺少 actions 配置项');
    }
    if (!Array.isArray(validActions)) {
      throw new Error('actions 配置项必须是一个以字符串为元素的数组');
    }
    var actionIndex = validActions.indexOf(action);
    if (actionIndex === -1) {
      throw new Error('action 不是 game.json 中配置的合法值');
    }
    obj.action = action;
  }
  invokeSharedMethod('showModal', {
    title: '提示',
    content,
    success: res => {
      if (res.confirm) {
        JSContext.publish('subContextMessage', obj);
      }
    }
  });
};
var onMessage = callback => {
  if (typeof callback !== 'function') {
    return;
  }
  var _callback = surroundThirdByTryCatch(function monitor() {
    var stime = Date.now();
    var ret = callback.apply(null, arguments);
    var cost = Date.now() - stime;
    if (cost >= 10) {
      Reporter.reportKeyValue({
        key: 'MiniGameOpenDataMonitor',
        value: [1, cost].join(',')
      });
    }
    return ret;
  }, 'at onMessage callback function');
  pendingMessageArray.forEach(msg => {
    _callback(msg);
  });
  setTimeout(() => {
    pendingMessageArray = [];
  });
  emitter.on(MESSAGE_EVENT, _callback);
};
JSContext.subscribe(MESSAGE_EVENT, ({
  data
}) => {
  data = parse(data);
  if (emitter.listeners(MESSAGE_EVENT).length !== 0) {
    emitter.emit(MESSAGE_EVENT, data);
  } else {
    pendingMessageArray.push(data);
  }
});

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getSystemInfo.js

var getSystemInfo = args => {
  BaseMethods_invokeSharedMethod('getSystemInfo', args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getSystemInfoSync.js

var getSystemInfoSync = () => {
  var ret = BaseMethods_invokeSharedMethod('getSystemInfoSync');
  return JSON.parse(JSON.stringify(ret));
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/innerglobal/index.js
var imageMap = new WeakMap();
var canvasMap = new WeakMap();
var contextMap = new WeakMap();
var isOffScreenMode;
/* harmony default export */ const innerglobal = ({
  imageMap,
  canvasMap,
  contextMap,
  isOffScreenMode
});
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/wrapper/protoProtectConfig.js
// !这个文件会被主域和子域共同引用，所以只可以 export 简单的配置，不要 import 任何文件

// !请谨慎配置，否则可能导致原型泄露而窃取关系链
var propertiesOfHTMLCanvasElementThatAllowAccessInOpenDataContext = ['width', 'height'];
var propertiesOfParentProtoOfHTMLCanvasElementThatAllowAccessInOpenDataContext = ['offsetTop', 'offsetLeft', 'offsetWidth', 'offsetHeight'];
var propertiesOfHTMLImageElementThatAllowAccessInOpenDataContext = ['width', 'height', 'complete'];
var propertiesOfCanvasRenderingContext2DThatAllowAccessInOpenDataContext = ['globalCompositeOperation', 'lineCap', 'lineJoin', 'textAlign', 'textBaseline', 'fillStyle', 'strokeStyle', 'globalAlpha', 'lineWidth', 'miterLimit', 'font', 'imageSmoothingEnabled'];
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/wrapper/CanvasWrapper.js



var {
  canvasMap: CanvasWrapper_canvasMap
} = innerglobal;
var canvasConfig = new WeakMap();
var initProps = function () {
  ;
  [...propertiesOfHTMLCanvasElementThatAllowAccessInOpenDataContext, ...propertiesOfParentProtoOfHTMLCanvasElementThatAllowAccessInOpenDataContext].forEach(prop => {
    defineGetter(this, prop, function () {
      var canvas = CanvasWrapper_canvasMap.get(this);
      var value = canvas[prop];
      if (typeof value === 'number') {
        return value;
      } else {
        return Number(value);
      }
    });
    defineSetter(this, prop, function (value) {
      var config = canvasConfig.get(this);
      if (config.readOnly) {
        console.warn('[GameOpenDataContext] Cannot assign to read only canvas.');
        return;
      }
      var canvas = CanvasWrapper_canvasMap.get(this);
      canvas[prop] = value;
    });
  });
  this.tagName = 'CANVAS';
  this.nodeName = 'CANVAS';
};
class CanvasWrapper {
  constructor(canvas, readOnly = true) {
    CanvasWrapper_canvasMap.set(this, canvas);
    canvasConfig.set(this, {
      readOnly
    });
    this.__canvas__ = true;
    initProps.call(this);
  }
}
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/wrapper/ContextWrapper.js



var {
  contextMap: ContextWrapper_contextMap
} = innerglobal;
var ContextWrapper_initProps = function (canvasWrapper) {
  this.canvas = canvasWrapper;
  propertiesOfCanvasRenderingContext2DThatAllowAccessInOpenDataContext.forEach(prop => {
    defineGetter(this, prop, function () {
      var context = ContextWrapper_contextMap.get(this);
      return context[prop];
    });
    defineSetter(this, prop, function (value) {
      var context = ContextWrapper_contextMap.get(this);
      context[prop] = value;
    });
  });
};
class ContextWrapper {
  constructor(context, canvasWrapper) {
    ContextWrapper_contextMap.set(this, context);
    ContextWrapper_initProps.call(this, canvasWrapper);
  }
}
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/ProtoCloner/constants.js
var PROTO_WHITE_LIST = {};
PROTO_WHITE_LIST.Canvas = {
  getContext: 'CanvasRenderingContext2D'
};
PROTO_WHITE_LIST.CanvasRenderingContext2D = {
  rect: undefined,
  lineTo: undefined,
  rotate: undefined,
  quadraticCurveTo: undefined,
  strokeText: undefined,
  clip: undefined,
  createRadialGradient: 'CanvasGradient',
  clearRect: undefined,
  restore: undefined,
  drawImage: undefined,
  arcTo: undefined,
  fillText: undefined,
  resetClip: undefined,
  strokeRect: undefined,
  arc: undefined,
  isPointInPath: undefined,
  moveTo: undefined,
  createImageData: 'ImageData',
  translate: undefined,
  scale: undefined,
  closePath: undefined,
  putImageData: undefined,
  bezierCurveTo: undefined,
  transform: undefined,
  measureText: 'TextMetrics',
  fillRect: undefined,
  stroke: undefined,
  save: undefined,
  createLinearGradient: 'CanvasGradient',
  beginPath: undefined,
  setTransform: undefined,
  createPattern: 'CanvasPattern',
  getImageData: 'ImageData',
  fill: undefined
};
PROTO_WHITE_LIST.CanvasGradient = {
  addColorStop: undefined
};
PROTO_WHITE_LIST.CanvasPattern = {
  setTransform: undefined
};
PROTO_WHITE_LIST.ImageData = {};
PROTO_WHITE_LIST.TextMetrics = {};
PROTO_WHITE_LIST.Image = {
  __uid: undefined,
  addEventListener: undefined,
  removeEventListener: undefined
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/ProtoCloner/index.js



var protoCache = {};
var objKeys = Object.keys;
var defProp = Object.defineProperty;
var getDesp = Object.getOwnPropertyDescriptor;
var hasOwnProp = Object.prototype.hasOwnProperty;
var ctx2dProps = ['globalAlpha', 'globalCompositeOperation', 'filter', 'imageSmoothingEnabled', 'imageSmoothingQuality', 'strokeStyle', 'fillStyle', 'shadowOffsetX', 'shadowOffsetY', 'shadowBlur', 'shadowColor', 'lineWidth', 'lineCap', 'lineJoin', 'miterLimit', 'lineDashOffset', 'font', 'textAlign', 'textBaseline', 'direction'];
var textMetricsProps = ['width', 'actualBoundingBoxLeft', 'actualBoundingBoxRight', 'fontBoundingBoxAscent', 'fontBoundingBoxDescent', 'actualBoundingBoxAscent', 'actualBoundingBoxDescent', 'emHeightAscent', 'emHeightDescent', 'hangingBaseline', 'alphabeticBaseline', 'ideographicBaseline'];
var replaceProto = (ctorName, obj) => {
  if (ctorName === 'CanvasRenderingContext2D') {
    ctx2dProps.forEach(p => {
      if (hasOwnProp.call(obj, p)) return;
      var d = getDesp(obj.__proto__, p);
      d && (d.get || d.set) && defProp(obj, p, d);
    });
  }
  if (ctorName === 'TextMetrics') {
    textMetricsProps.forEach(p => {
      if (hasOwnProp.call(obj, p)) return;
      var d = getDesp(obj.__proto__, p);
      d && d.get && defProp(obj, p, {
        set: undefined,
        enumerable: true,
        configurable: false,
        get: () => {
          var v = d.get.call(obj);
          return Number(v).valueOf();
        }
      });
    });
  }
  if (protoCache[ctorName]) {
    obj.__proto__ = protoCache[ctorName];
    return obj;
  }
  return undefined;
};
var hookProtoFunc = function (originalFunc, retCtorName) {
  return function () {
    var ret = originalFunc.apply(this, arguments);
    if (retCtorName && ret) {
      return replaceProto(retCtorName, ret);
    }
    return ret;
  };
};
var copyOriginalProto = function () {
  var originalProto = gameopendataSubContext_SharedEnv.getOriginalProto();
  var propKeys = objKeys(originalProto);
  for (var ctorName of propKeys) {
    var proto = originalProto[ctorName];
    var whiteList = PROTO_WHITE_LIST[ctorName];
    if (typeof proto === 'undefined' || typeof whiteList === 'undefined') {
      continue;
    }
    var newProto = {};
    var whiteListKeys = objKeys(whiteList);
    for (var k of whiteListKeys) {
      var ret = whiteList[k];
      var func = proto[k];
      if (func) {
        newProto[k] = hookProtoFunc(func, ret);
      }
    }
    protoCache[ctorName] = newProto;
  }
};
gameopendataSubContext_SharedEnv.onReady(() => {
  copyOriginalProto();
});
var constructorFactory = (ctorName, OriginalCtor) => function () {
  var obj = new OriginalCtor();
  if (isDevTools() || isWKRendererH5()) {
    return obj;
  }
  if (protoCache[ctorName]) {
    obj.__proto__ = protoCache[ctorName];
    return obj;
  }
  return undefined;
};
var getProto = ctorName => protoCache[ctorName];

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/canvas/index.js





var {
  imageMap: canvas_imageMap,
  canvasMap: canvas_canvasMap,
  contextMap: canvas_contextMap
} = innerglobal;
var objAssign = Object.assign;
var canvas_objKeys = Object.keys;
var Canvas;
var originalGetContext;
var originalDrawImage;
var originalCreatePattern;
var sharedCanvasWrapper;
var canvasContextProto;
gameopendataSubContext_SharedEnv.onReady(() => {
  Canvas = constructorFactory('Canvas', gameopendataSubContext_SharedEnv.Canvas);
});
var getRealTarget = function (warpper) {
  if (warpper && warpper.__image__) {
    return canvas_imageMap.get(warpper);
  }
  if (warpper && warpper.__canvas__) {
    return canvas_canvasMap.get(warpper);
  }
  return warpper;
};
var __drawImage = function () {
  if (arguments[0]) {
    arguments[0] = getRealTarget(arguments[0]);
  }
  return originalDrawImage.apply(this, arguments);
};
var __createPattern = function () {
  if (arguments[0]) {
    arguments[0] = getRealTarget(arguments[0]);
  }
  return originalCreatePattern.apply(this, arguments);
};
var __getImageData = function () {
  return {
    width: 0,
    height: 0,
    data: new Uint8ClampedArray(0)
  };
};
var __getCanvasContextProto = function () {
  if (canvasContextProto) {
    return canvasContextProto;
  }
  var originProto = getProto('CanvasRenderingContext2D');
  canvasContextProto = objAssign({}, originProto);
  canvas_objKeys(canvasContextProto).forEach(key => {
    var originFn = canvasContextProto[key];
    canvasContextProto[key] = function () {
      var originCtx = canvas_contextMap.get(this);
      return originFn.apply(originCtx, arguments);
    };
  });
  return canvasContextProto;
};
var __getContext = function (type) {
  if (type.toLowerCase() !== '2d') {
    console.error('[GameOpenDataContext] 子域只支持使用 2D 渲染模式 ');
    return undefined;
  }
  var canvas = canvas_canvasMap.get(this);
  var context;
  if (innerglobal.isOffScreenMode) {
    context = originalGetContext.call(canvas, '2d');
  } else {
    context = originalGetContext.call(canvas, '2d', {
      alpha: true
    });
  }
  var wrapper = new ContextWrapper(context, this);
  wrapper.__proto__ = __getCanvasContextProto();
  canvas = undefined;
  context = undefined;
  if (originalDrawImage === undefined) {
    originalDrawImage = wrapper.__proto__.drawImage;
    wrapper.__proto__.drawImage = __drawImage;
    wrapper.__proto__.getImageData = __getImageData;
  }
  if (originalCreatePattern === undefined) {
    originalCreatePattern = wrapper.__proto__.createPattern;
    wrapper.__proto__.createPattern = __createPattern;
  }
  return wrapper;
};
var wrapCanvas = (canvas, readOnly = true) => {
  var wrapper = new CanvasWrapper(canvas, readOnly);
  wrapper.__proto__ = getProto('Canvas');
  if (originalGetContext === undefined) {
    originalGetContext = wrapper.__proto__.getContext;
    wrapper.__proto__.getContext = __getContext;
  }
  return wrapper;
};
var createCanvas = () => {
  var canvas = new Canvas();
  var wrapper = wrapCanvas(canvas, false);
  return wrapper;
};
var getSharedCanvas = () => sharedCanvasWrapper;
var _setAndWrapSharedCanvas = canvas => {
  innerglobal.isOffScreenMode = gameopendataSubContext_SharedEnv.isUsedOffscreenSharedCanvas();
  sharedCanvasWrapper = wrapCanvas(canvas, true);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/wrapper/EventWrapper.js

var eventMap = new WeakMap();
var EventWrapper_initProps = function () {
  ;
  ['type'].forEach(prop => {
    defineGetter(this, prop, function () {
      var event = eventMap.get(this);
      var value = event[prop];
      if (typeof value === 'string') {
        return value;
      } else {
        return String(value);
      }
    });
    defineSetter(this, prop, function (value) {
      var event = eventMap.get(this);
      event[prop] = value;
    });
  });
  ['timestamp'].forEach(prop => {
    defineGetter(this, prop, function () {
      var event = eventMap.get(this);
      var value = event.timestamp || event.timeStamp;
      if (typeof value === 'number') {
        return value;
      } else {
        return Number(value);
      }
    });
    defineSetter(this, prop, function (value) {
      var event = eventMap.get(this);
      event[prop] = value;
    });
  });
};
class EventWrapper {
  constructor(target, event) {
    eventMap.set(this, event);
    EventWrapper_initProps.call(this);
    this.target = target;
    this.currentTarget = target;
  }
  preventDefault() {
    var event = eventMap.get(this);
    event.preventDefault(...arguments);
  }
  stopPropagation() {
    var event = eventMap.get(this);
    event.stopPropagation(...arguments);
  }
}
;// CONCATENATED MODULE: ./src/base/WXConfig.ts
var EnvPreloadType = (/* unused pure expression or super */ null && ({
  None: 0,
  BeforeLaunch: 1,
  AfterLaunch: 2
}));
var updateConfig = () => {
  if (WXConfig_WXConfig !== __wxConfig && typeof WXConfig_WXConfig !== 'undefined') {
    Object.assign(WXConfig_WXConfig, __wxConfig);
  }
};
var WXConfig_WXConfig = /* #__PURE__ */(() => {
  __wxConfig.onReady(updateConfig);
  return __wxConfig;
})();
/* harmony default export */ const base_WXConfig = (WXConfig_WXConfig);
;// CONCATENATED MODULE: ./src/base/env.ts

var PLATFORM = /* #__PURE__ */(() => base_WXConfig.platform)();
var IS_DEVTOOLS = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'devtools')()));
var IS_ANDROID = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'android')()));
var IS_IOS = /* #__PURE__ */(() => PLATFORM === 'ios')();
var IS_WINDOWS = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'windows')()));
var IS_MAC = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'mac')()));
var IS_MINA = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'mina')()));
var IS_PC = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => IS_WINDOWS || IS_MAC)()));
function debugEnabled() {
  if (!WXConfig || !('debug' in WXConfig) || typeof WXConfig.debug === 'undefined') return undefined;
  return !!WXConfig.debug;
}
var ENV = /* #__PURE__ */(/* unused pure expression or super */ null && ((_WXConfig$host => (_WXConfig$host = WXConfig.host) === null || _WXConfig$host === void 0 ? void 0 : _WXConfig$host.env)()));
var IS_HOST_SDK = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'SDK')()));
var IS_HOST_SAAA_SDK = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'SAAASDK')()));
var IS_HOST_WMPF = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'WMPF')()));
var IS_HOST_WECHAT = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'WeChat')()));
var IS_USE_NATIVE_MAP = /* #__PURE__ */(/* unused pure expression or super */ null && ((_WXConfig$host2 => ((_WXConfig$host2 = WXConfig.host) === null || _WXConfig$host2 === void 0 ? void 0 : _WXConfig$host2.forceUseNativeMap) || false)()));
var WK_RENDERER_H5 = /* #__PURE__ */(/* unused pure expression or super */ null && (function isRenderH5() {
  if (typeof WORKER_RUNTIME !== 'undefined' && WORKER_RUNTIME) {
    if (typeof self !== 'undefined') {
      return self && self.__wkrenderer_h5;
    }
  }
  return typeof window === 'object' && window && window.__wkrenderer_h5;
}()));
function isWkGameNativeRender() {
  return typeof window === 'object' && window && window.__wkrenderer_h5 && (window.__featBit & 0x2) > 0;
}
function isRemoteDebugEnabled() {
  return __webpack_require__.g.__isAppServiceRemoteDebugMode__ || typeof __initHelper !== 'undefined' && __initHelper === 1;
}
function isIn3rdApp() {
  var host = WXConfig.host;
  return host && host.env !== 'WeChat' && host.env !== 'WMPF';
}
function isReleaseBuild() {
  var release = true;
  typeof wxRunOnDebug !== 'undefined' && wxRunOnDebug(() => {
    release = false;
  });
  return release;
}
function isGame() {
  return  true ? true : 0;
}
function isAppServiceOrWebView() {
  var _Foundation;
  return typeof IS_APP === 'boolean' ? IS_APP : (_Foundation = Foundation) === null || _Foundation === void 0 ? void 0 : _Foundation.env.isApp;
}
var isAppService = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => typeof IS_APP !== 'undefined' && IS_APP)()));
function isNormalApp() {
  return WXConfig.appType === 0;
}
var thirdPartyAppType = (/* unused pure expression or super */ null && ([0, 1, 2, 3, 5, 6, 8, 9, 10, 11, 12, 13]));
function isThirdPartyApp() {
  return thirdPartyAppType.includes(WXConfig.appType);
}
function isFakeNativeApp() {
  return WXConfig.appType === 7;
}
function isPhysicalStoresApp() {
  return WXConfig.appType === 2;
}
function isWXStoreApp() {
  return WXConfig.appType === 10;
}
function isAppBasedOnGameEnv() {
  return WXConfig.appType === 19;
}
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/wrapper/ImageWrapper.js





var {
  imageMap: ImageWrapper_imageMap
} = innerglobal;
var listenerMap = new WeakMap();
var listenerFactory = function (eventTarget, listener) {
  var _listener = function (event) {
    event = new EventWrapper(eventTarget, event);
    typeof listener === 'function' && listener(event);
  };
  return _listener;
};
var ImageWrapper_initProps = function () {
  propertiesOfHTMLImageElementThatAllowAccessInOpenDataContext.forEach(prop => {
    defineGetter(this, prop, function () {
      var image = ImageWrapper_imageMap.get(this);
      return image[prop];
    });
    defineSetter(this, prop, function (value) {
      var image = ImageWrapper_imageMap.get(this);
      image[prop] = value;
    });
  });
  ['onload', 'onerror'].forEach(type => {
    defineGetter(this, type, function () {
      return this[`__original__${type}`];
    });
    defineSetter(this, type, function (listener) {
      var image = ImageWrapper_imageMap.get(this);
      var _listener = surroundThirdByTryCatch(listener, `at image.${type} callback function`);
      if (IS_IOS) {
        try {
          objDefProp(image, type, {
            writable: true,
            configurable: true,
            value: listenerFactory(this, _listener)
          });
        } catch {
          image[type] = listenerFactory(this, _listener);
        }
      } else {
        image[type] = listenerFactory(this, _listener);
      }
      objDefProp(this, `__original__${type}`, {
        value: listener,
        writable: true,
        configurable: true,
        enumerable: false
      });
    });
  });
  this.tagName = 'IMG';
  this.nodeName = 'IMG';
};
class ImageWrapper {
  constructor(img) {
    ImageWrapper_imageMap.set(this, img);
    this.__image__ = true;
    ImageWrapper_initProps.call(this);
  }
  addEventListener() {
    if (typeof arguments[1] === 'function') {
      var listener = arguments[1];
      var listenerWrapper = listenerFactory(this, listener);
      listenerMap.set(listener, listenerWrapper);
      arguments[1] = listenerWrapper;
    }
    var img = ImageWrapper_imageMap.get(this);
    img.addEventListener(...arguments);
  }
  removeEventListener() {
    if (typeof arguments[1] === 'function') {
      var listener = arguments[1];
      var listenerWrapper = listenerMap.get(listener);
      listenerMap.delete(listener);
      arguments[1] = listenerWrapper;
    }
    var img = ImageWrapper_imageMap.get(this);
    img.removeEventListener(...arguments);
  }
}
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/image/index.js





var startsWith = String.prototype.startsWith;
var replace = String.prototype.replace;
var indexOf = String.prototype.indexOf;
var {
  imageMap: image_imageMap
} = innerglobal;
var Image;
var hasDefinedSrc = false;
var imageDomain = ['https://wx.qlogo.cn/'];
gameopendataSubContext_SharedEnv.onReady(() => {
  Image = constructorFactory('Image', gameopendataSubContext_SharedEnv.Image);
  if (typeof WXConfig.wxAppInfo === 'object' && WXConfig.wxAppInfo.subContextImgDomain) {
    imageDomain = WXConfig.wxAppInfo.subContextImgDomain;
  }
});
var trim = function (str) {
  return replace.call(str, /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
};
var inDomainList = function (src) {
  var _SharedEnv$location;
  src = trim(src);
  if (!imageDomain || imageDomain.length === 0) {
    return false;
  }
  for (var i = 0; i < imageDomain.length; i++) {
    var domain = imageDomain[i];
    if (domain.length > 0 && startsWith.call(src, domain)) {
      return true;
    }
  }
  if (startsWith.call(src, gameopendataSubContext_SharedEnv === null || gameopendataSubContext_SharedEnv === void 0 ? void 0 : (_SharedEnv$location = gameopendataSubContext_SharedEnv.location) === null || _SharedEnv$location === void 0 ? void 0 : _SharedEnv$location.origin)) return true;
  return false;
};
var srcSetter = function (src) {
  var allowSrc;
  var invalidErrMsg = '[OpenDataContext] invalid image src. ';
  if (typeof src !== 'string') {
    console.error(invalidErrMsg + src);
    return;
  }
  if (indexOf.call(src, '@') >= 0) {
    console.error(invalidErrMsg + src);
    return;
  }
  if (gameopendataSubContext_SharedEnv.URL) {
    var URL = gameopendataSubContext_SharedEnv.URL;
    var urlObj = {};
    try {
      if (gameopendataSubContext_SharedEnv.location) {
        urlObj = new URL(src, gameopendataSubContext_SharedEnv.location.origin);
      } else {
        urlObj = new URL(src);
      }
      if (['http:', 'https:'].includes(urlObj.protocol)) {
        if (inDomainList(gameopendataSubContext_SharedEnv.location ? urlObj.href : src)) {
          allowSrc = gameopendataSubContext_SharedEnv.location ? urlObj.href : src;
        } else {
          console.error('[OpenDataContext] can not use remote http/https image in opendata context. ' + src);
        }
      } else {
        allowSrc = src;
      }
    } catch (err) {
      allowSrc = src;
    }
  } else {
    if (startsWith.call(src, 'http') || startsWith.call(src, 'https')) {
      if (inDomainList(src)) {
        allowSrc = src;
      }
    } else {
      allowSrc = src;
    }
  }
  if (allowSrc) {
    var image = image_imageMap.get(this);
    BaseMethods_invokeSharedMethod('getCloudFileInfo', {
      fileIds: [src],
      type: 'image',
      success(result) {
        if (/^(cloud):\/\//.test(src)) {
          this._cloudId = src;
        } else {
          this._cloudId = '';
        }
        image.src = result.data[0].url;
      }
    });
  } else {
    console.error(`[OpenDataContext] src "${src}" 不在后台可信域名中`);
  }
};
var createImage = () => {
  var image = new Image();
  var wrapper = new ImageWrapper(image);
  if (!hasDefinedSrc) {
    wrapper.__proto__.__defineGetter__('src', function () {
      if (this._cloudId) {
        return this._cloudId;
      }
      var image = image_imageMap.get(this);
      return image.src;
    });
    wrapper.__proto__.__defineSetter__('src', srcSetter);
    hasDefinedSrc = true;
  }
  return wrapper;
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/createInnerAudioContext.js
class Audio {
  get src() {
    return this.__src__ || '';
  }
  set src(value) {
    this.__src__ = value;
  }
  get startTime() {
    return this.__startTime__ || 0;
  }
  set startTime(value) {
    this.__startTime__ = value;
  }
  set autoplay(val) {}
  set loop(val) {}
  set obeyMuteSwitch(val) {}
  get paused() {
    return true;
  }
  get duration() {
    return 0;
  }
  get currentTime() {
    return 0;
  }
  get buffered() {
    return false;
  }
  play() {}
  pause() {}
  stop() {}
  seek() {}
  destroy() {}
  onPlay() {}
  onPause() {}
  onTimeUpdate() {}
  onStop() {}
  onCanplay() {}
  onError() {}
  onEnded() {}
  onWaiting() {}
  onSeeking() {}
  onSeeked() {}
}
var createInnerAudioContext = () => {
  console.warn('wx.createInnerAudioContext is not supported in SubContext.');
  return new Audio();
};

;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+wxapi-errno@1.0.185/node_modules/@tencent/wxapi-errno/dist/errno.js
var OK = 0;
var CANCEL = 1;
var NATIVE_BUFFER_EXCEED_SIZE_LIMIT = 2;
var SYSTEM_PERMISSION_DENIED = 3;
var INTERNAL_ERROR = 4;
var GENERAL_TIME_OUT = 5;
var API_OBSOLETED = 6;
var REQUIRE_USER_INTERACTION = 7;
var GENERAL_FAIL_USE_OTHER_SERVICE = 8;
var JSAPI_NOT_SUPPORTED = 100;
var INVALID_REQUEST_DATA = 101;
var JSAPI_PERMISSION_DENIED = 102;
var JSAPI_AUTHORIZE_DENIED = 103;
var JSAPI_AUTHORIZE_CANCELED = 104;
var JSAPI_INVALID_STATE = 105;
var JSAPI_INVALID_INDEX = 106;
var JSAPI_EMPTY_RET_DATA = 107;
var CGI_FAILED_FOR_NETWORK_ISSUES = 108;
var CGI_FAILED_FOR_RESPONSE_NULL = 109;
var SCOPE_EMPTY = 110;
var PROCESS_OOM = 111;
var API_SCOPE_NOT_DECLARED = 112;
var WXAPI_SERVER_SYSTEM_ERROR = 1000;
var WXAPI_INVALID_REQUEST_PARAM = 1001;
var WXAPI_EMPTY_REQUEST = 1002;
var WXAPI_SERVER_Frequency_Limit = 1003;
var WXAPI_SERVER_INVALID_OPEN_ID = 1004;
var WXAPI_SERVER_INVALID_APPID = 1005;
var WXAPI_SERVER_INSERT_DATA_FAILED = 1006;
var WXAPI_SERVER_GET_NO_DATA = 1007;
var WXAPI_SERVER_UPDATE_DATA_FAILED = 1008;
var WXAPI_SERVER_DATA_EXPIRED = 1009;
var WXAPI_SERVER_DATA_DELETED = 1010;
var WXAPI_SERVER_INVALID_USER_ID = 1011;
var WXAPI_SERVER_REQURE_POST_METHOD = 1012;
var WXAPI_SERVER_REQURE_GET_METHOD = 1013;
var WXAPI_SERVER_INVALID_USER_TICKET = 1014;
var WXAPI_SERVER_INVALID_API = 1015;
var WXAPI_SERVER_WEBSOCKT_NO_CONN_INFO = 1016;
var WXAPI_SERVER_MEM_ERR = 1017;
var WXAPI_SERVER_DUPLICATED_UUID = 1018;
var WXAPI_SERVER_NOT_FRIEND = 1019;
var WXAPI_SERVER_CODE_ALREADY_USED = 1020;
var WXAPI_SERVER_CODE_EXPIRED = 1021;
var WXAPI_SERVER_INVALID_JSON = 1022;
var WXAPI_SERVER_INVALID_STATE = 1023;
var WXAPI_SERVER_INVALID_PLUGIN_APPID = 1024;
var WXAPI_SERVER_WXA_APPID_PRIVACY_API_BANNED = 1025;
var WXAPI_SERVER_WXA_GAME_APPID_PRIVACY_API_BANNED = 1026;
var INVOKED_BY_USER_TAP = 50001;
var JSON_PARSE_ERROR = 100001;
var PRIVACY_SCOPE_IS_NOT_AUTH = 101100;
var PRIVACY_SCOPE_IS_BANNED = 101101;
var PRIVACY_SCOPE_IS_NOT_ALLOWED_TO_AUTH = 101102;
var SETTINGS_PAGE_NOT_FOUND = 102101;
var APPLYUPDATE_HAS_BEEN_CALLED = 103101;
var UPDATE_IS_NOT_READY = 103102;
var SUBPACKAGE_LOADING_UNKOWN_ERROR = 106000;
var SUBPACKAGE_LOADING_SUBPACKAGE_NOT_EXIST = 106001;
var SUBPACKAGE_LOADING_CLIENT_CHECKSUM_FAIL = 106002;
var SUBPACKAGE_LOADING_NETWORK_COMPONENT_FAIL = 106003;
var SUBPACKAGE_LOADING_NETWORK_FAIL_NOT_FOUND = 106004;
var SUBPACKAGE_LOADING_NETWORK_FAIL_GONE = 106005;
var SUBPACKAGE_LOADING_SERVER_FAIL = 106010;
var INVALID_RANDOM_VALUE_LENGTH = 109001;
var PAGE_NOT_FOUND = 200000;
var CAN_NOT_NAVIGATE_BACK = 201001;
var CAN_NOT_INVOKE_RELAUNCH = 201002;
var URL_HAS_BEEN_BANNED = 201003;
var NAVIGATE_ABILITY_BANNED = 301001;
var IOS_NOT_SUPPORT_CREATE_GAME_ENV = 301002;
var NOT_MINIPROGRAM_CAN_NAVIGATE_BACK = 301003;
var NOT_IN_TOUCHEND = 401101;
var LOW_PC_VERSION_OR_NOT_LOGIN = 401102;
var INVALID_STYLE = 500001;
var LENGTH_LIMITED = 502001;
var INVALID_FRONTCOLOR = 503101;
var INVALID_TEXTSTYLE = 504101;
var ABSOLUTE_PATH_ONLY = 505101;
var INVOKE_FREQUENTLY = 510001;
var INVALID_TEXT = 510101;
var UNKNOWN_NETWORK_ERROR = 600000;
var NETWORK_CRONET_COMPONENT_ERROR = 600001;
var NETWORK_URL_NOT_IN_DOMAIN_LIST = 600002;
var NETWORK_INTERRUPTED_ERROR = 600003;
var NETWORK_LOGIC_ERROR = 600004;
var NETWORK_ARGV_ERROR = 600005;
var NETWORK_SYSTEM_ERROR = 600006;
var NETWORK_MAX_TASK_ERROR = 600007;
var NETWORK_MAX_REDIRECT_ERROR = 600008;
var NETWORK_INVALID_URL_ERROR = 600009;
var NETWORK_INVALID_REQUEST_DATA_ERROR = 600010;
var NETWORK_URL_VALIDATE_ERROR = 600011;
var UNKNOWN_NETWORK_REQUEST_ERROR = 602000;
var REQUEST_SYSTEM_ERROR = 602001;
var REQUEST_SERVER_HTTP_ERROR = 602002;
var NOT_BUY_HTTPDNS_SERVICE = 602101;
var SERVICE_EXPIRED = 602102;
var NO_ENOUGH_HTTPDNS_QUOTA = 602103;
var EMPTY_SERVICER_RETURN = 602104;
var REQUEST_SERVICER_TIME_OUT = 602105;
var INVALID_SERVICER_RESPONSE = 602106;
var EMPTY_DOMAIN_HTTPDNS_RESULT = 602107;
var NOT_VALID_SERVICE_ID = 602108;
var REQUEST_BEYOUND_WEHTTPDNS_MAX_RETRY_NUMBER = 602120;
var REQUEST_EXCEED_MAX_NATIVE_BUFFER_LIMIT_ERROR = 602300;
var REQUEST_BIND_SOCKET_UNAVAILABLE_ERROR = 602301;
var REQUEST_RESPONSE_DATA_COVERT_ERROR = 602302;
var IOS_NOT_SUPPORT = 603101;
var ANDROID_NOT_SUPPORT = 603102;
var REQUIRE_PACKAGENAME_OR_PACKAGENAMEARRAY = 603103;
var REQUIRE_DOWNLOADID_OR_DOWNLOADIDARRAY_OR_APPIDARRAY = 603104;
var ABORT_DOWNLOAD_TASK = 603105;
var DOWNLOAD_SAVEFILE_ERROR = 603300;
var DOWNLOAD_EXCEED_MAX_FILE_SIZE_ERROR = 603301;
var DOWNLOAD_FILE_DATA_EMPTY_ERROR = 603302;
var DOWNLOAD_OPEN_PERMISSION_DENIED_ERROR = 603303;
var WEBSOCKET_IS_NOT_CONNECTED = 605101;
var SCOCKETTASK_READYSTATE_IS_NOT_OPEN = 605102;
var WEBSOCKET_CONNECT_FAIL = 605103;
var MDNS_RESOLVE_SYSTEM_ERROR = 606101;
var UNKNOWN_PAYMENT_ERROR = 700000;
var PAYMENT_USE_LIMITED = 700001;
var UNKNOWN_PAYMENT_DEFAULT_CLASS_ERROR = 701000;
var IOS_NOT_SUPPORT_PAYMENT = 701001;
var PAYMENT_NEED_REALNAME_VERIFY = 701002;
var PAYMENT_MIDAS_BUY_GOODS_FAILED = 701100;
var PAYMENT_MIDAS_GET_ACCOUNT_BALANCE_FAILED = 701101;
var PAYMENT_MIDAS_CURRENCY_PAY_FAILED = 701102;
var PAYMENT_MIDAS_CURRENCY_CANEL_PAY_FAILED = 701103;
var PAYMENT_MIDAS_CURRENCY_PRESENT_FAILED = 701104;
var PAYMENT_MIDAS_GET_WATER_FAILED = 701105;
var PAYMENT_MIDAS_CURRENCY_IN_SUFFICIENT = 701106;
var PAYMENT_MIDAS_CURRENCY_ORDER_NOT_EXISTS = 701107;
var PAYMENT_MIDAS_CURRENCY_ORDER_ALREADY_REFUNDED = 701108;
var PAYMENT_MIDAS_CURRENCY_CANCEL_PAY_AMOUNT_EXCEEDED = 701109;
var PAYMENT_MIDAS_CURRENCY_PAY_DUPLICATED_OPERATOR = 701110;
var PAYMENT_MIDAS_INVALID_PARAMETER = 701111;
var PAYMENT_MIDAS_GET_COUPONS_FAILED = 701112;
var PAYMENT_MIDAS_SET_COUPONS_ORDER_FAILED = 701113;
var PAYMENT_MIDAS_NO_VAILD_COUPONS = 701114;
var PAYMENT_MIDAS_ORDER_ALREADY_PAID = 701115;
var PAYMENT_MIDAS_NO_VALID_ROLLBACK_COUPON = 701116;
var PAYMENT_HONGBAO_QUICK_SEND_CANCEL_SELECT_CONVERSATION = 701117;
var UNKNOWN_STORAGE_ERROR = 800000;
var NONEXISTENT_STORAGE_SPACE = 800001;
var INTERNAL_ERROR_SET_DB_DATA_FAIL = 800002;
var INVALID_KEY = 800003;
var QUOTA_REACHED = 801001;
var INVALID_FETCHTYPE = 802001;
var BRANCHID_MUST_BE_STRING = 901101;
var BRANCHDIM_IS_OPTIONAL_STRING = 901102;
var EVENTTYPE_ERROR = 901103;
var TARGET_FILE_NOT_EXISTS = 1103002;
var IMAGE_DECODE_FAIL = 1103003;
var CREATE_TEMP_FILE_FAIL = 1103004;
var PROCESS_COMPRESS_IMAGE_ERROR = 1103005;
var PARAM_COMPRESS_QUALITY_INVALID = 1103006;
var SRC_IMAGE_WIDTH_OR_HEIGHT_IS_ZERO = 1103007;
var IS_LIVING_OR_CALLING_NOW = 1107001;
var SYSTEM_RECORD_PERMISSION_DENIED = 1107002;
var ILLEGAL_OPERATION_IN_BACKGROUND = 1107003;
var TAKE_SNAPSHOT_FAIL = 1107004;
var SAVE_TO_ALBUM_AFTER_TAKE_SNAPSHOT_FAIL = 1107005;
var SAVE_TO_TEMP_FILE_AFTER_TAKE_SNAPSHOT_FAIL = 1107006;
var NOT_IN_PICTURE_IN_PICTURE_MODE_NOW = 1107007;
var EXITING_PICTURE_IN_PICTURE_MODE_NOW = 1107008;
var REQUEST_BACKGROUND_PLAYBACK_BUT_SRC_EMPTY = 1107009;
var REQUEST_BACKGROUND_PLAYBACK_BUT_IN_RTC_MODE = 1107010;
var REQUEST_BACKGROUND_PLAYBACK_BUT_IN_BACKGROUND = 1107011;
var LOAD_RESOURCE_FILE_FAIL = 1107012;
var SYSTEM_RECORD_OR_CAMERA_PERMISSION_DENIED = 1107013;
var UNKNOWN_LOCATION_ERROR = 1200000;
var FS_OPERATION_NOT_PERMITTED = 1300001;
var FS_NO_SUCH_FILE_OR_DIR = 1300002;
var FS_IO_ERROR = 1300005;
var FS_BAD_FD = 1300009;
var FS_PERMISSION_DENIED = 1300013;
var FS_PATH_PERMISSION_DENIED = 1300014;
var FS_NOT_DIR = 1300020;
var FS_IS_DIR = 1300021;
var FS_INVALID_ARG = 1300022;
var FS_NAME_TOO_LONG = 1300036;
var FS_DIR_NOT_EMPTY = 1300066;
var FS_SYSTEM_ERROR = 1300201;
var FS_STORAGE_LIMIT_EXCEEDED = 1300202;
var FS_ENCODING_ERROR = 1300203;
var FS_SD_CARD_NOT_MOUNTED = 1300300;
var FS_EXT_ERROR = 1300301;
var FS_PERMISSION_DENIED_PATH = 1301000;
var FS_WRITE_EMPTY_DATA = 1301002;
var FS_ILLEGAL_OPERATION_ON_DIR = 1301003;
var FS_ILLEGAL_OPERATION_ON_PACKAGE_DIR = 1301004;
var FS_FILE_ALREADY_EXIST = 1301005;
var FS_LENGTH_OUT_OF_RANGE = 1301006;
var FS_OFFSET_OUT_OF_RANGE = 1301007;
var FS_FD_INVALID_TYPE = 1301008;
var FS_POSITION_OUT_OF_RANGE = 1301009;
var FS_STORE_DIR_IS_EMPTY = 1301100;
var FS_UNZIP_OPEN_FILE_FAIL = 1301102;
var FS_UNZIP_ENTRY_FAIL = 1301103;
var FS_UNZIP_FAIL = 1301104;
var FS_DECOMPRESS_FAIL = 1301111;
var FS_TEMP_FILE_NOT_EXIST = 1301112;
var FS_PERMISSION_DENIED_FD = 1302001;
var FS_FD_LIMIT_EXCEEDED = 1302002;
var FS_INVALID_FLAG = 1302003;
var FS_OPEN_WITH_FLAG_FAIL = 1302004;
var FS_ARRAY_BUFFER_NOT_EXIST = 1302005;
var FS_ARRAY_BUFFER_FORBID_WRITE = 1302100;
var UNKNOWN_OPENAPI_ERROR = 1400000;
var OPENAPI_APPID_NO_ENOUGH_QUOTA = 1400001;
var LOGIN_APPID_IS_BANNED = 1402101;
var UNKNOWN_USERINFO_ERROR = 1404000;
var APP_USERINFO_NOT_AUTHORIZED = 1404100;
var GET_USER_PROFILE_INVALID_MODE = 1404101;
var GET_USER_PROFILE_USER_ALREADY_GRANT = 1404102;
var GET_USER_PROFILE_SAME_USER_INFO = 1404103;
var GET_USER_PROFILE_USER_ALREADY_DENY_GRANT = 1404104;
var INVALID_TEMPLATE_ID = 1412000;
var LIST_REQUEST_FAIL = 1412001;
var SUBSCRIBE_REQUEST_FAIL = 1412002;
var SUBSCRIBE_INVALID_TEMPLATE_ID = 1412003;
var SUBSCRIBE_CGI_FAIL = 1412004;
var INVALID_FINDER_USER_NAME = 1416100;
var GET_FINDER_INFO_FAILED = 1416101;
var INVALID_FINDER_EXPORT_ID = 1416102;
var FINDER_NOT_SAME_CONTRACTOR = 1416103;
var FINDER_GET_EMPTY_FINDER_INFO = 1416104;
var FINDER_GET_PARTIALLY_VISIBLE_INFO = 1416105;
var FINDER_INVALID_FINDER_TOKEN = 1416106;
var FINDER_APPID_TOKEN_NO_PERMISSION = 1416107;
var FINDER_PARSE_TOKEN_FAILED = 1416108;
var FINDER_TOKEN_HIT_SPAM_LIMIT = 1416109;
var WEWORK_NOT_SAME_CONTRACTOR = 1420103;
var PHONE_NUMBER_GATEWAY_PHONE_NOT_MATCH = 1421101;
var BLUETOOTH_NOT_INIT = 1500101;
var BLUETOOTH_NOT_AVAILABLE = 1500102;
var BLE_NOT_SERVICE = 1500103;
var BLUETOOTH_SYSTEM_ERROR = 1500104;
var BLE_SYSTEM_NOT_SUPPORT = 1500105;
var GATT_SERVER_ALREADY_CONNECT = 1502001;
var GATT_SERVER_NOT_CONNECT = 1502002;
var NOT_GATT_SERVER = 1502003;
var UNKNOWN_IBEACON_ERROR = 1503000;
var UNKNOWN_NFC_ERROR = 1504000;
var NFC_NOT_SUPPORT = 1504001;
var NFC_NOT_SUPPORT_HCE = 1504002;
var NFC_NOT_OPENED = 1504003;
var NFC_NOT_SET_DEFAULT_NFC_APPLICATION = 1504100;
var NFC_REGISTER_AIDS_FAILED = 1504101;
var NFC_USER_NOT_AUTHORIZED = 1504200;
var NFC_PARSE_NDEF_MESSAGE_FAILED = 1504201;
var NFC_DISCOVERY_ALREADY_STARTED = 1504202;
var NFC_DISCOVERY_NOT_STARTED = 1504203;
var NFC_TECH_ALREADY_CONNECTED = 1504204;
var NFC_TECH_NOT_CONNECTED = 1504205;
var NFC_TAG_NOT_DISCOVERED = 1504206;
var NFC_INVALID_TECH = 1504207;
var NFC_UNAVAILABLE_TECH = 1504208;
var NFC_FUNCTION_NOT_SUPPORT = 1504209;
var NFC_SYSTEM_INTERNAL_ERROR = 1504210;
var UNKNOWN_WIFI_ERROR = 1505000;
var WIFI_NOT_INIT = 1505001;
var WIFI_NOT_OPENED = 1505002;
var WIFI_FAIL_MAYBE_CAUSE_BY_GPS_NOT_OPENED = 1505003;
var WIFI_FAIL_MAYBE_CAUSE_BY_GPS_PERMISSION_DENIED = 1505004;
var WIFI_FAIL_CONNECTED_WIFI_IS_NULL = 1505005;
var WIFI_FAIL_CONNECTED_WIFI_INVALID = 1505006;
var WIFI_FAIL_CONNECT_WIFI_UNKNOWN_ERROR = 1505020;
var WIFI_FAIL_CONNECT_WIFI_IN_BACKGROUND = 1505021;
var WIFI_FAIL_CONNECT_WIFI_OPEN_SETTINGS = 1505022;
var WIFI_FAIL_CONNECT_WIFI_DUPLICATED_REQUEST = 1505023;
var WIFI_FAIL_CONNECT_WIFI_PASSWORD_ERROR = 1505024;
var WIFI_FAIL_CONNECT_WIFI_WIFI_CONFIG_EXPIRED = 1505025;
var WIFI_FAIL_CONNECT_WIFI_TIMEOUT = 1505026;
var WIFI_FAIL_CONNECT_WIFI_USER_DENIED = 1505027;
var WIFI_FAIL_CONNECT_WIFI_SYSTEM_CONFIG_ERROR = 1505028;
var WIFI_FAIL_CONNECT_WIFI_INVALID_SSID = 1505029;
var WIFI_FAIL_CONNECT_WIFI_PENDING = 1505030;
var WIFI_FAIL_CONNECT_WIFI_INVALID_PASSWORD = 1505031;
var WIFI_FAIL_CONNECT_WIFI_SYSTEM_ERROR = 1505032;
var WIFI_FAIL_GET_CONNECTED_WIFI_FAIL = 1505040;
var UNKNOWN_BLE_ERROR = 1509000;
var BLE_CONNECT_FAIL = 1509001;
var BLE_NO_CHARACTERISTIC = 1509002;
var BLE_NOT_CONNECT = 1509003;
var BLE_PROP_NOT_SUPPORT = 1509004;
var BLE_OPERATE_TIMEOUT = 1509005;
var BLE_NO_DEVICE = 1509006;
var BLE_ALREADY_CONNECT = 1509007;
var BLE_SCAN_FAIL_LOCATION_PERMISSION_DENIED = 1509008;
var BLE_SCAN_FAIL_LOCATION_DISABLED = 1509009;
var BLE_OPEN_BLUETOOTH_ADAPTER_STATE_UPDATE_TIMEOUT = 1509010;
var UNKNOWN_BLUETOOTH_ERROR = 1510000;
var BLUETOOTH_NEED_PIN = 1510101;
var BLUETOOTH_BACKGROUND_MODE_APP_REACH_MAX_COUNT = 1510102;
var BLUETOOTH_MONITOR_CURRENT_INTERFACE_BUSY = 1510103;
var BLUETOOTH_MONITOR_DEVICE_EMPTY = 1510104;
var BLUETOOTH_MONITOR_REPEAT_SN_DEVICEID = 1510105;
var BLUETOOTH_MONITOR_BIND_SN_DEVICEID = 1510106;
var BLUETOOTH_MONITOR_INVALID_SN_SNTICKET = 1510107;
var BLUETOOTH_MONITOR_INVALID_ENV_VERSION = 1510108;
var BLUETOOTH_MONITOR_ENABLE_MONITORING = 1510109;
var BLUETOOTH_MONITOR_ONLY_CONNECTED = 1510110;
var BLUETOOTH_MONITOR_INVALID_BIND_SN_APPID = 1510111;
var BLUETOOTH_MONITOR_INVALID_DEVICES_MAX_COUNT = 1510112;
var BLUETOOTH_MONITOR_INVALID_SUBPACKAGES = 1510113;
var BLUETOOTH_MONITOR_INVALID_ENTRY_PACKAGE = 1510114;
var PASTEBOARD_EMPTY_CONTENT = 1512001;
var PASTEBOARD_UER_REJECT = 1512002;
var SEND_SMS_CONTENT_LENGTH_REACH_MAX_COUNT = 1517001;
var SIM_SYSTEM_NOT_SUPPORT = 1525001;
var SIM_SERVICE_NOT_CONNECTED = 1525002;
var SIM_SYSTEM_ERROR = 1525003;
var AI_SYSTEM_ERROR = 2000000;
var AI_INVALID_ARGUMENT = 2000001;
var AI_DEVICE_NOT_SUPPORTED = 2000002;
var AI_OS_NOT_SUPPORTED = 2000003;
var AI_LIBRARY_NOT_SUPPORTED = 2000004;
var UNKNOWN_ERROR = 2002000;
var FACE_DETECTION_NOT_INITIALIZE = 2002001;
var FACE_DETECTION_DUPLICATED_INITIALIZATION = 2002002;
var FACE_DETECTION_FAILED_INITIALIZATION = 2002003;
var FACE_NOT_DETECTED_OR_DETECTION_FAILED = 2002004;
var STOP_FACE_DETECTION_FAILED = 2002005;
var VK_SESSION_UNAVAILABLE = 2003000;
var VK_NO_SYSTEM_CAMERA_ACCESS = 2003001;
var VK_NO_MINIPROGRAM_CAMERA_ACCESS = 2003002;
var AI_INVALID_MODEL_FILE_PATH = 2004000;
var AI_CREATE_SESSION_SDK_FAIL = 2004001;
var AI_RUN_SESSION_SESSION_ID_IS_EMPTY = 2004002;
var AI_RUN_SESSION_INPUT_TENSORS_IS_EMPTY = 2004003;
var AI_RUN_SESSION_INPUT_DATA_TYPE_IS_UNSUPPORTED = 2004004;
var AI_RUN_SESSION_INVALID_SESSION_ID = 2004005;
var AI_RUN_SESSION_OUTPUT_DATA_TYPE_IS_UNSUPPORTED = 2004006;
var AI_RUN_SESSION_INPUT_TENSOR_DATA_IS_INVALID = 2004007;
var AI_RUN_SESSION_INVALID_SHAPE = 2004008;
var AI_RUN_SESSION_SDK_FAIL = 2004009;
var AI_ENVIRONMENT_NOT_READY = 2004010;
var AI_RELEASE_SESSION_ID_FIAL_SESSION_ID_NOT_EXIST = 2004011;
var AI_RUN_SESSION_INPUT_TENSOR_ATTRIBUTION_IMCOMPLETE = 2004012;
;// CONCATENATED MODULE: ./src/utils/timeout.js

var ObjectAssign = /* #__PURE__ */(() => Object.assign)();
var timeout = (func, args) => {
  var time = args.timeout;
  if (typeof time !== 'number') {
    func(args);
    return;
  }
  var isTimeout = false;
  var timer = setTimeout(() => {
    var res = {
      errMsg: 'request timeout',
      errno: GENERAL_TIME_OUT
    };
    isTimeout = true;
    typeof args.fail === 'function' && args.fail(res);
    typeof args.complete === 'function' && args.complete(res);
  }, time);
  var callbackObj = ['success', 'fail', 'complete'].reduce((obj, callbackName) => {
    obj[callbackName] = res => {
      if (isTimeout) {
        return;
      }
      clearTimeout(timer);
      typeof args[callbackName] === 'function' && args[callbackName](res);
    };
    return obj;
  }, {});
  func(ObjectAssign({}, args, callbackObj));
};
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getFriendUserGameData.js


var getFriendUserGameData = function (args) {
  timeout(_args => {
    BaseMethods_invokeSharedMethod('getFriendUserGameData', _args);
  }, args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getGroupUserGameData.js


var getGroupUserGameData = function (args) {
  timeout(_args => {
    BaseMethods_invokeSharedMethod('getGroupUserGameData', _args);
  }, args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getFriendCloudStorage.js


var getFriendCloudStorage = function (args) {
  timeout(_args => {
    BaseMethods_invokeSharedMethod('getFriendCloudStorage', _args);
  }, args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getGroupInfo.js


var getGroupInfo = function (args) {
  timeout(_args => {
    BaseMethods_invokeSharedMethod('getGroupInfo', _args);
  }, args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getGroupCloudStorage.js


var getGroupCloudStorage = function (args) {
  timeout(_args => {
    BaseMethods_invokeSharedMethod('getGroupCloudStorage', _args);
  }, args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getUserCloudStorage.js


var getUserCloudStorage = function (args) {
  timeout(_args => {
    BaseMethods_invokeSharedMethod('getUserCloudStorage', _args);
  }, args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getUserCloudStorageKeys.js


var getUserCloudStorageKeys = function (args) {
  timeout(_args => {
    BaseMethods_invokeSharedMethod('getUserCloudStorageKeys', _args);
  }, args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/removeUserCloudStorage.js


var removeUserCloudStorage = function (args) {
  timeout(_args => {
    BaseMethods_invokeSharedMethod('removeUserCloudStorage', _args);
  }, args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/setUserCloudStorage.js


var setUserCloudStorage = function (args) {
  timeout(_args => {
    BaseMethods_invokeSharedMethod('setUserCloudStorage', _args);
  }, args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/shareMessageToFriend.js

var shareMessageToFriend = args => {
  BaseMethods_invokeSharedMethod('shareMessageToFriend', args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getPotentialFriendList.js

var getPotentialFriendList = args => {
  BaseMethods_invokeSharedMethod('getPotentialFriendList', args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getUserInfo.js


var getUserInfo = function (args) {
  timeout(_args => {
    BaseMethods_invokeSharedMethod('getUserInfo', _args);
  }, args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/getGameServerManager.js

var getGameServerManager = () => BaseMethods_invokeSharedMethod('getGameServerManager');

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/handoff.js

var checkHandoffEnabled = args => {
  BaseMethods_invokeSharedMethod('checkHandoffEnabled', args);
};
var startHandoff = args => {
  BaseMethods_invokeSharedMethod('startHandoff', args);
};

;// CONCATENATED MODULE: ./src/base/emitter.js

var runThirdFunc = (fn, msg, ...args) => {
  if (typeof __errorTracer__ !== 'undefined') {
    __errorTracer__.surroundThirdByTryCatch(fn, msg)(...args);
  } else if (typeof __subContextEngine__ !== 'undefined') {
    __subContextEngine__.surroundThirdByTryCatch(fn, msg)(...args);
  } else {
    try {
      fn(...args);
    } catch (e) {
      console.error(`thirdScriptError\n${e === null || e === void 0 ? void 0 : e.message};${msg}`);
      console.error(e);
    }
  }
};
class Emitter {
  constructor(type = '', surround = false) {
    this.type = '';
    this.surround = false;
    this.eventMap = new Map();
    this.type = type;
    this.surround = surround;
  }
  on(name, callback) {
    if (isFunction(callback)) {
      if (this.eventMap.has(name)) {
        this.eventMap.get(name).add(callback);
      } else {
        this.eventMap.set(name, new Set([callback]));
      }
    } else {
      console.error('EmitterError: callback must be a function');
    }
  }
  off(name, callback) {
    var set = this.eventMap.get(name);
    if (typeof callback !== 'function') {
      set === null || set === void 0 ? void 0 : set.clear();
    } else {
      set === null || set === void 0 ? void 0 : set.delete(callback);
    }
  }
  emit(name, ...args) {
    var Q = [...(this.eventMap.get(name) || [])];
    var msg = `at ${this.type}${name} callback function`;
    Q.forEach(cb => this.surround ? runThirdFunc(cb, msg, ...args) : cb(...args));
  }
  removeAllListeners(name) {
    this.off(name);
  }
  getListenersLength(name) {
    var _this$eventMap$get;
    return ((_this$eventMap$get = this.eventMap.get(name)) === null || _this$eventMap$get === void 0 ? void 0 : _this$eventMap$get.size) || 0;
  }
}
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/event/touch/index.js


var touchEventTypes = ['Start', 'Move', 'End', 'Cancel'];
var touch_emitter = new Emitter('touch', true);
var cm = new Map();
function _cp(x) {
  if (Array.isArray(x)) {
    return x.map(_cp);
  } else if (x && typeof x === 'object') {
    if (!cm.has(x)) {
      var o = {};
      cm.set(x, o);
      Object.keys(x).forEach(k => {
        o[k] = _cp(x[k]);
      });
    }
    return cm.get(x);
  } else {
    return x;
  }
}
function deepCopy(x) {
  cm.clear();
  var ret = _cp(x);
  cm.clear();
  return ret;
}
gameopendataSubContext_SharedEnv.onReady(() => {
  touchEventTypes.forEach(type => {
    gameopendataSubContext_SharedEnv.Touch.on(type.toLowerCase(), event => {
      if (touch_emitter.getListenersLength(type) > 0) {
        touch_emitter.emit(type, deepCopy(event));
      }
    });
  });
});
var _exports = {};
touchEventTypes.forEach(type => {
  var onEventName = `onTouch${type}`;
  var offEventName = `offTouch${type}`;
  _exports[onEventName] = callback => {
    touch_emitter.on(type, callback);
  };
  _exports[offEventName] = callback => {
    touch_emitter.off(type, callback);
  };
});
/* harmony default export */ const touch = (_exports);
;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/event/index.js

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/modifyFriendInteractiveStorage.js

var modifyFriendInteractiveStorage = args => {
  BaseMethods_invokeSharedMethod('modifyFriendInteractiveStorage', args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/API/routeJSServer.js

var routeJSServer = args => {
  BaseMethods_invokeSharedMethod('routeJSServer', args);
};

;// CONCATENATED MODULE: ./src/game/gameopendataSubContext/index.js


























var onTouchStart = touch.onTouchStart;
var offTouchStart = touch.offTouchStart;
var onTouchMove = touch.onTouchMove;
var offTouchMove = touch.offTouchMove;
var onTouchEnd = touch.onTouchEnd;
var offTouchEnd = touch.offTouchEnd;
var onTouchCancel = touch.onTouchCancel;
var offTouchCancel = touch.offTouchCancel;
var wx = {
  getSystemInfo: getSystemInfo,
  getSystemInfoSync: getSystemInfoSync,
  createCanvas: createCanvas,
  createImage: createImage,
  createInnerAudioContext: createInnerAudioContext,
  onTouchStart,
  onTouchMove,
  onTouchEnd,
  onTouchCancel,
  offTouchStart,
  offTouchMove,
  offTouchEnd,
  offTouchCancel,
  onMessage: onMessage,
  routeJSServer: routeJSServer,
  checkHandoffEnabled: checkHandoffEnabled,
  startHandoff: startHandoff,
  getGroupUserGameData: getGroupUserGameData,
  getFriendUserGameData: getFriendUserGameData,
  getUserInfo: getUserInfo,
  getFriendCloudStorage: getFriendCloudStorage,
  getGroupInfo: getGroupInfo,
  getGroupCloudStorage: getGroupCloudStorage,
  getUserCloudStorage: getUserCloudStorage,
  setUserCloudStorage: setUserCloudStorage,
  getUserCloudStorageKeys: getUserCloudStorageKeys,
  removeUserCloudStorage: removeUserCloudStorage,
  modifyFriendInteractiveStorage: modifyFriendInteractiveStorage,
  shareMessageToFriend: shareMessageToFriend,
  getPotentialFriendList: getPotentialFriendList,
  getGameServerManager: getGameServerManager,
  getSharedCanvas: getSharedCanvas
};
var exportAPIs = {};
var apiCache = {};
var Global = globalThis;
var gameopendataSubContext_init = function (env) {
  Global.__isAdapterInjected = false;
  Global.__isSubContext = true;
  Global.WXConfig = JSON.parse(JSON.stringify(env.WXConfig));
  Global.wx = exportAPIs;
  Global.requirePlugin = (plugin, customEnv) => env.requirePlugin(plugin, customEnv, true);
  var {
    platform
  } = Global.WXConfig;
  if (platform === 'devtools') {
    Global.console = env.console;
  }
  wxNativeConsole = env.wxNativeConsole;
  Object.defineProperty(Global, '__wxSourceMap', {
    get: env.getWxSourceMap
  });
  gameopendataSubContext_SharedEnv.update(env);
  _setAndWrapSharedCanvas(gameopendataSubContext_SharedEnv.openDataContextGetSharedCanvas());
  Global.sharedCanvas = getSharedCanvas();
  if (!isWKRendererH5()) {
    Global.GameGlobal = Global;
  }
  if (platform === 'windows' || platform === 'mac' || platform === 'mina') {
    Object.defineProperties(Global, {
      Uint8Array: {
        value: Uint8Array
      },
      Uint16Array: {
        value: Uint16Array
      },
      Uint32Array: {
        value: Uint32Array
      },
      Float32Array: {
        value: Float32Array
      }
    });
  }
  Reporter = env.Reporter;
  env.apiReport(wx, 1);
  Object.keys(wx).forEach(key => {
    exportAPIs.__defineGetter__(key, () => {
      if (typeof wx[key] === 'function') {
        if (!apiCache[key]) {
          apiCache[key] = surroundByTryCatch(wx[key], `wx.${key}`);
        }
        return apiCache[key];
      } else {
        return wx[key];
      }
    });
  });
};

__gameOpenDataSDK__ = __webpack_exports__;
/******/ })()
;
var __condom__;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  condom: () => (/* binding */ condom_condom),
  condomWX: () => (/* binding */ condomWX),
  handleMessageEasyCondom: () => (/* reexport */ handleMessageEasyCondom),
  shouldCloseCondom: () => (/* reexport */ shouldCloseCondom)
});

;// CONCATENATED MODULE: ./src/condom/WxCondom.ts

var DEBUG = false;
var shouldCondom = obj => typeof obj === 'object' && obj !== null && !obj._isVue || typeof obj === 'function';
var Object$$toString = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Object.prototype.toString)()));
var Object$$hasOwnProperty = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Object.prototype.hasOwnProperty)()));
var String$$slice = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => String.prototype.slice)()));
var objectToString = /* #__PURE__ */(/* unused pure expression or super */ null && (Function.prototype.call.bind(Object$$toString)));
var WxCondom_hasOwnProperty = /* #__PURE__ */(/* unused pure expression or super */ null && (Function.prototype.call.bind(Object$$hasOwnProperty)));
var StringSlice = /* #__PURE__ */(/* unused pure expression or super */ null && (Function.prototype.call.bind(String$$slice)));
var getDataType = data => StringSlice(objectToString(data), 8, -1);
var PROPS_BLACK_LIST = (/* unused pure expression or super */ null && (['__proto__', '__defineGetter__', '__defineSetter__', '__lookupGetter__', '__lookupSetter__', '__ob__', '__su__', '$mobx']));
var ObjectAssign = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Object.assign)()));
var ObjectGetOwnPropertyNames = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Object.getOwnPropertyNames)()));
var ObjectGetOwnPropertySymbols = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Object.getOwnPropertySymbols)()));
var ObjectGetOwnPropertyDescriptor = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Object.getOwnPropertyDescriptor)()));
var ObjectGetOwnPropertyDescriptors = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Object.getOwnPropertyDescriptors)()));
var ObjectDefineProperty = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Object.defineProperty)()));
var ObjectGetPrototypeOf = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Object.getPrototypeOf)()));
var ObjectSetPrototypeOf = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Object.setPrototypeOf)()));
var ReflectGet = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Reflect.get)()));
var ReflectSet = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Reflect.set)()));
var ReflectDeleteProperty = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Reflect.deleteProperty)()));
var ReflectConstruct = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Reflect.construct)()));
var ReflectApply = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Reflect.apply)()));
function getAllPropertyDescs(obj) {
  var names = [...ObjectGetOwnPropertyNames(obj), ...ObjectGetOwnPropertySymbols(obj)];
  var descriptors = ObjectGetOwnPropertyDescriptors(obj);
  return names.map(name => ObjectAssign(descriptors[name], {
    name
  }));
}
var condomArray = (array, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, condomArray, forceUpdate) => {
  if (!isDeCondom && condomArray && !forceUpdate) return condomArray;
  condomArray = condomArray || [];
  condomMapping.set(array, condomArray);
  reverseCondomMapping.set(condomArray, array);
  var targetLength = array.length;
  var currentLength = condomArray.length;
  for (var i = 0; i < currentLength; ++i) {
    condomArray[i] = condom(array[i], {
      forceUpdate,
      path: DEBUG ? `[${i}]` : undefined
    });
  }
  if (targetLength < currentLength) {
    condomArray.slice(targetLength, currentLength - targetLength);
  } else {
    for (var _i = currentLength; _i < targetLength; ++_i) {
      condomArray.push(condom(array[_i], {
        forceUpdate,
        path: DEBUG ? `[${_i}]` : undefined
      }));
    }
  }
  return condomArray;
};
var LooseModeFunctionSet = /* #__PURE__ */new WeakSet();
var markCondomFunctionLooseMode = func => {
  LooseModeFunctionSet.add(func);
};
var JSONParse = JSON.parse;
var _jsonParse = str => {
  var res = JSONParse(str);
  avoidCondom(res);
  return res;
};
var _stringToAnyType = (data, dataType) => {
  var res = stringToAnyType(data, dataType);
  avoidCondom(res);
  return res;
};
var PassJsonParseFunctionSet = /* #__PURE__ */new WeakSet();
var markCondomFunctionJsonParse = func => {
  PassJsonParseFunctionSet.add(func);
};
var condomFunction = (func, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, condomFunction, forceUpdate) => {
  if (condomFunction) return condomFunction;
  condomFunction = function (...args) {
    var looseMode = LooseModeFunctionSet.has(func);
    var passJsonParse = PassJsonParseFunctionSet.has(func);
    var condomArgs = args.map((arg, index) => {
      if (index !== 0 || typeof arg !== 'object' || arg === null) return arg;
      var firstArg = ObjectAssign({}, arg);
      if (looseMode) {
        var {
          success,
          fail,
          complete
        } = arg;
        if (WxCondom_hasOwnProperty(arg, 'success')) {
          firstArg.success = typeof success === 'function' ? deCondom((...args) => {
            success(...args);
          }) : success;
        }
        if (WxCondom_hasOwnProperty(arg, 'fail')) {
          firstArg.fail = typeof fail === 'function' ? deCondom((...args) => {
            fail(...args);
          }) : fail;
        }
        if (WxCondom_hasOwnProperty(arg, 'complete')) {
          firstArg.complete = typeof complete === 'function' ? deCondom((...args) => {
            complete(...args);
          }) : complete;
        }
      }
      if (passJsonParse) {
        ObjectAssign(firstArg, {
          _jsonParse,
          _stringToAnyType
        });
      }
      return firstArg;
    });
    if (passJsonParse && (typeof args[0] !== 'object' || args[0] === null)) {
      condomArgs.push({
        _jsonParse,
        _stringToAnyType
      });
    }
    if (!looseMode) {
      condomArgs = deCondom(args);
    }
    if (this instanceof condomFunction) {
      return condom(ReflectConstruct(func, condomArgs, func));
    } else {
      return condom(ReflectApply(func, looseMode ? this : deCondom(this, {
        forceUpdate: true
      }), condomArgs));
    }
  };
  condomMapping.set(func, condomFunction);
  reverseCondomMapping.set(condomFunction, func);
  condomObjectDesc(func, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, condomFunction, forceUpdate);
  return condomFunction;
};
var condomObjectDesc = (obj, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, condomObject, forceUpdate) => {
  var propDescs = getAllPropertyDescs(obj);
  var condomObjectDescriptors = ObjectGetOwnPropertyDescriptors(condomObject);
  var _loop = function () {
    var desc = propDescs[i];
    var propName = desc.name;
    if (PROPS_BLACK_LIST.includes(propName)) return "continue";
    var hasValue = WxCondom_hasOwnProperty(desc, 'value');
    var currentDesc = WxCondom_hasOwnProperty(condomObjectDescriptors, propName) && condomObjectDescriptors[propName];
    if (!currentDesc) {
      if (hasValue) {
        ObjectDefineProperty(condomObject, propName, {
          value: condom(desc.value, {
            forceUpdate,
            path: DEBUG ? propName : undefined
          }),
          writable: desc.writable,
          enumerable: desc.enumerable,
          configurable: desc.configurable
        });
      } else {
        ObjectDefineProperty(condomObject, propName, {
          get() {
            return condom(ReflectGet(obj, propName, deCondom(this, {
              forceUpdate: true
            })));
          },
          set(val) {
            ReflectSet(obj, propName, deCondom(val), deCondom(this, {
              forceUpdate: true
            }));
          },
          enumerable: desc.enumerable,
          configurable: desc.configurable
        });
      }
    } else if (currentDesc.configurable) {
      if (hasValue) {
        ObjectDefineProperty(condomObject, propName, {
          value: condom(desc.value, {
            forceUpdate,
            path: DEBUG ? propName : undefined
          }),
          writable: desc.writable,
          enumerable: desc.enumerable,
          configurable: desc.configurable
        });
      } else {
        ObjectDefineProperty(condomObject, propName, {
          enumerable: desc.enumerable,
          configurable: desc.configurable
        });
      }
    } else if (currentDesc.writable) {
      condomObject[propName] = condom(desc.value, {
        forceUpdate,
        path: DEBUG ? propName : undefined
      });
    }
    if (currentDesc) ReflectDeleteProperty(condomObjectDescriptors, propName);
  };
  for (var i = 0; i < propDescs.length; i++) {
    var _ret = _loop();
    if (_ret === "continue") continue;
  }
  var deletedKeys = [...ObjectGetOwnPropertyNames(condomObjectDescriptors), ...ObjectGetOwnPropertySymbols(condomObjectDescriptors)];
  for (var _i2 = 0; _i2 < deletedKeys.length; ++_i2) {
    ReflectDeleteProperty(condomObject, deletedKeys[_i2]);
  }
  return condomObject;
};
var condomObjectPrototype = (obj, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, condomObject, forceUpdate) => {
  var proto = ObjectGetPrototypeOf(obj);
  if (proto !== null && proto !== void 0 && proto.constructor && proto.constructor.name !== 'Object') {
    ObjectSetPrototypeOf(condomObject, condom(proto, {
      forceUpdate,
      path: DEBUG ? '__proto__' : undefined
    }));
  }
  return condomObject;
};
var condomObject = (obj, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, condomObject = undefined, forceUpdate) => {
  if (!isDeCondom && condomObject && !forceUpdate) return condomObject;
  condomObject = condomObject || {};
  condomMapping.set(obj, condomObject);
  reverseCondomMapping.set(condomObject, obj);
  condomObjectDesc(obj, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, condomObject, forceUpdate);
  condomObjectPrototype(obj, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, condomObject, forceUpdate);
  return condomObject;
};
var condomPromise = (promise, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, promiseCondom, forceUpdate) => {
  if (promiseCondom) return promiseCondom;
  promiseCondom = new Promise((resolve, reject) => {
    promise.then(res => resolve(condom(res)), err => reject(condom(err)));
  });
  condomMapping.set(promise, promiseCondom);
  reverseCondomMapping.set(promiseCondom, promise);
  return promiseCondom;
};
var ArrayBuffer$$ = ArrayBuffer.prototype;
var condomDepth = 0;
var condomCount = 0;
var condomStart = 0;
var paths = (/* unused pure expression or super */ null && ([]));
var rootObj;
var rootErr;
var condomFactory = (isDeCondom, condom, deCondom, condomMapping, reverseCondomMapping) => (obj, {
  forceUpdate = false,
  path
} = {}) => {
  if (!shouldCondom(obj) || reverseCondomMapping.has(obj) || ignoreSet.has(obj)) return obj;
  var cachedObj = undefined;
  if (condomMapping.has(obj)) cachedObj = condomMapping.get(obj);
  if (condomSet.has(obj)) return cachedObj;
  condomSet.add(obj);
  var dataType = getDataType(obj);
  try {
    if (DEBUG) {
      if (condomDepth === 0) {
        rootObj = obj;
        rootErr = new Error();
        condomStart = Date.now();
      }
      condomDepth += 1;
      condomCount += 1;
      if (path) paths.push(path);
      if (condomCount >= 1e6) {
        if (condomCount === 1e6) {
          console.error('WxCondom may encountered an infinite loop.', rootObj, paths, rootErr.stack);
          var error = new Error('WxCondom may encountered an infinite loop. in ' + paths.join('.'));
          error.stack = rootErr.stack;
          Reporter.errorReport({
            key: 'appServiceSDKScriptError',
            error,
            extend: 'at WxCondom'
          });
        }
        return cachedObj || obj;
      }
    }
    var result = obj;
    switch (dataType) {
      case 'Array':
        {
          result = condomArray(obj, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, cachedObj, forceUpdate);
          break;
        }
      case 'Function':
        {
          result = condomFunction(obj, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, cachedObj, forceUpdate);
          break;
        }
      case 'Object':
        {
          result = condomObject(obj, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, cachedObj, forceUpdate);
          break;
        }
      case 'Promise':
        {
          result = condomPromise(obj, condom, deCondom, condomMapping, reverseCondomMapping, isDeCondom, cachedObj, forceUpdate);
          break;
        }
      case 'ArrayBuffer':
        {
          if (!isDeCondom && obj !== ArrayBuffer$$) {
            ObjectSetPrototypeOf(obj, ArrayBuffer$$);
          }
          break;
        }
      default:
        result = obj;
    }
    return result;
  } finally {
    condomSet.delete(obj);
    if (DEBUG) {
      condomDepth -= 1;
      if (condomDepth === 0) {
        var cost = Date.now() - condomStart;
        if (cost >= 1000) {
          console.warn(`WxCondom slow. cost ${cost}ms, count ${condomCount}.`);
        }
        condomCount = 0;
      }
      if (path) paths.pop();
    }
  }
};
var condomMapping = /* #__PURE__ */new WeakMap();
var reverseCondomMapping = /* #__PURE__ */new WeakMap();
var condomSet = /* #__PURE__ */new WeakSet();
var ignoreSet = /* #__PURE__ */new WeakSet();
var avoidCondom = obj => {
  if (!shouldCondom(obj)) return;
  ignoreSet.add(obj);
};
var condom = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => {
  var _condom = i => i;
  var _deCondom = i => i;
  var condom = (...args) => _condom(...args);
  var deCondom = (...args) => _deCondom(...args);
  _condom = condomFactory(false, condom, deCondom, condomMapping, reverseCondomMapping);
  _deCondom = condomFactory(true, deCondom, condom, reverseCondomMapping, condomMapping);
  return condom;
})()));
;// CONCATENATED MODULE: ./src/condom/OldWxCondom.js
function OldWxCondom_getDataType(data) {
  return Object.prototype.toString.call(data).split(' ')[1].split(']')[0];
}
var ObjGetProto = Object.getPrototypeOf;
var ObjGetPropNames = Object.getOwnPropertyNames;
var ObjGetPropDesc = Object.getOwnPropertyDescriptor;
var ObjDefProp = Object.defineProperty;
var OldWxCondom_PROPS_BLACK_LIST = ['constructor', '__proto__', '__defineGetter__', '__defineSetter__'];
var originalObjects = new WeakMap();
var originalFuncs = new WeakMap();
var originalArrays = new WeakMap();
var condomFuncs = new WeakMap();
var condomObjects = new WeakMap();
var condomArrays = new WeakMap();
var OldWxCondom_getAllPropertyDescs = obj => {
  var properties = [];
  for (var o = obj; o; o = ObjGetProto(o)) {
    var props = ObjGetPropNames(o);
    for (var i = 0; i < props.length; i++) {
      var prop = props[i];
      var desc = ObjGetPropDesc(o, prop);
      if (desc === undefined) {
        continue;
      }
      desc.name = prop;
      properties.push(desc);
    }
  }
  return properties;
};
var isBlackListProp = prop => {
  for (var i = 0; i < OldWxCondom_PROPS_BLACK_LIST.length; i++) {
    var blackProp = OldWxCondom_PROPS_BLACK_LIST[i];
    if (blackProp === prop) {
      return true;
    }
  }
  return false;
};
var funcCondomFactory = function (func) {
  if (condomFuncs.has(func)) {
    return condomFuncs.get(func);
  }
  var condomFunc = function () {
    'use strict';

    var argumentsCondom = [];
    for (var i = 0; i < arguments.length; i++) {
      argumentsCondom[i] = WxCondom(arguments[i]);
    }
    var obj = DeWxCondom(this) || this;
    var ret = func.apply(obj, argumentsCondom);
    return WxCondom(ret);
  };
  condomFuncs.set(func, condomFunc);
  originalFuncs.set(condomFunc, func);
  return condomFunc;
};
var arrayCondomFactory = function (array) {
  if (condomArrays.has(array)) {
    return condomArrays.get(array);
  }
  var condomArray = [];
  for (var i = 0; i < array.length; i++) {
    var value = array[i];
    condomArray.push(WxCondom(value));
  }
  condomArrays.set(array, condomArray);
  originalArrays.set(condomArray, array);
  return condomArray;
};
var objectCondomFactory = function (object) {
  var condomObject = condomObjects.has(object) ? condomObjects.get(object) : {};
  var propDescs = OldWxCondom_getAllPropertyDescs(object);
  for (var i = 0; i < propDescs.length; i++) {
    var desc = propDescs[i];
    var propName = desc.name;
    if (isBlackListProp(propName)) {
      continue;
    }
    if (propName in condomObject) {
      continue;
    }
    delete desc.value;
    delete desc.writable;
    ObjDefProp(condomObject, propName, Object.assign(desc, {
      get: objGetterFactory(propName).bind(condomObject),
      set: objSetterFactory(propName).bind(condomObject)
    }));
  }
  condomObjects.set(object, condomObject);
  originalObjects.set(condomObject, object);
  return condomObject;
};
var objGetterFactory = function (p) {
  return function () {
    var obj = originalObjects.get(this);
    if (obj === undefined) {
      return undefined;
    }
    if (obj === null) {
      return null;
    }
    return WxCondom(obj[p]);
  };
};
var objSetterFactory = function (p) {
  return function (value) {
    var obj = originalObjects.get(this);
    if (obj === undefined) {
      return;
    }
    if (obj === null) {
      return;
    }
    if (value != null) {
      var original = DeWxCondom(value);
      if (original) {
        obj[p] = original;
        return;
      }
    }
    obj[p] = WxCondom(value);
  };
};
var DeWxCondom = function (condom) {
  if (typeof condom !== 'function' && typeof condom !== 'object' || condom == null) {
    return undefined;
  }
  return originalObjects.get(condom) || originalFuncs.get(condom) || originalArrays.get(condom);
};
var WxCondom = function (value) {
  var dataType = OldWxCondom_getDataType(value);
  if (dataType === 'String' || dataType === 'Number' || dataType === 'Boolean') {
    return value.valueOf();
  } else if (dataType === 'Array') {
    return arrayCondomFactory(value);
  } else if (dataType === 'Function') {
    return funcCondomFactory(value);
  } else if (dataType === 'Object') {
    return objectCondomFactory(value);
  } else if (dataType === 'ArrayBuffer') {
    if (value !== ArrayBuffer.prototype) {
      value.__proto__ = ArrayBuffer.prototype;
    }
    return value;
  } else if (dataType === 'Undefined') {
    return undefined;
  } else if (dataType === 'Null') {
    return null;
  } else {
    return value;
  }
};
/* harmony default export */ const OldWxCondom = (WxCondom);
;// CONCATENATED MODULE: ./src/condom/WorkerEasyCondom.ts
function _parseKeyChain(params, keyChainStr) {
  if (!keyChainStr) return null;
  var keyChain = keyChainStr.split('.');
  if (!keyChain.length) return null;
  var lastKey = keyChain[keyChain.length - 1];
  var wrap = params;
  for (var i = 1; i < keyChain.length - 1; i++) {
    if (!wrap) {
      return null;
    }
    var _key = keyChain[i];
    wrap = wrap[_key];
  }
  return [wrap, lastKey];
}
function parseKeyChain(params, keyChainStrs) {
  keyChainStrs.forEach(keyChainStr => {
    var parsedKeyChain = _parseKeyChain(params, keyChainStr);
    if (!parsedKeyChain) return;
    var [wrap, key] = parsedKeyChain;
    Object.setPrototypeOf(wrap[key], ArrayBuffer.prototype);
  });
}
var handleMessageEasyCondom = msg => {
  var packkeys = msg.__wx_dont_hook_sdk_inner_variable_packkeys_otherwise_you_will_regret_and_occur_bug__;
  if (packkeys) {
    delete msg.__wx_dont_hook_sdk_inner_variable_packkeys_otherwise_you_will_regret_and_occur_bug__;
  }
  if (packkeys) {
    parseKeyChain(msg, packkeys);
    return true;
  }
  return false;
};

;// CONCATENATED MODULE: ./src/condom/gameCompat/index.ts
var weCompatCondom = {};

;// CONCATENATED MODULE: ./src/base/WXConfig.ts
var EnvPreloadType = (/* unused pure expression or super */ null && ({
  None: 0,
  BeforeLaunch: 1,
  AfterLaunch: 2
}));
var updateConfig = () => {
  if (WXConfig_WXConfig !== __wxConfig && typeof WXConfig_WXConfig !== 'undefined') {
    Object.assign(WXConfig_WXConfig, __wxConfig);
  }
};
var WXConfig_WXConfig = /* #__PURE__ */(() => {
  __wxConfig.onReady(updateConfig);
  return __wxConfig;
})();
/* harmony default export */ const base_WXConfig = (WXConfig_WXConfig);
;// CONCATENATED MODULE: ./src/base/env.ts

var PLATFORM = /* #__PURE__ */(() => base_WXConfig.platform)();
var IS_DEVTOOLS = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'devtools')()));
var IS_ANDROID = /* #__PURE__ */(() => PLATFORM === 'android')();
var IS_IOS = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'ios')()));
var IS_WINDOWS = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'windows')()));
var IS_MAC = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'mac')()));
var IS_MINA = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'mina')()));
var IS_PC = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => IS_WINDOWS || IS_MAC)()));
function debugEnabled() {
  if (!WXConfig || !('debug' in WXConfig) || typeof WXConfig.debug === 'undefined') return undefined;
  return !!WXConfig.debug;
}
var ENV = /* #__PURE__ */(/* unused pure expression or super */ null && ((_WXConfig$host => (_WXConfig$host = WXConfig.host) === null || _WXConfig$host === void 0 ? void 0 : _WXConfig$host.env)()));
var IS_HOST_SDK = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'SDK')()));
var IS_HOST_SAAA_SDK = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'SAAASDK')()));
var IS_HOST_WMPF = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'WMPF')()));
var IS_HOST_WECHAT = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'WeChat')()));
var IS_USE_NATIVE_MAP = /* #__PURE__ */(/* unused pure expression or super */ null && ((_WXConfig$host2 => ((_WXConfig$host2 = WXConfig.host) === null || _WXConfig$host2 === void 0 ? void 0 : _WXConfig$host2.forceUseNativeMap) || false)()));
var WK_RENDERER_H5 = /* #__PURE__ */(/* unused pure expression or super */ null && (function isRenderH5() {
  if (typeof WORKER_RUNTIME !== 'undefined' && WORKER_RUNTIME) {
    if (typeof self !== 'undefined') {
      return self && self.__wkrenderer_h5;
    }
  }
  return typeof window === 'object' && window && window.__wkrenderer_h5;
}()));
function isWkGameNativeRender() {
  return typeof window === 'object' && window && window.__wkrenderer_h5 && (window.__featBit & 0x2) > 0;
}
function isRemoteDebugEnabled() {
  return __webpack_require__.g.__isAppServiceRemoteDebugMode__ || typeof __initHelper !== 'undefined' && __initHelper === 1;
}
function isIn3rdApp() {
  var host = WXConfig.host;
  return host && host.env !== 'WeChat' && host.env !== 'WMPF';
}
function isReleaseBuild() {
  var release = true;
  typeof wxRunOnDebug !== 'undefined' && wxRunOnDebug(() => {
    release = false;
  });
  return release;
}
function isGame() {
  return  true ? true : 0;
}
function isAppServiceOrWebView() {
  var _Foundation;
  return typeof IS_APP === 'boolean' ? IS_APP : (_Foundation = Foundation) === null || _Foundation === void 0 ? void 0 : _Foundation.env.isApp;
}
var isAppService = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => typeof IS_APP !== 'undefined' && IS_APP)()));
function isNormalApp() {
  return WXConfig.appType === 0;
}
var thirdPartyAppType = (/* unused pure expression or super */ null && ([0, 1, 2, 3, 5, 6, 8, 9, 10, 11, 12, 13]));
function isThirdPartyApp() {
  return thirdPartyAppType.includes(WXConfig.appType);
}
function isFakeNativeApp() {
  return WXConfig.appType === 7;
}
function isPhysicalStoresApp() {
  return WXConfig.appType === 2;
}
function isWXStoreApp() {
  return WXConfig.appType === 10;
}
function isAppBasedOnGameEnv() {
  return WXConfig.appType === 19;
}
;// CONCATENATED MODULE: ./src/condom/gameCondomList.js
var gameCondomApiSequences = {
  request: 1,
  downloadFile: 2,
  uploadFile: 3,
  addNativeDownloadTask: 4,
  calRqt: 5,
  connectSocket: 6,
  closeSocket: 7,
  sendSocketMessage: 8,
  onSocketOpen: 9,
  onSocketClose: 10,
  onSocketMessage: 11,
  onSocketError: 12,
  getNetworkType: 13,
  onNetworkStatusChange: 14,
  offNetworkStatusChange: 15,
  onNetworkWeakChange: 16,
  offNetworkWeakChange: 17,
  openDocument: 18,
  setStorage: 19,
  setStorageSync: 20,
  getStorage: 21,
  getStorageSync: 22,
  getStorageInfo: 23,
  getStorageInfoSync: 24,
  removeStorage: 25,
  removeStorageSync: 26,
  clearStorage: 27,
  clearStorageSync: 28,
  authorize: 29,
  checkSession: 30,
  getUserInfo: 31,
  getUserProfile: 32,
  login: 33,
  openSetting: 34,
  getSetting: 35,
  operateWXData: 36,
  getWeRunData: 37,
  uploadWeRunData: 38,
  addWeRunData: 39,
  getGroupMsgTicket: 40,
  removeUserCloudStorage: 41,
  setUserCloudStorage: 42,
  openCustomerServiceConversation: 43,
  sendRedPacket: 44,
  openRedPacket: 45,
  sendBizRedPacket: 46,
  showRedPackage: 47,
  reportAnalytics: 48,
  reportMonitor: 49,
  requestSubscribeMessage: 50,
  requestSubscribeSystemMessage: 51,
  requestSubscribeWhatsNew: 52,
  getWhatsNewSubscriptionsSetting: 53,
  getUserGameLabel: 54,
  reportUserBehaviorBranchAnalytics: 55,
  publishWeChatState: 56,
  addCard: 57,
  openCard: 58,
  getFileSystemManager: 59,
  saveFileToDisk: 60,
  getDeviceInfo: 61,
  getWindowInfo: 62,
  getAppBaseInfo: 63,
  getSystemSetting: 64,
  getAppAuthorizeSetting: 65,
  openSystemBluetoothSetting: 66,
  openAppAuthorizeSetting: 67,
  startAccelerometer: 68,
  stopAccelerometer: 69,
  onAccelerometerChange: 70,
  offAccelerometerChange: 71,
  scanCode: 72,
  startCompass: 73,
  stopCompass: 74,
  onCompassChange: 75,
  offCompassChange: 76,
  startDeviceMotionListening: 77,
  stopDeviceMotionListening: 78,
  onDeviceMotionChange: 79,
  offDeviceMotionChange: 80,
  startGyroscope: 81,
  stopGyroscope: 82,
  onGyroscopeChange: 83,
  offGyroscopeChange: 84,
  setScreenBrightness: 85,
  getScreenBrightness: 86,
  setKeepScreenOn: 87,
  captureScreen: 88,
  vibrateShort: 89,
  vibrateLong: 90,
  getClipboardData: 91,
  setClipboardData: 92,
  makeBluetoothPair: 93,
  isBluetoothDevicePaired: 94,
  openBluetoothAdapter: 95,
  closeBluetoothAdapter: 96,
  getBluetoothAdapterState: 97,
  onBluetoothAdapterStateChange: 98,
  offBluetoothAdapterStateChange: 99,
  startBluetoothDevicesDiscovery: 100,
  stopBluetoothDevicesDiscovery: 101,
  getBluetoothDevices: 102,
  getConnectedBluetoothDevices: 103,
  createBLEConnection: 104,
  closeBLEConnection: 105,
  getBLEDeviceServices: 106,
  getBLEDeviceRSSI: 107,
  setBLEMTU: 108,
  getBLEMTU: 109,
  getBLEDeviceCharacteristics: 110,
  createBLEPeripheralServer: 111,
  onBLEPeripheralConnectionStateChanged: 112,
  offBLEPeripheralConnectionStateChanged: 113,
  notifyBLECharacteristicValueChanged: 114,
  notifyBLECharacteristicValueChange: 115,
  readBLECharacteristicValue: 116,
  writeBLECharacteristicValue: 117,
  onBluetoothDeviceFound: 118,
  offBluetoothDeviceFound: 119,
  onBLEMTUChange: 120,
  offBLEMTUChange: 121,
  onBLEConnectionStateChanged: 122,
  onBLEConnectionStateChange: 123,
  onBLECharacteristicValueChange: 124,
  offBLEConnectionStateChanged: 125,
  offBLEConnectionStateChange: 126,
  offBLECharacteristicValueChange: 127,
  startBeaconDiscovery: 128,
  stopBeaconDiscovery: 129,
  getBeacons: 130,
  onBeaconUpdate: 131,
  offBeaconUpdate: 132,
  onBeaconServiceChange: 133,
  offBeaconServiceChange: 134,
  getLocation: 135,
  getFuzzyLocation: 136,
  chooseMedia: 137,
  chooseMessageFile: 138,
  createInnerAudioContext: 139,
  getAvailableAudioSources: 140,
  setInnerAudioOption: 141,
  createVideoDecoder: 142,
  createMediaAudioPlayer: 143,
  createWebAudioContext: 144,
  getRecorderManager: 145,
  chooseImage: 146,
  previewImage: 147,
  previewMedia: 148,
  saveImageToPhotosAlbum: 149,
  joinVoIPChat: 150,
  exitVoIPChat: 151,
  updateVoIPChatMuteConfig: 152,
  onVoIPChatMembersChanged: 153,
  onVoIPChatSpeakersChanged: 154,
  onVoIPChatInterrupted: 155,
  offVoIPChatMembersChanged: 156,
  offVoIPChatSpeakersChanged: 157,
  offVoIPChatInterrupted: 158,
  subscribeVoIPVideoMembers: 159,
  onVoIPVideoMembersChanged: 160,
  offVoIPVideoMembersChanged: 161,
  onVoIPChatStateChanged: 162,
  offVoIPChatStateChanged: 163,
  createCanvas: 164,
  createOffScreenCanvas: 165,
  createImage: 166,
  createImageData: 167,
  createPath2D: 168,
  onTouchStart: 169,
  offTouchStart: 170,
  onTouchMove: 171,
  offTouchMove: 172,
  onTouchEnd: 173,
  offTouchEnd: 174,
  onTouchCancel: 175,
  offTouchCancel: 176,
  onWheel: 177,
  offWheel: 178,
  onMouseDown: 179,
  offMouseDown: 180,
  onMouseMove: 181,
  offMouseMove: 182,
  onMouseUp: 183,
  offMouseUp: 184,
  onKeyDown: 185,
  offKeyDown: 186,
  onKeyUp: 187,
  offKeyUp: 188,
  onPointerLockChange: 189,
  offPointerLockChange: 190,
  onPointerLockError: 191,
  offPointerLockError: 192,
  onKeyboardInput: 193,
  offKeyboardInput: 194,
  onKeyboardConfirm: 195,
  offKeyboardConfirm: 196,
  onKeyboardComplete: 197,
  offKeyboardComplete: 198,
  onKeyboardHeightChange: 199,
  offKeyboardHeightChange: 200,
  onWindowResize: 201,
  offWindowResize: 202,
  onGameLiveStateChange: 203,
  offGameLiveStateChange: 204,
  startGameLive: 205,
  checkGameLiveEnabled: 206,
  getGameLiveState: 207,
  getUserRecentGameLiveInfo: 208,
  getUserCurrentGameliveInfo: 209,
  getUserGameLiveDetails: 210,
  getShareInfo: 211,
  authPrivateMessage: 212,
  hideShareMenu: 213,
  onShareAppMessage: 214,
  offShareAppMessage: 215,
  onShareTimeline: 216,
  offShareTimeline: 217,
  shareAppMessage: 218,
  shareTimeline: 219,
  shareInvitationToLiveRoom: 220,
  setMessageToFriendQuery: 221,
  onShareMessageToFriend: 222,
  onAddToFavorites: 223,
  offAddToFavorites: 224,
  showShareImageMenu: 225,
  onCopyUrl: 226,
  offCopyUrl: 227,
  setWindowSize: 228,
  setTopBarText: 229,
  showToast: 230,
  hideToast: 231,
  showLoading: 232,
  hideLoading: 233,
  showModal: 234,
  showActionSheet: 235,
  setMenuStyle: 236,
  setStatusBarStyle: 237,
  getMenuButtonBoundingClientRect: 238,
  hideSplashScreen: 239,
  onError: 240,
  offError: 241,
  onUnhandledRejection: 242,
  offUnhandledRejection: 243,
  onLaunch: 244,
  offLaunch: 245,
  onShow: 246,
  offShow: 247,
  onHide: 248,
  offHide: 249,
  onAudioInterruptionBegin: 250,
  offAudioInterruptionBegin: 251,
  onAudioInterruptionEnd: 252,
  offAudioInterruptionEnd: 253,
  onShareInvitationToLiveRoom: 254,
  offShareInvitationToLiveRoom: 255,
  getSystemInfo: 256,
  getSystemInfoSync: 257,
  getSystemInfoAsync: 258,
  getBatteryInfo: 259,
  getBatteryInfoSync: 260,
  getLaunchOptionsSync: 261,
  getEnterOptionsSync: 262,
  setPreferredFramesPerSecond: 263,
  loadFont: 264,
  setCursor: 265,
  requestPointerLock: 266,
  exitPointerLock: 267,
  isPointerLocked: 268,
  getTextLineHeight: 269,
  requestMidasPayment: 270,
  requestMidasPaymentGameItem: 271,
  requestMidasFriendPayment: 272,
  checkIsSupportMidasFriendPayment: 273,
  gameLoginReport: 274,
  gameLogoutReport: 275,
  exitMiniProgram: 276,
  restartMiniProgram: 277,
  launchApp: 278,
  showKeyboard: 279,
  hideKeyboard: 280,
  updateKeyboard: 281,
  getExtConfig: 282,
  getExtConfigSync: 283,
  bindGroup: 284,
  joinGroup: 285,
  getAccountInfoSync: 286,
  encode: 287,
  decode: 288,
  parseXML: 289,
  createVideo: 290,
  createCamera: 291,
  createLivePlayer: 292,
  createLivePusher: 293,
  createWebView: 294,
  setDeviceOrientation: 295,
  onDeviceOrientationChange: 296,
  offDeviceOrientationChange: 297,
  onUserCaptureScreen: 298,
  offUserCaptureScreen: 299,
  postMessage: 300,
  onMessage: 301,
  getOpenDataContext: 302,
  createUserGameData: 303,
  updateUserGameData: 304,
  getPerformance: 305,
  setEnableDebug: 306,
  triggerGC: 307,
  onMemoryWarning: 308,
  offMemoryWarning: 309,
  reportPerformance: 310,
  testApiCallTime: 311,
  createWorker: 312,
  createSharedArrayBuffer: 313,
  checkIsUserAdvisedToRest: 314,
  getUpdateManager: 315,
  updateWeChatApp: 316,
  getAd: 317,
  openTencentGameContract: 318,
  openTencentPrivacyContract: 319,
  openUrl: 320,
  openTencentBoardGameContract: 321,
  openTencentChildrenGuideContract: 322,
  openTencentAccountCancelContract: 323,
  createRewardedVideoAd: 324,
  createIncentiveVideoAd: 325,
  createBannerAd: 326,
  createInterstitialAd: 327,
  createCustomAd: 328,
  createGridAd: 329,
  createCpsAd: 330,
  createUserInfoButton: 331,
  createGameClubButton: 332,
  createOpenSettingButton: 333,
  createFeedbackButton: 334,
  loadSubpackage: 335,
  preDownloadSubpackage: 336,
  navigateToMiniProgram: 337,
  createUDPSocket: 338,
  markScene: 339,
  reportScene: 340,
  createGamePortal: 341,
  createGameBanner: 342,
  createGameIcon: 343,
  getUserInteractiveStorage: 344,
  onInteractiveStorageModified: 345,
  offInteractiveStorageModified: 346,
  env: 347,
  getLogManager: 348,
  getRealtimeLogManager: 349,
  error: 350,
  isSystemError: 351,
  isSDKError: 352,
  isThirdError: 353,
  getGameRecorder: 354,
  createGameRecorderShareButton: 355,
  operateGameRecorderVideo: 356,
  cloud: 357,
  serviceMarket: 358,
  version: 359,
  getGameServerManager: 360,
  getBox2D: 361,
  protobuf: 362,
  createGameComponent: 363,
  getGroupEnterInfo: 364,
  onHandoff: 365,
  offHandoff: 366,
  setHandoffQuery: 367,
  faceDetect: 368,
  initFaceDetect: 369,
  stopFaceDetect: 370,
  createBufferURL: 371,
  revokeBufferURL: 372,
  createSignal: 373,
  startLocalServiceDiscovery: 374,
  stopLocalServiceDiscovery: 375,
  onLocalServiceFound: 376,
  offLocalServiceFound: 377,
  onLocalServiceLost: 378,
  offLocalServiceLost: 379,
  onLocalServiceDiscoveryStop: 380,
  offLocalServiceDiscoveryStop: 381,
  onLocalServiceResolveFail: 382,
  offLocalServiceResolveFail: 383,
  getLocalIPAddress: 384,
  startCPUProfiling: 385,
  stopCPUProfiling: 386,
  getExptInfo: 387,
  getExptInfoSync: 388,
  reportEvent: 389,
  getChannelsLiveInfo: 390,
  getChannelsLiveState: 391,
  getChannelsLiveReservation: 392,
  getChannelsLiveNoticeInfo: 393,
  openChannelsLive: 394,
  openChannelsActivity: 395,
  openChannelsUserProfile: 396,
  openChannelsLiveCollection: 397,
  openChannelsEvent: 398,
  reserveChannelsLive: 399,
  lanDebug: 400,
  createVKSession: 401,
  createVKReference: 402,
  isVKSupport: 403,
  onVerifyNotify: 404,
  offVerifyNotify: 405,
  navigateToUserCenter: 406,
  requestConsumeAdsSkipCard: 407,
  dumpGameLivePanelUI: 408,
  updateGameLivePanelMenu: 409,
  createInferenceSession: 410,
  getInferenceEnvInfo: 411,
  getDebuggerMessager: 412,
  getAdsSkipCardSharePresentQuota: 413,
  getAdsSkipCardQuestInfo: 414,
  getUserCryptoManager: 415,
  getRealNameVerifyMethod: 416,
  addToDesktop: 417,
  openPage: 418,
  getGameClubData: 419,
  previewPlayableView: 420,
  checkIsAddedToMyMiniProgram: 421,
  saveFile: 422,
  getFileInfo: 423,
  getSavedFileList: 424,
  getSavedFileInfo: 425,
  removeSavedFile: 426,
  showShareMenu: 427,
  updateShareMenu: 428,
  requestSubscribeLiveActivity: 429,
  openCustomerServiceChat: 430
};
var gameCondomApiReverseSequences = {
  1: 'request',
  2: 'downloadFile',
  3: 'uploadFile',
  4: 'addNativeDownloadTask',
  5: 'calRqt',
  6: 'connectSocket',
  7: 'closeSocket',
  8: 'sendSocketMessage',
  9: 'onSocketOpen',
  10: 'onSocketClose',
  11: 'onSocketMessage',
  12: 'onSocketError',
  13: 'getNetworkType',
  14: 'onNetworkStatusChange',
  15: 'offNetworkStatusChange',
  16: 'onNetworkWeakChange',
  17: 'offNetworkWeakChange',
  18: 'openDocument',
  19: 'setStorage',
  20: 'setStorageSync',
  21: 'getStorage',
  22: 'getStorageSync',
  23: 'getStorageInfo',
  24: 'getStorageInfoSync',
  25: 'removeStorage',
  26: 'removeStorageSync',
  27: 'clearStorage',
  28: 'clearStorageSync',
  29: 'authorize',
  30: 'checkSession',
  31: 'getUserInfo',
  32: 'getUserProfile',
  33: 'login',
  34: 'openSetting',
  35: 'getSetting',
  36: 'operateWXData',
  37: 'getWeRunData',
  38: 'uploadWeRunData',
  39: 'addWeRunData',
  40: 'getGroupMsgTicket',
  41: 'removeUserCloudStorage',
  42: 'setUserCloudStorage',
  43: 'openCustomerServiceConversation',
  44: 'sendRedPacket',
  45: 'openRedPacket',
  46: 'sendBizRedPacket',
  47: 'showRedPackage',
  48: 'reportAnalytics',
  49: 'reportMonitor',
  50: 'requestSubscribeMessage',
  51: 'requestSubscribeSystemMessage',
  52: 'requestSubscribeWhatsNew',
  53: 'getWhatsNewSubscriptionsSetting',
  54: 'getUserGameLabel',
  55: 'reportUserBehaviorBranchAnalytics',
  56: 'publishWeChatState',
  57: 'addCard',
  58: 'openCard',
  59: 'getFileSystemManager',
  60: 'saveFileToDisk',
  61: 'getDeviceInfo',
  62: 'getWindowInfo',
  63: 'getAppBaseInfo',
  64: 'getSystemSetting',
  65: 'getAppAuthorizeSetting',
  66: 'openSystemBluetoothSetting',
  67: 'openAppAuthorizeSetting',
  68: 'startAccelerometer',
  69: 'stopAccelerometer',
  70: 'onAccelerometerChange',
  71: 'offAccelerometerChange',
  72: 'scanCode',
  73: 'startCompass',
  74: 'stopCompass',
  75: 'onCompassChange',
  76: 'offCompassChange',
  77: 'startDeviceMotionListening',
  78: 'stopDeviceMotionListening',
  79: 'onDeviceMotionChange',
  80: 'offDeviceMotionChange',
  81: 'startGyroscope',
  82: 'stopGyroscope',
  83: 'onGyroscopeChange',
  84: 'offGyroscopeChange',
  85: 'setScreenBrightness',
  86: 'getScreenBrightness',
  87: 'setKeepScreenOn',
  88: 'captureScreen',
  89: 'vibrateShort',
  90: 'vibrateLong',
  91: 'getClipboardData',
  92: 'setClipboardData',
  93: 'makeBluetoothPair',
  94: 'isBluetoothDevicePaired',
  95: 'openBluetoothAdapter',
  96: 'closeBluetoothAdapter',
  97: 'getBluetoothAdapterState',
  98: 'onBluetoothAdapterStateChange',
  99: 'offBluetoothAdapterStateChange',
  100: 'startBluetoothDevicesDiscovery',
  101: 'stopBluetoothDevicesDiscovery',
  102: 'getBluetoothDevices',
  103: 'getConnectedBluetoothDevices',
  104: 'createBLEConnection',
  105: 'closeBLEConnection',
  106: 'getBLEDeviceServices',
  107: 'getBLEDeviceRSSI',
  108: 'setBLEMTU',
  109: 'getBLEMTU',
  110: 'getBLEDeviceCharacteristics',
  111: 'createBLEPeripheralServer',
  112: 'onBLEPeripheralConnectionStateChanged',
  113: 'offBLEPeripheralConnectionStateChanged',
  114: 'notifyBLECharacteristicValueChanged',
  115: 'notifyBLECharacteristicValueChange',
  116: 'readBLECharacteristicValue',
  117: 'writeBLECharacteristicValue',
  118: 'onBluetoothDeviceFound',
  119: 'offBluetoothDeviceFound',
  120: 'onBLEMTUChange',
  121: 'offBLEMTUChange',
  122: 'onBLEConnectionStateChanged',
  123: 'onBLEConnectionStateChange',
  124: 'onBLECharacteristicValueChange',
  125: 'offBLEConnectionStateChanged',
  126: 'offBLEConnectionStateChange',
  127: 'offBLECharacteristicValueChange',
  128: 'startBeaconDiscovery',
  129: 'stopBeaconDiscovery',
  130: 'getBeacons',
  131: 'onBeaconUpdate',
  132: 'offBeaconUpdate',
  133: 'onBeaconServiceChange',
  134: 'offBeaconServiceChange',
  135: 'getLocation',
  136: 'getFuzzyLocation',
  137: 'chooseMedia',
  138: 'chooseMessageFile',
  139: 'createInnerAudioContext',
  140: 'getAvailableAudioSources',
  141: 'setInnerAudioOption',
  142: 'createVideoDecoder',
  143: 'createMediaAudioPlayer',
  144: 'createWebAudioContext',
  145: 'getRecorderManager',
  146: 'chooseImage',
  147: 'previewImage',
  148: 'previewMedia',
  149: 'saveImageToPhotosAlbum',
  150: 'joinVoIPChat',
  151: 'exitVoIPChat',
  152: 'updateVoIPChatMuteConfig',
  153: 'onVoIPChatMembersChanged',
  154: 'onVoIPChatSpeakersChanged',
  155: 'onVoIPChatInterrupted',
  156: 'offVoIPChatMembersChanged',
  157: 'offVoIPChatSpeakersChanged',
  158: 'offVoIPChatInterrupted',
  159: 'subscribeVoIPVideoMembers',
  160: 'onVoIPVideoMembersChanged',
  161: 'offVoIPVideoMembersChanged',
  162: 'onVoIPChatStateChanged',
  163: 'offVoIPChatStateChanged',
  164: 'createCanvas',
  165: 'createOffScreenCanvas',
  166: 'createImage',
  167: 'createImageData',
  168: 'createPath2D',
  169: 'onTouchStart',
  170: 'offTouchStart',
  171: 'onTouchMove',
  172: 'offTouchMove',
  173: 'onTouchEnd',
  174: 'offTouchEnd',
  175: 'onTouchCancel',
  176: 'offTouchCancel',
  177: 'onWheel',
  178: 'offWheel',
  179: 'onMouseDown',
  180: 'offMouseDown',
  181: 'onMouseMove',
  182: 'offMouseMove',
  183: 'onMouseUp',
  184: 'offMouseUp',
  185: 'onKeyDown',
  186: 'offKeyDown',
  187: 'onKeyUp',
  188: 'offKeyUp',
  189: 'onPointerLockChange',
  190: 'offPointerLockChange',
  191: 'onPointerLockError',
  192: 'offPointerLockError',
  193: 'onKeyboardInput',
  194: 'offKeyboardInput',
  195: 'onKeyboardConfirm',
  196: 'offKeyboardConfirm',
  197: 'onKeyboardComplete',
  198: 'offKeyboardComplete',
  199: 'onKeyboardHeightChange',
  200: 'offKeyboardHeightChange',
  201: 'onWindowResize',
  202: 'offWindowResize',
  203: 'onGameLiveStateChange',
  204: 'offGameLiveStateChange',
  205: 'startGameLive',
  206: 'checkGameLiveEnabled',
  207: 'getGameLiveState',
  208: 'getUserRecentGameLiveInfo',
  209: 'getUserCurrentGameliveInfo',
  210: 'getUserGameLiveDetails',
  211: 'getShareInfo',
  212: 'authPrivateMessage',
  213: 'hideShareMenu',
  214: 'onShareAppMessage',
  215: 'offShareAppMessage',
  216: 'onShareTimeline',
  217: 'offShareTimeline',
  218: 'shareAppMessage',
  219: 'shareTimeline',
  220: 'shareInvitationToLiveRoom',
  221: 'setMessageToFriendQuery',
  222: 'onShareMessageToFriend',
  223: 'onAddToFavorites',
  224: 'offAddToFavorites',
  225: 'showShareImageMenu',
  226: 'onCopyUrl',
  227: 'offCopyUrl',
  228: 'setWindowSize',
  229: 'setTopBarText',
  230: 'showToast',
  231: 'hideToast',
  232: 'showLoading',
  233: 'hideLoading',
  234: 'showModal',
  235: 'showActionSheet',
  236: 'setMenuStyle',
  237: 'setStatusBarStyle',
  238: 'getMenuButtonBoundingClientRect',
  239: 'hideSplashScreen',
  240: 'onError',
  241: 'offError',
  242: 'onUnhandledRejection',
  243: 'offUnhandledRejection',
  244: 'onLaunch',
  245: 'offLaunch',
  246: 'onShow',
  247: 'offShow',
  248: 'onHide',
  249: 'offHide',
  250: 'onAudioInterruptionBegin',
  251: 'offAudioInterruptionBegin',
  252: 'onAudioInterruptionEnd',
  253: 'offAudioInterruptionEnd',
  254: 'onShareInvitationToLiveRoom',
  255: 'offShareInvitationToLiveRoom',
  256: 'getSystemInfo',
  257: 'getSystemInfoSync',
  258: 'getSystemInfoAsync',
  259: 'getBatteryInfo',
  260: 'getBatteryInfoSync',
  261: 'getLaunchOptionsSync',
  262: 'getEnterOptionsSync',
  263: 'setPreferredFramesPerSecond',
  264: 'loadFont',
  265: 'setCursor',
  266: 'requestPointerLock',
  267: 'exitPointerLock',
  268: 'isPointerLocked',
  269: 'getTextLineHeight',
  270: 'requestMidasPayment',
  271: 'requestMidasPaymentGameItem',
  272: 'requestMidasFriendPayment',
  273: 'checkIsSupportMidasFriendPayment',
  274: 'gameLoginReport',
  275: 'gameLogoutReport',
  276: 'exitMiniProgram',
  277: 'restartMiniProgram',
  278: 'launchApp',
  279: 'showKeyboard',
  280: 'hideKeyboard',
  281: 'updateKeyboard',
  282: 'getExtConfig',
  283: 'getExtConfigSync',
  284: 'bindGroup',
  285: 'joinGroup',
  286: 'getAccountInfoSync',
  287: 'encode',
  288: 'decode',
  289: 'parseXML',
  290: 'createVideo',
  291: 'createCamera',
  292: 'createLivePlayer',
  293: 'createLivePusher',
  294: 'createWebView',
  295: 'setDeviceOrientation',
  296: 'onDeviceOrientationChange',
  297: 'offDeviceOrientationChange',
  298: 'onUserCaptureScreen',
  299: 'offUserCaptureScreen',
  300: 'postMessage',
  301: 'onMessage',
  302: 'getOpenDataContext',
  303: 'createUserGameData',
  304: 'updateUserGameData',
  305: 'getPerformance',
  306: 'setEnableDebug',
  307: 'triggerGC',
  308: 'onMemoryWarning',
  309: 'offMemoryWarning',
  310: 'reportPerformance',
  311: 'testApiCallTime',
  312: 'createWorker',
  313: 'createSharedArrayBuffer',
  314: 'checkIsUserAdvisedToRest',
  315: 'getUpdateManager',
  316: 'updateWeChatApp',
  317: 'getAd',
  318: 'openTencentGameContract',
  319: 'openTencentPrivacyContract',
  320: 'openUrl',
  321: 'openTencentBoardGameContract',
  322: 'openTencentChildrenGuideContract',
  323: 'openTencentAccountCancelContract',
  324: 'createRewardedVideoAd',
  325: 'createIncentiveVideoAd',
  326: 'createBannerAd',
  327: 'createInterstitialAd',
  328: 'createCustomAd',
  329: 'createGridAd',
  330: 'createCpsAd',
  331: 'createUserInfoButton',
  332: 'createGameClubButton',
  333: 'createOpenSettingButton',
  334: 'createFeedbackButton',
  335: 'loadSubpackage',
  336: 'preDownloadSubpackage',
  337: 'navigateToMiniProgram',
  338: 'createUDPSocket',
  339: 'markScene',
  340: 'reportScene',
  341: 'createGamePortal',
  342: 'createGameBanner',
  343: 'createGameIcon',
  344: 'getUserInteractiveStorage',
  345: 'onInteractiveStorageModified',
  346: 'offInteractiveStorageModified',
  347: 'env',
  348: 'getLogManager',
  349: 'getRealtimeLogManager',
  350: 'error',
  351: 'isSystemError',
  352: 'isSDKError',
  353: 'isThirdError',
  354: 'getGameRecorder',
  355: 'createGameRecorderShareButton',
  356: 'operateGameRecorderVideo',
  357: 'cloud',
  358: 'serviceMarket',
  359: 'version',
  360: 'getGameServerManager',
  361: 'getBox2D',
  362: 'protobuf',
  363: 'createGameComponent',
  364: 'getGroupEnterInfo',
  365: 'onHandoff',
  366: 'offHandoff',
  367: 'setHandoffQuery',
  368: 'faceDetect',
  369: 'initFaceDetect',
  370: 'stopFaceDetect',
  371: 'createBufferURL',
  372: 'revokeBufferURL',
  373: 'createSignal',
  374: 'startLocalServiceDiscovery',
  375: 'stopLocalServiceDiscovery',
  376: 'onLocalServiceFound',
  377: 'offLocalServiceFound',
  378: 'onLocalServiceLost',
  379: 'offLocalServiceLost',
  380: 'onLocalServiceDiscoveryStop',
  381: 'offLocalServiceDiscoveryStop',
  382: 'onLocalServiceResolveFail',
  383: 'offLocalServiceResolveFail',
  384: 'getLocalIPAddress',
  385: 'startCPUProfiling',
  386: 'stopCPUProfiling',
  387: 'getExptInfo',
  388: 'getExptInfoSync',
  389: 'reportEvent',
  390: 'getChannelsLiveInfo',
  391: 'getChannelsLiveState',
  392: 'getChannelsLiveReservation',
  393: 'getChannelsLiveNoticeInfo',
  394: 'openChannelsLive',
  395: 'openChannelsActivity',
  396: 'openChannelsUserProfile',
  397: 'openChannelsLiveCollection',
  398: 'openChannelsEvent',
  399: 'reserveChannelsLive',
  400: 'lanDebug',
  401: 'createVKSession',
  402: 'createVKReference',
  403: 'isVKSupport',
  404: 'onVerifyNotify',
  405: 'offVerifyNotify',
  406: 'navigateToUserCenter',
  407: 'requestConsumeAdsSkipCard',
  408: 'dumpGameLivePanelUI',
  409: 'updateGameLivePanelMenu',
  410: 'createInferenceSession',
  411: 'getInferenceEnvInfo',
  412: 'getDebuggerMessager',
  413: 'getAdsSkipCardSharePresentQuota',
  414: 'getAdsSkipCardQuestInfo',
  415: 'getUserCryptoManager',
  416: 'getRealNameVerifyMethod',
  417: 'addToDesktop',
  418: 'openPage',
  419: 'getGameClubData',
  420: 'previewPlayableView',
  421: 'checkIsAddedToMyMiniProgram',
  422: 'saveFile',
  423: 'getFileInfo',
  424: 'getSavedFileList',
  425: 'getSavedFileInfo',
  426: 'removeSavedFile',
  427: 'showShareMenu',
  428: 'updateShareMenu',
  429: 'requestSubscribeLiveActivity',
  430: 'openCustomerServiceChat'
};

;// CONCATENATED MODULE: ./src/condom/gameCondomStrategy.js


var parseControlIncrementCondomStrategyExpt = expt => {
  if (!expt) return;
  var whiteExptName = IS_ANDROID ? 'clicfg_appbrand_android_control_close_condom_white' : 'clicfg_appbrand_ios_control_close_condom_white';
  if (typeof expt[whiteExptName] === 'string') {
    for (var i = 0; i < expt[whiteExptName].length; i++) {
      var curApiSequence = expt[whiteExptName][i];
      if (Number(curApiSequence) === 1) {
        gameCondomApiSequences[gameCondomApiReverseSequences[i + 1]] = true;
      } else if (Number(curApiSequence === 2)) {
        gameCondomApiSequences[gameCondomApiReverseSequences[i + 1]] = 2;
      }
    }
  }
};
var hasParseCondomStrategy = false;
var shouldCloseCondom = (api, expt) => {
  if (true) {
    if (expt === false) return false;
    if (!expt) return false;
    if (!hasParseCondomStrategy) {
      parseControlIncrementCondomStrategyExpt(expt);
      hasParseCondomStrategy = true;
    }
    if (gameCondomApiSequences[api] === true || gameCondomApiSequences[api] === 2) return gameCondomApiSequences[api];
    return false;
  }
  return false;
};

;// CONCATENATED MODULE: ./src/condom/index.ts






var condomWX = (wx, skipCondom = [], expt = {}) => {
  if (true) {
    var skipList = skipCondom;
    return Object.entries(Object.getOwnPropertyDescriptors(wx)).reduce((ret, [key, desc]) => {
      if (!desc.get) {
        if (!skipList.includes(key) && !shouldCloseCondom(key, expt)) {
          if (weCompatCondom[key]) {
            ret[key] = weCompatCondom[key](desc.value);
          } else {
            ret[key] = OldWxCondom(desc.value);
          }
        } else {
          ret[key] = desc.value;
        }
      } else {
        var origin = desc.get;
        var hookSetResult;
        Object.defineProperty(ret, key, {
          get() {
            if (hookSetResult) return hookSetResult;
            var ret = origin();
            if (skipList.includes(key) || shouldCloseCondom(key, expt)) return ret;else {
              if (weCompatCondom[key]) {
                return weCompatCondom[key](ret);
              } else {
                return OldWxCondom(ret);
              }
            }
          },
          set(hookVal) {
            hookSetResult = hookVal;
            return true;
          },
          configurable: true,
          enumerable: true
        });
      }
      return ret;
    }, {});
  } else { var apiName, _loop; }
};
var condom_condom = obj => new OldWxCondom(obj);

__condom__ = __webpack_exports__;
/******/ })()
;
var __subContextEngine__;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ CONTEXT_NAME_PREFIX),
/* harmony export */   m: () => (/* binding */ CONTEXT_NAME)
/* harmony export */ });
var CONTEXT_NAME = {
  APP: 'app',
  APP_RENDER: 'app_sub_render',
  APP_XRFRAME_RENDER: 'app_xrframe_render',
  APP_SCL: 'app_sub_scl',
  GAME: 'game',
  GAME_OPEN_DATA: 'gameOpenData'
};
var CONTEXT_NAME_PREFIX = {
  GAME_PLUGIN_PRELOAD: 'gamePlugin_preload_',
  GAME_PLUGIN: 'gamePlugin_',
  APP_CARDS: 'CARD_'
};

/***/ }),

/***/ 796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G$: () => (/* binding */ isDevtools)
/* harmony export */ });
/* unused harmony exports currentGlobal, deepFreeze, isIsolateContext, freezeGlobal, callInitFunc, handleThirdError, surroundByTryCatchFactory, executeOnlyOnce, isIOS, isAndroid, accessSync, readFileSync, isValidGameIndependentSubpackagePath, isValidGameIndependentSubpackageScene, isPlayableRuntimeNew, isAsyncContext */
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(888);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);

var currentGlobal = (/* unused pure expression or super */ null && (globalThis));
function deepFreeze(o) {
  if (o === currentGlobal && isDevtools()) {
    return;
  }
  Object.freeze(o);
  Object.getOwnPropertyNames(o).forEach(prop => {
    var old;
    try {
      old = o[prop];
    } catch (e) {}
    if ((typeof old === 'object' || typeof old === 'function') && !Object.isFrozen(old)) {
      deepFreeze(old);
    }
  });
}
var isIsolateContext = function () {
  return typeof __wxConfig !== 'undefined' && __wxConfig.isIsolateContext;
};
var freezeGlobal = function () {
  Protect.deepFreezeGlobalObjs(['console'], true);
};
var callInitFunc = /*#__PURE__*/(/* unused pure expression or super */ null && (function () {
  var _ref = _asyncToGenerator(function* (func, key) {
    Reporter.reportIDKey({
      key
    });
    try {
      yield func();
    } catch (error) {
      Reporter.reportIDKey({
        key: `${key}_fail`,
        force: true
      });
      var errorKey = key.indexOf('initGame') >= 0 ? 'gameSDKScriptError' : 'appServiceSDKScriptError';
      Reporter.errorReport({
        key: errorKey,
        error,
        extend: ''
      });
      wxConsole.error(error);
    }
  });
  return function callInitFunc(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}()));
var handleThirdError = function (error, extend, promise) {
  if (promise !== undefined) {
    Reporter.thirdErrorReport({
      error,
      isUnhandledRejection: true,
      promise,
      extend
    });
  } else {
    Reporter.thirdErrorReport({
      error,
      isUnhandledRejection: false,
      extend
    });
  }
};
var surroundByTryCatchFactory = function (key, fn) {
  return function () {
    try {
      return fn.apply(fn, arguments);
    } catch (error) {
      wxConsole.error(error);
      Reporter.errorReport({
        key,
        error,
        extend: ''
      });
    }
    return undefined;
  };
};
var executeOnlyOnce = func => {
  var executed = false;
  return (...args) => {
    if (executed) return false;
    executed = true;
    return func(...args);
  };
};
var isDevtools = function () {
  return __wxConfig.platform === 'devtools';
};
var isIOS = function () {
  return __wxConfig.platform === 'ios';
};
var isAndroid = function () {
  return __wxConfig.platform === 'android';
};
var accessSync = path => {
  var errMsg;
  WeixinJSBridge.invoke('accessSync', {
    path
  }, res => {
    if (/:fail/.test(res.errMsg)) {
      errMsg = res.errMsg;
    }
  });
  if (errMsg) {
    throw new Error(errMsg);
  }
};
var readFileSync = filePath => {
  var data;
  var errMsg;
  WeixinJSBridge.invoke('readFileSync', {
    filePath,
    encoding: 'utf-8'
  }, res => {
    if (/:fail/.test(res.errMsg)) {
      errMsg = res.errMsg;
    } else {
      data = res.data;
    }
  });
  if (errMsg) {
    throw new Error(errMsg);
  } else {
    return data;
  }
};
var isValidGameIndependentSubpackagePath = (path = '', subPackages = []) => {
  var isSubpackagePath = path && typeof path === 'string' && !/^index/.test(path);
  if (isSubpackagePath) {
    var pathSplited = path.replace(/(^\/+)|(\/+$)/g, '').split('/');
    var independentSubpackage = subPackages.find(item => {
      if (item.independent) {
        var root = item.root || '';
        var alias = item.alias || '';
        var rootSplited = root.replace(/(^\/+)|(\/+$)/g, '').split('/');
        if (pathSplited.length >= rootSplited.length) {
          var isRootIndependentValid = rootSplited.every((str, idx) => str === pathSplited[idx]);
          if (isRootIndependentValid) return isRootIndependentValid;
        }
        if (alias && path.indexOf(alias) === 0) {
          return true;
        }
      }
      return false;
    });
    if (independentSubpackage) {
      return independentSubpackage;
    }
  }
  return false;
};
var isValidGameIndependentSubpackageScene = scene => {
  var validScene = [1001, 1011, 1007, 1008, 1074, 1088, 1044, 1010, 1096, 1014, 1043, 1047, 1107, 1155];
  var bool = validScene.indexOf(scene) >= 0;
  return bool;
};
var isPlayableRuntimeNew = ({
  query,
  appType
} = {}) => !!(query !== null && query !== void 0 && query.playable_outid) || appType === 20;
var isAsyncContext = () => JSContext.isAsync();

/***/ }),

/***/ 704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var CurrentContext = {
  name: undefined,
  secure: true,
  runningType: 'app'
};
CurrentContext.init = function (env) {
  this.name = env.contextName;
  this.secure = env.contextSecure;
  if (typeof Foundation !== 'undefined') {
    Foundation.env.contextName = env.contextName;
    Foundation.env.typeStr = `${env.contextName}_Context`;
  }
  if (this.name.startsWith('game')) {
    this.runningType = 'game';
  } else if (this.name.startsWith('app')) {
    this.runningType = 'app';
  }
  this.remoteObjectProto = env.__proto__;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CurrentContext);

/***/ }),

/***/ 485:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(793);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(410);
/* harmony import */ var _CurrentContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(704);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(552);




function onFrameWorkError(res) {
  if (typeof __wxSourceMapRetrace__ === 'function') {
    res = __wxSourceMapRetrace__(res);
  }
  wxNativeConsole.error('FrameworkError', res);
}
function onError(res) {
  res = (0,_util__WEBPACK_IMPORTED_MODULE_3__/* .formatOnErrorParam */ .Bs)(res);
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.name === ___WEBPACK_IMPORTED_MODULE_2__.CONTEXT_NAME.APP_RENDER) {
    (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .handleInnerError */ .yH)(res, '');
  } else {
    (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .handleThirdError */ .sK)(res, '');
  }
}
function onUnhandledRejection(res = {}) {
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.name === ___WEBPACK_IMPORTED_MODULE_2__.CONTEXT_NAME.APP_RENDER) {
    (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .handleInnerError */ .yH)(res.reason, '', res.promise || null);
  } else {
    (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .handleThirdError */ .sK)(res.reason, '', res.promise || null);
  }
}
Foundation.onLoad(() => {
  if (typeof __webpack_require__.g.WeixinJSBridge === 'undefined') {
    __webpack_require__.g.WeixinJSBridge = {};
    __webpack_require__.g.WeixinJSBridge.subscribeHandler = function (event, res) {
      if (event === 'onError') {
        Foundation.emitUnhandledError(res);
      } else if (event === 'unhandledRejection') {
        Foundation.emitUnhandledRejection(res === null || res === void 0 ? void 0 : res.reason, res === null || res === void 0 ? void 0 : res.promise);
      }
    };
    __webpack_require__.g.WeixinJSBridge.invokeCallbackHandler = function () {};
  }
});
Foundation.onUnhandledRejection(onUnhandledRejection);
Foundation.onUnhandledError(onError);
Foundation.onFrameworkError(onFrameWorkError);

/***/ }),

/***/ 180:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var ReporterProxy = {};
var ObjKeys = Object.keys;
ReporterProxy.init = reporter => {
  Reporter = reporter;
  var keys = ObjKeys(reporter);
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (ReporterProxy[key] === undefined) {
      ReporterProxy[key] = reporter[key];
    }
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReporterProxy);

/***/ }),

/***/ 143:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   k: () => (/* binding */ initWxConfigReadyHandler)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61);

var initWxConfigReadyHandler = __wxConfigMainContext => {
  __wxConfigMainContext.onReady(__newWxConfigMainContext => {
    Foundation._onPostLoad(() => {
      var __wxConfigReadyHandler = __wxConfig.__readyHandler;
      _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.__wxConfig = Object.assign({}, __newWxConfigMainContext);
      if (typeof __wxConfigReadyHandler === 'function') {
        __wxConfigReadyHandler(__newWxConfigMainContext);
      }
    });
  });
};


/***/ }),

/***/ 636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ initAppContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61);

var checkVersionMatches = mainContextLibVersion => {
  var _libVersionInfo__;
  var subContextLibVersion = ((_libVersionInfo__ = __libVersionInfo__) === null || _libVersionInfo__ === void 0 ? void 0 : _libVersionInfo__.version) || '9.9.9';
  if (mainContextLibVersion !== subContextLibVersion) {
    wxNativeConsole.warn(`[checkVersionMatches] baselib versions between context do not match (mainContext ${mainContextLibVersion}, subContext ${subContextLibVersion})`);
    Reporter.reportIDKey({
      key: 'subContextLibVersionNotMatch'
    });
  }
};
var initAppContext = function (env) {
  if ((env.__wxConfig.platform === 'windows' || env.__wxConfig.platform === 'mac') && env.__wxConfig.host && env.__wxConfig.host.env === 'WMPF' && env.__isAppServiceRemoteDebugMode__) {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.console = __webpack_require__.g.console;
  } else if (env.__isAppServiceRemoteDebugMode__ && env.__wxConfig.platform !== 'ios') {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.console = env.originConsole;
  } else {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.console = new env.BaseConsole();
  }
  checkVersionMatches(env.wxLibVersion);
  __Function__ = env.__Function__;
  __userActionTracer__ = env.__userActionTracer__;
  __appServiceSDK__ = env.__appServiceSDK__;
  __sclEngine__ = env.__sclEngine__;
  WeixinJSBridge = env.WeixinJSBridge;
  Reporter = env.Reporter;
  wxNativeConsole = env.wxNativeConsole;
  WeixinSharedBuffer = env.WeixinSharedBuffer;
  WeixinNativePluginMgr = env.WeixinNativePluginMgr;
  BaseConsole = env.BaseConsole;
  $dbg = env.$dbg;
  __isAppServiceRemoteDebugMode__ = !!env.__isAppServiceRemoteDebugMode__;
  __remoteDebug__ = env.__remoteDebug__;
  __debuggerMessager__ = env.debuggerMessager;
  Foundation.onLibraryEnd(() => {
    env.setWxModule(__wxModule__);
  });
  __glassEaselAdapter__ = env.__glassEaselAdapter__;
  __glassEaselAdapter__.setSubContextAdapter(__glassEaselSubContextAdapter__);
  __glassEaselSubContextAdapter__.setMainContextAdapter(__glassEaselAdapter__);
  __glassEaselAdapter__.onSkylineEngineReady(skylineEngine => {
    __glassEaselSubContextAdapter__.setSkylineEngine(skylineEngine);
  });
  __subContextEngineBridge__.bridgeContext(env.__subContextEngineBridge__);
  env.__freezeLibContextGlobal__();
  Object.defineProperty(_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, '__wxSourceMap', {
    get: __condom__.condom(env.getWxSourceMap)
  });
  if (_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.WebAssembly) {
    delete _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.WebAssembly;
  }
  Trace = env.Trace;
};


/***/ }),

/***/ 808:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   D: () => (/* binding */ initAppRenderContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61);

var initAppRenderContext = function (env) {
  if (env.__wxConfig.debug) console = new env.BaseConsole();
  setTimeout = env.setTimeout;
  clearTimeout = env.clearTimeout;
  setInterval = env.setInterval;
  clearInterval = env.clearInterval;
  WeixinJSBridge = env.WeixinJSBridge;
  Reporter = env.Reporter;
  NativeGlobal = env.NativeGlobal;
  WeixinCanvas = env.WeixinCanvas;
  WeixinArrayBuffer = env.WeixinArrayBuffer;
  wxNativeConsole = env.wxNativeConsole;
  BaseConsole = env.BaseConsole;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.console = new env.BaseConsole();
  __sclEngine__ = env.__sclEngine__;
  __appServiceConsole__ = env.__appServiceConsole__;
  __glassEaselAdapter__ = env.__glassEaselAdapter__;
  __glassEaselAdapter__.setSkylineEngine(__skylineEngine__);
  __skylineEngine__.RuntimeCore.setGlassEaselAdapter(__glassEaselAdapter__);
  __glassEaselAdapter__.setWebviewEngine(__webviewEngine__);
  __webviewEngine__.setGlassEaselAdapter(__glassEaselAdapter__);
  __readFileSync__ = env.readFileSync;
  Trace = env.Trace;
  SkylineGlobal = env.SkylineGlobal;
};


/***/ }),

/***/ 654:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   d: () => (/* binding */ initAppSclContext)
/* harmony export */ });
var initAppSclContext = function (env) {
  setTimeout = env.setTimeout;
  clearTimeout = env.clearTimeout;
  setInterval = env.setInterval;
  clearInterval = env.clearInterval;
  WeixinJSBridge = env.WeixinJSBridge;
  Reporter = env.Reporter;
  NativeGlobal = env.NativeGlobal;
  WeixinCanvas = env.WeixinCanvas;
  WeixinArrayBuffer = env.WeixinArrayBuffer;
  wxNativeConsole = env.wxNativeConsole;
  __sclEngine__ = env.__sclEngine__;
  Trace = env.Trace;
};


/***/ }),

/***/ 618:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   y: () => (/* binding */ initAppXRFrameRenderContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61);

var initAppXRFrameRenderContext = function (env) {
  setTimeout = env.setTimeout;
  clearTimeout = env.clearTimeout;
  setInterval = env.setInterval;
  clearInterval = env.clearInterval;
  WeixinJSBridge = env.WeixinJSBridge;
  Reporter = env.Reporter;
  NativeGlobal = env.NativeGlobal;
  WeixinCanvas = env.WeixinCanvas;
  WeixinArrayBuffer = env.WeixinArrayBuffer;
  wxNativeConsole = env.wxNativeConsole;
  BaseConsole = env.BaseConsole;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.console = new env.BaseConsole();
  Trace = env.Trace;
  Foundation.onLibraryEnd(() => {
    env.subContextInitCallback(xrFrame);
  });
};


/***/ }),

/***/ 878:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   M: () => (/* binding */ initGameContext),
/* harmony export */   O: () => (/* binding */ preloadInitGameContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61);


var currentGlobals;
var comdomExptJsApi = (expt, wx, condomWx) => {
  Object.keys(condomWx).forEach(apiKey => {
    if (__condom__.shouldCloseCondom(apiKey, expt)) {
      condomWx[apiKey] = wx[apiKey];
    }
  });
  return condomWx;
};
var preWx;
var initGameContext = function (env) {
  var createOrGetSharedCanvas = env.createOrGetSharedCanvas;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.__isAdapterInjected = false;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.console = env.console;
  Object.defineProperty(_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, 'sharedCanvas', {
    get() {
      return createOrGetSharedCanvas();
    },
    set() {}
  });
  if (env.__is_wk_game) {
    currentGlobals = [...Protect.globalEsObjs.map(property => globalThis[property]), ...Protect.globalEsHiddenObjs];
  } else {
    currentGlobals = [...Protect.globalEsObjs.map(property => globalThis[property]), ...Protect.globalEsHiddenObjs].filter(Boolean);
  }
  var newCondomResult = env.__ctx_bridge.condomPrototype(currentGlobals);
  __wxConfig.onReady(() => {
    if (__wxConfig.useHighPerformanceMode === true) {
      _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx = env.wx;
      if (env.doAuditsInjectLogic) {
        env.doAuditsInjectLogic({
          globalWx: _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx
        });
      }
      return;
    }
    if (!newCondomResult) {
      var _env$__wxConfig;
      if (preWx) {
        preWx = comdomExptJsApi(__wxConfig.expt, env.wx, preWx);
        _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx = preWx;
        if (env.doAuditsInjectLogic) {
          env.doAuditsInjectLogic({
            globalWx: _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx
          });
        }
        return;
      }
      _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx = __condom__.condomWX(env.wx, env.skipCondom, (_env$__wxConfig = env.__wxConfig) === null || _env$__wxConfig === void 0 ? void 0 : _env$__wxConfig.expt);
      if (env.isPlayableEnv) {
        _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx = env.createPlayableMockWx(_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx);
      }
    } else {
      if (preWx) {
        preWx = comdomExptJsApi(__wxConfig.expt, env.wx, preWx);
        _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx = preWx;
      } else {
        var _env$__wxConfig2;
        _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx = __condom__.condomWX(env.wx, env.skipCondom, (_env$__wxConfig2 = env.__wxConfig) === null || _env$__wxConfig2 === void 0 ? void 0 : _env$__wxConfig2.expt);
      }
    }
    if (env.doAuditsInjectLogic) {
      env.doAuditsInjectLogic({
        globalWx: _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx
      });
    }
    if (env.isPlayableEnv) {
      _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx = env.createPlayableMockWx(_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx);
    }
  });
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.requirePlugin = env.requirePlugin;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.WXWebAssembly = env.WXWebAssembly;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.WXWeakRef = env.WXWeakRef;
  delete _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.WebAssembly;
  if (!_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.GameGlobal) {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.GameGlobal = _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z;
  }
  wxNativeConsole = env.wxNativeConsole;
  Object.defineProperty(_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, '__wxSourceMap', {
    get: __condom__.condom(env.getWxSourceMap)
  });
};
var preloadInitGameContext = function (env, skipCondomList, expt) {
  if (!env || !env.wx) return;
  preWx = __condom__.condomWX(env.wx, skipCondomList, expt);
};


/***/ }),

/***/ 338:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o: () => (/* binding */ initGameOpenDataContext)
/* harmony export */ });
var initGameOpenDataContext = function (env) {
  if (env.getWxSourceMap) env.getWxSourceMap = __condom__.condom(env.getWxSourceMap);
  __gameOpenDataSDK__.init(env);
};


/***/ }),

/***/ 331:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   m: () => (/* binding */ initGamePluginContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61);

var initGamePluginContext = function (env) {
  delete _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.NativeClient;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.console = env.console;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.WXWebAssembly = env.WXWebAssembly;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.env = {};
  if (env.pluginEnv) {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.pluginEnv = env.pluginEnv;
  }
  if (env.wx) {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx = env.wx;
  }
};


/***/ }),

/***/ 757:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ initMagicBrushFrameContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61);

function bannedFunc(name) {
  return function () {
    console.warn(`function ${name} is not supported in current env`);
  };
}
function initMagicBrushFrameContext(env) {
  JSContext.publish('magicBrushFrameSubContextBridge', {
    __subContextEngineBridge__
  });
  if (!env.isRefresh) return;
  env.console.info('[MagicBrushFrame][subContext] initMagicBrushFrameContext');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.Component = env.Component;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.Behavior = env.Behavior;
  setTimeout = env.setTimeout;
  clearTimeout = env.clearTimeout;
  setInterval = env.setInterval;
  clearInterval = env.clearInterval;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.setTimeout = bannedFunc('setTimeout');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.clearTimeout = bannedFunc('clearTimeout');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.setInterval = bannedFunc('setInterval');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.clearInterval = bannedFunc('clearInterval');
  WeixinJSBridge = env.WeixinJSBridge;
  Reporter = env.Reporter;
  wxNativeConsole = env.wxNativeConsole;
  __appServiceSDK__ = env.__appServiceSDK__;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.console = __appServiceSDK__.console;
  var wx = __appServiceSDK__.wx;
  __condom__.condomWX(wx);
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.wx = wx;
  __subContextEngineBridge__.bridgeContext(env.__subContextEngineBridge__);
  env.__freezeLibContextGlobal__();
  setTimeout(() => {
    JSContext.publish('magicBrushFrameSubContextReady', {
      frameSetInfo: env.frameSetInfo
    });
  }, 0);
}

/***/ }),

/***/ 61:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var Global = function () {
  return this;
}();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Global);

/***/ }),

/***/ 552:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CONTEXT_NAME: () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_15__.m),
/* harmony export */   CONTEXT_NAME_PREFIX: () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_15__.D),
/* harmony export */   injectEntryFile: () => (/* reexport safe */ _loadJsFiles__WEBPACK_IMPORTED_MODULE_13__.Wm),
/* harmony export */   loadJsFiles: () => (/* reexport safe */ _loadJsFiles__WEBPACK_IMPORTED_MODULE_13__.z5),
/* harmony export */   loadLibFiles: () => (/* reexport safe */ _loadJsFiles__WEBPACK_IMPORTED_MODULE_13__.C4),
/* harmony export */   onInitReady: () => (/* binding */ onInitReady),
/* harmony export */   onMainContextMessage: () => (/* binding */ onMainContextMessage),
/* harmony export */   postMessageToMainContext: () => (/* binding */ postMessageToMainContext),
/* harmony export */   postMessageToMainContextSync: () => (/* binding */ postMessageToMainContextSync),
/* harmony export */   surroundByTryCatch: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_12__.Ue),
/* harmony export */   surroundThirdByTryCatch: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_12__.M2)
/* harmony export */ });
/* harmony import */ var _ErrorHandler__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(485);
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61);
/* harmony import */ var _ReporterProxy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(180);
/* harmony import */ var _CurrentContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(704);
/* harmony import */ var _timer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(23);
/* harmony import */ var _WxConfigReadyHandler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(143);
/* harmony import */ var _contexts_GameContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(878);
/* harmony import */ var _contexts_GameOpenDataContext__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(338);
/* harmony import */ var _contexts_AppContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(636);
/* harmony import */ var _contexts_AppXRFrameRenderContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(618);
/* harmony import */ var _contexts_AppRenderContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(808);
/* harmony import */ var _contexts_GamePluginContext__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(331);
/* harmony import */ var _contexts_AppSclContext__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(654);
/* harmony import */ var _contexts_MagicBrushFrameContext__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(757);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(793);
/* harmony import */ var _loadJsFiles__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(951);
/* harmony import */ var _libcontext_Utils__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(796);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(227);
/* harmony import */ var src_util__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(410);



















var EVT_INIT_READY = 'subContext:initReady';
var mainContextMessageEmitter = new Foundation.EventEmitter();
var isEmitInitReady = false;
var onInitReady = function (cb) {
  if (isEmitInitReady) cb();else Foundation.once(EVT_INIT_READY, cb);
};
function initGlobal(env) {
  __webpack_require__.g.__isAppServiceRemoteDebugMode__ = !!env.__isAppServiceRemoteDebugMode__;
}
function initAutoTestHandler(env) {
  if (env.__isAppServiceRemoteDebugMode__) {
    // #6977 真机调试2.0 自动化测试需要以下内容
    if (env.__remoteDebug__ && env.__remoteDebug__.setAutoTestHandler) {
      try {
        $eval = env.__remoteDebug__.$$eval;
        var _this;
        env.__remoteDebug__.setAutoTestHandler({
          $eval(functionStr, args, ctx = null) {
            if (!_this) {
              if (env.__wxConfig.platform === 'ios') {
                _this = globalThis;
              } else {
                _this = {
                  ...globalThis,
                  console: env.originConsole
                };
              }
            }
            var fn = $eval(functionStr, _this);
            return fn.apply(ctx, args);
          },
          setGlobalFunctions(name, fn) {
            if (!_this) {
              globalThis[name] = fn;
            } else {
              _this[name] = fn;
            }
          }
        });
      } catch (e) {
        console.error(e);
      }
    }
  }
}
JSContext.subscribe('subContextEnvReady', (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .surroundByTryCatch */ .Ue)(env => {
  _CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.init(env);
  (0,_timer__WEBPACK_IMPORTED_MODULE_4__/* .initTimer */ .v)(env);
  initGlobal(env);
  initAutoTestHandler(env);
  Protect.hijack(true, _CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.secure ? null : globalThis);
  _ReporterProxy__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z.init(env.Reporter);
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .m.GAME) {
    (0,_contexts_GameContext__WEBPACK_IMPORTED_MODULE_6__/* .initGameContext */ .M)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .m.GAME_OPEN_DATA) {
    (0,_contexts_GameOpenDataContext__WEBPACK_IMPORTED_MODULE_16__/* .initGameOpenDataContext */ .o)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .m.APP) {
    (0,_contexts_AppContext__WEBPACK_IMPORTED_MODULE_7__/* .initAppContext */ .E)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .m.APP_RENDER) {
    (0,_contexts_AppRenderContext__WEBPACK_IMPORTED_MODULE_9__/* .initAppRenderContext */ .D)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .m.APP_XRFRAME_RENDER) {
    (0,_contexts_AppXRFrameRenderContext__WEBPACK_IMPORTED_MODULE_8__/* .initAppXRFrameRenderContext */ .y)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .m.APP_SCL) {
    (0,_contexts_AppSclContext__WEBPACK_IMPORTED_MODULE_17__/* .initAppSclContext */ .d)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name.startsWith(_constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME_PREFIX */ .D.GAME_PLUGIN)) {
    (0,_contexts_GamePluginContext__WEBPACK_IMPORTED_MODULE_10__/* .initGamePluginContext */ .m)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name.startsWith(_constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME_PREFIX */ .D.APP_CARDS)) {
    (0,_contexts_MagicBrushFrameContext__WEBPACK_IMPORTED_MODULE_11__/* .initMagicBrushFrameContext */ .Z)(env);
  } else {
    throw new Error('subContextEnvReady: missing context name.');
  }
  (0,_WxConfigReadyHandler__WEBPACK_IMPORTED_MODULE_5__/* .initWxConfigReadyHandler */ .k)(env.__wxConfig);
}));
JSContext.subscribe('preloadSubContextEnvReady', (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .surroundByTryCatch */ .Ue)(env => {
  _CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.init(env);
  if (env.preHandleEnv) {
    (0,_contexts_GameContext__WEBPACK_IMPORTED_MODULE_6__/* .preloadInitGameContext */ .O)(env.preHandleEnv, env.skipCondomList, env.expt);
  }
}));
JSContext.subscribe('subContextRefreshEnv', (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .surroundByTryCatch */ .Ue)(env => {
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === 'game') {
    (0,_contexts_GameContext__WEBPACK_IMPORTED_MODULE_6__/* .initGameContext */ .M)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === 'gameOpenData') {
    (0,_contexts_GameOpenDataContext__WEBPACK_IMPORTED_MODULE_16__/* .initGameOpenDataContext */ .o)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === 'app') {
    (0,_contexts_AppContext__WEBPACK_IMPORTED_MODULE_7__/* .initAppContext */ .E)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === 'app_sub_render') {
    (0,_contexts_AppRenderContext__WEBPACK_IMPORTED_MODULE_9__/* .initAppRenderContext */ .D)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === 'app_xrframe_render') {
    (0,_contexts_AppXRFrameRenderContext__WEBPACK_IMPORTED_MODULE_8__/* .initAppXRFrameRenderContext */ .y)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === 'app_sub_scl') {
    (0,_contexts_AppSclContext__WEBPACK_IMPORTED_MODULE_17__/* .initAppSclContext */ .d)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name.startsWith('gamePlugin_')) {
    (0,_contexts_GamePluginContext__WEBPACK_IMPORTED_MODULE_10__/* .initGamePluginContext */ .m)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name.startsWith(_constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME_PREFIX */ .D.APP_CARDS)) {
    (0,_contexts_MagicBrushFrameContext__WEBPACK_IMPORTED_MODULE_11__/* .initMagicBrushFrameContext */ .Z)(env);
  } else {
    throw new Error('subContextRefreshEnv: missing context name.');
  }
  JSContext.publish('subContextRefreshEnvReady', null, true);
}));
JSContext.subscribe('subContextRefreshWxConfig', (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .surroundByTryCatch */ .Ue)(data => {
  var {
    key,
    value
  } = data;
  if (typeof key === 'string' && value) {
    __wxConfig[key] = value;
  }
}));
JSContext.subscribe('exportGlobalRequire', (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .surroundByTryCatch */ .Ue)(data => {
  var nameTester = /^[A-Za-z]+(\.[A-Za-z]+)*$/;
  var addVariable = variable => {
    var {
      name,
      value,
      needCondom
    } = variable;
    if (typeof name !== 'string' || !nameTester.test(name)) {
      throw new Error('exportGlobalRequire: illegal variable name.');
    }
    var matchList = name.split('.');
    matchList.reduce((obj, key, idx, matchList) => {
      if (idx === matchList.length - 1) {
        if (key in obj) {
          throw new Error(`exportGlobalRequire: Variable ${name} exists.`);
        }
        obj[key] = needCondom ? __condom__.condom(value) : value;
      }
      if (!((0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .getDataType */ .Em)(obj[key]) === 'Array' || (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .getDataType */ .Em)(obj[key]) === 'Function' || (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .getDataType */ .Em)(obj[key]) === 'Object')) {
        var searchPath = matchList.slice(0, idx + 1).join('.');
        throw new Error(`exportGlobalRequire: ${searchPath} is not an Object.`);
      }
      return obj[key];
    }, _global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z);
  };
  if (Object.prototype.toString.call(data) === '[object Array]') return data.forEach(addVariable);
  return addVariable(data);
}));
JSContext.subscribe('mainContextMessage', res => {
  mainContextMessageEmitter.emit('mainContextMessage', res);
});
JSContext.subscribe('subContextDestroy', () => {});
JSContext.subscribe('readyLoadSDKSubPackage', res => {
  Object.getOwnPropertyNames(res).forEach(key => {
    _global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z[key] = res[key];
  });
  JSContext.publish('readyLoadSDKSubPackageDone');
});
var NEED_DELETE_GLOBAL_LIST = ['WeixinJSCore', 'WeixinNativeBuffer', 'WeixinWorker', 'NativeGlobal', 'lockSharedNativeBuffer', 'unlockSharedNativeBuffer', 'getNativeBufferId', 'getNativeBuffer', 'setNativeBuffer', 'setSharedNativeBuffer', 'getSharedNativeBuffer', 'WeixinArrayBuffer'];
var shouldDeferPublishSubcontextReady = typeof IS_RENDER_CTX !== 'undefined';
Foundation.onLoad(() => {
  NEED_DELETE_GLOBAL_LIST.forEach(name => {
    delete _global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z[name];
  });
  JSContext.publish('subContextReady', {
    contextGlobal: {
      get __wxSourceMap() {
        return _global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.__wxSourceMap;
      },
      get __require() {
        return _CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name === 'game' || _CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.name.startsWith('gamePlugin_') ? _global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.require : __condom__.condom(_global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.require);
      },
      jsonParse: JSON.parse,
      jsonStringify: JSON.stringify,
      arrayBufferProto: ArrayBuffer.prototype
    }
  }, true);
}, shouldDeferPublishSubcontextReady);
var hadReadOnly = false;
var globalReadOnlyProtect = function () {
  if (hadReadOnly) return;
  hadReadOnly = true;
  Protect.overwriteSetPrototypeOf();
  Protect.deepFreezeGlobalObjs([], false);
};
Foundation.onLibraryEnd(() => {
  Foundation.onLoad(() => {
    if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.secure && __wxConfig && __wxConfig.isIsolateContext) {
      globalReadOnlyProtect();
    }
    Foundation.emit(EVT_INIT_READY);
    isEmitInitReady = true;
  });
  Foundation.onStart(() => {
    if (__wxConfig.plugins) {
      Protect.hijackFunction({});
      if (!(0,_libcontext_Utils__WEBPACK_IMPORTED_MODULE_14__/* .isDevtools */ .G$)()) {
        globalReadOnlyProtect();
      }
    }
  });
});
var postMessageToMainContext = msg => {
  (0,src_util__WEBPACK_IMPORTED_MODULE_18__/* .nextMicroTask */ .YF)(() => {
    JSContext.publish('subContextMessage', msg);
  });
};
var postMessageToMainContextSync = msg => {
  JSContext.publish('subContextMessage', msg);
};
var onMainContextMessage = fn => {
  mainContextMessageEmitter.on('mainContextMessage', fn);
};


/***/ }),

/***/ 951:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C4: () => (/* binding */ loadLibFiles),
/* harmony export */   Wm: () => (/* binding */ injectEntryFile),
/* harmony export */   z5: () => (/* binding */ loadJsFiles)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(227);
/* harmony import */ var _CurrentContext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(704);


var isApp = () => _CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_1__/* .CONTEXT_NAME */ .m.APP;
var loadJsFiles = (paths, moduleName, options) => {
  var shouldBlock = isApp();
  if (JSContext && JSContext.publish) {
    if (shouldBlock) __wxModule__.globalRequireBlocker.block();
    var ret = JSContext.publish('loadJsFiles', {
      paths,
      options,
      moduleName,
      contextName: _CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.name
    });
    if (shouldBlock) __wxModule__.globalRequireBlocker.unblock();
    if (shouldBlock) __wxModule__.globalRequireBlocker.flushQueue();
    return ret;
  } else return 'failed';
};
var injectEntryFile = (moduleName, separatedPlugins) => {
  var shouldBlock = isApp();
  if (JSContext && JSContext.publish) {
    if (shouldBlock) __wxModule__.globalRequireBlocker.block();
    var ret = JSContext.publish('injectEntryFile', {
      moduleName,
      separatedPlugins
    });
    if (shouldBlock) __wxModule__.globalRequireBlocker.unblock();
    if (shouldBlock) __wxModule__.globalRequireBlocker.flushQueue();
    return ret;
  } else return 'failed';
};
var loadLibFiles = paths => {
  if (JSContext && JSContext.publish) {
    return JSContext.publish('loadLibFiles', {
      paths,
      contextName: _CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.name
    });
  } else return 'failed';
};


/***/ }),

/***/ 23:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   v: () => (/* binding */ initTimer)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61);
/* harmony import */ var _CurrentContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(704);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(793);



var timerFuncFactory = function (fn, extend) {
  return function () {
    if (typeof arguments[0] === 'function') {
      arguments[0] = (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .surroundThirdByTryCatch */ .M2)(arguments[0], extend);
    }
    return fn(...arguments);
  };
};
var initTimer = env => {
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.setTimeout = timerFuncFactory(env.setTimeout, 'at setTimeout callback function');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.clearTimeout = timerFuncFactory(env.clearTimeout);
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.setInterval = timerFuncFactory(env.setInterval, 'at setInterval callback function');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.clearInterval = timerFuncFactory(env.clearInterval);
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.runningType === 'game') {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.requestAnimationFrame = timerFuncFactory(env.requestAnimationFrame, 'at requestAnimationFrame callback function');
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.cancelAnimationFrame = timerFuncFactory(env.cancelAnimationFrame);
  }
};


/***/ }),

/***/ 793:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Em: () => (/* binding */ getDataType),
/* harmony export */   M2: () => (/* binding */ surroundThirdByTryCatch),
/* harmony export */   Ue: () => (/* binding */ surroundByTryCatch),
/* harmony export */   sK: () => (/* binding */ handleThirdError),
/* harmony export */   yH: () => (/* binding */ handleInnerError)
/* harmony export */ });
/* unused harmony export deepFreeze */
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(227);
/* harmony import */ var _CurrentContext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(704);
/* harmony import */ var _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(180);



var handleThirdError = function (error, extend, promise) {
  try {
    var key;
    if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .m.GAME) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.RunType.GAME;
    } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .m.GAME_OPEN_DATA) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.RunType.GAME_SUBCONTEXT;
    } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .m.APP) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.RunType.APP;
    } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.name.startsWith(_constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME_PREFIX */ .D.GAME_PLUGIN)) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.RunType.GAME_SUBCONTEXT;
    } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .m.APP_RENDER) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.RunType.APP_SUBCONTEXT;
    } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .m.APP_XRFRAME_RENDER) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.RunType.APP_SUBCONTEXT;
    } else {
      throw new Error('unknown context');
    }
    if (promise !== undefined) {
      _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.thirdErrorReport({
        key,
        error,
        extend,
        triggerErrorCallback: !_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.secure,
        isUnhandledRejection: true,
        promise
      });
    } else {
      _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.thirdErrorReport({
        key,
        error,
        extend,
        triggerErrorCallback: !_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.secure,
        isUnhandledRejection: false
      });
    }
  } catch (e) {
    console.error('[ErrorHandler] error in Report.thirdErrorReport: ', e.message);
  }
};
function surroundThirdByTryCatch(fn, extend) {
  return function () {
    var res;
    try {
      if (typeof fn === 'function') {
        res = fn.apply(fn, arguments);
      }
    } catch (error) {
      handleThirdError(error, extend);
    }
    return res;
  };
}
function handleInnerError(error, extend, promise) {
  var key = '';
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .m.APP_RENDER) {
    key = 'appSubContextSDKScriptError';
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.runningType === 'game') {
    key = 'gameSubContextSDKScriptError';
  }
  if (typeof _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.thirdErrorReport !== 'function') {
    var msg = extend ? `${error.message};${extend}` : error.message;
    var errMsg = `${key}\n${msg}\n${error.stack}`;
    if (typeof console !== 'undefined') {
      console.error(errMsg);
    }
    return;
  }
  try {
    if (promise !== undefined) {
      _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.errorReport({
        key,
        error,
        extend,
        triggerErrorCallback: !_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.secure,
        isUnhandledRejection: true,
        promise
      });
    } else {
      _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.errorReport({
        key,
        error,
        extend,
        triggerErrorCallback: !_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.secure,
        isUnhandledRejection: false
      });
    }
  } catch (e) {
    console.error('[ErrorHandler] error in Report.errorReport: ', e.message);
  }
}
function surroundByTryCatch(fn, extend) {
  return function () {
    try {
      return fn.apply(fn, arguments);
    } catch (e) {
      wxConsole.error(e.message, e.stack);
      if (Object.prototype.toString.apply(e) === '[object Error]') {
        if (e.type === 'AppServiceSdkKnownError') {
          throw e;
        } else {
          handleInnerError(e, extend);
        }
      }
      return undefined;
    }
  };
}
function getDataType(data) {
  return Object.prototype.toString.call(data).split(' ')[1].split(']')[0];
}
function deepFreeze(o) {
  Object.freeze(o);
  Object.getOwnPropertyNames(o).forEach(prop => {
    var old;
    try {
      old = o[prop];
    } catch (e) {}
    if ((typeof old === 'object' || typeof old === 'function') && !Object.isFrozen(old)) {
      deepFreeze(old);
    }
  });
  return o;
}

/***/ }),

/***/ 410:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Bs: () => (/* binding */ formatOnErrorParam),
/* harmony export */   YF: () => (/* binding */ nextMicroTask)
/* harmony export */ });
/* unused harmony export nextMacroTask */
var formatOnErrorParam = function (res) {
  if (typeof res === 'string') {
    try {
      return JSON.parse(res.replace(/"/g, '\\"').replace(/'/g, '"').replace(/\n/g, '\\n'));
    } catch (e) {
      return {
        message: res,
        stack: ''
      };
    }
  } else {
    return res;
  }
};
var nextMacroTaskTimerId = null;
var nextMacroTaskCallbacks = (/* unused pure expression or super */ null && ([]));
var nextMacroTask = cb => {
  nextMacroTaskCallbacks.push(cb);
  if (nextMacroTaskTimerId === null) {
    nextMacroTaskTimerId = setTimeout(() => {
      nextMacroTaskTimerId = null;
      for (var i = 0; i < nextMacroTaskCallbacks.length; ++i) {
        if (typeof nextMacroTaskCallbacks[i] === 'function') {
          nextMacroTaskCallbacks[i]();
        }
      }
      nextMacroTaskCallbacks.length = 0;
    }, 0);
  }
};
var pendingMicroTask = false;
var nextMicroTaskCallbacks = [];
var nextMicroTask = cb => {
  nextMicroTaskCallbacks.push(cb);
  if (!pendingMicroTask) {
    pendingMicroTask = true;
    Promise.resolve().then(() => {
      for (var i = 0; i < nextMicroTaskCallbacks.length; ++i) {
        if (typeof nextMicroTaskCallbacks[i] === 'function') {
          try {
            nextMicroTaskCallbacks[i]();
          } catch (err) {
            wxNativeConsole.error('[system] Error: nextMicroTaskCallback occur fatal error: ', err);
            console.error('[system] Error: nextMicroTaskCallback occur fatal error: ', err);
            throw err;
          }
        }
      }
      pendingMicroTask = false;
      nextMicroTaskCallbacks.length = 0;
    });
  }
};

/***/ }),

/***/ 888:
/***/ ((module) => {

module.exports = BabelRuntimeHelpers.asyncToGenerator;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(552);
/******/ 	__subContextEngine__ = __webpack_exports__;
/******/ 	
/******/ })()
;

})(this); /* LIBRARY_CLOSURE_END (this) */

var __WAGameSubContextEndTime__ = Date.now() /* @snapshot-ignore Date.now */
typeof this.__wxLibrary.onEnd === 'function' && this.__wxLibrary.onEnd();
delete this.__wxLibrary;
//# sourceURL=WAGameSubContext.js
