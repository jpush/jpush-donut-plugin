
;try {

;(function () { /* LIBRARY_CLOSURE_START () */


            let getGlobalVar = "getSclEngineGlobalVar"
            let sdkSubpakcageGlobalVarGetter
            if(globalThis[getGlobalVar]) {
              sdkSubpakcageGlobalVarGetter = globalThis[getGlobalVar]
            } else if(typeof globalThis.WeixinJSBridge !== "undefined" && globalThis.WeixinJSBridge[getGlobalVar]){
              sdkSubpakcageGlobalVarGetter = globalThis.WeixinJSBridge[getGlobalVar]
            }
            var {forSubLibEnv,WeixinJSBridge,wxConsole,Reporter,__wxConfig,WebAssembly,wxNativeConsole,__initHelper} = sdkSubpakcageGlobalVarGetter();
          

/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 908:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* provided dependency */ var __exparserSclEngine__ = __webpack_require__(817);
(()=>{var e={816:(e,t,n)=>{t.wasm_initialize=function(e,r){var i=function(){var e=null;return"undefined"!=typeof NativeGlobal&&void 0!==NativeGlobal.WebAssembly?e=NativeGlobal.WebAssembly:"undefined"!=typeof libGlobal&&void 0!==libGlobal.WebAssembly?e=libGlobal.WebAssembly:"undefined"!=typeof WebAssembly&&(e=WebAssembly),e}(),o=e.bin,_=~~e.fileType,l=new i.Memory({initial:16}),a={js:{mem:l},"./exparser_scl_backend_bg.js":n(856)},c=function(e){for(var n in e.instance.exports)t[n]=e.instance.exports[n];t.memory||(t.memory=l),t.wasm_initialize=null,r(t)},u=i.instantiate(o,a,_);"function"==typeof u.then?u.then(c):c(u)}},856:(e,t,n)=>{"use strict";function r(){}function i(){}n.r(t),n.d(t,{BoundingClientRect:()=>H,Callback:()=>z,Context:()=>D,Element:()=>I,Listener:()=>L,ScrollPosition:()=>G,__wbg_debug_fda1f49ea6af7a1d:()=>ae,__wbg_error_09919627ac0992f5:()=>_e,__wbg_error_8ff19d586a987aef:()=>ce,__wbg_getDevicePixelRatio_bad18211fbb2a2d3:()=>U,__wbg_getEngineConfig_d071336fb0f35c81:()=>K,__wbg_getSafeArea_e02a51c464e82ae4:()=>V,__wbg_getTheme_6ee867e661a1fe00:()=>J,__wbg_getWindowHeight_5055bbf1cbab7ad7:()=>F,__wbg_getWindowWidth_5d3459d21d0fb732:()=>q,__wbg_info_c8f1b00be4ef10bc:()=>ue,__wbg_instanceof_ExparserElement_74ace43f429ed53b:()=>te,__wbg_invoke_e595dd16845dff2f:()=>Y,__wbg_log_e8ba7b992c7ad0eb:()=>se,__wbg_new_693216e109162396:()=>ie,__wbg_setTimeout_73cd22a52998d9f8:()=>$,__wbg_stack_0ddaca5d1abfb52f:()=>oe,__wbg_subscribe_76e57ecbbf87c182:()=>Z,__wbg_timeoutCallback_5a0fccae410eec7e:()=>ee,__wbg_triggerEvent_fe8e7714c046228c:()=>X,__wbg_warn_0227db1aa6989248:()=>fe,__wbindgen_debug_string:()=>pe,__wbindgen_json_parse:()=>ne,__wbindgen_json_serialize:()=>re,__wbindgen_object_clone_ref:()=>Q,__wbindgen_object_drop_ref:()=>M,__wbindgen_string_new:()=>le,__wbindgen_throw:()=>de,setCurrentFrameView:()=>R,wasm_main:()=>B}),r.prototype.encode=function(e){for(var t=[],n=e.length,r=0;r<n;){var i=e.codePointAt(r),o=0,_=0;for(i<=127?(o=0,_=0):i<=2047?(o=6,_=192):i<=65535?(o=12,_=224):i<=2097151&&(o=18,_=240),t.push(_|i>>o),o-=6;o>=0;)t.push(128|i>>o&63),o-=6;r+=i>=65536?2:1}return t},i.prototype.decode=function(e){if(void 0===e)return"";for(var t="",n=0;n<e.length;){var r=e[n],i=0,o=0;if(r<=127?(i=0,o=255&r):r<=223?(i=1,o=31&r):r<=239?(i=2,o=15&r):r<=244&&(i=3,o=7&r),e.length-n-i>0)for(var _=0;_<i;)o=o<<6|63&(r=e[n+_+1]),_+=1;else o=65533,i=e.length-n;t+=String.fromCodePoint(o),n+=i+1}return t};var o=n(518),_=n(816);function l(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function a(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,u(r.key),r)}}function c(e,t,n){return t&&a(e.prototype,t),n&&a(e,n),Object.defineProperty(e,"prototype",{writable:!1}),e}function u(e){var t=function(e,t){if("object"!=s(e)||!e)return e;var n=e[Symbol.toPrimitive];if(void 0!==n){var r=n.call(e,"string");if("object"!=s(r))return r;throw new TypeError("@@toPrimitive must return a primitive value.")}return String(e)}(e);return"symbol"==s(t)?t:String(t)}function s(e){return s="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},s(e)}e=n.hmd(e);var f=new Array(32).fill(void 0);function p(e){return f[e]}f.push(void 0,null,!0,!1);var d=f.length;function g(e){var t=p(e);return function(e){e<36||(f[e]=d,d=e)}(e),t}function b(e){d===f.length&&f.push(f.length+1);var t=d;return d=f[t],f[t]=e,t}var v=new(void 0===i?(0,e.require)("util").TextDecoder:i)("utf-8",{ignoreBOM:!0,fatal:!0});v.decode();var y=null;function w(){return null!==y&&y.buffer===_.memory.buffer||(y=new Uint8Array(_.memory.buffer)),y}function h(e,t){return v.decode(w().subarray(e,e+t))}var m=0,k=new(void 0===r?(0,e.require)("util").TextEncoder:r)("utf-8"),x="function"==typeof k.encodeInto?function(e,t){return k.encodeInto(e,t)}:function(e,t){var n=k.encode(e);return t.set(n),{read:e.length,written:n.length}};function S(e,t,n){if(void 0===n){var r=k.encode(e),i=t(r.length);return w().subarray(i,i+r.length).set(r),m=r.length,i}for(var o=e.length,_=t(o),l=w(),a=0;a<o;a++){var c=e.charCodeAt(a);if(c>127)break;l[_+a]=c}if(a!==o){0!==a&&(e=e.slice(a)),_=n(_,o,o=a+3*e.length);var u=w().subarray(_+a,_+o);a+=x(e,u).written}return m=a,_}var E=null;function C(){return null!==E&&E.buffer===_.memory.buffer||(E=new Int32Array(_.memory.buffer)),E}function j(e){var t=s(e);if("number"==t||"boolean"==t||null==e)return"".concat(e);if("string"==t)return'"'.concat(e,'"');if("symbol"==t){var n=e.description;return null==n?"Symbol":"Symbol(".concat(n,")")}if("function"==t){var r=e.name;return"string"==typeof r&&r.length>0?"Function(".concat(r,")"):"Function"}if(Array.isArray(e)){var i=e.length,o="[";i>0&&(o+=j(e[0]));for(var _=1;_<i;_++)o+=", "+j(e[_]);return o+"]"}var l,a=/\[object ([^\]]+)\]/.exec(toString.call(e));if(!(a.length>1))return toString.call(e);if("Object"==(l=a[1]))try{return"Object("+JSON.stringify(e)+")"}catch(e){return"Object"}return e instanceof Error?"".concat(e.name,": ").concat(e.message,"\n").concat(e.stack):l}function W(e,t){if(!(e instanceof t))throw new Error("expected instance of ".concat(t.name));return e.ptr}function P(e){return null==e}function O(e){return function(){throw new Error("".concat(e," is not defined"))}}var A=32;function T(e){if(1==A)throw new Error("out of js stack");return f[--A]=e,A}function N(e,t){try{return e.apply(this,t)}catch(e){_.__wbindgen_exn_store(b(e))}}function R(e){_.setCurrentFrameView(e)}function B(){_.wasm_main()}var H=function(){function e(){l(this,e)}return c(e,[{key:"__destroy_into_raw",value:function(){var e=this.ptr;return this.ptr=0,e}},{key:"free",value:function(){var e=this.__destroy_into_raw();_.__wbg_boundingclientrect_free(e)}},{key:"left",get:function(){return _.__wbg_get_boundingclientrect_left(this.ptr)},set:function(e){_.__wbg_set_boundingclientrect_left(this.ptr,e)}},{key:"top",get:function(){return _.__wbg_get_boundingclientrect_top(this.ptr)},set:function(e){_.__wbg_set_boundingclientrect_top(this.ptr,e)}},{key:"width",get:function(){return _.__wbg_get_boundingclientrect_width(this.ptr)},set:function(e){_.__wbg_set_boundingclientrect_width(this.ptr,e)}},{key:"height",get:function(){return _.__wbg_get_boundingclientrect_height(this.ptr)},set:function(e){_.__wbg_set_boundingclientrect_height(this.ptr,e)}}],[{key:"__wrap",value:function(t){var n=Object.create(e.prototype);return n.ptr=t,n}}]),e}(),z=function(){function e(){l(this,e)}return c(e,[{key:"__destroy_into_raw",value:function(){var e=this.ptr;return this.ptr=0,e}},{key:"free",value:function(){var e=this.__destroy_into_raw();_.__wbg_callback_free(e)}},{key:"exec",value:function(e){try{var t=this.__destroy_into_raw();_.callback_exec(t,T(e))}finally{f[A++]=void 0}}}],[{key:"__wrap",value:function(t){var n=Object.create(e.prototype);return n.ptr=t,n}}]),e}(),D=function(){function e(){l(this,e)}return c(e,[{key:"__destroy_into_raw",value:function(){var e=this.ptr;return this.ptr=0,e}},{key:"free",value:function(){var e=this.__destroy_into_raw();_.__wbg_context_free(e)}},{key:"getWindowWidth",value:function(){return _.context_getWindowWidth(this.ptr)}},{key:"getWindowHeight",value:function(){return _.context_getWindowHeight(this.ptr)}},{key:"getDevicePixelRatio",value:function(){return _.context_getDevicePixelRatio(this.ptr)}},{key:"getTheme",value:function(){try{var e=_.__wbindgen_add_to_stack_pointer(-16);_.context_getTheme(e,this.ptr);var t=C()[e/4+0],n=C()[e/4+1];return h(t,n)}finally{_.__wbindgen_add_to_stack_pointer(16),_.__wbindgen_free(t,n)}}},{key:"appendStyleSheet",value:function(e,t){var n=S(e,_.__wbindgen_malloc,_.__wbindgen_realloc),r=m;return _.context_appendStyleSheet(this.ptr,n,r,!P(t),P(t)?0:t)>>>0}},{key:"appendStyleSheetBincode",value:function(e,t){var n,r,i=(n=e,r=(0,_.__wbindgen_malloc)(1*n.length),w().set(n,r/1),m=n.length,r),o=m;return _.context_appendStyleSheetBincode(this.ptr,i,o,!P(t),P(t)?0:t)>>>0}},{key:"clearStyleSheets",value:function(){_.context_clearStyleSheets(this.ptr)}},{key:"render",value:function(e){try{_.context_render(this.ptr,T(e))}finally{f[A++]=void 0}}},{key:"bindRootNode",value:function(e){W(e,I),_.context_bindRootNode(this.ptr,e.ptr)}},{key:"getRootNode",value:function(){var e=_.context_getRootNode(this.ptr);return 0===e?void 0:I.__wrap(e)}},{key:"createElement",value:function(e,t){var n=S(e,_.__wbindgen_malloc,_.__wbindgen_realloc),r=m,i=S(t,_.__wbindgen_malloc,_.__wbindgen_realloc),o=m,l=_.context_createElement(this.ptr,n,r,i,o);return I.__wrap(l)}}],[{key:"__wrap",value:function(t){var n=Object.create(e.prototype);return n.ptr=t,n}},{key:"create",value:function(){var t=_.context_create();return e.__wrap(t)}},{key:"getNodeUnderPoint",value:function(e,t){var n=_.context_getNodeUnderPoint(e,t);return I.__wrap(n)}},{key:"getExparserElementByViewId",value:function(e){return g(_.context_getExparserElementByViewId(e))}}]),e}(),I=function(){function e(){l(this,e)}return c(e,[{key:"__destroy_into_raw",value:function(){var e=this.ptr;return this.ptr=0,e}},{key:"free",value:function(){var e=this.__destroy_into_raw();_.__wbg_element_free(e)}},{key:"release",value:function(){var e=this.__destroy_into_raw();_.element_release(e)}},{key:"associateComponent",value:function(e){_.element_associateComponent(this.ptr,b(e))}},{key:"cloneNode",value:function(){var t=_.element_cloneNode(this.ptr);return e.__wrap(t)}},{key:"equal",value:function(t){return W(t,e),0!==_.element_equal(this.ptr,t.ptr)}},{key:"getParentNode",value:function(){var t=_.element_getParentNode(this.ptr);return 0===t?void 0:e.__wrap(t)}},{key:"getChildNode",value:function(t){var n=_.element_getChildNode(this.ptr,t);return 0===n?void 0:e.__wrap(n)}},{key:"appendChild",value:function(t){W(t,e),_.element_appendChild(this.ptr,t.ptr)}},{key:"insertChild",value:function(t,n){W(t,e),_.element_insertChild(this.ptr,t.ptr,n)}},{key:"removeChild",value:function(e){_.element_removeChild(this.ptr,e)}},{key:"replaceChild",value:function(t,n){W(t,e),_.element_replaceChild(this.ptr,t.ptr,n)}},{key:"spliceBefore",value:function(t,n,r){W(t,e),W(r,e),_.element_spliceBefore(this.ptr,t.ptr,n,r.ptr)}},{key:"spliceAppend",value:function(t){W(t,e),_.element_spliceAppend(this.ptr,t.ptr)}},{key:"spliceRemove",value:function(t,n){W(t,e),_.element_spliceRemove(this.ptr,t.ptr,n)}},{key:"length",value:function(){return _.element_length(this.ptr)>>>0}},{key:"getBoundingClientRect",value:function(){var e=_.element_getBoundingClientRect(this.ptr);return 0===e?void 0:H.__wrap(e)}},{key:"getScrollPosition",value:function(){var e=_.element_getScrollPosition(this.ptr);return G.__wrap(e)}},{key:"setScrollPosition",value:function(e,t,n){_.element_setScrollPosition(this.ptr,!P(e),P(e)?0:e,!P(t),P(t)?0:t,!P(n),P(n)?0:n)}},{key:"setId",value:function(e){var t=S(e,_.__wbindgen_malloc,_.__wbindgen_realloc),n=m;_.element_setId(this.ptr,t,n)}},{key:"setClass",value:function(e){var t=S(e,_.__wbindgen_malloc,_.__wbindgen_realloc),n=m;_.element_setClass(this.ptr,t,n)}},{key:"setStyle",value:function(e){var t=S(e,_.__wbindgen_malloc,_.__wbindgen_realloc),n=m;_.element_setStyle(this.ptr,t,n)}},{key:"setStyleScope",value:function(e){_.element_setStyleScope(this.ptr,!P(e),P(e)?0:e)}},{key:"setAttribute",value:function(e,t){var n=S(e,_.__wbindgen_malloc,_.__wbindgen_realloc),r=m,i=S(t,_.__wbindgen_malloc,_.__wbindgen_realloc),o=m;_.element_setAttribute(this.ptr,n,r,i,o)}},{key:"getAttribute",value:function(e){try{var t=_.__wbindgen_add_to_stack_pointer(-16),n=S(e,_.__wbindgen_malloc,_.__wbindgen_realloc),r=m;_.element_getAttribute(t,this.ptr,n,r);var i=C()[t/4+0],o=C()[t/4+1];return h(i,o)}finally{_.__wbindgen_add_to_stack_pointer(16),_.__wbindgen_free(i,o)}}},{key:"setText",value:function(e){var t=S(e,_.__wbindgen_malloc,_.__wbindgen_realloc),n=m;_.element_setText(this.ptr,t,n)}}],[{key:"__wrap",value:function(t){var n=Object.create(e.prototype);return n.ptr=t,n}}]),e}(),L=function(){function e(){l(this,e)}return c(e,[{key:"__destroy_into_raw",value:function(){var e=this.ptr;return this.ptr=0,e}},{key:"free",value:function(){var e=this.__destroy_into_raw();_.__wbg_listener_free(e)}},{key:"exec",value:function(e){try{return 0!==_.listener_exec(this.ptr,T(e))}finally{f[A++]=void 0}}},{key:"release",value:function(){var e=this.__destroy_into_raw();_.listener_release(e)}}],[{key:"__wrap",value:function(t){var n=Object.create(e.prototype);return n.ptr=t,n}}]),e}(),G=function(){function e(){l(this,e)}return c(e,[{key:"__destroy_into_raw",value:function(){var e=this.ptr;return this.ptr=0,e}},{key:"free",value:function(){var e=this.__destroy_into_raw();_.__wbg_scrollposition_free(e)}},{key:"scrollLeft",get:function(){return _.__wbg_get_scrollposition_scrollLeft(this.ptr)},set:function(e){_.__wbg_set_scrollposition_scrollLeft(this.ptr,e)}},{key:"scrollTop",get:function(){return _.__wbg_get_scrollposition_scrollTop(this.ptr)},set:function(e){_.__wbg_set_scrollposition_scrollTop(this.ptr,e)}},{key:"scrollWidth",get:function(){return _.__wbg_get_scrollposition_scrollWidth(this.ptr)},set:function(e){_.__wbg_set_scrollposition_scrollWidth(this.ptr,e)}},{key:"scrollHeight",get:function(){return _.__wbg_get_scrollposition_scrollHeight(this.ptr)},set:function(e){_.__wbg_set_scrollposition_scrollHeight(this.ptr,e)}}],[{key:"__wrap",value:function(t){var n=Object.create(e.prototype);return n.ptr=t,n}}]),e}();function M(e){g(e)}var q="function"==typeof __exparserSclEngine__.getWindowWidth?__exparserSclEngine__.getWindowWidth:O("__exparserSclEngine__.getWindowWidth"),F="function"==typeof __exparserSclEngine__.getWindowHeight?__exparserSclEngine__.getWindowHeight:O("__exparserSclEngine__.getWindowHeight"),U="function"==typeof __exparserSclEngine__.getDevicePixelRatio?__exparserSclEngine__.getDevicePixelRatio:O("__exparserSclEngine__.getDevicePixelRatio");function V(){return b(__exparserSclEngine__.getSafeArea())}function J(e){var t=S(__exparserSclEngine__.getTheme(),_.__wbindgen_malloc,_.__wbindgen_realloc),n=m;C()[e/4+1]=n,C()[e/4+0]=t}function K(){return b(__exparserSclEngine__.getEngineConfig())}function Q(e){return b(p(e))}function X(e,t,n,r,i){__exparserSclEngine__.exparser.triggerEvent(p(e),h(t,n),g(r),g(i))}function Y(){return N((function(e,t,n,r){__exparserSclEngine__.invoke(h(e,t),g(n),0===r?void 0:z.__wrap(r))}),arguments)}function Z(){return N((function(e,t,n){__exparserSclEngine__.subscribe(h(e,t),0===n?void 0:L.__wrap(n))}),arguments)}function $(e,t){return setTimeout(p(e),t>>>0)}function ee(e,t){__exparserSclEngine__.timeoutCallback(e>>>0,z.__wrap(t))}function te(e){return p(e)instanceof __exparserSclEngine__.exparser.Element}function ne(e,t){return b(JSON.parse(h(e,t)))}function re(e,t){var n=p(t),r=S(JSON.stringify(void 0===n?null:n),_.__wbindgen_malloc,_.__wbindgen_realloc),i=m;C()[e/4+1]=i,C()[e/4+0]=r}function ie(){return b(new Error)}function oe(e,t){var n=S(p(t).stack,_.__wbindgen_malloc,_.__wbindgen_realloc),r=m;C()[e/4+1]=r,C()[e/4+0]=n}function _e(e,t){try{(0,o.consoleErrorReport)(h(e,t))}finally{_.__wbindgen_free(e,t)}}function le(e,t){return b(h(e,t))}function ae(e){console.debug(p(e))}function ce(e){(0,o.consoleErrorReport)(p(e))}function ue(e){console.info(p(e))}function se(e){console.log(p(e))}function fe(e){console.warn(p(e))}function pe(e,t){var n=S(j(p(t)),_.__wbindgen_malloc,_.__wbindgen_realloc),r=m;C()[e/4+1]=r,C()[e/4+0]=n}function de(e,t){throw new Error(h(e,t))}},987:(e,t,n)=>{var r=n(518),i=n(816);e.exports=n(856);var o=function(){e.exports.memory=i.memory,e.exports.__wbg_set_wasm&&e.exports.__wbg_set_wasm(i),"function"==typeof i.__wbindgen_start?i.__wbindgen_start():"function"==typeof i.wasm_main&&i.wasm_main()},_=null;e.exports.wasm_initialize=function(e,t){void 0===t&&(t=e,e=void 0),i.wasm_initialize?_?_.push(t):(_=[t],i.wasm_initialize(e,(function(){o();var e=_;_=null,e.forEach((function(e){e()}))}))):t&&setTimeout(t,0)},i.wasm_initialize||o(),e.exports.setErrorListener=r.setErrorListener},518:(e,t,n)=>{"use strict";n.r(t),n.d(t,{consoleErrorReport:()=>o,setErrorListener:()=>i});var r=null,i=function(e){r=e},o=function(e){if(r){var t=e.split("\nStack:\n",2)[0].trim();r(new Error(t))}else console.error(e)}}},t={};function n(r){var i=t[r];if(void 0!==i)return i.exports;var o=t[r]={id:r,loaded:!1,exports:{}};return e[r](o,o.exports,n),o.loaded=!0,o.exports}n.d=(e,t)=>{for(var r in t)n.o(t,r)&&!n.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},n.hmd=e=>((e=Object.create(e)).children||(e.children=[]),Object.defineProperty(e,"exports",{enumerable:!0,set:()=>{throw new Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: "+e.id)}}),e),n.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),n.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var r=n(987);module.exports=r})();

/***/ }),

/***/ 715:
/***/ ((module) => {

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}
function _asyncToGenerator(fn) {
  return function () {
    var self = this,
      args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(undefined);
    });
  };
}
module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 817:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   exparser: () => (/* binding */ _exparser),
/* harmony export */   getDevicePixelRatio: () => (/* binding */ getDevicePixelRatio),
/* harmony export */   getEngineConfig: () => (/* binding */ getEngineConfig),
/* harmony export */   getKeyboardHeight: () => (/* binding */ getKeyboardHeight),
/* harmony export */   getMenuButtonBoundingClientRect: () => (/* binding */ getMenuButtonBoundingClientRect),
/* harmony export */   getMenuButtonBoundingClientRectAsync: () => (/* binding */ getMenuButtonBoundingClientRectAsync),
/* harmony export */   getSafeArea: () => (/* binding */ getSafeArea),
/* harmony export */   getTheme: () => (/* binding */ getTheme),
/* harmony export */   getViewportSize: () => (/* binding */ getViewportSize),
/* harmony export */   getWindowHeight: () => (/* binding */ getWindowHeight),
/* harmony export */   getWindowWidth: () => (/* binding */ getWindowWidth),
/* harmony export */   invoke: () => (/* binding */ invoke),
/* harmony export */   onThemeChange: () => (/* binding */ onThemeChange),
/* harmony export */   onViewportResize: () => (/* binding */ onViewportResize),
/* harmony export */   subscribe: () => (/* binding */ subscribe),
/* harmony export */   timeoutCallback: () => (/* binding */ timeoutCallback),
/* harmony export */   timestamp: () => (/* binding */ timestamp),
/* harmony export */   timestampMs: () => (/* binding */ timestampMs)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(715);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _vendor_exparser_cmd_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(995);
/* harmony import */ var _vendor_exparser_cmd_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_vendor_exparser_cmd_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _vendor_glass_easel_template_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(312);
/* harmony import */ var _vendor_glass_easel_template_common__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_vendor_glass_easel_template_common__WEBPACK_IMPORTED_MODULE_2__);



_vendor_exparser_cmd_js__WEBPACK_IMPORTED_MODULE_1__.globalOptions.publicProperties = true;
_vendor_exparser_cmd_js__WEBPACK_IMPORTED_MODULE_1__.globalOptions.renderingMode = 'full';
_vendor_exparser_cmd_js__WEBPACK_IMPORTED_MODULE_1__.globalOptions.classPrefix = '';
_vendor_exparser_cmd_js__WEBPACK_IMPORTED_MODULE_1__.globalOptions.templateEngine = _vendor_glass_easel_template_common__WEBPACK_IMPORTED_MODULE_2__.GlassEaselTemplate;
var _exparser = _vendor_exparser_cmd_js__WEBPACK_IMPORTED_MODULE_1__;

var bridge = WeixinJSBridge;
var bridgeOn = {};
if (typeof forSubLibEnv === 'object' && forSubLibEnv) {
  bridgeOn = forSubLibEnv.bridgeOn;
} else {
  var LISTENABLE_BRIDGE_EVENTS = ['onViewDidResize', 'onAppRouteResized', 'onDeviceOrientationChange', 'onTouchStart', 'onTouchMove', 'onTouchEnd', 'onTouchCancel', 'onTextViewDrag', 'onImageViewLoad', 'onScrollViewScroll', 'onThemeChange', 'onKeyboardHeightChange'];
  LISTENABLE_BRIDGE_EVENTS.forEach(name => {
    bridgeOn[name] = WeixinJSBridge.addEventListener.bind(WeixinJSBridge, name);
  });
}
var viewportResizeListeners = [];
var themeChangeListeners = [];
var viewportWidth = 0;
var viewportHeight = 0;
var devicePixelRatio = 0;
var theme = null;
var rawSafeArea;
var safeArea = null;
var keyboardHeight = 0;
var deviceOrientation;
__wxConfig.onReady(() => {
  rawSafeArea = Object.assign({}, __wxConfig.safeArea);
  deviceOrientation = __wxConfig.deviceOrientation;
});
var convertSafeArea = safeArea => {
  if (!safeArea) return safeArea;
  return {
    left: safeArea.left,
    top: safeArea.top,
    right: Math.max(viewportWidth - safeArea.right, 0),
    bottom: Math.max(viewportHeight - safeArea.bottom, 0)
  };
};
var updateViewportSize = /*#__PURE__*/function () {
  var _ref = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()(function* (res) {
    if (res.deviceOrientation && res.deviceOrientation !== deviceOrientation) {
      deviceOrientation = res.deviceOrientation;
      yield new Promise(resolve => {
        bridge.invoke('getSystemInfoAsync', {}, res => {
          rawSafeArea = res.safeArea;
          resolve();
        });
      });
    }
    viewportWidth = res.size.framesetWidth || res.size.screenWidth;
    viewportHeight = res.size.framesetHeight || res.size.screenHeight;
    safeArea = convertSafeArea(rawSafeArea);
    viewportResizeListeners.forEach(cb => {
      cb();
    });
  });
  return function updateViewportSize(_x) {
    return _ref.apply(this, arguments);
  };
}();
var updateViewportSizeWithoutSizeArgs = /*#__PURE__*/function () {
  var _ref2 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()(function* () {
    yield new Promise(resolve => {
      setTimeout(() => {
        bridge.invoke('getSystemInfoAsync', {}, res => {
          viewportWidth = res.screenWidth;
          viewportHeight = res.screenHeight;
          rawSafeArea = res.safeArea;
          resolve();
        });
      }, 0);
    });
    safeArea = convertSafeArea(rawSafeArea);
    viewportResizeListeners.forEach(cb => {
      cb();
    });
  });
  return function updateViewportSizeWithoutSizeArgs() {
    return _ref2.apply(this, arguments);
  };
}();
bridgeOn.onViewDidResize(updateViewportSize);
bridgeOn.onAppRouteResized(updateViewportSize);
bridgeOn.onDeviceOrientationChange(updateViewportSizeWithoutSizeArgs);
bridgeOn.onThemeChange(res => {
  if (theme !== res.theme && __wxConfig.darkmode) {
    theme = res.theme;
    _vendor_exparser_cmd_js__WEBPACK_IMPORTED_MODULE_1__.triggerRender(() => {
      themeChangeListeners.forEach(cb => cb({
        theme
      }));
    });
  }
});
bridgeOn.onKeyboardHeightChange(res => {
  keyboardHeight = res.height;
});
var onThemeChange = function (cb) {
  themeChangeListeners.push(cb);
};
var onViewportResize = function (cb) {
  viewportResizeListeners.push(cb);
};
var getInitialViewportSize = function () {
  return new Promise(resolve => {
    if (!devicePixelRatio || !viewportWidth || !viewportHeight) {
      bridge.invoke('getSystemInfo', {}, res => {
        devicePixelRatio = res.pixelRatio;
        if (!viewportWidth || !viewportHeight) {
          viewportWidth = res.framesetWidth || res.screenWidth;
          viewportHeight = res.framesetHeight || res.screenHeight;
        }
        rawSafeArea = res.safeArea;
        safeArea = convertSafeArea(rawSafeArea);
        resolve();
      });
    } else {
      resolve();
    }
  });
};
var getInitialTheme = function () {
  if (!theme) {
    var wxConfig = __wxConfig;
    var {
      darkmode
    } = wxConfig;
    theme = darkmode ? wxConfig.theme : 'light';
  }
};
var timestamp = function () {
  return Math.floor(Date.now() / 1000);
};
var timestampMs = function () {
  return Date.now() % 1000;
};
var getEngineConfig = function () {
  return {
    relativeToParentContent: false
  };
};
var getWindowWidth = function () {
  getInitialViewportSize();
  return viewportWidth;
};
var getViewportSize = /*#__PURE__*/function () {
  var _ref3 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()(function* () {
    yield getInitialViewportSize();
    return {
      width: viewportWidth,
      height: viewportHeight
    };
  });
  return function getViewportSize() {
    return _ref3.apply(this, arguments);
  };
}();
var getWindowHeight = function () {
  getInitialViewportSize();
  return viewportHeight;
};
var getTheme = function () {
  getInitialTheme();
  return theme || 'light';
};
var getDevicePixelRatio = function () {
  return devicePixelRatio;
};
var getSafeArea = function () {
  return safeArea;
};
var getMenuButtonBoundingClientRect = function () {
  var rect = {};
  bridge.invoke('getMenuButtonBoundingClientRect', {}, res => {
    Object.assign(rect, res);
    delete rect.errMsg;
  });
  return rect;
};
var getMenuButtonBoundingClientRectAsync = function () {
  getInitialViewportSize();
  return new Promise(resolve => {
    bridge.invoke('getMenuButtonBoundingClientRect', {}, res => {
      resolve(res);
    });
  });
};
var getKeyboardHeight = () => keyboardHeight;
var invoke = function (name, args, callback) {
  bridge.invoke(name, args, res => {
    if (callback) {
      callback.exec(res);
    }
  });
};
var subscribe = function (name, listener) {
  bridgeOn[name](res => {
    if (!listener) return undefined;
    var passToNextListener = listener.exec(res);
    return passToNextListener;
  }, {
    prepend: true
  });
};
var timeoutCallback = function (duration, callback) {
  if (callback) {
    setTimeout(args => {
      callback.exec(args);
    }, duration);
  }
};

/***/ }),

/***/ 498:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ binStyles),
/* harmony export */   W: () => (/* binding */ styles)
/* harmony export */ });
var styles = [];
var binStyles = [];

/***/ }),

/***/ 312:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = (() => {
  // webpackBootstrap
  "use strict";
  var __webpack_modules__ = {
    674: (__unused_webpack_module, __nested_webpack_exports__, __nested_webpack_require_150__) => {
      __nested_webpack_require_150__.r(__nested_webpack_exports__);
      __nested_webpack_require_150__.d(__nested_webpack_exports__, {
        "GlassEaselTemplate": () => GlassEaselTemplate
      });
      ;
      var checkSubFieldsUpdated = function (node) {
        for (var k in node) {
          if (Object.prototype.hasOwnProperty.call(node, k)) {
            var v = node[k];
            if (v === true) return true;
            if (!v) continue;
            var sub = checkSubFieldsUpdated(v);
            if (sub) return true;
          }
        }
        return false;
      };
      var evaluateExprWithUpdateCheck = function (valueType, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, returnValueWhenNotUpdated) {
        if (typeof valueType === 'object') {
          var indirectValueCache_1 = [];
          var w_1 = function (func, args) {
            var method = func;
            var exparser = __webpack_require__(995);
            return exparser.safeCallback('Template Function', method, null, args);
          };
          var indirectValueCacheVisitor_1 = function (index) {
            if (indirectValueCache_1[index] === undefined) {
              var updater = valueType.I[index];
              var v = updater(data, scopes, indirectValueCacheVisitor_1, w_1);
              if (v === undefined) {
                indirectValueCache_1[index] = null;
              } else {
                indirectValueCache_1[index] = v;
              }
            }
            return indirectValueCache_1[index];
          };
          var updatePathTreeNode = dataUpdatePathTree === true || valueType.L(dataUpdatePathTree, scopeUpdatePathTrees, indirectValueCacheVisitor_1);
          var needReturnValue = returnValueWhenNotUpdated || updatePathTreeNode === true || updatePathTreeNode && checkSubFieldsUpdated(updatePathTreeNode);
          if (needReturnValue) {
            var value = valueType.F(data, scopes, indirectValueCacheVisitor_1, w_1);
            var lvaluePath = null;
            if (valueType.M) {
              var m = valueType.M;
              lvaluePath = [];
              for (var i = 0; i < m.length; i += 1) {
                var slice = m[i];
                if (typeof slice === 'number') {
                  if (i === 0) {
                    if (!scopeLvaluePaths[slice]) {
                      lvaluePath = null;
                      break;
                    }
                    lvaluePath.push.apply(lvaluePath, scopeLvaluePaths[slice]);
                  } else {
                    var v = indirectValueCacheVisitor_1(slice);
                    lvaluePath.push(typeof v === 'number' ? v : v.toString());
                  }
                } else {
                  lvaluePath.push(slice);
                }
              }
            }
            return [value, updatePathTreeNode, lvaluePath];
          }
        } else if (returnValueWhenNotUpdated) {
          return [valueType, undefined, null];
        }
        return null;
      };
      var evaluateExpr = function (valueType, data, scopes, scopeLvaluePaths) {
        if (typeof valueType === 'object') {
          var indirectValueCache_2 = [];
          var w_2 = function (func, args) {
            var method = func;
            var exparser = __webpack_require__(995);
            return exparser.safeCallback('Template Function', method, null, args);
          };
          var indirectValueCacheVisitor_2 = function (index) {
            if (indirectValueCache_2[index] === undefined) {
              var updater = valueType.I[index];
              var v = updater(data, scopes, indirectValueCacheVisitor_2, w_2);
              if (v === undefined) {
                indirectValueCache_2[index] = null;
              } else {
                indirectValueCache_2[index] = v;
              }
            }
            return indirectValueCache_2[index];
          };
          var value = valueType.F(data, scopes, indirectValueCacheVisitor_2, w_2);
          var lvaluePath = null;
          if (valueType.M) {
            var m = valueType.M;
            lvaluePath = [];
            for (var i = 0; i < m.length; i += 1) {
              var slice = m[i];
              if (typeof slice === 'number') {
                if (i === 0) {
                  if (!scopeLvaluePaths[slice]) {
                    lvaluePath = null;
                    break;
                  }
                  lvaluePath.push.apply(lvaluePath, scopeLvaluePaths[slice]);
                } else {
                  var v = indirectValueCacheVisitor_2(slice);
                  lvaluePath.push(typeof v === 'number' ? v : v.toString());
                }
              } else {
                lvaluePath.push(slice);
              }
            }
          }
          return [value, lvaluePath];
        }
        return [valueType, null];
      };
      var dataValueToString = function (v) {
        if (v === null || v === undefined) {
          return '';
        }
        return v.toString();
      };
      var dataValueToStringOrNumber = function (v) {
        if (typeof v === 'number') {
          return v;
        }
        if (v === null || v === undefined) {
          return '';
        }
        return v.toString();
      };
      ;
      var STYLE_SEGMENT_INDEX;
      (function (STYLE_SEGMENT_INDEX) {
        STYLE_SEGMENT_INDEX[STYLE_SEGMENT_INDEX["ATTR"] = 0] = "ATTR";
      })(STYLE_SEGMENT_INDEX || (STYLE_SEGMENT_INDEX = {}));
      var dashToCamelCase = function (dash) {
        var ret = dash.indexOf('-') <= 0 ? dash : dash.replace(/-[a-z]/g, function (s) {
          return s[1].toUpperCase();
        });
        return ret;
      };
      var applyPropertyInner = function (node, propName, exprRes, lvaluePath, nodeDataProxy, isComponentNode, pendingModelBindings) {
        var exparser = __webpack_require__(995);
        var propValue = exparser.dataUtils.deepCopy(exprRes);
        if (node instanceof exparser.VirtualNode && node.is === 'slot' && propName === 'name') {
          exparser.Element.setSlotName(node, dataValueToString(propValue));
          return false;
        }
        if (propName === 'id') {
          node.id = dataValueToString(propValue);
          return false;
        }
        if (propName === 'slot') {
          node.slot = dataValueToString(propValue);
          return false;
        }
        if (propName === 'class') {
          if (isComponentNode) {
            var hasExternalClass_1 = node.hasExternalClass('class');
            if (hasExternalClass_1) {
              node.setExternalClass('class', dataValueToString(propValue));
            } else {
              node.class = dataValueToString(propValue);
            }
          } else {
            node.class = dataValueToString(propValue);
          }
          return false;
        }
        if (isComponentNode) {
          var camelName = dashToCamelCase(propName);
          var hasProperty = exparser.Component.hasPublicProperty(node, camelName);
          if (hasProperty) {
            nodeDataProxy.scheduleReplace([camelName], propValue, null);
            return true;
          }
          if (propName.slice(0, 6) === 'model:') {
            if (!lvaluePath) {
              console.warn("Cannot apply reverse binding to property \"" + propName + "\" because the binding expression is not a valid lvalue");
            }
            var camelModelName = camelName.slice(6);
            var hasProperty_1 = exparser.Component.hasPublicProperty(node, camelModelName);
            if (hasProperty_1) {
              nodeDataProxy.scheduleReplace([camelModelName], propValue, null);
              pendingModelBindings.push([camelModelName, lvaluePath]);
              return true;
            }
          }
        }
        if (propName === 'style') {
          node.setNodeStyle(dataValueToString(propValue), STYLE_SEGMENT_INDEX.ATTR);
          return false;
        }
        if (/^data:/.test(propName)) {
          var setName = propName.slice(5);
          node.dataset[setName] = propValue;
          return false;
        }
        if (/^data-/.test(propName)) {
          var setName = dashToCamelCase(propName.slice(5).toLowerCase());
          node.dataset[setName] = propValue;
          return false;
        }
        var eventMatches = /^(capture-)?(mut-)?(bind|catch):?(.+)$/.exec(propName);
        if (eventMatches) {
          var handlerName_1 = dataValueToString(propValue);
          node.addListener(eventMatches[4], function (ev) {
            var host = node.ownerShadowRoot.getHostNode();
            var ret;
            if (typeof host === 'object') {
              var methodCaller = exparser.Element.getMethodCaller(host) || host;
              var f = methodCaller[handlerName_1];
              if (typeof f === 'function') {
                ret = f.call(methodCaller, ev);
              }
            }
            return ret;
          });
          return false;
        }
        if (/^mark:/.test(propName)) {
          node.setMark(propName.slice(5), propValue);
          return false;
        }
        var hasExternalClass = isComponentNode && node.hasExternalClass(propName);
        if (hasExternalClass) {
          node.setExternalClass(propName, dataValueToString(propValue));
          return false;
        }
        if (node instanceof exparser.NativeNode) {
          if (typeof propValue === 'boolean') {
            if (propValue === true) {
              node.setAttribute(propName, '');
            } else {
              node.removeAttribute(propName);
            }
          } else {
            node.setAttribute(propName, dataValueToString(propValue));
          }
          return false;
        }
        return false;
      };
      var applyProperties = function (node, props, data, scopes, scopeLvaluePaths, dataUpdatePathTree, scopeUpdatePathTrees) {
        var _a;
        node.dataset = node.dataset || {};
        var needDoUpdates = false;
        var pendingModelBindings = [];
        var exparser = __webpack_require__(995);
        var isComponentNode = node instanceof exparser.Component;
        var nodeDataProxy = isComponentNode ? exparser.Component.getDataProxy(node) : null;
        for (var propName in props) {
          if (!Object.prototype.hasOwnProperty.call(props, propName)) continue;
          var propValueType = props[propName];
          var exprRes = void 0;
          var lvaluePath = null;
          if (scopeUpdatePathTrees) {
            var res = evaluateExprWithUpdateCheck(propValueType, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, false);
            if (!res) continue;
            exprRes = res[0];
            lvaluePath = res[2];
          } else {
            _a = evaluateExpr(propValueType, data, scopes, scopeLvaluePaths), exprRes = _a[0], lvaluePath = _a[1];
          }
          var needDoUpdatesForThisProp = applyPropertyInner(node, propName, exprRes, lvaluePath, nodeDataProxy, isComponentNode, pendingModelBindings);
          if (needDoUpdatesForThisProp) needDoUpdates = true;
        }
        if (needDoUpdates) {
          nodeDataProxy.doUpdates(null, true);
        }
        if (isComponentNode) {
          var _loop_1 = function (i) {
            var _a = pendingModelBindings[i],
              propName = _a[0],
              lvaluePath = _a[1];
            node.setPropertyChangeListener(propName, function (value) {
              var host = node.ownerShadowRoot.getHostNode();
              var nodeDataProxy = exparser.Component.getDataProxy(host);
              nodeDataProxy.scheduleReplace(lvaluePath, value, null);
              nodeDataProxy.doUpdates(null, false);
            });
          };
          for (var i = 0; i < pendingModelBindings.length; i += 1) {
            _loop_1(i);
          }
        }
      };
      var applyPropertyInBindingMap = function (node, propName, propValueType, data) {
        node.dataset = node.dataset || {};
        var pendingModelBindings = [];
        var exparser = __webpack_require__(995);
        var isComponentNode = node instanceof exparser.Component;
        var nodeDataProxy = isComponentNode ? exparser.Component.getDataProxy(node) : null;
        var _a = evaluateExpr(propValueType, data, null, null),
          exprRes = _a[0],
          lvaluePath = _a[1];
        var needDoUpdatesForThisProp = applyPropertyInner(node, propName, exprRes, lvaluePath, nodeDataProxy, isComponentNode, pendingModelBindings);
        if (needDoUpdatesForThisProp) {
          nodeDataProxy.doUpdates(null, true);
        }
        if (isComponentNode) {
          var _loop_2 = function (i) {
            var _a = pendingModelBindings[i],
              propName_1 = _a[0],
              lvaluePath_1 = _a[1];
            node.setPropertyChangeListener(propName_1, function (value) {
              var host = node.ownerShadowRoot.getHostNode();
              var nodeDataProxy = exparser.Component.getDataProxy(host);
              nodeDataProxy.scheduleReplace(lvaluePath_1, value, null);
              nodeDataProxy.doUpdates(null, false);
            });
          };
          for (var i = 0; i < pendingModelBindings.length; i += 1) {
            _loop_2(i);
          }
        }
      };
      ;
      var collectKeys = function (list) {
        var keyIndexes = {};
        for (var index = 0; index < list.length; index += 1) {
          var itemKey = list[index];
          if (!itemKey) {
            if (Number.isNaN(itemKey)) {
              list[index] = undefined;
            }
          } else if (Object.prototype.hasOwnProperty.call(keyIndexes, itemKey)) {
            list[index] = undefined;
          } else {
            keyIndexes[dataValueToString(itemKey)] = index;
          }
        }
        return keyIndexes;
      };
      var collectKeysAndFreeIndexes = function (list) {
        var keyIndexes = {};
        var freeIndexes = [];
        for (var index = 0; index < list.length; index += 1) {
          var itemKey = list[index];
          if (!itemKey) {
            if (Number.isNaN(itemKey)) {
              list[index] = undefined;
            }
            freeIndexes.push(index);
          } else if (Object.prototype.hasOwnProperty.call(keyIndexes, itemKey)) {
            list[index] = undefined;
            freeIndexes.push(index);
          } else {
            keyIndexes[dataValueToString(itemKey)] = index;
          }
        }
        return [keyIndexes, freeIndexes];
      };
      var listDiff = function (oldList, newList, dataList) {
        var oldKeyIndexes = collectKeys(oldList);
        var _a = collectKeysAndFreeIndexes(newList),
          newKeyIndexes = _a[0],
          newFreeIndexes = _a[1];
        var currentList = [];
        var children = new Array(oldList.length);
        var indexChanged = new Array(oldList.length);
        var removes = [];
        var inserts = [];
        var freeIndex = 0;
        var deletedItemCount = 0;
        for (var i = 0; i < oldList.length; i += 1) {
          var itemKey = oldList[i];
          if (itemKey) {
            if (Object.prototype.hasOwnProperty.call(newKeyIndexes, itemKey)) {
              var itemIndex = newKeyIndexes[dataValueToString(itemKey)];
              currentList.push(newList[itemIndex]);
              children[i] = dataList[itemIndex];
              indexChanged[i] = i !== itemIndex;
            } else {
              removes.push(i - deletedItemCount);
              deletedItemCount += 1;
              currentList.push(null);
              children[i] = null;
            }
          } else {
            if (freeIndex < newFreeIndexes.length) {
              var itemIndex = newFreeIndexes[freeIndex];
              currentList.push(newList[itemIndex]);
              children[i] = dataList[itemIndex];
              freeIndex += 1;
              indexChanged[i] = i !== itemIndex;
            } else {
              removes.push(i - deletedItemCount);
              deletedItemCount += 1;
              currentList.push(null);
              children[i] = null;
            }
          }
        }
        var currentIndex = 0;
        var stables = [];
        for (var newIndex = 0; newIndex < newList.length;) {
          var newItemKey = newList[newIndex];
          var currentItemKey = currentList[currentIndex];
          while (currentItemKey === null) {
            currentIndex += 1;
            currentItemKey = currentList[currentIndex];
          }
          if (currentIndex >= currentList.length) {
            inserts.push({
              oldIndex: oldKeyIndexes[dataValueToString(newItemKey)],
              index: newIndex,
              pos: -1
            });
            currentIndex += 1;
            newIndex += 1;
          } else if (currentItemKey === newItemKey) {
            stables.push(currentIndex);
            currentIndex += 1;
            newIndex += 1;
          } else if (newItemKey) {
            if (currentItemKey) {
              if (newKeyIndexes[dataValueToString(currentItemKey)] === newIndex + 1) {
                inserts.push({
                  oldIndex: oldKeyIndexes[dataValueToString(newItemKey)],
                  index: newIndex,
                  pos: currentIndex
                });
              } else {
                currentIndex += 1;
                currentItemKey = currentList[currentIndex];
                if (currentItemKey === newItemKey) {
                  stables.push(currentIndex);
                  currentIndex += 1;
                } else {
                  currentIndex -= 1;
                  inserts.push({
                    oldIndex: oldKeyIndexes[dataValueToString(newItemKey)],
                    index: newIndex,
                    pos: currentIndex
                  });
                }
              }
            } else {
              inserts.push({
                oldIndex: oldKeyIndexes[dataValueToString(newItemKey)],
                index: newIndex,
                pos: currentIndex
              });
            }
            newIndex += 1;
          } else {
            currentIndex += 1;
          }
        }
        var stableIndex = 0;
        for (var i = 0; i < inserts.length; i += 1) {
          var currentIndex_1 = inserts[i].pos;
          if (currentIndex_1 === -1) break;
          while (stableIndex < stables.length && currentIndex_1 > stables[stableIndex]) {
            stableIndex += 1;
          }
          if (stableIndex >= stables.length) {
            inserts[i].pos = -1;
          } else {
            inserts[i].pos = stables[stableIndex];
          }
        }
        return {
          children: children,
          indexChanged: indexChanged,
          removes: removes,
          inserts: inserts
        };
      };
      var applyListDiff = function (removes, inserts, exparserNode, dataList, baseLvaluePath, newListItemFunc) {
        var exparserChildren = exparserNode.childNodes;
        var insertNodes = [];
        for (var i = 0; i < inserts.length; i += 1) {
          var insert = inserts[i];
          insertNodes.push({
            node: insert.oldIndex !== undefined ? exparserChildren[insert.oldIndex] : null,
            before: insert.pos >= 0 ? exparserChildren[insert.pos] : undefined,
            index: insert.index
          });
        }
        for (var i = 0; i < removes.length; i += 1) {
          var index = removes[i];
          var node = exparserChildren[index];
          exparserNode.removeChild(node);
        }
        for (var i = 0; i < insertNodes.length; i += 1) {
          var _a = insertNodes[i],
            before = _a.before,
            index = _a.index;
          var node = insertNodes[i].node;
          if (node === null) {
            var _b = dataList[index],
              item = _b.item,
              key = _b.index;
            if (baseLvaluePath) baseLvaluePath.push(key);
            node = newListItemFunc(item, key, baseLvaluePath);
            if (baseLvaluePath) baseLvaluePath.pop();
          }
          exparserNode.insertBefore(node, before);
        }
      };
      ;
      var VIRTUAL_NODE_TYPES;
      (function (VIRTUAL_NODE_TYPES) {
        VIRTUAL_NODE_TYPES[VIRTUAL_NODE_TYPES["PURE"] = 0] = "PURE";
        VIRTUAL_NODE_TYPES[VIRTUAL_NODE_TYPES["IF"] = 1] = "IF";
        VIRTUAL_NODE_TYPES[VIRTUAL_NODE_TYPES["FOR"] = 2] = "FOR";
        VIRTUAL_NODE_TYPES[VIRTUAL_NODE_TYPES["TEMPLATE_IS"] = 3] = "TEMPLATE_IS";
        VIRTUAL_NODE_TYPES[VIRTUAL_NODE_TYPES["SHADOW_ROOT"] = 4] = "SHADOW_ROOT";
        VIRTUAL_NODE_TYPES[VIRTUAL_NODE_TYPES["SLOT"] = 5] = "SLOT";
        VIRTUAL_NODE_TYPES[VIRTUAL_NODE_TYPES["INCLUDE"] = 6] = "INCLUDE";
        VIRTUAL_NODE_TYPES[VIRTUAL_NODE_TYPES["BLOCK_SLOT"] = 7] = "BLOCK_SLOT";
      })(VIRTUAL_NODE_TYPES || (VIRTUAL_NODE_TYPES = {}));
      var insertChildren = function (genObjectGroup, exparserNode, children, data, scopes, scopeLvaluePaths, shadowRoot) {
        if (!children) return;
        for (var i = 0; i < children.length; i += 1) {
          var child = children[i];
          if (child == null) continue;
          if (child.S === undefined) {
            var childNode = genObjectToExparserNode(genObjectGroup, child, data, scopes, scopeLvaluePaths, null, shadowRoot);
            exparserNode.appendChild(childNode);
          } else {
            var content = evaluateExpr(child.S, data, scopes, scopeLvaluePaths)[0];
            var childNode = shadowRoot.createTextNode(dataValueToString(content));
            exparserNode.appendChild(childNode);
          }
        }
      };
      var genObjectToExparserNode = function (genObjectGroup, genObj, data, scopes, scopeLvaluePaths, shadowRootHost, shadowRoot) {
        var exparserNode = null;
        if (typeof genObj.V !== 'undefined') {
          var vObj_1 = genObj;
          if (vObj_1.V === VIRTUAL_NODE_TYPES.IF) {
            var virtualTagName = 'wx:if';
            var exparserNode_1 = shadowRoot.createVirtualNode(virtualTagName);
            exparserNode_1.__templateArgs = {};
            var exparser = __webpack_require__(995);
            exparser.Element.setInheritSlots(exparserNode_1);
            var branches = vObj_1.B;
            for (var i = 0; i < branches.length; i += 1) {
              var branch = branches[i];
              var res = evaluateExpr(branch.B, data, scopes, scopeLvaluePaths);
              if (res[0]) {
                insertChildren(genObjectGroup, exparserNode_1, branch.C, data, scopes, scopeLvaluePaths, shadowRoot);
                exparserNode_1.__templateArgs.key = i;
                break;
              }
            }
            return exparserNode_1;
          } else if (vObj_1.V === VIRTUAL_NODE_TYPES.FOR) {
            var virtualTagName = 'wx:for';
            var exparserNode_2 = shadowRoot.createVirtualNode(virtualTagName);
            exparserNode_2.__templateArgs = {};
            var exparser = __webpack_require__(995);
            exparser.Element.setInheritSlots(exparserNode_2);
            var keyList_1 = exparserNode_2.__templateArgs.keyList = [];
            var keyName_1 = vObj_1.K;
            var appendListItem = function (item, index, lvaluePath) {
              if (keyName_1 === '*this') {
                keyList_1.push(item);
              } else {
                keyList_1.push(item == null ? undefined : item[keyName_1]);
              }
              var virtualTagName = 'wx:for-item';
              var childNode = shadowRoot.createVirtualNode(virtualTagName);
              exparser.Element.setInheritSlots(childNode);
              scopes.push(item);
              scopes.push(index);
              scopeLvaluePaths.push(lvaluePath);
              scopeLvaluePaths.push(null);
              insertChildren(genObjectGroup, childNode, vObj_1.C, data, scopes, scopeLvaluePaths, shadowRoot);
              scopeLvaluePaths.pop();
              scopeLvaluePaths.pop();
              scopes.pop();
              scopes.pop();
              exparserNode_2.appendChild(childNode);
            };
            var _a = evaluateExpr(vObj_1.L, data, scopes, scopeLvaluePaths),
              list = _a[0],
              lvaluePath = _a[1];
            if (list instanceof Array) {
              for (var i = 0; i < list.length; i += 1) {
                if (lvaluePath) lvaluePath.push(i);
                appendListItem(list[i], i, lvaluePath);
                if (lvaluePath) lvaluePath.pop();
              }
            } else if (typeof list === 'object') {
              for (var key in list) {
                if (Object.prototype.hasOwnProperty.call(list, key)) {
                  if (lvaluePath) lvaluePath.push(key);
                  appendListItem(list[key], key, lvaluePath);
                  if (lvaluePath) lvaluePath.pop();
                }
              }
            } else if (typeof list === 'string') {
              for (var i = 0; i < list.length; i += 1) {
                if (lvaluePath) lvaluePath.push(i);
                appendListItem(list[i], i, lvaluePath);
                if (lvaluePath) lvaluePath.pop();
              }
            } else if (typeof list === 'number') {
              for (var i = 0; i < list; i += 1) {
                if (lvaluePath) lvaluePath.push(i);
                appendListItem(i, i, lvaluePath);
                if (lvaluePath) lvaluePath.pop();
              }
            }
            return exparserNode_2;
          } else if (vObj_1.V === VIRTUAL_NODE_TYPES.TEMPLATE_IS) {
            var exparserNode_3 = shadowRoot.createVirtualNode('template');
            exparserNode_3.__templateArgs = {};
            var exparser = __webpack_require__(995);
            exparser.Element.setInheritSlots(exparserNode_3);
            var name_1 = evaluateExpr(vObj_1.N, data, scopes, scopeLvaluePaths)[0];
            var is = exparserNode_3.__templateArgs.key = dataValueToString(name_1);
            var target = genObjectGroup(is);
            if (target) {
              var subData = evaluateExpr(vObj_1.D, data, scopes, scopeLvaluePaths)[0];
              insertChildren(genObjectGroup, exparserNode_3, target.C, subData, [], [], shadowRoot);
            }
            return exparserNode_3;
          } else if (vObj_1.V === VIRTUAL_NODE_TYPES.INCLUDE) {
            var exparserNode_4 = shadowRoot.createVirtualNode('include');
            var exparser = __webpack_require__(995);
            exparser.Element.setInheritSlots(exparserNode_4);
            return exparserNode_4;
          } else if (vObj_1.V === VIRTUAL_NODE_TYPES.SHADOW_ROOT) {
            var exparser = __webpack_require__(995);
            exparserNode = shadowRoot = exparser.ShadowRoot.create(shadowRootHost);
          } else if (vObj_1.V === VIRTUAL_NODE_TYPES.SLOT) {
            var n = exparserNode = shadowRoot.createVirtualNode('slot');
            var name_2 = evaluateExpr(vObj_1.N, data, scopes, scopeLvaluePaths)[0];
            var exparser = __webpack_require__(995);
            exparser.Element.setSlotName(n, dataValueToString(name_2));
          } else if (vObj_1.V === VIRTUAL_NODE_TYPES.BLOCK_SLOT) {
            var n = exparserNode = shadowRoot.createVirtualNode('virtual');
            var name_3 = evaluateExpr(vObj_1.N, data, scopes, scopeLvaluePaths)[0];
            n.slot = dataValueToString(name_3);
          } else if (vObj_1.V === VIRTUAL_NODE_TYPES.PURE) {
            var n = exparserNode = shadowRoot.createVirtualNode('virtual');
            var exparser = __webpack_require__(995);
            exparser.Element.setInheritSlots(n);
          }
        } else {
          var compObj = genObj;
          var domTag = compObj.T;
          if (shadowRoot.tagNameUsed(domTag) || domTag.indexOf('-') >= 0) {
            exparserNode = shadowRoot.createComponent(domTag, undefined, compObj.G);
          } else {
            exparserNode = shadowRoot.createNativeNode(domTag);
          }
        }
        var exparser = __webpack_require__(995);
        if (exparserNode instanceof exparser.Element) {
          var scopeData = genObj.SD;
          if (scopeData !== undefined) {
            if (!exparserNode.__templateArgs) exparserNode.__templateArgs = {};
            var sd = evaluateExpr(scopeData, data, scopes, scopeLvaluePaths)[0];
            exparserNode.__templateArgs.scopeData = sd;
          }
          var compObj = genObj;
          if (compObj.EA) {
            for (var k in compObj.EA) {
              exparserNode.setAttribute(k, compObj.EA[k]);
            }
          }
          var attr = compObj.A;
          if (attr) {
            applyProperties(exparserNode, attr, data, scopes, scopeLvaluePaths);
          }
          var children = genObj.C;
          if (children) {
            insertChildren(genObjectGroup, exparserNode, children, data, scopes, scopeLvaluePaths, shadowRoot);
          }
        }
        return exparserNode;
      };
      var updateChildren = function (exparserNode, genObjectGroup, children, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, shadowRoot) {
        if (!children) return;
        for (var i = 0; i < children.length; i += 1) {
          var child = children[i];
          if (child == null) continue;
          if (child.S === undefined) {
            genObjectExparserNodeUpdate(exparserNode.childNodes[i], genObjectGroup, child, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, shadowRoot);
          } else {
            var res = evaluateExprWithUpdateCheck(child.S, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, false);
            if (res) {
              var content = res[0];
              exparserNode.childNodes[i].textContent = dataValueToString(content);
            }
          }
        }
      };
      var genObjectExparserNodeUpdate = function (exparserNode, genObjectGroup, genObj, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, shadowRoot) {
        if (typeof genObj.V !== 'undefined') {
          var vObj_2 = genObj;
          if (vObj_2.V === VIRTUAL_NODE_TYPES.IF) {
            var createNewNode = function (key, children) {
              var virtualTagName = 'wx:if';
              var newExparserNode = shadowRoot.createVirtualNode(virtualTagName);
              newExparserNode.__templateArgs = {};
              var exparser = __webpack_require__(995);
              exparser.Element.setInheritSlots(newExparserNode);
              newExparserNode.__templateArgs.key = key;
              if (children) {
                insertChildren(genObjectGroup, newExparserNode, children, data, scopes, scopeLvaluePaths, shadowRoot);
              }
              exparserNode.parentNode.replaceChild(newExparserNode, exparserNode);
            };
            var branches = vObj_2.B;
            for (var i = 0; i < branches.length; i += 1) {
              var branch = branches[i];
              var value = evaluateExprWithUpdateCheck(branch.B, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, true)[0];
              if (value) {
                if (exparserNode.__templateArgs.key === i) {
                  genObjectExparserNodeUpdate(exparserNode, genObjectGroup, branch, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, shadowRoot);
                } else {
                  createNewNode(i, branch.C);
                }
                return;
              }
            }
            if (exparserNode.__templateArgs.key !== -1) {
              createNewNode(-1);
            }
            return;
          } else if (vObj_2.V === VIRTUAL_NODE_TYPES.FOR) {
            var oldKeyList = exparserNode.__templateArgs.keyList;
            var keyList_2 = exparserNode.__templateArgs.keyList = [];
            var keyName_2 = vObj_2.K;
            var collectKeyList = function (item) {
              if (keyName_2 === '*this') {
                keyList_2.push(item);
              } else {
                keyList_2.push(item == null ? undefined : item[keyName_2]);
              }
            };
            var newListItem = function (item, index, lvaluePath) {
              var virtualTagName = 'wx:for-item';
              var childNode = shadowRoot.createVirtualNode(virtualTagName);
              var exparser = __webpack_require__(995);
              exparser.Element.setInheritSlots(childNode);
              scopes.push(item);
              scopes.push(index);
              scopeLvaluePaths.push(lvaluePath);
              scopeLvaluePaths.push(null);
              insertChildren(genObjectGroup, childNode, vObj_2.C, data, scopes, scopeLvaluePaths, shadowRoot);
              scopeLvaluePaths.pop();
              scopeLvaluePaths.pop();
              scopes.pop();
              scopes.pop();
              return childNode;
            };
            var updateListItem = function (item, index, updatePathTree, lvaluePath, indexChanged, exparserNode) {
              scopes.push(item);
              scopes.push(index);
              scopeUpdatePathTrees.push(updatePathTree);
              scopeUpdatePathTrees.push(indexChanged ? true : undefined);
              scopeLvaluePaths.push(lvaluePath);
              scopeLvaluePaths.push(null);
              var children = vObj_2.C;
              updateChildren(exparserNode, genObjectGroup, children, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, shadowRoot);
              scopeLvaluePaths.pop();
              scopeLvaluePaths.pop();
              scopeUpdatePathTrees.pop();
              scopeUpdatePathTrees.pop();
              scopes.pop();
              scopes.pop();
            };
            var _a = evaluateExprWithUpdateCheck(vObj_2.L, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, true),
              list = _a[0],
              listUpdatePathTree = _a[1],
              baseLvaluePath = _a[2];
            var objectKeyAsIndex = false;
            var dataList = [];
            if (list instanceof Array) {
              for (var i = 0; i < list.length; i += 1) {
                collectKeyList(list[i]);
                dataList.push({
                  item: list[i],
                  index: i
                });
              }
            } else if (typeof list === 'object') {
              objectKeyAsIndex = true;
              for (var key in list) {
                collectKeyList(list[key]);
                dataList.push({
                  item: list[key],
                  index: key
                });
              }
            } else if (typeof list === 'string') {
              for (var i = 0; i < list.length; i += 1) {
                collectKeyList(list[i]);
                dataList.push({
                  item: list[i],
                  index: i
                });
              }
            } else if (typeof list === 'number') {
              for (var i = 0; i < list; i += 1) {
                collectKeyList(i);
                dataList.push({
                  item: i,
                  index: i
                });
              }
            }
            var _b = listDiff(oldKeyList, keyList_2, dataList),
              children = _b.children,
              indexChanged = _b.indexChanged,
              inserts = _b.inserts,
              removes = _b.removes;
            for (var i = 0; i < children.length; i += 1) {
              var newChild = children[i];
              if (newChild) {
                var updatePathTree = void 0;
                if (listUpdatePathTree === true) updatePathTree = true;else if (listUpdatePathTree) updatePathTree = listUpdatePathTree[newChild.index];
                if (baseLvaluePath) baseLvaluePath.push(newChild.index);
                updateListItem(newChild.item, newChild.index, updatePathTree, baseLvaluePath, objectKeyAsIndex || indexChanged[i], exparserNode.childNodes[i]);
                if (baseLvaluePath) baseLvaluePath.pop();
              }
            }
            applyListDiff(removes, inserts, exparserNode, dataList, baseLvaluePath, newListItem);
            return;
          } else if (vObj_2.V === VIRTUAL_NODE_TYPES.TEMPLATE_IS) {
            var res = evaluateExprWithUpdateCheck(vObj_2.N, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, false);
            if (res && exparserNode.__templateArgs.key !== res[0]) {
              var newExparserNode = genObjectToExparserNode(genObjectGroup, vObj_2, data, scopes, scopeLvaluePaths, null, shadowRoot);
              exparserNode.parentNode.replaceChild(newExparserNode, exparserNode);
            } else {
              var is = exparserNode.__templateArgs.key;
              var target = genObjectGroup(is);
              var _c = evaluateExprWithUpdateCheck(vObj_2.D, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, true),
                subData = _c[0],
                subUpdatePathTree = _c[1];
              updateChildren(exparserNode, genObjectGroup, target.C, subData, [], subUpdatePathTree, [], [], shadowRoot);
            }
            return;
          } else if (vObj_2.V === VIRTUAL_NODE_TYPES.SLOT) {
            var res = evaluateExprWithUpdateCheck(vObj_2.N, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, false);
            if (res) {
              var exparser = __webpack_require__(995);
              exparser.Element.setSlotName(exparserNode, dataValueToString(res[0]));
            }
          } else if (vObj_2.V === VIRTUAL_NODE_TYPES.INCLUDE) {
            return;
          } else if (vObj_2.V === VIRTUAL_NODE_TYPES.BLOCK_SLOT) {
            var res = evaluateExprWithUpdateCheck(vObj_2.N, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, false);
            if (res) {
              exparserNode.slot = dataValueToString(res[0]);
            }
          }
        }
        var exparser = __webpack_require__(995);
        if (exparserNode instanceof exparser.Element) {
          var compObj = genObj;
          var attr = compObj.A;
          if (attr) {
            applyProperties(exparserNode, attr, data, scopes, scopeLvaluePaths, dataUpdatePathTree, scopeUpdatePathTrees);
          }
          var children = genObj.C;
          if (children) {
            updateChildren(exparserNode, genObjectGroup, children, data, scopes, dataUpdatePathTree, scopeUpdatePathTrees, scopeLvaluePaths, shadowRoot);
          }
        }
      };
      ;
      var DEFAULT_GEN_OBJECT_GROUP_LIST = function () {
        return {
          P: '',
          C: [{
            V: VIRTUAL_NODE_TYPES.SLOT,
            N: '',
            C: []
          }]
        };
      };
      var GlassEaselTemplateNative = function () {
        function GlassEaselTemplateNative(behavior, data, innerData, _componentOptions) {
          this.data = data;
          this.innerData = innerData;
          if (typeof behavior.template === 'string') {
            var exparser = __webpack_require__(995);
            this.genObjectGroup = exparser.precompileTemplate(behavior.template).content[''];
          } else {
            var c = behavior.template || {
              content: DEFAULT_GEN_OBJECT_GROUP_LIST
            };
            this.genObjectGroup = c.content;
          }
          this.updateMode = '';
        }
        GlassEaselTemplateNative.create = function (behavior, data, innerData, componentOptions) {
          return new GlassEaselTemplateNative(behavior, data, innerData, componentOptions);
        };
        GlassEaselTemplateNative.prototype.createInstance = function (elem, _updateOptions) {
          var inst = new GlassEaselTemplateNativeInstance();
          inst.template = this;
          var genObjectRoot = inst.template.genObjectGroup('');
          inst.genObject = {
            V: VIRTUAL_NODE_TYPES.SHADOW_ROOT,
            C: genObjectRoot.C
          };
          inst.bindingMap = genObjectRoot.BM;
          var exparser = __webpack_require__(995);
          inst.data = exparser.dataUtils.deepCopy(this.data);
          inst.idMap = Object.create(null);
          var slots = Object.create(null);
          slots[''] = null;
          var shadowRoot = genObjectToInitTree(elem, inst.genObject, inst.data, inst.idMap, slots);
          if (slots[''] === null && shadowRoot.childNodes.length > 0) {
            var slot = document.createElement('virtual');
            shadowRoot.appendChild(slot);
            slots[''] = slot;
          }
          inst.shadowRoot = shadowRoot;
          inst.slots = slots;
          inst.listeners = [];
          return inst;
        };
        return GlassEaselTemplateNative;
      }();
      var GlassEaselTemplateNativeInstance = function () {
        function GlassEaselTemplateNativeInstance() {}
        GlassEaselTemplateNativeInstance.prototype.updateValues = function (elem, data, changedPaths, _changedValues, _changes, _updateOptions) {
          if (!this.bindingMapInstance) {
            var bm_1 = {};
            for (var k in this.bindingMap) {
              if (Object.prototype.hasOwnProperty.call(this.bindingMap, k)) {
                var bindingPathList = this.bindingMap[k];
                var bindingTargets = new Array(bindingPathList.length);
                for (var i = 0; i < bindingPathList.length; i += 1) {
                  var pathIndexes = bindingPathList[i];
                  var curNode = elem.shadowRoot;
                  var curGenObjectNode = this.genObject;
                  var propName = null;
                  for (var j = 0; j < pathIndexes.length; j += 1) {
                    var index = pathIndexes[j];
                    if (typeof index === 'number') {
                      curNode = curNode.childNodes[index];
                      curGenObjectNode = curGenObjectNode.C[index];
                    } else {
                      propName = index;
                      break;
                    }
                  }
                  var propValueType = propName === null ? curGenObjectNode.S : curGenObjectNode.A[propName];
                  if (propName && (propName === 'id' || propName.indexOf(':') >= 0)) {
                    bindingTargets[i] = [curNode, "illegal-update:" + propName, propValueType];
                  } else {
                    bindingTargets[i] = [curNode, propName, propValueType];
                  }
                }
                bm_1[k] = bindingTargets;
              }
            }
            this.bindingMapInstance = bm_1;
          }
          var bm = this.bindingMapInstance;
          for (var i = 0; i < changedPaths.length; i += 1) {
            var path = changedPaths[i];
            var dataField = path[0];
            var targets = bm[dataField];
            if (targets === undefined) continue;
            for (var j = 0; j < targets.length; j += 1) {
              var _a = targets[j],
                node = _a[0],
                propName = _a[1],
                propValueType = _a[2];
              var exprRes = evaluateExpr(propValueType, data, null, null)[0];
              if (propName !== null) {
                if (typeof exprRes === 'boolean') {
                  if (exprRes === true) {
                    node.setAttribute(propName, '');
                  } else {
                    node.removeAttribute(propName);
                  }
                } else {
                  node.setAttribute(propName, dataValueToString(exprRes));
                }
              } else {
                node.textContent = dataValueToString(exprRes);
              }
            }
          }
        };
        return GlassEaselTemplateNativeInstance;
      }();
      var genObjectToInitTree = function (host, genObj, data, idMap, slots) {
        var elem;
        var isRoot = false;
        if (typeof genObj.V !== 'undefined') {
          var vObj = genObj;
          if (vObj.V === VIRTUAL_NODE_TYPES.SHADOW_ROOT) {
            elem = document.createDocumentFragment();
            isRoot = true;
          }
          if (vObj.V === VIRTUAL_NODE_TYPES.SLOT) {
            var elem_1 = slots[''] = document.createElement('virtual');
            return elem_1;
          }
        } else {
          var compObj = genObj;
          var domTag = compObj.T;
          elem = document.createElement(domTag);
          var props = compObj.A;
          var _loop_1 = function (propName) {
            if (!Object.prototype.hasOwnProperty.call(props, propName)) return "continue";
            var propValueType = props[propName];
            var exprRes = evaluateExpr(propValueType, data, null, null)[0];
            if (propName === 'id') {
              idMap[dataValueToString(exprRes)] = elem;
            } else {
              var _a = propName.split(':', 2),
                directive = _a[0],
                p = _a[1];
              if (p) {
                if (directive === 'bind') {
                  var handlerName_1 = dataValueToString(exprRes);
                  var exparser = __webpack_require__(995);
                  exparser.addListenerToElement(elem, p, function (ev) {
                    var ret;
                    if (typeof host === 'object') {
                      var f = host[handlerName_1];
                      if (typeof f === 'function') {
                        ret = f.call(host, ev);
                      }
                    }
                    return ret;
                  });
                }
              } else {
                if (typeof exprRes === 'boolean') {
                  if (exprRes === true) {
                    elem.setAttribute(propName, '');
                  } else {
                    elem.removeAttribute(propName);
                  }
                } else {
                  elem.setAttribute(directive, dataValueToString(exprRes));
                }
              }
            }
          };
          for (var propName in props) {
            _loop_1(propName);
          }
        }
        var children = genObj.C;
        if (children.length === 1 && children[0].V === VIRTUAL_NODE_TYPES.SLOT) {
          if (!isRoot) {
            slots[''] = elem;
          }
        } else {
          for (var i = 0; i < children.length; i += 1) {
            var child = children[i];
            if (child.S === undefined) {
              var childNode = genObjectToInitTree(host, child, data, idMap, slots);
              elem.appendChild(childNode);
            } else {
              var content = evaluateExpr(child.S, data, null, null)[0];
              var childNode = document.createTextNode(dataValueToString(content));
              elem.appendChild(childNode);
            }
          }
        }
        return elem;
      };
      ;
      var BINDING_MAP_UPDATE_SET_DATA_FIELDS_LIMIT = 1;
      var src_DEFAULT_GEN_OBJECT_GROUP_LIST = function () {
        return {
          P: '',
          C: [{
            V: VIRTUAL_NODE_TYPES.SLOT,
            N: '',
            C: []
          }]
        };
      };
      var collectIdMapAndSlots = function (elem, idMap, slots) {
        var children = elem.childNodes;
        for (var i = 0; i < children.length; i += 1) {
          var child = children[i];
          var exparser = __webpack_require__(995);
          if (child instanceof exparser.Element) {
            if (child.__id) idMap[child.__id] = child;
            if (child.__slotName !== undefined) slots[child.__slotName] = child;
            collectIdMapAndSlots(child, idMap, slots);
          }
        }
      };
      var GlassEaselTemplate = function () {
        function GlassEaselTemplate(behavior, data, innerData, _componentOptions) {
          this.data = data;
          this.innerData = innerData;
          if (typeof behavior.template === 'string') {
            var exparser = __webpack_require__(995);
            this.genObjectGroup = exparser.precompileTemplate(behavior.template).content[''];
            this.updateMode = '';
          } else {
            var c = behavior.template || {
              content: src_DEFAULT_GEN_OBJECT_GROUP_LIST
            };
            this.genObjectGroup = c.content;
            this.updateMode = c.updateMode || '';
          }
        }
        GlassEaselTemplate.create = function (behavior, data, innerData, componentOptions) {
          if (componentOptions.renderingMode === 'native') {
            return new GlassEaselTemplateNative(behavior, data, innerData, componentOptions);
          }
          return new GlassEaselTemplate(behavior, data, innerData, componentOptions);
        };
        GlassEaselTemplate.prototype.createInstance = function (elem, _updateOptions) {
          var inst = new GlassEaselTemplateInstance();
          inst.template = this;
          var genObjectRoot = inst.template.genObjectGroup('');
          inst.genObject = {
            V: VIRTUAL_NODE_TYPES.SHADOW_ROOT,
            C: genObjectRoot.C
          };
          if (this.updateMode === '' || this.updateMode === 'bindingMap') {
            inst.bindingMap = genObjectRoot.BM;
            if (this.updateMode === 'bindingMap') {
              inst.forceBindingMapUpdate = true;
            }
          }
          var exparser = __webpack_require__(995);
          inst.data = exparser.dataUtils.deepCopy(this.data);
          inst.idMap = Object.create(null);
          inst.slots = Object.create(null);
          inst.shadowRoot = genObjectToExparserNode(inst.template.genObjectGroup, inst.genObject, this.innerData, [], [], elem, null);
          collectIdMapAndSlots(inst.shadowRoot, inst.idMap, inst.slots);
          inst.listeners = [];
          return inst;
        };
        return GlassEaselTemplate;
      }();
      var GlassEaselTemplateInstance = function () {
        function GlassEaselTemplateInstance() {}
        GlassEaselTemplateInstance.prototype.updateValues = function (elem, data, changedPaths, _changedValues, _changes, _updateOptions) {
          if (this.forceBindingMapUpdate) {
            this.tryBindingMapUpdate(elem, data, changedPaths);
            return;
          }
          if (changedPaths.length <= BINDING_MAP_UPDATE_SET_DATA_FIELDS_LIMIT) {
            if (this.bindingMap) {
              if (this.tryBindingMapUpdate(elem, data, changedPaths)) {
                return;
              }
            }
          }
          var dataUpdataPathTree = Object.create(null);
          for (var i = 0; i < changedPaths.length; i += 1) {
            var p = changedPaths[i];
            var cur = dataUpdataPathTree;
            for (var j = 0; j < p.length; j += 1) {
              var field = p[j];
              if (cur[field] === true) break;
              if (j === p.length - 1) {
                cur[field] = true;
                break;
              }
              if (!cur[field]) {
                cur[field] = Object.create(null);
              }
              cur = cur[field];
            }
          }
          genObjectExparserNodeUpdate(this.shadowRoot, this.template.genObjectGroup, this.genObject, data, [], dataUpdataPathTree, [], [], elem.shadowRoot);
        };
        GlassEaselTemplateInstance.prototype.tryBindingMapUpdate = function (elem, data, changedPaths) {
          if (!this.bindingMapInstance) {
            var bm_1 = {};
            for (var k in this.bindingMap) {
              if (Object.prototype.hasOwnProperty.call(this.bindingMap, k)) {
                var bindingPathList = this.bindingMap[k];
                var bindingTargets = new Array(bindingPathList.length);
                for (var i = 0; i < bindingPathList.length; i += 1) {
                  var pathIndexes = bindingPathList[i];
                  var curNode = elem.shadowRoot;
                  var curGenObjectNode = this.genObject;
                  var propName = null;
                  for (var j = 0; j < pathIndexes.length; j += 1) {
                    var index = pathIndexes[j];
                    if (typeof index === 'number') {
                      curNode = curNode.childNodes[index];
                      curGenObjectNode = curGenObjectNode.C[index];
                    } else {
                      propName = index;
                      break;
                    }
                  }
                  var propValueType = propName === null ? curGenObjectNode.S : curGenObjectNode.A[propName];
                  bindingTargets[i] = [curNode, propName, propValueType];
                }
                bm_1[k] = bindingTargets;
              }
            }
            this.bindingMapInstance = bm_1;
          }
          var bm = this.bindingMapInstance;
          for (var i = 0; i < changedPaths.length; i += 1) {
            var path = changedPaths[i];
            if (path.length !== 1) return false;
            var dataField = path[0];
            var targets = bm[dataField];
            if (targets === undefined) return false;
          }
          for (var i = 0; i < changedPaths.length; i += 1) {
            var path = changedPaths[i];
            var dataField = path[0];
            var targets = bm[dataField];
            for (var j = 0; j < targets.length; j += 1) {
              var _a = targets[j],
                node = _a[0],
                propName = _a[1],
                propValueType = _a[2];
              if (propName !== null) {
                applyPropertyInBindingMap(node, propName, propValueType, data);
              } else {
                var content = evaluateExpr(propValueType, data, null, null)[0];
                node.textContent = dataValueToString(content);
              }
            }
          }
          return true;
        };
        return GlassEaselTemplateInstance;
      }();
    }
  };
  var __webpack_module_cache__ = {};
  function __nested_webpack_require_54112__(moduleId) {
    if (__webpack_module_cache__[moduleId]) {
      return __webpack_module_cache__[moduleId].exports;
    }
    var module = __webpack_module_cache__[moduleId] = {
      exports: {}
    };
    __webpack_modules__[moduleId](module, module.exports, __nested_webpack_require_54112__);
    return module.exports;
  }
  /* webpack/runtime/define property getters */
  (() => {
    __nested_webpack_require_54112__.d = (exports, definition) => {
      for (var key in definition) {
        if (__nested_webpack_require_54112__.o(definition, key) && !__nested_webpack_require_54112__.o(exports, key)) {
          Object.defineProperty(exports, key, {
            enumerable: true,
            get: definition[key]
          });
        }
      }
    };
  })();
  /* webpack/runtime/hasOwnProperty shorthand */
  (() => {
    __nested_webpack_require_54112__.o = (obj, prop) => Object.prototype.hasOwnProperty.call(obj, prop);
  })();
  /* webpack/runtime/make namespace object */
  (() => {
    __nested_webpack_require_54112__.r = exports => {
      if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
        Object.defineProperty(exports, Symbol.toStringTag, {
          value: 'Module'
        });
      }
      Object.defineProperty(exports, '__esModule', {
        value: true
      });
    };
  })();
  return __nested_webpack_require_54112__(674);
})();

/***/ }),

/***/ 995:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* provided dependency */ var exparser = __webpack_require__(995);
module.exports=function(e){function t(n){if(r[n])return r[n].exports;var o=r[n]={exports:{},id:n,loaded:!1};return e[n].call(o.exports,o,o.exports,t),o.loaded=!0,o.exports}var r={};return t.m=e,t.c=r,t.p="",t(0)}([function(e,t,r){var n=r(1),o=r(3),i=r(5),a=r(6),l=r(7),s=r(8),_=r(9),c=r(15),d=r(12),u=r(17),f=r(18),p=r(19),h=r(16),v=r(10),m=r(20),b=r(14),g=r(21),y=r(4),w=r(13),x=r(22);t.FreeTmpl=x,t.precompileTemplate=x.precompiler?x.precompiler.compile:null,t.precompiler=x.precompiler?x.precompiler:null,t.HtmlLLParser=x.htmlParser?x.htmlParser:null,t.LLParser=n,t.dataPath=l,t.dataUtils=i,t.Event=a,t.Element=_,t.TextNode=d,t.NativeNode=u,t.VirtualNode=f,t.ShadowRoot=p,t.Behavior=s,t.Component=c,t.Observer=v,t.DataGroup=h,t.ElementIterator=m,t.FakeDomElement=b,t.registerBehavior=s.create,t.registerElement=c.register,t.createElement=c.create,t.createTextNode=d.create,t.createVirtualNode=f.create,t.appendChild=_.appendChild,t.insertBefore=_.insertBefore,t.removeChild=_.removeChild,t.replaceChild=_.replaceChild,t.addListenerToElement=a.addListenerToElement,t.removeListenerFromElement=a.removeListenerFromElement,t.triggerEvent=a.triggerEvent,t.triggerRender=g.triggerRender,t.safeCallback=o.safeCallback,t.addGlobalErrorListener=o.addGlobalErrorListener,t.removeGlobalErrorListener=o.removeGlobalErrorListener,t.addGlobalWarningListener=o.addGlobalWarningListener,t.removeGlobalWarningListener=o.removeGlobalWarningListener,t.globalOptions=y,t.globalState=w,c._setDefaultTemplateEngine(x);var C=t.updateDefaultComponent=function(){delete c._list[""],c.register({is:"",options:{writeOnly:!0,allowInWriteOnly:!0,lazyRegistration:!1,classPrefix:"",addGlobalClass:!1,templateEngine:null,renderingMode:"full",multipleSlots:!1,reflectToAttributes:!1}})};C(),t.initBackend=function(){C()};var S=function(e){var t="";if(e instanceof exparser.Element&&(e.id&&(t+=' id="'+e.id+'"'),e.slot&&(t+=' slot="'+e.slot+'"'),e.__slotName&&(t+=' name="'+e.__slotName+'"'),e.classList&&(t+=' class="'+e.class+'"'),"dom"===y.documentBackend&&e.$$&&e.$$.getAttribute("style")&&(t+=' style="'+e.$$.getAttribute("style")+'"')),e instanceof exparser.VirtualNode)return t;if(e instanceof exparser.Component)return c.listPublicProperties(e).forEach(function(r){t+=" "+r+"="+JSON.stringify(e[r])}),t;for(var r=e.attributes,n=0;n<r.length;n++)t+=" "+r[n].name+'="'+r[n].value+'"';return t},E=t.dumpElementToString=function(e,t,r){var n=null;"dom"===y.documentBackend&&(n=window);var o=0;r=r||0;var i="";for(o=r;o;o--)i+="  ";var a="";if(e instanceof exparser.Element){var l="dom"===y.documentBackend&&e.$$?e.$$.tagName.toLowerCase()+":":"";a+=i+"<"+l+e.is+S(e)+">",a+=e instanceof exparser.VirtualNode?" [Exp-Virtual]":e instanceof exparser.NativeNode?" [Exp-Native]":" [Exp-Component]",a+="\n"+E(t?e.__wxSlotChildren:e.childNodes,t,r+1)}else if(e instanceof exparser.TextNode)a+=i+e.textContent+" [Exp-Text]\n";else if(n&&n.HTMLElement&&e instanceof n.HTMLElement)a+=i+"<"+e.tagName.toLowerCase()+S(e)+"> [DOM-Element]",a+="\n"+E(t?e.__wxSlotChildren||e.childNodes:e.childNodes,t,r+1);else if(n&&n.Text&&e instanceof n.Text)a+=i+e.textContent+" [DOM-Text]\n";else if(void 0!==e.length)for(o=0;o<e.length;o++)a+=E(e[o],t,r);else a=i+"[unknown node]\n";return a};t.dumpElement=function(e,t){console.log(E(e,t))}},function(e,t,r){var n=null,o=16384,i=128,a=128,l=0,s=1,_=65536,c=function(){},d=c.stats={all:0,copyIn:0,parse:0,constructOut:0},u=function(e){var t=n.llparser_create_descriptor(e,1);return t},f=function(e,t){var r=n.llparser_create_descriptor(e,0),o=!1;"^"===t[0]&&(o=!0);for(var i=o?1:0;i<t.length;i++){var a=t.charCodeAt(i);if("-"===t[i+1]){var l=t.charCodeAt(i+2);a<=l?(n.llparser_descriptor_add_range(r,a,l),i+=2):n.llparser_descriptor_add_char(r,a)}else n.llparser_descriptor_add_char(r,a)}return o&&n.llparser_descriptor_revert(r),r};c.create=function(e,t,d){n||(n=r(2));var p=new c;d=d||o;var h=p._llp=n.llparser_create(d,i,a),v={},m={},b="";v.ALL=n.llparser_create_descriptor(h,0),n.llparser_descriptor_set_all(v.ALL),v.NULL=n.llparser_create_descriptor(h,0),n.llparser_descriptor_set_nil(v.NULL);for(b in e)v[b]=u(h);for(b in e)for(var g=e[b],y=v[b],w=0;w<g.length;w++){for(var x=g[w].id,C=g[w].states,S=[],E=0;E<C.length;E++){var O=C[E];v[O]||(v[O]=f(h,O)),S.push(v[O])}var N=l;"_raw"===x?N=s:"_jump"===x?N=_+0:"_blank"===x&&(N=_+1);var k=n.llparser_add_rule(h,N,y,S.length,S[0],S[1],S[2],S[3],S[4],S[5],S[6],S[7]);N===l&&(m[k]=t[x])}return n.llparser_prepare(h),p._inputPtr=n.llparser_get_input_buffer(h),p._resultPtr=n.llparser_get_result(h),p._stateIdMap=v,p._ruleCbMap=m,p._charCountLimit=d,p};var p=function(e,t,r,n,o){for(var i=[],a={i:0,r:0,n:!1,cc:-1,c:[]},l=a,s=o.pos,_=!1,c=!1,d=!1;;){var u=t[s],f=t[s+1];if(f<0?(c=!0,f=-f-1):c=!1,u>=0){d=!0;var p=r.slice(u,f);l.c.push(p),_=c}else{if(u===-1&&0===f)break;d=!1;var h=-u,v=f,m={i:l.c.length-(_?1:0),r:h,n:c,cc:v,c:[]};if(_){var b=l.c.length-1,g=l.c[b];m.c.push(g),l.c[b]=m}else l.c.push(m);i.push(l),l=m,_=!1}if(!d||!_)for(;l.c.length===l.cc;){_=l.n;var y=i.pop();if(y.c[l.i]=n[l.r].call(e,l.c),l=y,_)break}s+=2}return a.c[0]},h=function(e,t,r,n){for(var o=n>e.length?e.length:n,i=0;i<o;i++)t[r+i]=e.charCodeAt(i);t[r+o]=0};c.prototype.parse=function(e,t){var r=Date.now();h(t,new Uint16Array(n.memory.buffer),this._inputPtr>>1,this._charCountLimit),d.copyIn=d.copyIn+Date.now()-r,r=Date.now();var o=n.llparser_parse(this._llp,this._stateIdMap[e]);if(d.parse=d.parse+Date.now()-r,r=Date.now(),o)throw new Error("Parsing failed at character position "+(o-1)+' near "'+t.slice(o-20,o)+'"');var i=p(this,new Int32Array(n.memory.buffer),t,this._ruleCbMap,{pos:this._resultPtr>>2});return d.constructOut=d.constructOut+Date.now()-r,i},c.prototype.destroy=function(){n.llparser_destroy(this._llp)},e.exports=c},function(e,t){e.exports=function(e){function t(n){if(r[n])return r[n].exports;var o=r[n]={i:n,l:!1,exports:{}};return e[n].call(o.exports,o,o.exports,t),o.l=!0,o.exports}var r={};return t.m=e,t.c=r,t.d=function(e,r,n){t.o(e,r)||Object.defineProperty(e,r,{enumerable:!0,get:n})},t.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},t.t=function(e,r){if(1&r&&(e=t(e)),8&r)return e;if(4&r&&"object"==typeof e&&e&&e.__esModule)return e;var n=Object.create(null);if(t.r(n),Object.defineProperty(n,"default",{enumerable:!0,value:e}),2&r&&"string"!=typeof e)for(var o in e)t.d(n,o,function(t){return e[t]}.bind(null,o));return n},t.n=function(e){var r=e&&e.__esModule?function(){return e.default}:function(){return e};return t.d(r,"a",r),r},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p="",t(t.s=0)}([function(e,t,r){"use strict";function n(e,t,r){return m.llparser_create(e,t,r)}function o(e){m.llparser_destroy(e)}function i(e,t){return m.llparser_create_descriptor(e,t)}function a(e){m.llparser_descriptor_set_all(e)}function l(e){m.llparser_descriptor_set_nil(e)}function s(e,t){m.llparser_descriptor_add_char(e,t)}function _(e,t,r){m.llparser_descriptor_add_range(e,t,r)}function c(e){m.llparser_descriptor_revert(e)}function d(e,t,r,n,o,i,a,l,s,_,c,d){return m.llparser_add_rule(e,t,r,n,o,i,a,l,s,_,c,d)}function u(e){m.llparser_prepare(e)}function f(e,t){return m.llparser_parse(e,t)}function p(e){return m.llparser_get_input_buffer(e)}function h(e){return m.llparser_get_result(e)}function v(){m.wasm_main()}r.r(t),r.d(t,"llparser_create",function(){return n}),r.d(t,"llparser_destroy",function(){return o}),r.d(t,"llparser_create_descriptor",function(){return i}),r.d(t,"llparser_descriptor_set_all",function(){return a}),r.d(t,"llparser_descriptor_set_nil",function(){return l}),r.d(t,"llparser_descriptor_add_char",function(){return s}),r.d(t,"llparser_descriptor_add_range",function(){return _}),r.d(t,"llparser_descriptor_revert",function(){return c}),r.d(t,"llparser_add_rule",function(){return d}),r.d(t,"llparser_prepare",function(){return u}),r.d(t,"llparser_parse",function(){return f}),r.d(t,"llparser_get_input_buffer",function(){return p}),r.d(t,"llparser_get_result",function(){return h}),r.d(t,"wasm_main",function(){return v}),r.d(t,"memory",function(){return b});var m=r(1),b=m.memory;m.__wbindgen_start()},function(e,t,r){"use strict";r.r(t),r.d(t,"memory",function(){return i}),r.d(t,"rust_calloc",function(){return a}),r.d(t,"rust_free",function(){return l}),r.d(t,"llparser_create",function(){return s}),r.d(t,"llparser_destroy",function(){return _}),r.d(t,"llparser_create_descriptor",function(){return c}),r.d(t,"llparser_descriptor_set_all",function(){return d}),r.d(t,"llparser_descriptor_set_nil",function(){return u}),r.d(t,"llparser_descriptor_add_char",function(){return f}),r.d(t,"llparser_descriptor_add_range",function(){return p}),r.d(t,"llparser_descriptor_revert",function(){return h}),r.d(t,"llparser_add_rule",function(){return v}),r.d(t,"llparser_prepare",function(){return m}),r.d(t,"llparser_parse",function(){return b}),r.d(t,"llparser_get_input_buffer",function(){return g}),r.d(t,"llparser_get_result",function(){return y}),r.d(t,"wasm_main",function(){return w}),r.d(t,"__wbindgen_start",function(){return x});var n=new ArrayBuffer(1114112),o=function(e,t,r){function n(e){var t=0,r=0,n=0,o=0,i=0,a=0,_=0;r=(t=e+-8|0)+(e=-8&(o=m[e+-4>>2]))|0;e:{t:{r:{n:{o:if(!(1&o)){if(!(3&o))break n;if(e=(o=m[t>>2])+e|0,(0|(t=t-o|0))==m[262246]){if(3!=(3&m[r+4>>2]))break o;return m[262244]=e,m[r+4>>2]=-2&m[r+4>>2],m[t+4>>2]=1|e,void(m[e+t>>2]=e)}o>>>0>=256?s(t):(0|(n=m[t+8>>2]))==(0|(i=m[t+12>>2]))?(a=1048576,_=m[262144]&p(o>>>3),m[a>>2]=_):(m[n+12>>2]=i,m[i+8>>2]=n)}if(2&(o=m[r+4>>2]))m[r+4>>2]=-2&o,m[t+4>>2]=1|e,m[e+t>>2]=e;else{o:{if(m[262247]!=(0|r)){if((0|r)!=m[262246])break o;return m[262246]=t,e=m[262244]+e|0,m[262244]=e,m[t+4>>2]=1|e,void(m[e+t>>2]=e)}if(m[262247]=t,e=m[262245]+e|0,m[262245]=e,m[t+4>>2]=1|e,(0|t)==m[262246]&&(m[262244]=0,m[262246]=0),(r=m[262254])>>>0>=e>>>0)break n;if(!(e=m[262247]))break n;i:if(!((o=m[262245])>>>0<41))for(t=1049e3;;){if((n=m[t>>2])+m[t+4>>2]>>>0>e>>>0&&n>>>0<=e>>>0)break i;if(!(t=m[t+8>>2]))break}if(n=4095,e=m[262252]){for(t=0;t=t+1|0,e=m[e+8>>2];);n=t>>>0>4095?t:4095}if(m[262256]=n,o>>>0<=r>>>0)break n;return void(m[262254]=-1)}if(e=(n=-8&o)+e|0,n>>>0>=256?s(r):(0|(n=m[r+12>>2]))==(0|(r=m[r+8>>2]))?(a=1048576,_=m[262144]&p(o>>>3),m[a>>2]=_):(m[r+12>>2]=n,m[n+8>>2]=r),m[t+4>>2]=1|e,m[e+t>>2]=e,m[262246]==(0|t)){m[262244]=e;break n}}if(e>>>0<256)break r;if(l(t,e),e=m[262256]+-1|0,m[262256]=e,!e){if(e=m[262252])break t;e=4095;break e}}return}return e=1048584+((r=e>>>3)<<3)|0,o=m[262144],r=1<<(31&r),n=m[e+8>>2],o&r||(m[262144]=r|o,n=e),r=n,m[e+8>>2]=t,m[r+12>>2]=t,m[t+12>>2]=e,void(m[t+8>>2]=r)}for(t=0;t=t+1|0,e=m[e+8>>2];);e=t>>>0>4095?t:4095}m[262256]=e}function o(e,t,r,n,o,i,a,l,s,_,c,d){var u;return C=u=C+-64|0,m[u+60>>2]=e,m[u+56>>2]=t,m[u+52>>2]=r,m[u+48>>2]=n,m[u+44>>2]=o,m[u+40>>2]=i,m[u+36>>2]=a,m[u+32>>2]=l,m[u+28>>2]=s,m[u+24>>2]=_,m[u+20>>2]=c,m[u+16>>2]=d,t=m[m[u+60>>2]+28>>2],r=m[u+60>>2],e=m[r>>2],m[r>>2]=e+1,m[u+12>>2]=t+w(e,44),m[m[u+12>>2]>>2]=m[u+52>>2],m[m[u+12>>2]+4>>2]=m[u+48>>2],m[u+48>>2]>0&&(m[m[u+12>>2]+8>>2]=m[u+44>>2]),m[u+48>>2]>1&&(m[m[u+12>>2]+12>>2]=m[u+40>>2]),m[u+48>>2]>2&&(m[m[u+12>>2]+16>>2]=m[u+36>>2]),m[u+48>>2]>3&&(m[m[u+12>>2]+20>>2]=m[u+32>>2]),m[u+48>>2]>4&&(m[m[u+12>>2]+24>>2]=m[u+28>>2]),m[u+48>>2]>5&&(m[m[u+12>>2]+28>>2]=m[u+24>>2]),m[u+48>>2]>6&&(m[m[u+12>>2]+32>>2]=m[u+20>>2]),m[u+48>>2]>7&&(m[m[u+12>>2]+36>>2]=m[u+16>>2]),m[m[u+12>>2]+40>>2]=m[u+56>>2],m[u+48>>2]>0&&function(e,t,r){var n=0;m[28+(n=C-32|0)>>2]=e,m[n+24>>2]=t,m[n+20>>2]=r,m[n+16>>2]=(m[n+20>>2]-m[m[n+28>>2]+24>>2]|0)/140,1==m[m[n+20>>2]+4>>2]&&(t=m[m[n+28>>2]+40>>2],r=m[n+28>>2],e=m[r+8>>2],m[r+8>>2]=e+1,m[n+12>>2]=t+(e<<3),m[m[n+12>>2]>>2]=m[n+24>>2],m[m[n+12>>2]+4>>2]=m[m[n+20>>2]+136>>2],m[m[n+20>>2]+136>>2]=m[n+12>>2])}(m[u+60>>2],m[u+12>>2],m[u+52>>2]),C=u- -64|0,m[u+12>>2]}function i(e,t,r,n,o){var a;if(C=a=C-48|0,m[a+44>>2]=e,m[a+40>>2]=t,m[a+36>>2]=r,m[a+32>>2]=n,m[a+28>>2]=o,m[m[a+40>>2]>>2]!=m[a+36>>2])for(m[m[a+40>>2]>>2]=m[a+36>>2],m[a+24>>2]=m[m[a+40>>2]+136>>2],m[a+20>>2]=1&(0!=m[a+28>>2]^-1^-1);m[a+24>>2];){for(m[a+20>>2]||(m[a+28>>2]=m[a+24>>2]),m[a+16>>2]=m[m[m[a+24>>2]>>2]+8>>2],1==m[m[a+16>>2]+4>>2]&&i(m[a+44>>2],m[a+16>>2],m[a+36>>2],m[a+32>>2],m[a+28>>2]),m[a+12>>2]=0;!(m[a+12>>2]>=128);)b[m[a+12>>2]+(m[a+16>>2]+8|0)|0]&&(y[m[a+28>>2]>>2]>=y[m[a+32>>2]+(m[a+12>>2]<<2)>>2]&&m[m[a+32>>2]+(m[a+12>>2]<<2)>>2]||(m[m[a+32>>2]+(m[a+12>>2]<<2)>>2]=m[m[a+28>>2]>>2])),m[a+12>>2]=m[a+12>>2]+1;m[a+24>>2]=m[m[a+24>>2]+4>>2]}C=a+48|0}function a(e,t,r,n){var o;for(m[44+(o=C-48|0)>>2]=e,m[o+40>>2]=t,m[o+36>>2]=r,m[o+32>>2]=n,m[o+28>>2]=m[m[o+40>>2]+136>>2];m[o+28>>2];){if(m[o+24>>2]=m[m[m[o+28>>2]>>2]+8>>2],m[o+24>>2]==m[o+40>>2])for(m[o+20>>2]=m[m[m[o+28>>2]>>2]+12>>2],m[o+16>>2]=0;!(m[o+16>>2]>=128);){e:{if(1!=m[m[o+20>>2]+4>>2]){if(!b[m[o+16>>2]+(m[o+20>>2]+8|0)|0])break e}else if(m[o+12>>2]=m[m[o+44>>2]+32>>2]+((m[o+20>>2]-m[m[o+44>>2]+24>>2]|0)/140<<9),!m[m[o+12>>2]+(m[o+16>>2]<<2)>>2])break e;y[m[o+28>>2]>>2]>=y[m[o+32>>2]+(m[o+16>>2]<<2)>>2]&&m[m[o+32>>2]+(m[o+16>>2]<<2)>>2]||(m[m[o+32>>2]+(m[o+16>>2]<<2)>>2]=m[m[o+28>>2]>>2])}m[o+16>>2]=m[o+16>>2]+1}m[o+28>>2]=m[m[o+28>>2]+4>>2]}}function l(e,t){var r=0,n=0,o=0,i=0;m[e+16>>2]=0,m[e+20>>2]=0,o=e,r=0,(n=t>>>8)&&(r=31,t>>>0>16777215||(r=62+((t>>>(6-(n=x(n))&31)&1)-(n<<1)|0)|0)),m[o+28>>2]=r,o=1048848+(r<<2)|0;e:{t:{r:{n:{if((i=m[262145])&(n=1<<(31&r))){if(n=m[o>>2],(-8&m[n+4>>2])!=(0|t))break n;r=n;break r}m[262145]=n|i,m[o>>2]=e,m[e+24>>2]=o;break e}for(o=t<<(31==(0|r)?0:25-(r>>>1)&31);;){if(!(r=m[(i=16+((o>>>29&4)+n|0)|0)>>2]))break t;if(o<<=1,n=r,(-8&m[r+4>>2])==(0|t))break}}return t=m[r+8>>2],m[t+12>>2]=e,m[r+8>>2]=e,m[e+24>>2]=0,m[e+12>>2]=r,void(m[e+8>>2]=t)}m[i>>2]=e,m[e+24>>2]=n}m[e+12>>2]=e,m[e+8>>2]=e}function s(e){var t,r=0,n=0,o=0,i=0,a=0,l=0;t=m[e+24>>2];e:{t:{if((0|e)==(0|(r=m[e+12>>2]))){if(o=m[(r=e+20|0)>>2],n=m[(o?20:16)+e>>2])break t;r=0;break e}n=m[e+8>>2],m[n+12>>2]=r,m[r+8>>2]=n;break e}for(o=o?r:e+16|0;i=o,(n=m[(o=(r=n)+20|0)>>2])||(o=r+16|0,n=m[r+16>>2]),n;);m[i>>2]=0}e:if(t){n=1048848+(m[e+28>>2]<<2)|0;t:{if((0|e)==m[n>>2]){if(m[n>>2]=r,r)break t;return a=1048580,l=m[262145]&p(m[e+28>>2]),void(m[a>>2]=l)}if(m[(m[t+16>>2]==(0|e)?16:20)+t>>2]=r,!r)break e}m[r+24>>2]=t,(n=m[e+16>>2])&&(m[r+16>>2]=n,m[n+24>>2]=r),(e=m[e+20>>2])&&(m[r+20>>2]=e,m[e+24>>2]=r)}}function _(e,t){var r,n,o;return C=r=C-32|0,m[r+24>>2]=e,m[r+20>>2]=t,m[r+16>>2]=0,m[r+12>>2]=0,n=r,o=function e(t,r,n,o,i,a,l){var s,_=0,c=0;C=s=C-96|0,m[s+88>>2]=t,m[s+84>>2]=r,m[s+80>>2]=n,m[s+76>>2]=o,m[s+72>>2]=i,m[s+68>>2]=a,m[s+64>>2]=l,m[s+60>>2]=g[m[s+80>>2]+(m[m[s+76>>2]>>2]<<1)>>1],y[s+60>>2]>=128&&(m[s+60>>2]=1);e:if(m[m[s+72>>2]>>2]>(m[s+64>>2]-4|0))m[s+92>>2]=-1;else if(1==m[m[s+84>>2]+4>>2])if(m[s+56>>2]=m[m[s+76>>2]>>2],m[s+52>>2]=m[m[s+72>>2]>>2],m[s+48>>2]=0,m[s+44>>2]=0,m[s+40>>2]=m[m[s+88>>2]+32>>2]+((m[s+84>>2]-m[m[s+88>>2]+24>>2]|0)/140<<9),m[s+36>>2]=0,!m[m[s+40>>2]+(m[s+60>>2]<<2)>>2]|y[s+60>>2]<=0|y[s+60>>2]>=127?!m[s+60>>2]|!m[m[s+40>>2]+508>>2]?m[m[s+40>>2]>>2]&&(m[s+36>>2]=m[m[s+40>>2]>>2]):m[s+36>>2]=m[m[s+40>>2]+508>>2]:m[s+36>>2]=m[m[s+40>>2]+(m[s+60>>2]<<2)>>2],m[s+36>>2]){for(m[s+68>>2]||m[m[s+36>>2]+40>>2]||(m[s+48>>2]=m[m[s+72>>2]>>2],t=m[s+72>>2],m[t>>2]=m[t>>2]+2),m[s+32>>2]=0;m[s+32>>2]<m[m[s+36>>2]+4>>2];){if(m[s+28>>2]=m[s+68>>2],m[s+68>>2]||!m[m[s+36>>2]+40>>2]|m[m[s+36>>2]+40>>2]==(m[s+32>>2]+65536|0)||(m[s+28>>2]=1),_=s,c=e(m[s+88>>2],m[(m[s+36>>2]+8|0)+(m[s+32>>2]<<2)>>2],m[s+80>>2],m[s+76>>2],m[s+72>>2],m[s+28>>2],m[s+64>>2]),m[_+24>>2]=c,m[s+24>>2]<0){m[s+92>>2]=-1;break e}m[s+68>>2]|m[m[s+36>>2]+40>>2]!=(m[s+32>>2]+65536|0)||(m[s+44>>2]=m[s+24>>2]),m[s+32>>2]=m[s+32>>2]+1}for(m[s+68>>2]||(m[m[s+36>>2]+40>>2]?1==m[m[s+36>>2]+40>>2]&&(r=m[s+56>>2],n=m[m[s+88>>2]+48>>2],o=m[s+72>>2],t=m[o>>2],m[o>>2]=t+1,m[n+(t<<2)>>2]=r,m[s+44>>2]=m[m[s+72>>2]>>2],r=m[m[s+76>>2]>>2],n=m[m[s+88>>2]+48>>2],o=m[s+72>>2],t=m[o>>2],m[o>>2]=t+1,m[n+(t<<2)>>2]=r):(m[m[m[s+88>>2]+48>>2]+(m[s+48>>2]<<2)>>2]=0-m[s+36>>2],m[m[m[s+88>>2]+48>>2]+(m[s+48>>2]+1<<2)>>2]=m[m[s+36>>2]+4>>2],m[s+44>>2]=m[s+48>>2]+1));;){if(m[m[s+72>>2]>>2]>(m[s+64>>2]-4|0)){m[s+92>>2]=-1;break e}if(m[s+20>>2]=m[m[s+88>>2]+36>>2]+((m[s+84>>2]-m[m[s+88>>2]+24>>2]|0)/140<<9),m[s+16>>2]=0,m[s+60>>2]=g[m[s+80>>2]+(m[m[s+76>>2]>>2]<<1)>>1],y[s+60>>2]>=128&&(m[s+60>>2]=1),!m[m[s+20>>2]+(m[s+60>>2]<<2)>>2]|y[s+60>>2]<=0|y[s+60>>2]>=127?!m[s+60>>2]|!m[m[s+20>>2]+508>>2]||(m[s+16>>2]=m[m[s+20>>2]+508>>2]):m[s+16>>2]=m[m[s+20>>2]+(m[s+60>>2]<<2)>>2],!m[s+16>>2])break;for(m[s+68>>2]||(m[m[s+16>>2]+40>>2]?65536!=m[m[s+16>>2]+40>>2]&&(m[m[s+72>>2]>>2]=m[s+52>>2]):(m[m[m[s+88>>2]+48>>2]+(m[s+44>>2]<<2)>>2]=(0-m[m[m[s+88>>2]+48>>2]+(m[s+44>>2]<<2)>>2]|0)-1,m[s+48>>2]=m[m[s+72>>2]>>2],t=m[s+72>>2],m[t>>2]=m[t>>2]+2)),m[s+12>>2]=1;m[s+12>>2]<m[m[s+16>>2]+4>>2];){if(m[s+8>>2]=m[s+68>>2],m[s+68>>2]||!m[m[s+16>>2]+40>>2]|m[m[s+16>>2]+40>>2]==(m[s+12>>2]+65536|0)||(m[s+8>>2]=1),_=s,c=e(m[s+88>>2],m[(m[s+16>>2]+8|0)+(m[s+12>>2]<<2)>>2],m[s+80>>2],m[s+76>>2],m[s+72>>2],m[s+8>>2],m[s+64>>2]),m[_+4>>2]=c,m[s+4>>2]<0){m[s+92>>2]=-1;break e}m[s+68>>2]|m[m[s+16>>2]+40>>2]!=(m[s+12>>2]+65536|0)||(m[s+44>>2]=m[s+4>>2]),m[s+12>>2]=m[s+12>>2]+1}m[s+68>>2]||(m[m[s+16>>2]+40>>2]?1==m[m[s+16>>2]+40>>2]&&(r=m[s+56>>2],n=m[m[s+88>>2]+48>>2],o=m[s+72>>2],t=m[o>>2],m[o>>2]=t+1,m[n+(t<<2)>>2]=r,m[s+44>>2]=m[m[s+72>>2]>>2],r=m[m[s+76>>2]>>2],n=m[m[s+88>>2]+48>>2],o=m[s+72>>2],t=m[o>>2],m[o>>2]=t+1,m[n+(t<<2)>>2]=r):(m[m[m[s+88>>2]+48>>2]+(m[s+48>>2]<<2)>>2]=0-m[s+16>>2],m[m[m[s+88>>2]+48>>2]+(m[s+48>>2]+1<<2)>>2]=m[m[s+16>>2]+4>>2],m[s+44>>2]=m[s+48>>2]+1))}m[s+92>>2]=m[s+44>>2]}else m[s+92>>2]=-1;else{if(m[s+60>>2]&&(-1==m[m[s+84>>2]+4>>2]&&(t=m[s+76>>2],m[t>>2]=m[t>>2]+1),!m[m[s+84>>2]+4>>2])){if(!b[m[s+60>>2]+(m[s+84>>2]+8|0)|0]){m[s+92>>2]=-1;break e}t=m[s+76>>2],m[t>>2]=m[t>>2]+1}m[s+68>>2]||(r=m[m[s+76>>2]>>2],n=m[m[s+84>>2]+4>>2],o=m[m[s+88>>2]+48>>2],i=m[s+72>>2],t=m[i>>2],m[i>>2]=t+1,m[o+(t<<2)>>2]=r-(-2==(0|n)?0:1),r=m[m[s+76>>2]>>2],n=m[m[s+88>>2]+48>>2],o=m[s+72>>2],t=m[o>>2],m[o>>2]=t+1,m[n+(t<<2)>>2]=r),m[s+92>>2]=m[m[s+72>>2]>>2]-1}return C=s+96|0,m[s+92>>2]}(m[r+24>>2],m[r+20>>2],m[m[r+24>>2]+44>>2],r+12|0,r+16|0,0,m[m[r+24>>2]+12>>2]<<1),m[n+8>>2]=o,e=m[m[r+24>>2]+48>>2],t=m[r+16>>2],m[r+16>>2]=t+1,m[e+(t<<2)>>2]=-1,e=m[m[r+24>>2]+48>>2],t=m[r+16>>2],m[r+16>>2]=t+1,m[e+(t<<2)>>2]=0,g[m[m[r+24>>2]+44>>2]+(m[r+12>>2]<<1)>>1]|m[r+8>>2]<0?m[r+28>>2]=m[r+12>>2]+1:m[r+28>>2]=0,C=r+32|0,m[r+28>>2]}function c(e){var t;return!(t=function(e){var t=0,r=0,n=0,o=0,i=0,a=0,_=0,c=0,d=0,u=0,v=0;e:{t:{r:{if(e>>>0>=245){if(e>>>0>=4294901709)break t;if(o=-8&(e=e+11|0),!(c=m[262145]))break r;r=0-o|0,_=0,(e>>>=8)&&(_=31,o>>>0>16777215||(_=62+((o>>>(6-(e=x(e))&31)&1)-(e<<1)|0)|0));n:{o:{if(e=m[1048848+(_<<2)>>2]){for(i=o<<(31==(0|_)?0:25-(_>>>1)&31);;){if(!((a=-8&m[e+4>>2])>>>0<o>>>0||(a=a-o|0)>>>0>=r>>>0||(n=e,r=a))){r=0;break o}if(a=m[e+20>>2],e=m[16+((i>>>29&4)+e|0)>>2],t=a&&(0|a)!=(0|e)?a:t,i<<=1,!e)break}if(t){e=t;break o}if(n)break n}if(n=0,!(e=(0-(e=2<<(31&_))|e)&c))break r;if(!(e=m[1048848+(f(e&0-e)<<2)>>2]))break r}for(;n=(a=(i=(t=-8&m[e+4>>2])-o|0)>>>0<r>>>0&t>>>0>=o>>>0)?e:n,r=a?i:r,e=(t=m[e+16>>2])||m[e+20>>2];);if(!n)break r}if(r>>>0>=(e=m[262244])-o>>>0&&e>>>0>=o>>>0)break r;s(n);n:if(r>>>0>=16){if(m[n+4>>2]=3|o,m[4+(t=n+o|0)>>2]=1|r,m[t+r>>2]=r,r>>>0>=256){l(t,r);break n}e=1048584+((r>>>=3)<<3)|0,i=m[262144],r=1<<(31&r),_=m[e+8>>2],i&r||(m[262144]=r|i,_=e),r=_,m[e+8>>2]=t,m[r+12>>2]=t,m[t+12>>2]=e,m[t+8>>2]=r}else e=r+o|0,m[n+4>>2]=3|e,m[4+(e=e+n|0)>>2]=1|m[e+4>>2];return n+8|0}n:{o:{if(!(3&(e=(t=m[262144])>>>(n=31&(r=(o=e>>>0<11?16:e+11&-8)>>>3))))){if(o>>>0<=y[262244])break r;if(e)break o;if(!(e=m[262145]))break r;for(t=m[1048848+(f(e&0-e)<<2)>>2],r=(-8&m[t+4>>2])-o|0,i=t;;){if(!(e=m[t+16>>2])&&!(e=m[t+20>>2]))break n;r=(t=(n=(-8&m[e+4>>2])-o|0)>>>0<r>>>0)?n:r,i=t?e:i,t=e}}r=(e=m[1048592+(a=(n=r+(1&(-1^e))|0)<<3)>>2])+8|0,(0|(i=m[e+8>>2]))==(0|(a=a+1048584|0))?(u=1048576,v=p(n)&t,m[u>>2]=v):(m[i+12>>2]=a,m[a+8>>2]=i),t=n<<3,m[e+4>>2]=3|t,m[4+(e=e+t|0)>>2]=1|m[e+4>>2];break t}return n=f(0-(e=(r=e<<n)&(0-(e=2<<n)|e))&e),e=m[1048592+(i=n<<3)>>2],(0|(r=m[e+8>>2]))==(0|(i=i+1048584|0))?(u=1048576,v=p(n)&t,m[u>>2]=v):(m[r+12>>2]=i,m[i+8>>2]=r),i=e+8|0,m[e+4>>2]=3|o,r=(t=n<<3)-o|0,m[4+(a=e+o|0)>>2]=1|r,m[e+t>>2]=r,(e=m[262244])&&(e=1048584+((n=e>>>3)<<3)|0,t=m[262246],o=m[262144],n=1<<(31&n),_=m[e+8>>2],o&n||(m[262144]=n|o,_=e),n=_,m[e+8>>2]=t,m[n+12>>2]=t,m[t+12>>2]=e,m[t+8>>2]=n),m[262246]=a,m[262244]=r,i}return s(i),r>>>0>=16?(m[i+4>>2]=3|o,m[4+(a=o+i|0)>>2]=1|r,m[r+a>>2]=r,(e=m[262244])&&(e=1048584+((n=e>>>3)<<3)|0,t=m[262246],o=m[262144],n=1<<(31&n),_=m[e+8>>2],o&n||(m[262144]=n|o,_=e),n=_,m[e+8>>2]=t,m[n+12>>2]=t,m[t+12>>2]=e,m[t+8>>2]=n),m[262246]=a,m[262244]=r):(e=r+o|0,m[i+4>>2]=3|e,m[4+(e=e+i|0)>>2]=1|m[e+4>>2]),i+8|0}r:{n:{o:{i:{if((t=m[262244])>>>0<o>>>0){if((e=m[262245])>>>0>o>>>0)break e;if(r=0,-1==(0|(t=h((e=o+65583|0)>>>16))))break t;if(!(n=t<<16))break t;if(e=(i=-65536&e)+m[262248]|0,m[262248]=e,t=m[262249],m[262249]=t>>>0>e>>>0?t:e,!(r=m[262247]))break i;for(e=1049e3;;){if((0|n)==((t=m[e>>2])+(a=m[e+4>>2])|0))break o;if(!(e=m[e+8>>2]))break}break n}return e=m[262246],(n=t-o|0)>>>0<=15?(m[262246]=0,m[262244]=0,m[e+4>>2]=3|t,o=4+(t=e+t|0)|0,r=1|m[t+4>>2]):(m[262244]=n,r=e+o|0,m[262246]=r,m[r+4>>2]=1|n,m[e+t>>2]=n,r=3|o,o=e+4|0),m[o>>2]=r,e+8|0}for((e=m[262255])>>>0<=n>>>0&&e||(m[262255]=n),e=0,m[262256]=4095,m[262251]=i,m[262250]=n,m[262253]=0;t=e+1048584|0,m[e+1048592>>2]=t,m[e+1048596>>2]=t,256!=(0|(e=e+8|0)););m[262247]=n,e=i+-40|0,m[262245]=e,m[n+4>>2]=1|e,m[4+(e+n|0)>>2]=40,m[262254]=2097152;break r}if(!(m[e+12>>2]|n>>>0<=r>>>0|t>>>0>r>>>0)){m[e+4>>2]=i+a,t=(e=m[262247])+15&-8,m[262247]=t+-8,r=8+((n=i+m[262245]|0)+(e-t|0)|0)|0,m[262245]=r,m[t+-4>>2]=1|r,m[4+(e+n|0)>>2]=40,m[262254]=2097152;break r}}e=m[262255],m[262255]=e>>>0<n>>>0?e:n,t=n+i|0,e=1049e3;n:{for(;;){if((0|t)!=m[e>>2]){if(e=m[e+8>>2])continue;break n}break}if(!m[e+12>>2]){m[e>>2]=n,m[e+4>>2]=i+m[e+4>>2],m[n+4>>2]=3|o,i=n+o|0,o=(t-n|0)-o|0;o:{i:{if((0|t)!=m[262247]){if(m[262246]==(0|t))break i;if(1==(3&(e=m[t+4>>2]))&&((r=-8&e)>>>0>=256?s(t):(0|(a=m[t+12>>2]))==(0|(_=m[t+8>>2]))?(u=1048576,v=m[262144]&p(e>>>3),m[u>>2]=v):(m[_+12>>2]=a,m[a+8>>2]=_),o=r+o|0,t=t+r|0),m[t+4>>2]=-2&m[t+4>>2],m[i+4>>2]=1|o,m[o+i>>2]=o,o>>>0>=256){l(i,o);break o}e=1048584+((t=o>>>3)<<3)|0,r=m[262144],t=1<<(31&t),_=m[e+8>>2],r&t||(m[262144]=t|r,_=e),r=_,m[e+8>>2]=i,m[r+12>>2]=i,m[i+12>>2]=e,m[i+8>>2]=r;break o}m[262247]=i,e=m[262245]+o|0,m[262245]=e,m[i+4>>2]=1|e;break o}m[262246]=i,e=m[262244]+o|0,m[262244]=e,m[i+4>>2]=1|e,m[e+i>>2]=e}return n+8|0}}for(e=1049e3;!((t=m[e>>2])>>>0<=r>>>0&&(a=t+m[e+4>>2]|0)>>>0>r>>>0);)e=m[e+8>>2];for(m[262247]=n,e=i+-40|0,m[262245]=e,m[n+4>>2]=1|e,m[4+(e+n|0)>>2]=40,m[262254]=2097152,m[(t=(e=(a+-32&-8)-8|0)>>>0<r+16>>>0?r:e)+4>>2]=27,e=m[262250],_=m[262251],d=m[262253],m[(c=t+16|0)>>2]=m[262252],m[c+4>>2]=d,m[t+8>>2]=e,m[t+12>>2]=_,m[262251]=i,m[262250]=n,m[262252]=t+8,m[262253]=0,e=t+28|0;m[e>>2]=7,a>>>0>(e=e+4|0)>>>0;);(0|t)!=(0|r)&&(m[t+4>>2]=-2&m[t+4>>2],e=t-r|0,m[r+4>>2]=1|e,m[t>>2]=e,e>>>0>=256?l(r,e):(e=1048584+((t=e>>>3)<<3)|0,n=m[262144],t=1<<(31&t),_=m[e+8>>2],n&t||(m[262144]=t|n,_=e),t=_,m[e+8>>2]=r,m[t+12>>2]=r,m[r+12>>2]=e,m[r+8>>2]=t))}if(r=0,!((e=m[262245])>>>0<=o>>>0))break e}return r}return t=e-o|0,m[262245]=t,n=(e=m[262247])+o|0,m[262247]=n,m[n+4>>2]=1|t,m[e+4>>2]=3|o,e+8|0}(e))|!(3&b[t+-4|0])||function(e,t){if(t)for(;v[0|e]=0,e=e+1|0,t=t+-1|0;);}(t,e),t}function d(e,t){return 0|c(w(e|=0,t|=0))}function u(){}function f(e){return e?31-x(e+-1^e)|0:32}function p(e){var t;return(-1>>>(t=31&e)&-2)<<t|(-1<<(e=0-e&31)&-2)>>>e}function h(t){t|=0;var n=0|r.byteLength/65536,o=n+t|0;if(n<o&&o<65536){var i=new ArrayBuffer(w(o,65536)),a=new e.Int8Array(i);a.set(v),v=a,v=new e.Int8Array(i),new e.Int16Array(i),m=new e.Int32Array(i),b=new e.Uint8Array(i),g=new e.Uint16Array(i),y=new e.Uint32Array(i),new e.Float32Array(i),new e.Float64Array(i),r=i}return n}var v=new e.Int8Array(r),m=(new e.Int16Array(r),new e.Int32Array(r)),b=new e.Uint8Array(r),g=new e.Uint16Array(r),y=new e.Uint32Array(r),w=(new e.Float32Array(r),new e.Float64Array(r),e.Math.imul),x=(e.Math.fround,e.Math.abs,e.Math.clz32),C=(e.Math.min,e.Math.max,e.Math.floor,e.Math.ceil,e.Math.sqrt,t.abort,e.NaN,e.Infinity,1048576);return{memory:Object.create(Object.prototype,{grow:{value:h},buffer:{get:function(){return r}}}),rust_calloc:d,rust_free:function(e){n(e|=0)},llparser_create:function(e,t,r){return 0|function(e,t,r){var n,o,i;return C=n=C-32|0,m[n+28>>2]=e,m[n+24>>2]=t,m[n+20>>2]=r,e=n,t=m[n+28>>2]?m[n+28>>2]:256,m[e+28>>2]=t,e=n,t=m[n+24>>2]?m[n+24>>2]:256,m[e+24>>2]=t,e=n,t=m[n+20>>2]?m[n+20>>2]:256,m[e+20>>2]=t,o=n,i=d(((((((w(m[n+24>>2],140)+52|0)+w(m[n+20>>2],44)|0)+(m[n+24>>2]<<9)|0)+(m[n+24>>2]<<9)|0)+w(m[n+20>>2],m[n+24>>2]<<3)|0)+(m[n+28>>2]<<1)|0)+(m[n+28>>2]<<3)|0,1),m[o+16>>2]=i,m[m[n+16>>2]+12>>2]=m[n+28>>2],m[m[n+16>>2]+16>>2]=m[n+24>>2],m[m[n+16>>2]+20>>2]=m[n+20>>2],m[m[n+16>>2]+4>>2]=0,m[m[n+16>>2]>>2]=0,m[m[n+16>>2]+8>>2]=0,m[n+12>>2]=m[n+16>>2]+52,m[m[n+16>>2]+24>>2]=m[n+12>>2],m[n+12>>2]=m[n+12>>2]+w(m[n+24>>2],140),m[m[n+16>>2]+28>>2]=m[n+12>>2],m[n+12>>2]=m[n+12>>2]+w(m[n+20>>2],44),m[m[n+16>>2]+32>>2]=m[n+12>>2],m[n+12>>2]=m[n+12>>2]+(m[n+24>>2]<<9),m[m[n+16>>2]+36>>2]=m[n+12>>2],m[n+12>>2]=m[n+12>>2]+(m[n+24>>2]<<9),m[m[n+16>>2]+40>>2]=m[n+12>>2],m[n+12>>2]=m[n+12>>2]+w(m[n+20>>2],m[n+24>>2]<<3),m[m[n+16>>2]+44>>2]=m[n+12>>2],m[n+12>>2]=m[n+12>>2]+(m[n+28>>2]<<1),m[m[n+16>>2]+48>>2]=m[n+12>>2],C=n+32|0,m[n+16>>2]}(e|=0,t|=0,r|=0)},llparser_destroy:function(e){!function(e){var t;C=t=C-16|0,m[t+12>>2]=e,n(m[t+12>>2]),C=t+16|0}(e|=0)},llparser_create_descriptor:function(e,t){return 0|function(e,t){var r,n;return m[12+(r=C-16|0)>>2]=e,m[r+8>>2]=t,t=m[m[r+12>>2]+24>>2],n=m[r+12>>2],e=m[n+4>>2],m[n+4>>2]=e+1,m[r+4>>2]=t+w(e,140),m[m[r+4>>2]+4>>2]=m[r+8>>2]?1:0,m[r+4>>2]}(e|=0,t|=0)},llparser_descriptor_set_all:function(e){var t;e|=0,m[12+(t=C-16|0)>>2]=e,m[m[t+12>>2]+4>>2]=-1,v[m[t+12>>2]+135|0]=1},llparser_descriptor_set_nil:function(e){var t;e|=0,m[12+(t=C-16|0)>>2]=e,m[m[t+12>>2]+4>>2]=-2,v[m[t+12>>2]+8|0]=1},llparser_descriptor_add_char:function(e,t){!function(e,t){var r;m[12+(r=C-16|0)>>2]=e,m[r+8>>2]=t,v[m[r+8>>2]+(m[r+12>>2]+8|0)|0]=1}(e|=0,t|=0)},llparser_descriptor_add_range:function(e,t,r){!function(e,t,r){var n;for(m[12+(n=C-16|0)>>2]=e,m[n+8>>2]=t,m[n+4>>2]=r,m[n>>2]=m[n+8>>2];!(m[n>>2]>m[n+4>>2]);)v[m[n>>2]+(m[n+12>>2]+8|0)|0]=1,m[n>>2]=m[n>>2]+1}(e|=0,t|=0,r|=0)},llparser_descriptor_revert:function(e){!function(e){var t;for(m[12+(t=C-16|0)>>2]=e,m[t+8>>2]=1;!(m[t+8>>2]>=127);)v[m[t+8>>2]+(m[t+12>>2]+8|0)|0]=1&(0!=b[m[t+8>>2]+(m[t+12>>2]+8|0)|0]^-1),m[t+8>>2]=m[t+8>>2]+1}(e|=0)},llparser_add_rule:function(e,t,r,n,i,a,l,s,_,c,d,u){return 0|o(e|=0,t|=0,r|=0,n|=0,i|=0,a|=0,l|=0,s|=0,_|=0,c|=0,d|=0,u|=0)},llparser_prepare:function(e){!function(e){var t;for(C=t=C-32|0,m[t+28>>2]=e,m[t+24>>2]=0;!(m[t+24>>2]>=m[m[t+28>>2]+4>>2]);)m[t+20>>2]=m[m[t+28>>2]+24>>2]+w(m[t+24>>2],140),1==m[m[t+20>>2]+4>>2]&&i(m[t+28>>2],m[t+20>>2],m[t+20>>2],m[m[t+28>>2]+32>>2]+(m[t+24>>2]<<9)|0,0),m[t+24>>2]=m[t+24>>2]+1;for(m[t+16>>2]=0;!(m[t+16>>2]>=m[m[t+28>>2]+4>>2]);)m[t+12>>2]=m[m[t+28>>2]+24>>2]+w(m[t+16>>2],140),1==m[m[t+12>>2]+4>>2]&&(m[m[t+12>>2]>>2]=0,a(m[t+28>>2],m[t+12>>2],m[t+12>>2],m[m[t+28>>2]+36>>2]+(m[t+16>>2]<<9)|0)),m[t+16>>2]=m[t+16>>2]+1;C=t+32|0}(e|=0)},llparser_parse:function(e,t){return 0|_(e|=0,t|=0)},llparser_get_input_buffer:function(e){var t;return e|=0,m[12+(t=C-16|0)>>2]=e,m[m[t+12>>2]+44>>2]},llparser_get_result:function(e){var t;return e|=0,m[12+(t=C-16|0)>>2]=e,m[m[t+12>>2]+48>>2]},wasm_main:u,__wbindgen_start:u}}({Math:Math,Int8Array:Int8Array,Uint8Array:Uint8Array,Int16Array:Int16Array,Uint16Array:Uint16Array,Int32Array:Int32Array,Uint32Array:Uint32Array,Float32Array:Float32Array,Float64Array:Float64Array,NaN:NaN,Infinity:1/0},{abort:function(){throw new Error("abort")}},n),i=o.memory,a=o.rust_calloc,l=o.rust_free,s=o.llparser_create,_=o.llparser_destroy,c=o.llparser_create_descriptor,d=o.llparser_descriptor_set_all,u=o.llparser_descriptor_set_nil,f=o.llparser_descriptor_add_char,p=o.llparser_descriptor_add_range,h=o.llparser_descriptor_revert,v=o.llparser_add_rule,m=o.llparser_prepare,b=o.llparser_parse,g=o.llparser_get_input_buffer,y=o.llparser_get_result,w=o.wasm_main,x=o.__wbindgen_start}])},function(e,t,r){var n=r(4),o=function(e){this.empty=!0,this._type=e,this._arr=[],this._index=0};o.create=function(e){return new o(e)},o.prototype.add=function(e){var t=this._index++;return this._arr.push({id:t,func:e}),this.empty=!1,t},o.prototype.remove=function(e){var t=this._arr,r=0;if("function"==typeof e)for(r=0;r<t.length;r++){var n=t[r].func;if(n===e)return t.splice(r,1),this.empty=!t.length,n}else for(r=0;r<t.length;r++)if(t[r].id===e){var o=t[r].func;return t.splice(r,1),this.empty=!t.length,o}return null},o.prototype.call=function(e,t,r){for(var n=this._arr,o=!1,i=0;i<n.length;i++){var l=a(this._type,n[i].func,e,t,r);l===!1&&(o=!0)}if(o)return!1};var i=function(e,t){if(!t.type||l.call(null,[e,t])!==!1){if(n.throwGlobalError)throw e;console.error(e.message+"\n"+e.stack)}},a=o.safeCallback=function(e,t,r,n,o){try{return t.apply(r,n)}catch(l){var a="[Exparser] [Error] [Component] "+(e||"Error Listener")+" Error @ ";r&&r.is&&(a+=r.is),a+="#"+(t.name||"(anonymous)"),o&&o.triggerLifeTime("error",[l]),i(l,{message:a,type:e,element:r,method:t,args:n})}},l=o.create();o.addGlobalErrorListener=function(e){return l.add(e)},o.removeGlobalErrorListener=function(e){return l.remove(e)};var s=null;o.addGlobalWarningListener=function(e){return s=o.create(),s.add(e)},o.removeGlobalWarningListener=function(e){if(s){var t=s.remove(e);return s.empty&&(s=null),t}return null},o.hasGlobalWarningListeners=function(){return!!s},o.triggerWarning=function(e){var t="[Exparser] [Warning] [Component] "+e;s.call(null,[t],null)},e.exports=o},function(e,t){var r={lazyRegistration:!0,publicProperties:!1,availability:null,domain:"",writeOnly:!1,allowInWriteOnly:!1,classPrefix:null,styleScope:"",addGlobalClass:!1,templateEngine:null,renderingMode:"full",multipleSlots:!1,reflectToAttributes:!1,writeFieldsToNode:!0,writeIdToDOM:!1,separateInnerData:!0,innerDataExclude:null,listenerChangeLifeTimes:!1,randomizeTagName:!1,virtualHost:!1,throwGlobalError:!1,writeExtraInfoToAttr:!1,documentBackend:"undefined"!=typeof window&&"undefined"!=typeof document?"dom":"none",hasDOMBackend:!("undefined"==typeof window||"undefined"==typeof document),customContext:null};e.exports=r},function(e,t){var r=Object.prototype.hasOwnProperty,n=function(e,t){var o=typeof e;if("object"===o&&null!==e){var i=t?t.get(e):void 0;if(void 0!==i)return i;if(e instanceof Array){i=[],t&&t.set(e,i);for(var a=0;a<e.length;a++)i[a]=n(e[a],t)}else{i={},t&&t.set(e,i);for(var l in e)r.call(e,l)&&(i[l]=n(e[l],t))}return i}if("symbol"!==o)return e};t.deepCopy=function(e,t){var r=t&&"undefined"!=typeof WeakMap?new WeakMap:null;return n(e,r)}},function(e,t,r){var n=r(3),o=(Object.prototype.hasOwnProperty,function(){});o.prototype=Object.create(Object.prototype,{constructor:{value:o,writable:!0,configurable:!0}});var i=null;o._setElementSystem=function(e){i=e,o._setElementSystem=null};var a=null;o._setComponent=function(e){a=e,o._setComponent=null};var l=Date.now();o.setInitTimeStamp=function(e){return l=void 0===e?Date.now():e},o.getInitTimeStamp=function(e){return l},o.create=function(e,t,r){r=r||{};var n=r.originalEvent,i=r.extraFields||{},a=Date.now()-l,s=new o;s.currentTarget=null,s.type=e,s.timeStamp=a,s.mark=null,s.detail=t,s.bubbles=!!r.bubbles,s.composed=!!r.composed,s.__originalEvent=n,s.__hasCapture=!!r.capturePhase,s.__stopped=!1,s.__dispatched=!1;for(var _ in i)s[_]=i[_];return s},o.prototype.preventDefault=function(){this.__originalEvent&&this.__originalEvent.preventDefault();
},o.prototype.stopPropagation=function(){this.__stopped=!0},o.prototype.isStopped=function(){return!!this.__stopped};o.prototype.markMutated=function(){this.__mutatedMarked=!0},o.prototype.mutatedMarked=function(){return!!this.__mutatedMarked};var s=function(e,t,r,n){for(var o=e,a=e instanceof i?e.collectMarks():{},l=[],s=[],_=e;_;){if(o!==_&&(l.push(e),e=_,s.push(a),a=e instanceof i?e.collectMarks():{}),o=_.parentNode,n(_,e,a)===!1)return;if(_.__wxHost){if(r)break;e=l.pop()||_.__wxHost,a=s.pop()||(e instanceof i?e.collectMarks():{}),_=_.__wxHost,o=_}else{var c=!0;_ instanceof i&&(c=!1),_=c||r?_.parentNode:_.__wxSlotParent}}};o.dispatchEvent=function(e,t){if(!t.__dispatched){t.__dispatched=!0,e.__wxElement&&e.__wxHost!==e.__wxElement&&(e=e.__wxElement,e.shadowRoot instanceof i&&(e=e.shadowRoot)),t.target=e instanceof i?e.__methodCaller:e;var r=function(e,r,n){if(!(r&&r.length&&t.mutatedMarked())){var o=t.currentTarget=n instanceof i?n.__methodCaller:n,l=e.call(o,[t],n instanceof a?n:void 0);r&&r.length&&t.markMutated(),l===!1&&(t.__originalEvent&&t.__originalEvent.preventDefault(),t.__stopped=!0)}},n=t.type,o=!t.composed;if(t.__hasCapture){var l=[];s(e,n,o,function(e,t,r){return e.__wxCaptureEvents&&e.__wxCaptureEvents[n]&&l.push([e,t,r]),!0});for(var _=l.length-1;_>=0;_--){var c=l[_],d=c[0],u=c[1];t.target=u instanceof i?u.__methodCaller:u,t.mark=c[2];var f=d.__wxCaptureMutated&&d.__wxCaptureMutated[n];if(r(d.__wxCaptureEvents[n],f,d),t.__stopped)break}}if(t.target=e instanceof i?e.__methodCaller:e,!t.__stopped){var p=!t.bubbles;s(e,n,o,function(e,o,a){t.target=o instanceof i?o.__methodCaller:o,t.mark=a;var l=e.__wxMutated&&e.__wxMutated[n];return e.__wxEvents&&e.__wxEvents[n]&&r(e.__wxEvents[n],l,e),!p&&!t.__stopped})}}},o.triggerEvent=function(e,t,r,n){var i=o.create(t,r,n);o.dispatchEvent(e,i)},o.addListenerToElement=function(e,t,r,o){var i=o&&o.mutated;if(i){var l=r;r=function(e){if(!e.mutatedMarked()){var t=Array.prototype.slice.call(arguments);return l.apply(this,t)}}}var s=void 0;return o&&(o.useCapture||o.capture)?(e.__wxCaptureEvents||(e.__wxCaptureEvents=Object.create(null)),e.__wxCaptureEvents[t]||(e.__wxCaptureEvents[t]=n.create("Event Listener")),s=e.__wxCaptureEvents[t].add(r),i&&(e.__wxCaptureMutated||(e.__wxCaptureMutated=Object.create(null)),e.__wxCaptureMutated[t]||(e.__wxCaptureMutated[t]=[]),e.__wxCaptureMutated[t].push(s))):(e.__wxEvents||(e.__wxEvents=Object.create(null)),e.__wxEvents[t]||(e.__wxEvents[t]=n.create("Event Listener")),s=e.__wxEvents[t].add(r),i&&(e.__wxMutated||(e.__wxMutated=Object.create(null)),e.__wxMutated[t]||(e.__wxMutated[t]=[]),e.__wxMutated[t].push(s))),e instanceof a&&e.__componentOptions.listenerChangeLifeTimes&&e.triggerLifeTime("listenerChanged",[!0,t,r,o]),s},o.removeListenerFromElement=function(e,t,r,n){var o=null;if(n&&(n.useCapture||n.capture)){if(e.__wxCaptureEvents&&e.__wxCaptureEvents[t]&&(o=e.__wxCaptureEvents[t].remove(r)),e.__wxCaptureMutated&&e.__wxCaptureMutated[t]){var i=e.__wxCaptureMutated[t].indexOf(r);i!==-1&&e.__wxCaptureMutated[t].splice(i,1)}}else if(e.__wxEvents&&e.__wxEvents[t]&&(o=e.__wxEvents[t].remove(r)),e.__wxMutated&&e.__wxMutated[t]){var i=e.__wxMutated[t].indexOf(r);i!==-1&&e.__wxMutated[t].splice(i,1)}o&&e instanceof a&&e.__componentOptions.listenerChangeLifeTimes&&e.triggerLifeTime("listenerChanged",[!1,t,o,n])},e.exports=o},function(e,t,r){var n=r(1),o=" \n\r\t\f",i=null,a=function(){i=n.create({MULTIPLE_PATHS:[{id:"arrayConcat",states:["MULTIPLE_PATHS",",","SINGLE_PATH"]},{id:"array",states:["SINGLE_PATH"]}],SINGLE_PATH:[{id:"arrayConcat",states:["SINGLE_PATH",".","VAR_NAME"]},{id:"arrayConcat",states:["SINGLE_PATH","[","INT","]"]},{id:"array",states:["VAR_NAME"]},{id:"_jump",states:["SINGLE_PATH",o]}],VAR_NAME:[{id:"_blank",states:[o,"VAR_NAME"]},{id:"_jump",states:["VAR_NAME",o]},{id:"_raw",states:["*","*"]},{id:"_raw",states:["_a-zA-Z$","VAR_NAME_AFTER"]}],VAR_NAME_AFTER:[{id:"_raw",states:["_a-zA-Z0-9$","VAR_NAME_AFTER"]},{id:"_raw",states:["NULL"]}],INT:[{id:"_blank",states:[o,"INT"]},{id:"_jump",states:["INT",o]},{id:"toNumber",states:["0-9","INT_AFTER"]}],INT_AFTER:[{id:"_raw",states:["0-9","INT_AFTER"]},{id:"_raw",states:["NULL"]}]},{arrayConcat:function(e){return e[0].push(e[2]),e[0]},array:function(e){return e},toNumber:function(e){return parseInt(e[0]+e[1],10)}})};t.parseMultiPaths=function(e){return i||a(),i.parse("MULTIPLE_PATHS",e)},t.parseSinglePath=function(e){for(var t=e.length,r=[],n="",o=0,i=!1,a=!1,l=0;l<t;l++){var s=e[l];if("\\"===s)l+1<t&&("."===e[l+1]||"["===e[l+1]||"]"===e[l+1]||"\\"===e[l+1])?(n+=e[l+1],l++):n+="\\";else if("."===s)n&&(r.push(n),n="");else if("["===s){if(n&&(r.push(n),n=""),0===r.length)throw new Error("The path string should not start with []: "+e);a=!0,i=!1}else if("]"===s){if(!i)throw new Error("There should be digits inside [] in the path string: "+e);a=!1,r.push(o),o=0}else if(a){if(s<"0"||s>"9")throw new Error("Only digits (0-9) can be put inside [] in the path string: "+e);i=!0,o=10*o+s.charCodeAt(0)-48}else n+=s}if(n&&r.push(n),0===t)throw new Error("The path string should not be empty");return r}},function(e,t,r){var n=r(3),o=r(4),i=r(7),a=["created","ready","cacheAttached","attached","moved","detached","route","saved","restored","error","listenerChanged","performanceData"],l=[String,Number,Boolean,Object,Array,null],s=function(){},_=i.parseMultiPaths,c=function(){};c.matchTypeWithValue=function(e,t){if(e===String){if("string"!=typeof t)return!1}else if(e===Number){if(!Number.isFinite(t))return!1}else if(e===Boolean){if("boolean"!=typeof t)return!1}else if(e===Object){if(null===t||t.constructor!==Object)return!1}else if(e===Array){if(null===t||t.constructor!==Array)return!1}else if(void 0===t)return!1;return!0};var d=function(e){for(var t=[],r=0;r<e.length;r++)t[r]=e[r];return t},u=function(e){var t={};for(var r in e)t[r]=e[r];return t},f=function(e,t){for(var r in t)hasOwnProperty.call(e,r)?(n.hasGlobalWarningListeners()&&"_"===r.charAt(0)&&n.triggerWarning('data field "'+r+'" from different behaviors is overriding or merging.'),"object"!=typeof e[r]||"object"!=typeof t[r]||null===t[r]||t[r]instanceof Array?e[r]=t[r]:(e[r]instanceof Array?e[r]=d(e[r]):e[r]=u(e[r]),f(e[r],t[r]))):e[r]=t[r]};c.create=function(e){var t=new c;return t.is=e.is||"",t.using=e.using||{},t.generics=e.generics||{},t.placeholder=e.placeholder||{},t.template=e.template,t.externalClasses=e.externalClasses||[],t.data="object"==typeof e.data?{}:null,t.properties=Object.create(null),t.methods=Object.create(null),t.listeners=Object.create(null),t.relations=Object.create(null),t.ancestors=[],t.initiator=e.initiator,t.lifetimes=Object.create(null),t.pageLifetimes=Object.create(null),t.observers=[],t.options={publicProperties:!!(e.options&&void 0!==e.options.publicProperties?e.options.publicProperties:o.publicProperties)},t.definitionFilter=e.definitionFilter,t._unprepared=e,(e.options&&void 0!==e.options.lazyRegistration?e.options.lazyRegistration:o.lazyRegistration)||c.prepare(t),e.is&&(c._list[e.is]=t),t},c.prepare=function(e){var t=e._unprepared;if(t){e._unprepared=null;var r=e.ancestors,o="",i=0;for(i=0;i<(t.behaviors||[]).length;i++){var d=t.behaviors[i],u=d;"string"==typeof u&&(u=c._list[d],n.hasGlobalWarningListeners()&&(u instanceof c||n.triggerWarning('behavior "'+d+'" is not found (when preparing behavior "'+e.is+'").'))),u._unprepared&&c.prepare(u),"object"==typeof u.data&&(null===e.data?e.data=u.data:f(e.data,u.data));for(o in u.generics){var p=u.generics[o];"object"!=typeof p&&(p={}),e.generics[o]={default:p.default}}for(o in u.properties)n.hasGlobalWarningListeners()&&"_"===o.charAt(0)&&void 0!==e.properties[o]&&n.triggerWarning('property "'+o+'" from different behaviors is overriding (when preparing behavior "'+e.is+'").'),e.properties[o]=u.properties[o];for(o in u.relations)e.relations[o]=u.relations[o];for(o in u.methods)n.hasGlobalWarningListeners()&&"_"===o.charAt(0)&&e.methods[o]&&n.triggerWarning('method "'+o+'" from different behaviors is overriding (when preparing behavior "'+e.is+'").'),e.methods[o]=u.methods[o];for(var h=0;h<u.ancestors.length;h++)r.indexOf(u.ancestors[h])<0&&r.push(u.ancestors[h])}"object"==typeof t.data&&(null===e.data?e.data=t.data:f(e.data,t.data));for(o in t.properties){n.hasGlobalWarningListeners()&&"_"===o.charAt(0)&&void 0!==e.properties[o]&&n.triggerWarning('property "'+o+'" from different behaviors is overriding (when preparing behavior "'+e.is+'").');var v=t.properties[o];l.indexOf(v)>=0?v={type:v}:l.indexOf(v.type)<0&&v.optionalTypes&&v.optionalTypes.length>0&&(v.type=v.optionalTypes[0]),n.hasGlobalWarningListeners()&&l.indexOf(v.type)<0&&n.triggerWarning('the type of property "'+o+'" is illegal (when preparing behavior "'+e.is+'").'),void 0===v.value&&(v.type===String?v.value="":v.type===Number?v.value=0:v.type===Boolean?v.value=!1:v.type===Array?v.value=[]:v.value=null),e.properties[o]={type:v.type,optionalTypes:v.optionalTypes,value:v.value,filter:v.filter,observer:v.observer,public:!!(void 0===v.public?e.options.publicProperties:v.public),availability:v.availability,observeAssignments:!!v.observeAssignments}}if(t.lifetimes&&"object"==typeof t.lifetimes)for(o in t.lifetimes)e.lifetimes[o]=t.lifetimes[o];for(i=0;i<a.length;i++)void 0===e.lifetimes[a[i]]&&(e.lifetimes[a[i]]=t[a[i]]);for(o in t.listeners)e.listeners[o]=t.listeners[o];var m=t.observers;if(m instanceof Array)for(i=0;i<m.length;i++){var b=m[i];e.observers.push({paths:_(b.fields||"**"),observer:b.observer})}else for(o in m)e.observers.push({paths:_(o),observer:m[o]});if(t.pageLifetimes&&"object"==typeof t.pageLifetimes)for(o in t.pageLifetimes)e.pageLifetimes[o]=t.pageLifetimes[o];for(o in t.relations){var g=t.relations[o];e.relations[o]={target:g.target||o,type:g.type,linked:g.linked||s,linkChanged:g.linkChanged||s,unlinked:g.unlinked||s,linkFailed:g.linkFailed||s}}for(o in t.methods)"function"==typeof t.methods[o]&&(n.hasGlobalWarningListeners()&&"_"===o.charAt(0)&&e.methods[o]&&n.triggerWarning('method "'+o+'" from different behaviors is overriding (when preparing behavior "'+e.is+'").'),e.methods[o]=t.methods[o]);r.push(e)}},c._list=Object.create(null),c.prototype.hasBehavior=function(e){this._unprepared&&c.prepare(this);for(var t=0;t<this.ancestors.length;t++)if(e instanceof c){if(this.ancestors[t]===e)return!0}else if(this.ancestors[t]===c._list[e])return!0;return!1},c.prototype._getAllListeners=function(){for(var e={},t=this.ancestors,r=0;r<t.length;r++){var n=this.ancestors[r];for(var o in n.listeners)Object.prototype.hasOwnProperty.call(e,o)?e[o].push(n.listeners[o]):e[o]=[n.listeners[o]]}return e},c.prototype._addObserversToDataProxy=function(e){for(var t=this.ancestors,r=0;r<t.length;r++)for(var n=this.ancestors[r].observers,o=0;o<n.length;o++){var i=n[o];e.addObserver(i.observer,i.paths)}},c.prototype._getAllLifeTimeFuncs=function(){var e={},t=this.ancestors;a.forEach(function(t){e[t]=n.create("Lifetime Method")});for(var r=0;r<t.length;r++){var o=t[r];for(var i in o.lifetimes)o.lifetimes[i]&&(e[i]||(e[i]=n.create("Lifetime Method")),e[i].add(o.lifetimes[i]))}return e},c.prototype._getAllPageLifeTimeFuncs=function(){for(var e={},t=this.ancestors,r=0;r<t.length;r++){var o=t[r];for(var i in o.pageLifetimes)o.pageLifetimes[i]&&(e[i]||(e[i]=n.create("Page Lifetime Method")),e[i].add(o.pageLifetimes[i]))}return e},c.callDefinitionFilter=function(e){var t=e.definitionFilter,r=[];return e.behaviors instanceof Array&&e.behaviors.forEach(function(t){t="string"==typeof t?c._list[t]:t,t&&t.definitionFilter&&(r.push(t.definitionFilter),t.definitionFilter.call(null,e))}),"function"==typeof t?function(e){t(e,r)}:null},e.exports=c},function(e,t,r){var n=r(3),o=r(6),i=r(10),a=r(11),l=r(12),s=r(14),_=r(4),c=r(13),d=function(e){u(this,e||null)};d.prototype=Object.create(Object.prototype,{constructor:{value:d,writable:!0,configurable:!0},id:{get:function(){return this.__id},set:function(e){var t=String(e);if(this.__id!==t){if(this.__id=t,this.ownerShadowRoot){var r=this.ownerShadowRoot.__wxHost;r.__idCacheDirty=!0,this.__domElement&&r.__componentOptions.writeIdToDOM&&("dom"===_.documentBackend?this.__domElement.id=t:"custom"===_.documentBackend&&this.__domElement.setId(t))}_.writeExtraInfoToAttr&&this.__domElement&&"dom"===_.documentBackend&&this.__domElement.setAttribute("exparser:info-attr-id",t),(this.__propObservers&&!this.__propObservers.empty||this.__subtreeObserversCount)&&i._callObservers(this,"__propObservers",{type:"properties",target:this,propertyName:"id"})}},configurable:!0},slot:{get:function(){return this.__slot},set:function(e){if(e=String(e),this.__slot!==e){if(this.__inheritSlots)return void(n.hasGlobalWarningListeners()&&n.triggerWarning('slots-inherited nodes do not support "slot" attribute.'));this.__slot=e,w(this),(this.__propObservers&&!this.__propObservers.empty||this.__subtreeObserversCount)&&i._callObservers(this,"__propObservers",{type:"properties",target:this,propertyName:"slot"})}},configurable:!0},attributes:{get:function(){var e=[];if(!this.__attributes)return e;for(var t in this.__attributes)e.push({name:t,value:this.__attributes[t]});return e},set:function(){},configurable:!0},class:{get:function(){return this.classList.getClassNames()},set:function(e){this.classList&&this.classList.setClassNames(e),(this.__propObservers&&!this.__propObservers.empty||this.__subtreeObserversCount)&&i._callObservers(this,"__propObservers",{type:"properties",target:this,propertyName:"class"})},configurable:!0},style:{get:function(){return this.__domElement?this.__domElement.style:null},set:function(e){return M.call(this,e)},configurable:!0}}),o._setElementSystem(d),a._setElementSystem(d);var u=d.initialize=function(e,t,r,n){e.__id="",e.__slot="",e.__virtual=!1,e.__inheritSlots=!1,e.__attributes=null,e.__marks=null,e.__attached=!1,e.parentNode=null,e.childNodes=[],e.ownerShadowRoot=r,e.__wxSlotParent=null,e.__wxSlotChildren=e.childNodes,e.__subtreeObserversCount=0,e.classList=null,e.__styleSegments=[],e.__methodCaller=e,e.__relationHandler=null,e.__backendContext=n,e.__backendExtracted=c.backendExtractedDefault,e.__domElement=t,e.__autoDestroy=!0,e.$$=t,t&&(t.__wxElement=e)};d._clone=function(e,t,r,n){if(e.__id=t.__id,e.__slot=t.__slot,e.__virtual=t.__virtual,e.__inheritSlots=t.__inheritSlots,e.__marks=t.__marks?{}:null,t.__marks)for(var o in t.__marks)e.__marks[o]=t.__marks[o];e.__attributes=Object.create(null);for(var i in t.__attributes)e.__attributes[i]=t.__attributes[i];e.__attached=!1,e.parentNode=null,e.childNodes=[],e.ownerShadowRoot=n,e.__wxSlotParent=null,e.__wxSlotChildren=e.childNodes,e.__subtreeObserversCount=0,e.classList=null,e.__styleSegments=[],e.__methodCaller=e,e.__relationHandler=null,e.__backendContext=t.__backendContext,e.__backendExtracted=c.backendExtractedDefault,e.__domElement=r,e.$$=r,r&&(r.__wxElement=e)},d.prototype.setAutoDestroy=function(e){this.__autoDestroy=!!e},d.prototype.destroy=function(){"custom"===_.documentBackend&&this.__domElement&&(this.__domElement.release(),this.__domElement=null)};var f=function(e){if(!e.parentNode||e.parentNode.__attached){var t=function(e){if(e instanceof d){e.__attached=!0,e.__lifeTimeFuncs&&e.__lifeTimeFuncs.attached.call(e.__methodCaller,[],e),e.__relationHandler&&e.__relationHandler("attached"),e.__attachedObservers&&!e.__attachedObservers.empty&&i._callSingleObserver(e,"__attachedObservers",{type:"attachStatus",target:e,status:"attached"}),e.shadowRoot instanceof d&&t(e.shadowRoot);for(var r=e.childNodes,n=0;n<r.length;n++)t(r[n])}};t(e)}},p=function(e){if(e.__attached){var t=function(e){if(!(e instanceof d))return void(e.__autoDestroy&&e.destroy());for(var r=e.childNodes,n=0;n<r.length;n++)t(r[n]);e.shadowRoot instanceof d&&t(e.shadowRoot),e.__attached=!1,e.__autoDestroy&&e.destroy(),e.__lifeTimeFuncs&&e.__lifeTimeFuncs.detached.call(e.__methodCaller,[],e),e.__relationHandler&&e.__relationHandler("detached"),e.__attachedObservers&&!e.__attachedObservers.empty&&i._callSingleObserver(e,"__attachedObservers",{type:"attachStatus",target:e,status:"detached"})};t(e)}},h=function(e){if(!e.__attached)return f(e);var t=function(e){if(e instanceof d){for(var r=e.childNodes,n=0;n<r.length;n++)t(r[n]);e.shadowRoot instanceof d&&t(e.shadowRoot),e.__lifeTimeFuncs&&e.__lifeTimeFuncs.moved.call(e.__methodCaller,[],e),e.__relationHandler&&e.__relationHandler("moved")}};t(e)},v=function(e,t,r){if(e.__childObservers&&!e.__childObservers.empty||e.__subtreeObserversCount){var n=null,o=[r];n="add"===t?{type:"childList",target:e,addedNodes:o}:"remove"===t?{type:"childList",target:e,removedNodes:o}:{type:"childList",target:e,addedNodes:o,removedNodes:o},i._callObservers(e,"__childObservers",n)}},m=function(e,t){if(e instanceof d&&(!t.__wxHost.__idCacheDirty||!t.__slotCacheDirty)){var r=function(e){e.__id&&(t.__wxHost.__idCacheDirty=!0),void 0!==e.__slotName&&(t.__slotCacheDirty=!0);for(var n=e.childNodes,o=0;o<n.length;o++){var i=n[o];i instanceof d&&r(i)}};r(e)}};d._updateIdMap=function(e){var t=e.shadowRoot;if(e.__idCacheDirty){e.__idCacheDirty=!1;var r=e.__idCache=Object.create(null),n=function(e){e.__id&&(r[e.__id]||(r[e.__id]=e));for(var t=e.childNodes,o=0;o<t.length;o++)t[o]instanceof d&&n(t[o])};n(t)}};var b=function(e){if(e.__hostAssociated&&e.__slotCacheDirty){e.__slotCacheDirty=!1;var t=e.__wxHost,r=null,o=Object.create(null);r=void 0!==t.__singleSlot?{"":t.__singleSlot}:t.__slots;var i=function(e){void 0!==e.__slotName&&(o[e.__slotName]?n.hasGlobalWarningListeners()&&n.triggerWarning('slot "'+e.__slotName+'" duplication is found under a single shadow root. The first one was accepted.'):o[e.__slotName]=e);for(var t=e.childNodes,r=0;r<t.length;r++)t[r]instanceof d&&i(t[r])};i(e),void 0!==t.__singleSlot?t.__singleSlot!==o[""]&&(o[""]&&(o[""].__wxSlotChildren=t.childNodes),g(t,o,r,!0),t.__singleSlot&&(t.__singleSlot.__wxSlotChildren=[]),t.__singleSlot=o[""]||null):(g(t,o,r,!1),t.__slots=o)}},g=function(e,t,r,n){var o=e.childNodes,i=0;if(n){var a=t[""];if(a)for(;i<o.length;i++)S(a,o[i],null,!1,!1,!1,-1);else if(a=r[""])for(;i<o.length;i++)S(a,null,o[i],!0,!1,!1,i)}else{var l=function(e){for(var n=0;n<e.length;n++){var o=e[n],i=o.__slot||"",a=t[i];a?S(a,o,null,!1,!0,!0):(a=r[i],a&&S(a,null,o,!0,!0,!0)),o.__inheritSlots&&l(o.childNodes)}};l(o)}},y=function(e,t,r,n){for(var o=function(e,t,n){var i=e.childNodes,a=0;for(t&&(a=i.indexOf(t)+(n?0:1));a<i.length;a++){var l=i[a];if(l.__slot===r)return l;if(l.__inheritSlots){var s=o(l,null,!1);if(s)return s}}return null};t!==e;t=t.parentNode){var i=o(t.parentNode,t,n);if(i)return i;n=!1}return null},w=function(e){for(var t=e.parentNode;t&&t.__inheritSlots;)t=t.parentNode;if(t&&void 0===t.__singleSlot){var r=e.__slot||"",o=t.__slots[r];if(o){var i=y(t,e,r,!1);S(o,e,i,!1,!0,!0)}else n.hasGlobalWarningListeners()&&n.triggerWarning('slot "'+r+'" is not found.'),o=e.__wxSlotParent,o&&S(o,null,e,!0,!0,!0)}},x=function(e,t,r,n,o){var i=e;if(i instanceof d){for(;i.__virtual;){var a=i.__wxSlotParent;if(!a){i=null;break}if(t&&!r){var l=a.__wxSlotChildren.indexOf(i);r=a.__wxSlotChildren[l+1]}i=a}i instanceof d&&(i=i.__domElement)}if(i){var s=n,_=null,c=null;if(t)if(t.__virtual){var u=document.createDocumentFragment(),f=function(e){for(var t=0;t<e.__wxSlotChildren.length;t++){var r=e.__wxSlotChildren[t];r.__virtual?f(r):u.appendChild(r.__domElement)}};f(t),_=u}else _=t.__domElement;if(r)if(r.__virtual){var p=e,h=0;if(n){var v=function(e){for(var t=0;t<e.__wxSlotChildren.length;t++){var r=e.__wxSlotChildren[t];r.__virtual?v(r):i.removeChild(r.__domElement)}};v(r),s=!1,h=o+1}else p=r.__wxSlotParent,h=r===t?o:p.__wxSlotChildren.indexOf(r);if(t){var m=function(e,t){for(;t<e.__wxSlotChildren.length;t++){var r=e.__wxSlotChildren[t];if(!r.__virtual)return r;var n=m(r,0);if(n)return n}};r=null;for(var b=p;r=m(b,h),!r&&b.__virtual;b=b.__wxSlotParent)h=b.__wxSlotParent.__wxSlotChildren.indexOf(b)+1;r&&(c=r.__domElement)}}else c=r.__domElement;s?_?i.replaceChild(_,c):i.removeChild(c):_&&(c?i.insertBefore(_,c):i.appendChild(_))}else if(t&&t.__wxSlotParent){var g=function(e){if(e.__virtual)for(var t=0;t<e.__wxSlotChildren.length;t++)g(e.__wxSlotChildren[t]);else{var r=e.__domElement;r&&r.parentNode&&r.parentNode.removeChild(r)}};g(t)}},C=function(e,t,r,n,o){var i=e;if(i instanceof d){for(;i.__virtual;){var a=i.__wxSlotParent;if(!a){i=null;break}if(t&&!r){var l=a.__wxSlotChildren.indexOf(i);r=a.__wxSlotChildren[l+1]}i=a}i instanceof d&&(i=i.__domElement)}if(i)if(!t||r||t.__virtual){var s=e.__backendContext.createElement("fragment",""),_=0,c=null;if(t){var u=function(e){if(e.__virtual)for(var t=0;t<e.__wxSlotChildren.length;t++){var r=e.__wxSlotChildren[t];u(r)}else s.appendChild(e.__domElement)};u(t)}if(r){var f=e,p=0,h=null;if(n){var v=function(e){if(e.__virtual){for(var t=0,r=0;r<e.__wxSlotChildren.length;r++)t+=v(e.__wxSlotChildren[r]);return t}return h||(h=e),1};_=v(r),p=o+1}else f=r.__wxSlotParent,p=r===t?o:f.__wxSlotChildren.indexOf(r);if(t&&!h)for(var m=function(e,t){for(;t<e.__wxSlotChildren.length;t++){var r=e.__wxSlotChildren[t];if(!r.__virtual)return r;var n=m(r,0);if(n)return n}return null},b=f;h=m(b,p),!h&&b.__virtual;b=b.__wxSlotParent)p=b.__wxSlotParent.__wxSlotChildren.indexOf(b)+1;h&&(c=h.__domElement)}c?i.spliceBefore(c,_,s):i.spliceAppend(s),s.release()}else i.appendChild(t.__domElement);else if(t&&t.__wxSlotParent){var g=t.__backendContext.createElement("fragment",""),y=function(e){if(e.__virtual)for(var t=0;t<e.__wxSlotChildren.length;t++)y(e.__wxSlotChildren[t]);else{var r=e.__domElement;g.appendChild(r)}};y(t),g.release()}},S=function(e,t,r,n,o,i,a){if(n&&(r.__wxSlotParent=null),o&&(a=e.__wxSlotChildren.indexOf(r)),t){var l=t.__wxSlotParent;if(t.__wxSlotParent=e,l&&i){var s=l.__wxSlotChildren.indexOf(t);l.__wxSlotChildren.splice(s,1),l===e&&s<a&&a--}}var c=!1;t&&t.__backendExtracted?c=!0:r&&r.__backendExtracted&&(c=!0),"dom"===_.documentBackend?c||x(e,t,r,n,a):"custom"===_.documentBackend&&e.__backendContext&&C(e,t,r,n,a),_.writeExtraInfoToAttr&&"dom"===_.documentBackend&&(n&&r instanceof d&&r.__domElement&&r.__domElement.removeAttribute("exparser:info-in-slot-of"),t instanceof d&&t.__domElement&&(void 0!==e.__slotName&&e.ownerShadowRoot?t.__domElement.setAttribute("exparser:info-in-slot-of",e.ownerShadowRoot.__wxHost.__componentInstanceId):t.__domElement.removeAttribute("exparser:info-in-slot-of"))),o&&(a===-1&&(a=e.__wxSlotChildren.length),t?e.__wxSlotChildren.splice(a,n?1:0,t):e.__wxSlotChildren.splice(a,n?1:0))},E=function(e,t){for(var r=e.childNodes,n=0;n<r.length;n++){var o=r[n];t(e,o),o.__inheritSlots&&E(o,t)}},O=d.insertChildToElement=function(e,t,r,o){if(void 0!==e.__slotName)return!1;var a=r>=0?e.childNodes[r]:null;o&&t===a&&(o=!1);var l=null,s=e,_=e;if(t){l=t.parentNode,t.parentNode=e;var c=e.__subtreeObserversCount;if(l){var d=l.childNodes.indexOf(t);l.childNodes.splice(d,1),l===e&&d<r&&r--,c-=l.__subtreeObserversCount}c&&i._updateSubtreeCaches(t,c)}for(var u=e;u&&u.__inheritSlots;)u=u.parentNode;for(var g=!u||!u.__slots,w=!g||e.__inheritSlots,x=l;x&&x.__inheritSlots;)x=x.parentNode;var C=!x||!x.__slots,O=!C||l&&l.__inheritSlots;if(g)void 0!==e.__singleSlot&&(s=_=e.__singleSlot,n.hasGlobalWarningListeners()&&(s||n.triggerWarning("slot is not found."))),s?S(s,t,a,o,w,O,r):t.__wxSlotParent&&S(t.__wxSlotParent,null,t,!0,O,!1),t&&!C&&t.__inheritSlots&&E(t,function(e,t){S(e,t,null,!1,!0,!0,-1)});else{var N="";if(t&&(N=t.__slot||"",s=u.__slots[N]||null,n.hasGlobalWarningListeners()&&(s||n.triggerWarning('slot "'+N+'" is not found.'))),a&&(_=u.__slots[a.__slot||""]||null),a&&_&&o&&S(_,null,a,o,!0,!1),t)if(s){var k=a?y(u,a,N,!o):y(u,e,N,!1);S(s,t,k,!1,!0,O)}else t.__wxSlotParent&&S(t.__wxSlotParent,null,t,!0,O,!1);a&&o&&a.__inheritSlots&&E(a,function(e,t){S(e,t,null,!1,!0,!0,-1)}),t&&t.__inheritSlots&&E(t,function(t,r){var i=r.__slot||"",l=u.__slots[i]||null;if(l){var s=a?y(u,a,i,!o):y(u,e,i,!1);S(l,r,s,!1,!0,!0)}else n.hasGlobalWarningListeners()&&n.triggerWarning('slot "'+i+'" is not found.'),r.__wxSlotParent&&S(r.__wxSlotParent,null,r,!0,!0,!1)})}return o&&(e.__subtreeObserversCount&&i._updateSubtreeCaches(a,-e.__subtreeObserversCount),a.parentNode=null),r===-1&&(r=e.childNodes.length),t?e.childNodes.splice(r,o?1:0,t):e.childNodes.splice(r,o?1:0),e.ownerShadowRoot&&(o&&m(a,e.ownerShadowRoot),t&&m(t,e.ownerShadowRoot),b(e.ownerShadowRoot)),o&&(p(a),v(e,"remove",a)),t&&(l?h(t):f(t),l===e?v(e,"move",t):(l&&v(l,"remove",t),v(e,"add",t))),!0},N=function(e,t,r,n){if(t&&e.ownerShadowRoot!==t.ownerShadowRoot)throw new Error("Cannot move the node from one shadow tree to another shadow tree.");var o=n?r:t,i=-1;if(r&&(i=e.childNodes.indexOf(r),i<0))return null;var a=O(e,t,i,n);return a?o:null};d._attachShadowRoot=function(e){var t=e.__wxHost;t.__wxSlotChildren=[e],S(t,e,null,!1,!1,0),e.__hostAssociated=!0,b(e)},d.appendChild=function(e,t){return N(e,t,null,!1)},d.insertBefore=function(e,t,r){return N(e,t,r,!1)},d.removeChild=function(e,t){return N(e,null,t,!0)},d.replaceChild=function(e,t,r){return N(e,t,r,!0)},d.prototype.appendChild=function(e){return N(this,e,null,!1)},d.prototype.insertBefore=function(e,t){return N(this,e,t,!1)},d.prototype.removeChild=function(e){return N(this,null,e,!0)},d.prototype.replaceChild=function(e,t){return N(this,e,t,!0)};var k=function(e){var t=!0,r=!0;if(e instanceof d?(e.__backendExtracted=!0,e.$$=e.__domElement=null,r=!1):e instanceof l&&(e.__backendExtracted=!0,e.$$=e.__domElement=null,t=!1,r=!1),t&&e.__wxSlotChildren)for(var n=0;n<e.__wxSlotChildren.length;n++){var o=e.__wxSlotChildren[n];k(o)}else if(r&&e.childNodes)for(var i=0;i<e.childNodes.length;i++)k(e.childNodes[i])};d.extractBackend=function(e){if(e.__backendExtracted)return null;var t=e.__domElement;return k(e),t};var A=function(e,t){if(!t){var r=s.toElement(e.__domElement);return e.$$=e.__domElement=r,r}if(e.__domElement.tagName.toUpperCase()===t.tagName)e.$$=e.__domElement=t;else{var n=s.toElement(e.__domElement);e.$$=e.__domElement=n,t.parentNode.replaceChild(n,t)}return null},T=function(e,t){if(!t){var r=document.createTextNode(e.textContent);return e.$$=e.__domElement=r,r}if("undefined"!=typeof t.textContent)t.textContent=e.textContent,e.$$=e.__domElement=t;else{var n=document.createTextNode(e.textContent);e.$$=e.__domElement=n,t.parentNode.replaceChild(n,t)}return null},L=function(e,t){if(!t)return e;for(;e.childNodes&&t.childNodes&&t.childNodes.length;)e.appendChild(t.childNodes[0]);return t.parentNode.replaceChild(e,t),null},P=function(e,t,r){var n=e instanceof d&&e.__virtual,o=t?t.childNodes[r]:void 0,i=!0,a=!0,s=null;if(e instanceof d)e.__backendExtracted=!1,n||(s=A(e,o)),a=!1;else if(e instanceof l)e.__backendExtracted=!1,s=T(e,o),i=!1,a=!1;else{var _=document.createDocumentFragment();if(_.__wxSlotChildren=e.__wxSlotChildren,o&&o.childNodes)for(;o.childNodes.length;)_.appendChild(o.childNodes[0]);s=L(e,o),e=_}s?(t.appendChild(s),o=s):o=t?t.childNodes[r]:void 0;var c=0;if(i&&e.__wxSlotChildren)for(var u=0;u<e.__wxSlotChildren.length;u++){var f=e.__wxSlotChildren[u];if(n)r=P(f,t,r);else if(f.asShadowRoot){for(var p=0;p<f.asShadowRoot.childNodes.length;p++)c=P(f.asShadowRoot.childNodes[p],o,c);e.shadowRoot=o,o.__wxHost=e,e.__wxSlotChildren[0]=o,o.__wxSlotParent=e,e.__singleSlot===f&&(e.__singleSlot=o)}else c=P(f,o,c)}else if(a&&e.childNodes)for(var h=0;h<e.childNodes.length;h++)c=P(e.childNodes[h],o,c);if(n)return r;for(;o.childNodes.length>c;)o.removeChild(o.childNodes[c]);return r+1};d.injectBackend=function(e,t){if(e.__backendExtracted){var r=document.createDocumentFragment();r.appendChild(t),P(e,r,0)}},d.prototype.triggerEvent=function(e,t,r){o.triggerEvent(this,e,t,r)},d.prototype.dispatchEvent=function(e){o.dispatchEvent(this,e)},d.prototype.addListener=function(e,t,r){o.addListenerToElement(this,e,t,r)},d.prototype.removeListener=function(e,t,r){o.removeListenerFromElement(this,e,t,r)},d.setMethodCaller=function(e,t){e.__methodCaller=t},d.getMethodCaller=function(e){return e.__methodCaller},d.prototype.getAttribute=function(e){if(!this.__attributes)return null;var t=this.__attributes[e];return void 0===t?null:t},d.prototype.setAttribute=function(e,t){this.__attributes||(this.__attributes=Object.create(null)),t=String(t),this.__attributes[e]!==t&&(this.__attributes[e]=t,this.__domElement&&this.__domElement.setAttribute&&this.__domElement.setAttribute(e,t))},d.prototype.setStyle=function(e){this.__domElement&&"custom"===_.documentBackend&&this.__domElement.setStyle(e)},d.prototype.removeAttribute=function(e){this.__attributes&&(delete this.__attributes[e],this.__domElement&&"dom"===_.documentBackend&&this.__domElement.removeAttribute(e))},d.prototype.getBoundingClientRect=function(){return this.__domElement?this.__domElement.getBoundingClientRect():{left:0,top:0,width:0,height:0}},d.prototype.setMark=function(e,t){this.__marks||(this.__marks={}),this.__marks[e]=t},d.prototype.collectMarks=function(){for(var e={},t=this;t;t=t.parentNode)if(t.__marks)for(var r in t.__marks)hasOwnProperty.call(e,r)||(e[r]=t.__marks[r]);return e};var M=d.prototype.setNodeStyle=function(e,t){if(this.__styleSegments[t||0]!==e){this.__styleSegments[t||0]=e;var r=this.__styleSegments.join(";");if(this.__domElement&&this.ownerShadowRoot&&this.ownerShadowRoot.__childrenPropsFilter){var n=this.ownerShadowRoot.__childrenPropsFilter,o=n.style;if("function"==typeof o)return void("dom"===_.documentBackend?this.__domElement.setAttribute("style",o.call(this,r)):"custom"===_.documentBackend&&this.__domElement.setStyle(o.call(this,r)))}this.__domElement&&("dom"===_.documentBackend?this.__domElement.setAttribute("style",r):"custom"===_.documentBackend&&this.__domElement.setStyle(r)),(this.__propObservers&&!this.__propObservers.empty||this.__subtreeObserversCount)&&i._callObservers(this,"__propObservers",{type:"properties",target:this,propertyName:"style"})}};d.replaceDocumentElement=function(e,t,r){e.__attached||("dom"===_.documentBackend?t.parentNode.replaceChild(e.__domElement,t):"custom"===_.documentBackend&&t.replaceChild(e.__domElement,r),f(e))},d.pretendAttached=function(e){e.__attached||f(e)},d.pretendDetached=function(e){e.__attached&&p(e)},d.isAttached=function(e){return e.__attached},d.setSlotName=function(e,t){if(t=null==t?"":String(t),void 0===e.__slotName){if(0!==e.childNodes.length||0!==e.__wxSlotChildren.length)return;e.__wxSlotChildren=[]}e.__slotName=t,e.ownerShadowRoot&&(e.ownerShadowRoot.__slotCacheDirty=!0,b(e.ownerShadowRoot))},d.setInheritSlots=function(e){e.__singleSlot||e.__slots||e.__wxSlotChildren.length||(e.__wxSlotChildren=[],e.__inheritSlots=!0)},d.getInheritSlots=function(e){return e.__inheritSlots};var R=function(e,t){var r=e.match(/^(#[_a-zA-Z][-_a-zA-Z0-9:]*|)((?:\.-?[_a-zA-Z][-_a-zA-Z0-9]*)+|)$/);if(!r)return null;var n=r[1].slice(1),o=r[2].split(".");return o.shift(),n||o.length?{id:n,classes:o,relation:t||""}:null},D=d.parseSelector=function(e){for(var t=String(e||"").split(","),r=[],n=!1,o=0;o<t.length;o++){for(var i=t[o].split(/( |\t|>+)/g),a=[],l="",s=0;s<i.length;s++){var _=i[s];if(_&&" "!==_&&"\t"!==_)if(">"!==_[0]){var c=R(_,l);if(l="",!c)break;a.push(c)}else{if(""!==l)break;l=_,">>>"===_&&(n=!0)}}s===i.length&&a.length&&r.push(a)}return r.length?{crossShadow:n,union:r}:null},B=function(e,t,r,n,o){if(t===e)return!1;var i=r[n],a=!0;i.id&&i.id!==t.__id&&(a=!1);for(var l=i.classes,s=0;a&&s<l.length;s++)t.classList.contains(l[s])||(a=!1);if(!a&&">"===o)return!1;var _=t;if(a&&0===n){if(null===e)return!0;for(_=_.parentNode;_;_=_.parentNode)if(_===e)return!0;if(">>>"!==o)return!1;_=t,a=!1}var c=a?i.relation:o;do _.parentNode?_=_.parentNode:">>>"===c?_=_.__wxHost:">>>"===o?(a=!1,_=_.__wxHost):_=null,_===e&&(_=null);while(_&&!d.isSelectable(_));if(!_)return!1;if(a){var u=B(e,_,r,n-1,c);if(u)return!0;if(">>>"!==o)return!1}return B(e,_,r,n,o)},I=function(e,t,r){if(!d.isSelectable(r))return!1;for(var n=e.union,o=0;o<n.length;o++){var i=n[o];if(B(t,r,i,i.length-1,">"))return!0}return!1},j=function(e,t,r,n,o){if(I(t,r,n)&&(e.push(n),o))return!0;if(n.shadowRoot&&t.crossShadow){
var i=n.ownerShadowRoot?n.ownerShadowRoot.__wxHost.__componentOptions.domain:_.domain,a=n.__componentOptions.domain;if(i===a&&j(e,t,r,n.shadowRoot,o)&&o)return!0}for(var l=n.childNodes,s=0;s<l.length;s++)if(l[s]instanceof d&&j(e,t,r,l[s],o)&&o)return!0;return!1};d.prototype.querySelector=function(e){var t="object"==typeof e?e:D(e);if(!t)return null;var r=[];return j(r,t,this,this,!0),r[0]||null},d.prototype.querySelectorAll=function(e){var t="object"==typeof e?e:D(e),r=[];return t?(j(r,t,this,this,!1),r):[]},d.matchSelector=function(e,t){var r="object"==typeof e?e:D(e);return!!r&&I(r,null,t)},d.prototype.matchSelector=function(e,t){var r="object"==typeof e?e:D(e);return!!r&&I(r,this,t)},d.isSelectable=function(e){return!!e.classList},e.exports=d},function(e,t,r){var n=r(3),o=function(){};o.prototype=Object.create(Object.prototype,{constructor:{value:o,writable:!0,configurable:!0}}),o.create=function(e){var t=new o;return t._cb=e,t._noSubtreeCb=function(t){t.target===this&&e.call(this,t)},t._binded=[],t},o.prototype.observe=function(e,t){t=t||{};var r=0,o=t.subtree?this._cb:this._noSubtreeCb;t.properties&&(e.__propObservers||(e.__propObservers=n.create("Observer Callback")),this._binded.push({funcArr:e.__propObservers,id:e.__propObservers.add(o),subtree:t.subtree?e:null}),r++),t.childList&&(e.__childObservers||(e.__childObservers=n.create("Observer Callback")),this._binded.push({funcArr:e.__childObservers,id:e.__childObservers.add(o),subtree:t.subtree?e:null}),r++),t.characterData&&(e.__textObservers||(e.__textObservers=n.create("Observer Callback")),this._binded.push({funcArr:e.__textObservers,id:e.__textObservers.add(o),subtree:t.subtree?e:null}),r++),t.subtree&&i(e,r),t.attachStatus&&(e.__attachedObservers||(e.__attachedObservers=n.create("Observer Callback")),this._binded.push({funcArr:e.__attachedObservers,id:e.__attachedObservers.add(o),subtree:null}))},o.prototype.disconnect=function(){for(var e=this._binded,t=0;t<e.length;t++){var r=e[t];r.funcArr.remove(r.id),r.subtree&&i(r.subtree,-1)}this._binded=[]};var i=o._updateSubtreeCaches=function(e,t){e.__subtreeObserversCount+=t;var r=e.childNodes;if(r)for(var n=0;n<r.length;n++)i(r[n],t)};o._callObservers=function(e,t,r){do e[t]&&e[t].call(e,[r]),e=e.parentNode;while(e&&e.__subtreeObserversCount)},o._callSingleObserver=function(e,t,r){e[t]&&e[t].call(e,[r])},e.exports=o},function(e,t,r){var n=r(4),o=function(){},i=/(~|\^+)?-?[_0-9a-z][-_0-9a-z]*/gi,a=null;o._setElementSystem=function(e){a=e,o._setElementSystem=null};var l=Object.prototype.hasOwnProperty;o.create=function(e,t){var r=new o;r._prefix="",r._addOriginalClass=!1,r._alias=t,r._resolvedAlias={};for(var n in t)r._resolvedAlias[n]="";return r._rawNames=[],r._elem=e,r._owner=null,r._prevGenNames="",r};var s=function(e){var t="",r=e._rawNames,n=e._prefix,o=e._owner?e._owner._resolvedAlias:null,i=e._addOriginalClass;n&&(n+="--");for(var a=0;a<r.length;a++){var s=r[a];if(a&&(t+=" "),o&&l.call(o,s))t+=o[s];else if("~"===s[0])t+=s.slice(1);else if("^"===s[0]){s=s.slice(1);for(var _=e._owner||null;"^"===s[0];)s=s.slice(1),_=_?_._owner:null;var c=_?_._prefix:"";c&&(c+="--"),t+=c+s}else i&&(t+=s+" "),t+=n+s}return t},_=function(e){var t=e._elem.__domElement;if(t){var r=s(e);if("dom"===n.documentBackend)r?t.setAttribute("class",r):t.removeAttribute("class");else if("custom"===n.documentBackend){if(e._prevGenNames===r)return;e._prevGenNames=r,t.setClass(r)}}},c=function(e){var t=e.classList;t instanceof o&&(t._alias&&d(t),_(t));for(var r=e.childNodes,n=0;n<r.length;n++)r[n]instanceof a&&c(r[n])},d=function(e){var t=e._owner;if(!t)return!1;var r=!1;for(var n in e._alias){var o=e._alias[n],i=[];if(o)for(var s=0;s<o.length;s++){var _=o[s];if(l.call(t._alias,_)){var d=t._resolvedAlias[_];i.push(d)}else{var u=e._prefix&&_?e._prefix+"--"+_:_;i.push(u)}}var f=i.join(" ");e._resolvedAlias[n]!==f&&(r=!0,e._resolvedAlias[n]=f)}r&&e._elem.shadowRoot instanceof a&&c(e._elem.shadowRoot)};o.prototype.toggle=function(e,t){var r=this._rawNames.indexOf(e);void 0===t&&(t=r<0),t?r<0&&(this._rawNames.push(e),_(this)):r>=0&&(this._rawNames.splice(r,1),_(this))},o.prototype.contains=function(e){for(var t=this._rawNames,r=0;r<t.length;r++){var n=t[r];if("~"===n[0]){if(n.slice(1)===e)return!0}else if("^"===n[0]){for(var o=1;"^"===n[o];)o++;if(n.slice(o)===e)return!0}else if(n===e)return!0}return!1},o.prototype._setOwnerOptions=function(e,t,r){var n=this._prefix;this._prefix=t,n===(t||"")&&this._owner===e||(this._addOriginalClass=r,this._owner=e,this._alias&&d(this),_(this))},o.prototype._setAlias=function(e,t){var r=this._owner,n=String(t).match(i);this._alias[e]=n;var o=[];if(n)for(var a=0;a<n.length;a++){var s=n[a];r&&l.call(r._alias,s)?o.push(r._resolvedAlias[s]):o.push(this._prefix?this._prefix+"--"+s:s)}this._resolvedAlias[e]=o.join(" "),c(this._elem.shadowRoot)},o.prototype.setClassNames=function(e){e=void 0===e||null===e?"":String(e),this._rawNames=e.match(i)||[],_(this)},o.prototype.getClassNames=function(){return s(this)},o.prototype.getPrefix=function(){return this._prefix},o.prototype.getAddOriginalClass=function(){return this._addOriginalClass},o.prototype.getRawNames=function(){return this._rawNames},e.exports=o},function(e,t,r){var n=r(10),o=r(4),i=r(13),a=function(){};a.prototype=Object.create(Object.prototype,{constructor:{value:a,writable:!0,configurable:!0}});var l=a._advancedCreate=function(e,t,r){var n=new a;n.__slot="";var l=null;if(i.backendExtractedDefault||"dom"!==o.documentBackend)if("custom"===o.documentBackend){var s=void 0===r?o.customContext:r;n.__backendContext=s,s?(l=s.createElement("text",""),l.setText(e||""),l.textContent=e,l.__wxElement=n):n.__textContent=e}else n.__textContent=e;else l=document.createTextNode(e||""),l.__wxElement=n;return n.$$=n.__domElement=l,n.__backendExtracted=i.backendExtractedDefault,n.__subtreeObserversCount=0,n.__autoDestroy=!0,n.parentNode=null,n.ownerShadowRoot=t,n};a.create=function(e){return l(e,null)},a.prototype.setAutoDestroy=function(e){this.__autoDestroy=!!e},a.prototype.destroy=function(){"custom"===o.documentBackend&&this.__domElement&&(this.__domElement.release(),this.__domElement=null)},Object.defineProperty(a.prototype,"textContent",{get:function(){return this.__domElement?this.__domElement.textContent:this.__textContent},set:function(e){if(e=String(e),this.__domElement){if(this.__domElement.textContent===e)return;this.__domElement.textContent=e,"custom"===o.documentBackend&&this.__domElement.setText(e)}else{if(this.__textContent===e)return;this.__textContent=e}(this.__textObservers&&!this.__textObservers.empty||this.__subtreeObserversCount)&&n._callObservers(this,"__textObservers",{type:"characterData",target:this})}}),e.exports=a},function(e,t){t.backendExtractedDefault=!1,t.enableBackendExtractedDefault=function(){t.backendExtractedDefault=!0},t.disableBackendExtractedDefault=function(){t.backendExtractedDefault=!1}},function(e,t){var r=function(e){this.tagName=e,this.id="",this.attrs={}};r.toElement=function(e){var t=document.createElement(e.tagName);e.id&&(t.id=e.id);for(var r in e.attrs)t.setAttribute(r,e.attrs[r]);return t},r.fromElement=function(e){var t=new r(e.tagName);t.id=e.id;for(var n=e.attributes,o=0;o<n.length;o++)t.attrs[n[o].name]=n[o].value;return t},r.prototype.cloneNode=function(){var e=new r;e.id=this.id;for(var t in this.attrs)e.attrs[t]=this.attrs[t];return e},r.prototype.removeAttribute=function(e,t){delete this.attrs[e]},r.prototype.setAttribute=function(e,t){this.attrs[e]=t},r.prototype.getAttribute=function(e){return this.attrs[e]},e.exports=r},function(e,t,r){var n=r(3),o=r(5),i=r(16),a=r(6),l=r(8),s=r(9),_=r(17),c=r(10),d=r(11),u=r(14),f=r(4),p=r(13),h=r(7),v=a.addListenerToElement,m=h.parseSinglePath,b=o.deepCopy,g=function(){};g.prototype=Object.create(s.prototype,{constructor:{value:g,writable:!0,configurable:!0},data:{get:function(){return this.__dataProxy._data},set:function(e){var t=this.__dataProxy;for(var r in e)t.scheduleReplace([r],e[r]);t.doUpdates()},configurable:!0},$:{get:function(){return s._updateIdMap(this),this.__idCache},set:function(){}}});var y=function(){};y.prototype=Object.create(Object.prototype),a._setComponent(g);var w=null;g._setDefaultTemplateEngine=function(e){w=e,g._setDefaultTemplateEngine=null};var x=function(e,t,r){if(r)for(var o=0;o<r.length;o++)if(l.matchTypeWithValue(r[o],e))return e;return t===String?null===e||void 0===e?(n.hasGlobalWarningListeners()&&n.triggerWarning("property received type-uncompatible value: expected <String> but get null value. Used empty string instead."),""):(n.hasGlobalWarningListeners()&&"object"==typeof e&&n.triggerWarning("property received type-uncompatible value: expected <String> but got object-typed value. Forcely converted."),String(e)):t===Number?isFinite(e)?Number(e):(n.hasGlobalWarningListeners()&&("number"==typeof e?n.triggerWarning("property received type-uncompatible value: expected <Number> but got NaN or Infinity. Used 0 instead."):n.triggerWarning("property received type-uncompatible value: expected <Number> but got non-number value. Used 0 instead.")),0):t===Boolean?!!e:t===Array?e instanceof Array?e:(n.hasGlobalWarningListeners()&&n.triggerWarning("property received type-uncompatible value: expected <Array> but got non-array value. Used empty array instead."),[]):t===Object?"object"==typeof e?e:(n.hasGlobalWarningListeners()&&n.triggerWarning("property received type-uncompatible value: expected <Object> but got non-object value. Used null instead."),null):void 0===e?null:e},C=function(e,t,r){if("dom"===f.documentBackend){var n=t.replace(/[A-Z]/g,function(e){return"-"+e.toLowerCase()}),o=typeof r;"boolean"===o?r?e.__domElement.setAttribute(n,""):e.__domElement.removeAttribute(n):"object"===o?e.__domElement.setAttribute(n,JSON.stringify(r)):e.__domElement.setAttribute(n,r)}},S=function(e,t,r){var o=[t?t.__wxHost.__componentOptions.domain:void 0],i=n.safeCallback("Availablity Controller",r,e,o);return!!i},E=function(e,t,r,o){var i=[e.ownerShadowRoot?e.ownerShadowRoot.__wxHost.__componentOptions.domain:void 0,o?void 0:r],a=n.safeCallback("Availablity Controller",t,e.__methodCaller,i,e);return!!a};i.setPropUpdater(function(e,t,r,o){var i=e[0],a=this.__propData[i];r=x(r,t.type,t.optionalTypes);var l=!t.availability||E(this,t.availability,r,o);if(!l)return n.hasGlobalWarningListeners()&&n.triggerWarning('the new value for property "'+i+'" in component "'+(this.is||"")+'" is currently not available. The value is not changed.'),a;if(t.filter){var s=n.safeCallback("Property Filter",t.filter,this.__methodCaller,o?[]:[r,a,e],this);void 0!==s&&(r=s)}return this.__domElement&&this.__componentOptions.reflectToAttributes&&this.__propPublic[i]&&C(this,i,r),r}),i.setPropObserver(function(e,t,r,o,i,a){if(o.observeAssignments||e!==t){var l=r[0];this.__propertyChangeListeners&&this.__propertyChangeListeners[l]&&!a&&n.safeCallback("Property Observer",this.__propertyChangeListeners[l],this.__methodCaller,[e],this),o.observer&&n.safeCallback("Property Observer",o.observer,this.__methodCaller,i?[]:[e,t,r],this),o.public&&(this.__propObservers&&!this.__propObservers.empty||this.__subtreeObserversCount)&&c._callObservers(this,"__propObservers",{type:"properties",target:this,propertyName:l})}});var O=function(e,t,r){t.__relationLinks||(t.__relationLinks={});for(var n=t.__relationLinks[r]=[],o=0;o<e.length;o++)n.push(null)},N=function(e,t,r,o,i){for(var a=g.prototype.hasBehavior,_="parent"===o,c="shadowHost"===o,d=0;d<e.length;d++){var u=e[d],f=null;if(f="object"!=typeof u.target?l._list[u.target]:u.target){var p=t[d],h=null;if(!i)for(var v=c?r.ownerShadowRoot&&r.ownerShadowRoot.__wxHost:r.parentNode;v;v=c?v.ownerShadowRoot&&v.ownerShadowRoot.__wxHost:v.parentNode)if(s.isSelectable(v)){if(a.call(v,f)){var m=null;m=_?v.__relationMap.child:c?v.__relationMap.shadowContent:v.__relationMap.descendant;for(var b=0;b<m.length;b++){var y=m[b],w=null;if(w="object"!=typeof y.target?l._list[y.target]:y.target,w&&a.call(r,w)){h={parent:v,relation:y};break}}}if(_||h)break}t[d]=h,!p||h&&p.parent===h.parent||(n.safeCallback("Relation Unlinked Callback",p.relation.unlinked,p.parent.__methodCaller,[r.__methodCaller],p.parent),n.safeCallback("Relation Unlinked Callback",u.unlinked,r.__methodCaller,[p.parent.__methodCaller],r)),!h||p&&p.parent===h.parent||(n.safeCallback("Relation Linked Callback",h.relation.linked,h.parent.__methodCaller,[r.__methodCaller],h.parent),n.safeCallback("Relation Linked Callback",u.linked,r.__methodCaller,[h.parent.__methodCaller],r)),p&&h&&p.parent===h.parent&&(n.safeCallback("Relation Link Changed Callback",h.relation.linkChanged,h.parent.__methodCaller,[r.__methodCaller],h.parent),n.safeCallback("Relation Link Changed Callback",u.linkChanged,r.__methodCaller,[h.parent.__methodCaller],r)),i||h||n.safeCallback("Relation Link Failed Callback",u.linkFailed,r.__methodCaller,[],r)}}},k=function(e,t){var r=[],n=t.type,o="child"===n,i="shadowContent"===n,a=function(n){for(var l=n.childNodes,_=0;_<l.length;_++){var c=l[_];if(c instanceof s)if(s.isSelectable(c)){if(c.__relationLinks){var d=null;if(d=o?c.__relationLinks.parent:i?c.__relationLinks.shadowHost:c.__relationLinks.ancestor)for(var u=0;u<d.length;u++){var f=d[u];if(f&&f.parent===e&&f.relation===t){r.push(c);break}}}i&&c instanceof g&&a(c.shadowRoot),o||a(c)}else a(c)}};return a(i?e.shadowRoot:e),r},A=function(e,t,r){if(e instanceof s){var n=0,o=null;if(e instanceof g){for(e.__pageLifeTimeFuncs[t]&&e.__pageLifeTimeFuncs[t].call(e.__methodCaller,r||[]),o=e.childNodes,n=0;n<o.length;n++)A(o[n],t,r);e=e.shadowRoot}for(o=e.childNodes,n=0;n<o.length;n++)A(o[n],t,r)}};g._list={},g.register=function(e){var t=e.options||{},r=l.create(e),n=void 0!==t.classPrefix?t.classPrefix:f.classPrefix;null!==n&&void 0!==n||(n=r.is||"");var o=new y;return o._unprepared=r,o.is=e.is||"",o.behavior=r,o.protoFunc=null,o.props=null,o.template=null,o.innerEvents=null,o.generics=r.generics,o.placeholder=r.placeholder,o.initiator=r.initiator||null,o.options={availability:t.availability||f.availability,domain:t.domain||f.domain,writeOnly:!!(void 0!==t.writeOnly?t.writeOnly:f.writeOnly),allowInWriteOnly:!!(void 0!==t.allowInWriteOnly?t.allowInWriteOnly:f.allowInWriteOnly),classPrefix:n,styleScope:t.styleScope||f.styleScope,addGlobalClass:!!(void 0!==t.addGlobalClass?t.addGlobalClass:f.addGlobalClass),templateEngine:t.templateEngine||f.templateEngine||w,renderingMode:t.renderingMode||f.renderingMode,multipleSlots:!!(void 0!==t.multipleSlots?t.multipleSlots:f.multipleSlots),reflectToAttributes:!!(void 0!==t.reflectToAttributes?t.reflectToAttributes:f.reflectToAttributes),writeFieldsToNode:!!(void 0!==t.writeFieldsToNode?t.writeFieldsToNode:f.writeFieldsToNode),writeIdToDOM:!!(void 0!==t.writeIdToDOM?t.writeIdToDOM:f.writeIdToDOM),separateInnerData:!!(void 0!==t.separateInnerData?t.separateInnerData:f.separateInnerData),innerDataExclude:t.innerDataExclude||f.innerDataExclude,listenerChangeLifeTimes:!!(void 0!==t.listenerChangeLifeTimes?t.listenerChangeLifeTimes:f.listenerChangeLifeTimes),randomizeTagName:!!(void 0!==t.randomizeTagName?t.randomizeTagName:f.randomizeTagName),virtualHost:!!(void 0!==t.virtualHost?t.virtualHost:f.virtualHost)},r._unprepared||g.prepare(o),void 0!==e.is&&(g._list[r.is]=o),o},g.isPrepared=function(e){return!e._unprepared},g.prepare=function(e){var t=e._unprepared;if(t){e._unprepared=null;var r=e.options,o={};t._unprepared&&l.prepare(t),r.writeOnly&&(o.data={value:null});var a=e.props={};Object.keys(t.properties).forEach(function(e){var n=t.properties[e];a[e]={type:n.type,optionalTypes:n.optionalTypes,value:n.value,filter:"function"==typeof n.filter?n.filter:null==n.filter?null:t.methods[n.filter],observer:"function"==typeof n.observer?n.observer:null==n.observer?null:t.methods[n.observer],public:n.public,availability:n.availability,observeAssignments:n.observeAssignments},r.writeFieldsToNode&&(o[e]={enumerable:!0,get:function(){return this.__propData[e]},set:function(t){var r=this.__dataProxy;r.scheduleReplace([e],t),r.doUpdates()}})});var s=function(){};e.protoFunc=s;var _=s.prototype=Object.create(g.prototype,o);if(_.is=e.is,_.__componentOptions=r,_.__using=t.using,e.dataGroupObserverTree=i._createObserverTree(a),t._addObserversToDataProxy(e.dataGroupObserverTree),_.__behavior=t,r.writeFieldsToNode)for(var c in t.methods)_[c]=t.methods[c];_.__lifeTimeFuncs=t._getAllLifeTimeFuncs(),_.__pageLifeTimeFuncs=t._getAllPageLifeTimeFuncs();var d=t.relations,u=_.__relationMap={};for(var f in d){var p=d[f],h=p.type;u[h]?u[h].push(p):u[h]=[p]}var v=[];u.parent&&v.push(function(e){N(this.__relationMap.parent,this.__relationLinks.parent,this,"parent","detached"===e)}),u.ancestor&&v.push(function(e){N(this.__relationMap.ancestor,this.__relationLinks.ancestor,this,"ancestor","detached"===e)}),u.shadowHost&&v.push(function(e){N(this.__relationMap.shadowHost,this.__relationLinks.shadowHost,this,"shadowHost","detached"===e)}),e.relationHandler=function(e){for(var t=0;t<v.length;t++)v[t].call(this,e)};var m={},b={},y=t.data,w="";for(w in y)b[w]=y[w];for(w in a){var x=a[w];n.hasGlobalWarningListeners()&&void 0!==b[w]&&n.triggerWarning('data field "'+w+'" is overwritten by property with the same name.'),b[w]=x.value,m[w]=x.public}var C=b,S=r.separateInnerData,E=r.innerDataExclude;if(E){C={};for(var O in b)E.test(O)||(C[O]=b[O]);S||(b=C)}var k=r.templateEngine;e.template=k.create(t,b,C,r),_.__propPublic=m;var A=t._getAllListeners(),T=e.innerEvents=[];for(var L in A){for(var P=A[L],M=L.indexOf("."),R=L.slice(M+1),D=M<1?"":L.slice(0,M),B=[],I=0;I<P.length;I++){var j=P[I];"function"!=typeof j&&(j=null==j?null:t.methods[j]),B.push(j)}T.push({id:D,name:R,funcs:B})}}};var T=1,L=Object.prototype.hasOwnProperty,P=function(e,t){return function(r){return e.call(t.__methodCaller,r,t)}},M=function(e,t,r){var o={};for(var i in e){var a=e[i],l=t[i];"object"!=typeof l&&L.call(g._list,l)&&(l=g._list[l]),"object"!=typeof l&&null!=a.default&&(l=g._list[a.default]),n.hasGlobalWarningListeners()&&(l||n.triggerWarning('generic "'+i+'" is not instantiated. The default component is used instead.')),l&&(o[i]=l)}if(n.hasGlobalWarningListeners())for(var s in t)void 0===e[s]&&n.triggerWarning('generic "'+s+'" is not defined. It will be ignored.');return o},R=function(e,t){var r={};for(var n in t)r[n]=t[n];for(var n in e)r[n]=e[n];return r},D=g._advancedCreate=function(e,t,r,o,a,l,_){var c=t;c._unprepared&&g.prepare(c);var h=c.options,m=!h.availability||S(c,r,h.availability);m||(n.hasGlobalWarningListeners()&&n.triggerWarning('the component "'+(c.is||"")+'" is currently not available. The default component is used instead.'),c=g._list[""]);var y=c.protoFunc,w=new y;w.__placeholder=R(l,c.placeholder);var x=c.generics;x?w.__generics=M(x,a||{},h):w.__generics={};var C=null,E=f.documentBackend;if(h.virtualHost){var C=null;"dom"!==E&&"custom"!==E||(C=void 0);var N=null;"custom"===E&&(N=void 0===o?f.customContext:o),s.initialize(w,C,r,N),w.__virtual=!0}else if("dom"===E)C=p.backendExtractedDefault?new u(e):document.createElement(e),s.initialize(w,C,r,null);else if("custom"===E){var N=void 0===o?f.customContext:o;N&&(C=N.createElement("empty",e)),s.initialize(w,C,r,N)}else s.initialize(w,null,r,null);var k=0,A=w.__externalClassAlias={};if(c.behavior.externalClasses){var L=c.behavior.externalClasses;for(k=0;k<L.length;k++)A[L[k]]=null}if(w.classList=d.create(w,A),r){var D=r.__wxHost;C&&"custom"===E&&D.__componentOptions.styleScope&&C.setStyleScope(D.__componentOptions.styleScope),w.classList._setOwnerOptions(D.classList,D.__componentOptions.classPrefix,D.__componentOptions.addGlobalClass),f.writeExtraInfoToAttr&&C&&C.setAttribute("exparser:info-class-prefix",D.__componentOptions.classPrefix&&D.__componentOptions.classPrefix+"--")}"dom"===E&&f.writeExtraInfoToAttr&&C&&(w.__componentInstanceId=T++,C.setAttribute("exparser:info-component-id",w.__componentInstanceId));var B=w.__templateInstance=c.template.createInstance(w,_);w.__propData=B.data;var I=h.separateInnerData;w.__innerData=I?b(w.__propData):null;var j=h.innerDataExclude;if(I&&j){var F={};for(var H in w.__innerData)j.test(H)||(F[H]=w.__innerData[H]);w.__innerData=F}w.__dataProxy=i._advancedCreate(w,w.__propData,w.__innerData,j,c.dataGroupObserverTree,function(e,t,r,n){w.__templateInstance.updateValues(w,I?w.__innerData:w.__propData,e,t,r,n)}),B.beforeMergeValues&&w.__dataProxy.setBeforeMergeCb(function(e,t,r){w.__templateInstance.beforeMergeValues(e,t,r)}),B.beforeUpdateValues&&w.__dataProxy.setBeforeUpdateCb(function(e){w.__templateInstance.beforeUpdateValues(w,I?w.__innerData:w.__propData,e)}),h.writeOnly&&w.__dataProxy.setHidingValue(!0),w.__idCacheDirty=!1,w.__idCache=B.idMap,null===B.slots[""]&&(B.slots[""]=C),c.options.multipleSlots?w.__slots=B.slots:(w.__singleSlot=B.slots[""]||null,w.__singleSlot&&(w.__singleSlot.__wxSlotChildren=w.childNodes)),B.shadowRoot instanceof s?(w.shadowRoot=B.shadowRoot,s._attachShadowRoot(B.shadowRoot)):C instanceof u?(w.shadowRoot=C,C.__wxHost=w,w.__domElement.asShadowRoot=B.shadowRoot,w.__wxSlotChildren=[C],C.__wxSlotParent=w):(w.shadowRoot=C,C.__wxHost=w,""!==f.documentBackend&&w.__domElement.appendChild(B.shadowRoot),w.__wxSlotChildren=[C],C.__wxSlotParent=w);for(var W=B.listeners,G=0;G<W.length;G++){var U=W[G];v(U.target,U.name,P(U.func,w))}var V=c.innerEvents;for(k=0;k<V.length;k++){var $=V[k],z=$.id?"this"===$.id?w:w.__idCache[$.id]:w.shadowRoot;if(z)for(var q=$.name,J=$.funcs,Z=0;Z<J.length;Z++)v(z,q,P(J[Z],w))}var K=w.__relationMap;return K.parent&&(O(K.parent,w,"parent"),w.__relationHandler=c.relationHandler),K.ancestor&&(O(K.ancestor,w,"ancestor"),w.__relationHandler=c.relationHandler),K.shadowHost&&(O(K.shadowHost,w,"shadowHost"),w.__relationHandler=c.relationHandler),w.__propertyChangeListeners=null,"custom"===E&&C&&C.associateComponent(w),c.initiator&&n.safeCallback("Component Initiator",c.initiator,w.__methodCaller,[],w),w.__lifeTimeFuncs.created.call(w.__methodCaller,[],w),w};g.createWithGenericsAndContext=function(e,t,r,o,i){return"object"==typeof e?D(e.is,e,null,o,r,null,i):e?e.indexOf("-")<0&&!t?_.create(e):(n.hasGlobalWarningListeners()&&(t||L.call(g._list,e)||"virtual"===e||n.triggerWarning('component "'+e+'" is not found. The default component is used instead.')),D(e.toLowerCase(),t||L.call(g._list,e)&&g._list[e]||g._list[""],null,o,r,null,i)):D("virtual",g._list[""],null,o,r,null,i)},g.createWithGenerics=function(e,t,r,n){return g.createWithGenericsAndContext(e,t,r,void 0,n)},g.createWithContext=function(e,t,r,n){return g.createWithGenericsAndContext(e,t,null,r,n)},g.create=function(e,t,r){return g.createWithGenerics(e,t,null,r)},g.listProperties=function(e){var t=[];for(var r in e.__propPublic)void 0!==e.__propPublic[r]&&t.push(r);return t},g.listPublicProperties=function(e){var t=[];for(var r in e.__propPublic)e.__propPublic[r]===!0&&t.push(r);return t},g.hasProperty=function(e,t){return void 0!==e.__propPublic[t]},g.hasPublicProperty=function(e,t){return e.__propPublic[t]===!0},g.getMethodsFromDef=function(e){return e.behavior._unprepared&&l.prepare(e.behavior),e.behavior.methods},g.getMethod=function(e,t){return e.__behavior.methods[t]},g.getComponentOptions=function(e){return e.__componentOptions},g.prototype.triggerLifeTime=function(e,t){this.__lifeTimeFuncs[e].call(this.__methodCaller,t||[])},g.prototype.triggerPageLifeTime=function(e,t){A(this,e,t)},g.prototype.hasBehavior=function(e){return"object"!=typeof e&&Object.prototype.hasOwnProperty.call(this.__using,e)&&(e=this.__using[e]),!!this.__behavior&&this.__behavior.hasBehavior(e)},g.prototype.getRootBehavior=function(){return this.__behavior},g.prototype.getPlaceholder=function(e){return this.__placeholder[e]},g.prototype.getRelationNodes=function(e){var t=this.__behavior.relations[e];if(!t)return null;if("parent"===t.type||"ancestor"===t.type||"shadowHost"===t.type){for(var r=this.__relationMap[t.type],n=0;n<r.length&&r[n]!==t;n++);return this.__relationLinks[t.type][n]?[this.__relationLinks[t.type][n].parent]:[]}return k(this,t)},g.prototype.hasExternalClass=function(e){return L.call(this.__externalClassAlias,e)},g.prototype.setExternalClass=function(e,t){this.classList._setAlias(e,t)},g.prototype.setPropertyChangeListener=function(e,t){this.__propertyChangeListeners||(this.__propertyChangeListeners={}),this.__propertyChangeListeners[e]=t},g.prototype.replaceDataOnPath=function(e,t){this.__dataProxy.scheduleReplace(e,t)},g.prototype.isInnerDataExcluded=function(e){var t=this.__componentOptions.innerDataExclude;return!!t&&t.test(e)},g.getInnerData=function(e){return e.__innerData},g.getDataProxy=function(e){return e.__dataProxy},g.replaceWholeData=function(e,t,r){e.__propData=t,e.__dataProxy.replaceWholeData(t,r)},g.prototype.applyDataUpdates=function(){this.__dataProxy.doUpdates()},g.prototype.setData=function(e){var t=this.__dataProxy;for(var r in e)t.scheduleReplace(m(r),e[r]);t.doUpdates()},e.exports=g},function(e,t,r){var n=r(3),o=r(5),i=null,a=null,l=Object.prototype.hasOwnProperty,s=o.deepCopy,_=function(e,t,r,n,o,i){this._data=t,this._innerData=r,this._innerDataExclude=n,this._comp=e,this._updateCb=i,this._beforeMergeCb=null,this._beforeUpdateCb=null,this._hidingValue=!1,this._changes=[],this._doingUpdates=null,this._propFields=o._propFields,this._observers=o._observers,this._observerTree=o._observerTree,this._relatedObserverTreeObj=o,this._observerStatus=[]};_._advancedCreate=function(e,t,r,n,o,i){return new _(e,t,r,n,o,i)};var c=function(e){this._propFields=e,this._observerIdInc=0,this._observers=[],this._observerTree={}};_._createObserverTree=function(e){return new c(e)},_.create=function(e,t,r){var n=new c({});return new _({__methodCaller:e},t,null,null,n,r)},_.setPropUpdater=function(e){i=e},_.setPropObserver=function(e){a=e},_.prototype.replaceWholeData=function(e,t){this._data=e},_.prototype.setHidingValue=function(e){this._hidingValue=!!e},_.prototype.setBeforeMergeCb=function(e){this._beforeMergeCb=e},_.prototype.setBeforeUpdateCb=function(e){this._beforeUpdateCb=e};var d=function(e,t,r){for(var o=e,i=0;i<t.length;i++){var a=t[i];if("**"===a)return n.hasGlobalWarningListeners()&&i!==t.length-1&&n.triggerWarning('"**" can only be used at the end of a path descriptor.'),o["**"]||(o["**"]=[]),void o["**"].push(r);o[a]||(o[a]={}),o=o[a]}o["~"]||(o["~"]=[]),o["~"].push(r)},u=function(e,t,r){for(var n=0;n<t.length;n++)d(e,t[n],r)},f=function(e,t,r){for(var n=e,o=0,i="";o<t.length&&(i=t[o],"**"!==i);o++){if(!n)return;n=n[i]}var a="**"===i?n["**"]:n["~"];if(a)for(o=0;o<a.length;o++)if(a[o]===r){a.splice(o,1);break}},p=function(e,t,r){for(var n=0;n<t.length;n++)f(e,t[n],r)};c.prototype.addObserver=function(e,t){var r=this._observerIdInc++;return this._observers[r]={pathObj:t,func:e},u(this._observerTree,t,r),r},c.prototype.removeObserver=function(e){var t=this._observers[e];p(this._observerTree,t.pathObj,e),this._observers[e]=null},c.prototype.moveObserver=function(e,t){var r=this._observers[e];p(this._observerTree,r.pathObj,e),r.pathObj=t,u(this._observerTree,t,e)},_.prototype.getObserverTree=function(){return this._relatedObserverTreeObj};var h=function(e,t,r){for(var o=[],i=r.pathObj,a=0;a<i.length;a++){for(var l=i[a],s=t,_=0;_<l.length;_++){var c=l[_];if("**"===c)break;if("object"!=typeof s){s=void 0;break}s=s[c]}o[a]=s}n.safeCallback("Data Observer",r.func,e.__methodCaller,o,e)},v=function(e,t){var r=null,n=0,o=-1;for(var i in e)if("~"!==i)if("**"!==i)v(e[i],t);else for(r=e["**"],n=0;n<r.length;n++)o=r[n],t[o]=!0;else for(r=e["~"],n=0;n<r.length;n++)o=r[n],t[o]=!0},m=function(e,t,r){for(var n=e,o=0;o<r.length;o++){if(n["**"])for(var i=n["**"],a=0;a<i.length;a++){var s=i[a];t[s]=!0}var _=r[o];if("number"==typeof _){if(!l.call(n,_)){n=null;break}}else if(!/^[_a-zA-Z]/.test(_)||!l.call(n,_)){n=null;break}n=n[_]}n&&v(n,t)},b=function(e,t,r,n,o){for(var i=0;i<e.length;i++){var a=e[i],l=t[i];l&&l&&(t[i]=!1,h(r,o?void 0:n,a))}};_.prototype.scheduleReplace=function(e,t,r){this._changes.push([e,t,r])},_.prototype.setChanges=function(e){this._changes=e},_.prototype.getChanges=function(){return this._changes},_.prototype.doUpdates=function(e,t){var r=this._propFields,n=this._comp,o=this._hidingValue,_=this._innerDataExclude,c=!!this._doingUpdates,d=this._relatedObserverTreeObj._observerIdInc,u=null,f=null,p=null;d?(c||(this._doingUpdates={changedPaths:[],changedValues:[],combinedChanges:[],changesTotal:0}),u=this._doingUpdates.changedPaths,f=this._doingUpdates.changedValues,p=this._doingUpdates.combinedChanges):(u=[],f=[],p=[]);var h=this._changes;this._changes=[];var v=[];this._beforeMergeCb&&this._beforeMergeCb(h,v,e);for(var g=0;g<h.length;g++){var y=h[g],w=y[0],x=y[1],C=x,S=void 0,E=w[0],O=!!_&&_.test(E),N=r[E];if(N&&1===w.length)S=this._data[E],x=i.call(this._comp,w,N,x,this._hidingValue),O||(this._innerData?(C=s(x),v[g]||(this._innerData[E]=C)):C=x,y[1]=C),O&&!this._innerData||(this._data[E]=x);else{var k=this._data,A=E,T=null,L=1;if(!O||this._innerData){for(;L<w.length;L++)T=w[L],"number"==typeof T&&isFinite(T)?l.call(k,A)&&k[A]instanceof Array||(k[A]=[]):(!l.call(k,A)||null===k[A]||"object"!=typeof k[A]||k[A]instanceof Array)&&(k[A]={}),k=k[A],A=T;k[A]=x}if(this._innerData&&(k=this._innerData,A=E,!O)){for(L=1;L<w.length;L++)T=w[L],"number"==typeof T&&isFinite(T)?l.call(k,A)&&k[A]instanceof Array||(k[A]=[]):(!l.call(k,A)||null===k[A]||"object"!=typeof k[A]||k[A]instanceof Array)&&(k[A]={}),k=k[A],A=T;C=s(x),v[g]||(k[A]=C),y[1]=C}}m(this._observerTree,this._observerStatus,w),O||(u.push(w),f.push([C,S,x]),p.push(y)),d&&(this._doingUpdates.changesTotal+=1)}if(!c){if(this._beforeUpdateCb&&this._beforeUpdateCb(e),d){var P=0;do P=this._doingUpdates.changesTotal,b(this._observers,this._observerStatus,n,this._data,o);while(P!==this._doingUpdates.changesTotal);this._doingUpdates=null}this._updateCb(u,f,p,e);for(var M=0;M<f.length;M++){var R=f[M];if(R){var D=u[M],B=D[0],I=r[B];I&&a.call(n,R[2],R[1],D,I,o,t)}}}},e.exports=_},function(e,t,r){var n=r(9),o=r(11),i=r(14),a=r(4),l=r(13),s=function(){};s.prototype=Object.create(n.prototype,{constructor:{value:s,writable:!0,configurable:!0}});var _=s._advancedCreate=function(e,t,r){var _=new s;_.is=e.toLowerCase();var c=null,d=null;if("dom"===a.documentBackend?c=l.backendExtractedDefault?new i(e):document.createElement(e):"custom"===a.documentBackend&&(d=void 0===r?a.customContext:r,d&&(c=d.createElement("image"===e?e:"empty",e))),n.initialize(_,c,t,d),_.classList=o.create(_,null),c&&"custom"===a.documentBackend&&c.associateComponent(_),t){var u=t.__wxHost;c&&"custom"===a.documentBackend&&u.__componentOptions.styleScope&&c.setStyleScope(u.__componentOptions.styleScope),_.classList._setOwnerOptions(u.classList,u.__componentOptions.classPrefix,u.__componentOptions.addGlobalClass),a.writeExtraInfoToAttr&&c&&c.setAttribute("exparser:info-class-prefix",u.__componentOptions.classPrefix&&u.__componentOptions.classPrefix+"--")}return _};s.create=function(e){return _(e,null)};var c=s._advancedClone=function(e,t){var r=new s;r.is=e.is;var _=null;if(e.__domElement&&("dom"===a.documentBackend?_=e.__domElement instanceof i?l.backendExtractedDefault?e.__domElement.cloneNode():i.toElement(e.__domElement):l.backendExtractedDefault?i.fromElement(e.__domElement):document.importNode?document.importNode(e.__domElement,!1):e.__domElement.cloneNode(!1):"custom"===a.documentBackend&&(_=e.__domElement.cloneNode())),n._clone(r,e,_,t),r.classList=o.create(r,null),_&&"custom"===a.documentBackend&&_.associateComponent(r),t){var c=t.__wxHost;r.classList._setOwnerOptions(c.classList,c.__componentOptions.classPrefix,c.__componentOptions.addGlobalClass),a.writeExtraInfoToAttr&&_&&_.setAttribute("exparser:info-class-prefix",c.__componentOptions.classPrefix&&c.__componentOptions.classPrefix+"--")}return r};s.cloneNode=function(e){return c(e,null)},e.exports=s},function(e,t,r){var n=r(9),o=r(4),i=function(e,t,r){a(this,e,t,r)};i.prototype=Object.create(n.prototype);var a=i.initialize=function(e,t,r,i){e.is=t||"";var a=null,l=null;"dom"===o.documentBackend?a=void 0:"custom"===o.documentBackend&&(l=void 0===i?o.customContext:i,
l&&(a=void 0)),n.initialize(e,a,r,l),e.__virtual=!0};i._advancedCreate=function(e,t,r){return new i(e,t,r)},i.create=function(e){return new i(e,null)},e.exports=i},function(e,t,r){var n=r(9),o=r(15),i=r(18),a=r(17),l=r(12),s=Object.prototype.hasOwnProperty,_=function(e){i.initialize(this,"shadow",this,e.__backendContext),this.__hostAssociated=!1,this.__wxHost=e,this.__childrenPropsFilter=null,this.__slotCacheDirty=!1};_.prototype=Object.create(i.prototype),_.create=function(e){var t=new _(e);if(e.ownerShadowRoot&&e.ownerShadowRoot.__childrenPropsFilter)if(t.__childrenPropsFilter)for(var r in e.ownerShadowRoot.__childrenPropsFilter)t.__childrenPropsFilter[r]||(t.__childrenPropsFilter[r]=e.ownerShadowRoot.__childrenPropsFilter[r]);else t.__childrenPropsFilter=e.ownerShadowRoot.__childrenPropsFilter;return t};var c=function(e,t){var r={};for(var n in e){var i=e[n];"object"!=typeof i&&(s.call(t.__using,i)?i=t.__using[i]:s.call(t.__generics,i)&&(i=t.__generics[i]||o._list[""]),r[n]=i)}return r},d=function(e,t){var r={};for(var n in e){var i=e[n];"object"!=typeof i&&s.call(t.__placeholder,i)&&(i=t.__placeholder[i],s.call(t.__using,i)?i=t.__using[i]:s.call(t.__generics,i)&&(i=t.__generics[i]||o._list[""]),r[n]=i)}return r},u="abcdefghijklmnopqrstuvwxyz",f=function(){for(var e=Date.now(),t="exparser-",r=0;r<8;r++){var n=(e+Math.floor(26*Math.random()))%26;e=Math.floor(e/26),t+=u[n]}return t};_.prototype.createTextNode=function(e){return l._advancedCreate(e,this,this.__backendContext)},_.prototype.createNativeNode=function(e){return a._advancedCreate(e,this,this.__backendContext)},_.prototype.cloneNativeNode=function(e){return a._advancedClone(e,this)},_.prototype.createVirtualNode=function(e){return i._advancedCreate(e,this,this.__backendContext)},_.prototype.getCompDefByTagName=function(e){var t=this.__wxHost;return s.call(t.__using,e)?t.__using[e]:s.call(t.__generics,e)?t.__generics[e]:e},_.prototype.createComponent=function(e,t,r,n){var i=null;i=void 0===t?e:t;var a=this.__wxHost;"object"!=typeof i&&(i=this.getCompDefByTagName(i),"object"!=typeof i&&(i=o._list[i]||o._list[""]));var l=d(r,a);return r&&(r=c(r,a)),"object"==typeof e&&(e=i.is),a.__componentOptions.randomizeTagName&&(e=f()),a.__componentOptions.writeOnly&&!i.options.allowInWriteOnly&&(i=o._list[""]),o._advancedCreate(e,i,this,this.__backendContext,r,l,n)},_.prototype.tagNameUsed=function(e){var t=this.__wxHost;return!!s.call(t.__using,e)||(!!s.call(t.__placeholder,e)||(!!s.call(t.__generics,e)||!!s.call(t.__placeholder,e)))},_.prototype.getHostNode=function(){return this.__wxHost},_.prototype.getElementById=function(e){return n._updateIdMap(this.__wxHost),this.__wxHost.__idCache[e]},e.exports=_},function(e,t,r){var n=r(9),o=r(12),i=function(){};i.create=function(e,t,r){var a=new i;if(!(e instanceof n||e instanceof o))throw new Error("ElementIterator can only be used for exparser.Element or exparser.TextNode");a._elem=e,a._elemTypeLimit=r||n;var l=t.split("-");if("shadow"===l[0])a._composed=!1;else{if("composed"!==l[0])throw new Error("Unrecognized iterator type: "+t);a._composed=!0}if("ancestors"===l[1])a._relation="ancestors",a._order=0;else{if("descendants"!==l[1])throw new Error("Unrecognized iterator type: "+t);if(a._relation="descendants","root"!==l[2])throw new Error("Unrecognized iterator type: "+t);if("first"===l[3])a._order=-1;else{if("last"!==l[3])throw new Error("Unrecognized iterator type: "+t);a._order=1}}return a};var a=function(e,t,r,n){for(;e;e=r?e.__wxSlotParent||e.__wxHost||e.parentNode:e.parentNode)if(e instanceof t&&n(e)===!1)return!1;return!0},l=function(e,t,r,n,o){if(n<0&&e instanceof t&&o(e)===!1)return!1;var i=r?e.__wxSlotChildren||e.childNodes:e.childNodes;if(i)for(var a=0;a<i.length;a++)if(l(i[a],t,r,n,o)===!1)return!1;return!(n>0&&e instanceof t&&o(e)===!1)};i.prototype.forEach=function(e){return"ancestors"===this._relation?a(this._elem,this._elemTypeLimit,this._composed,e):l(this._elem,this._elemTypeLimit,this._composed,this._order,e)},e.exports=i},function(e,t,r){var n=r(4),o=r(3),i=!1,a=[],l=[],s=function(e){var t=a;a=[];var r=l;l=[],i=!0;for(var _=r.length,c=0;c<r.length;c++){var d=r[c];d.render(function(){if(_--,0===_){i=!1,a.length&&(n.hasDOMBackend&&"function"==typeof requestAnimationFrame?requestAnimationFrame(s):setTimeout(s,16));for(var e=0;e<t.length;e++)"function"==typeof t[e]&&o.safeCallback("render",t[e],null,[])}})}},_=function(e,t){a.push(t||null),l.indexOf(e)<0&&l.push(e),i||1!==a.length||(n.hasDOMBackend&&"function"==typeof requestAnimationFrame?requestAnimationFrame(s):setTimeout(s,16))};t.triggerRender=function(e,t){"function"==typeof e?"custom"===n.documentBackend&&n.customContext&&_(n.customContext,e):e.__backendContext&&_(e.__backendContext,t)}},function(e,t,r){var n=r(4),o=r(3),i=r(9),a=r(17),l=r(12),s=r(19),_=r(15),c=r(23),d=r(24),u=function(){};u.prototype=Object.create(Object.prototype,{constructor:{value:u,writable:!0,configurable:!0}});var f=function(){};f.prototype=Object.create(Object.prototype,{constructor:{value:f,writable:!0,configurable:!0}});var p=null,h=null;u.precompiler=h,u.htmlParser=p;var v=function(e){return e.replace(/-([a-z])/g,function(e,t){return t.toUpperCase()})},m=Object.prototype.hasOwnProperty,b=function(e,t){if(null!==e&&"object"==typeof e&&m.call(e,t))return e[t]},g=function(e,t,r,n){if(m.call(t,r)){var i=t[r];if("function"==typeof i)return o.safeCallback("Template Method",i,e,n)}},y={t:1,n:'"slot"',v:!0,sn:"",a:[],c:[],p:null},w=function(e,t,r){e.classList.toggle(t,!!r)},x=function(e,t,r){e[t]=r},C=function(e,t,r){var n=e.__dataProxy;n.scheduleReplace([t],r),n.doUpdates()},S=function(e,t,r){e.class=r},E=function(e,t,r){"dom"===n.documentBackend?e.setAttribute("style",r):"custom"===n.documentBackend&&e.setStyle(r)},O=function(e,t,r){e.setAttribute("class",r)},N=function(e,t,r){e.textContent=r},k=function(e,t,r){e.dataset||(e.dataset={}),e.dataset[t]=r},A={$:function(e,t,r){r===!0?e.setAttribute(t,""):r===!1||void 0===r||null===r?e.removeAttribute(t):e.setAttribute(t,r)},":":x,c:w,s:function(e,t,r){var n=e.style;n&&(n[t]=r)},d:k},T=function(e,t,r){return[{t:1,n:"slot",v:!0,sn:"",a:[],c:[]}]};u.create=function(e,t,r,n){var i=void 0===e.template?T:e.template,a=i;if("function"!=typeof i)if(h&&"undefined"!=typeof window&&"undefined"!=typeof document){var l="__exparserFreeTmpl",s=h.compile(i),_=document.createElement("script");_.type="text/javascript",_.innerHTML="window."+l+"="+s,document.head.appendChild(_),document.head.removeChild(_),a=window[l],window[l]=null}else if("undefined"!=typeof process&&"undefined"!=typeof process.versions&&"undefined"!=typeof process.versions.node)a=u.precompileAndGetCreator(i);else if(h){var c=h.compile(i),d=new Function("return "+c);a=d()}else o.hasGlobalWarningListeners()&&o.triggerWarning("Non-precompiled template is not usable in this environment. Empty template is used instead."),a=T;var f=Object.create(u.prototype);return f._initValuesJSON=JSON.stringify(r),t!==r?f._dataJSON=JSON.stringify(t):f._dataJSON=null,f._tagTreeRoot=L(a,r,e.methods,n),f._renderingMode=n.renderingMode,f};var L=function(e,t,r,o){var i=o.renderingMode,l="native"===i,s=l,_=!1,c=Object.create(null);l&&!n.hasDOMBackend&&(e=T);var u={},f=e(b,g,r),p=function(e){for(var r=0;r<e.length;r++){var o=e[r];if(3!==o.t){var i=o.n,c=!(l||"string"==typeof i&&i.indexOf("-")<0);"slot"===i&&""===o.sn&&(_=!0),o.n=i;var f=o.st;f&&f.e&&(f.o=E,s&&(f.v=f.e(t,u,null)));var h=o.cl;h&&h.e&&(h.o=l?O:S,s&&(h.v=h.e(t,u,null)));var m=null;c||(o.p=m=l?document.createElement(o.n):a.create(o.n),f&&void 0!==f.v&&("dom"===n.documentBackend?m.setAttribute("style",f.v):"custom"===n.documentBackend&&m.__domElement.setStyle(f.v)),l&&h&&void 0!==h.v&&m.setAttribute("class",h.v));for(var b=o.a,g=0;g<b.length;g++){var y=b[g];if(y.d)l||d[y.n].register(y.n,y,o);else{l||("bind"===y.n.slice(0,4)?(y.evCatch=!1,y.ev=v(y.n.slice(4)),":"===y.ev[0]&&(y.ev=y.ev.slice(1))):"catch"===y.n.slice(0,5)&&(y.evCatch=!0,y.ev=v(y.n.slice(5)),":"===y.ev[0]&&(y.ev=y.ev.slice(1))));var k=y.o;if(c)k?"&"===k?y.o=A[":"]:y.o=A[k]:(y.o=A[":"],y.n=v(y.n)),y.o===x&&(y.o=C),s&&y.e&&(y.v=y.e(t,u,null));else if(!y.ev){var T=A;k?"&"===k?y.o=T[":"]:y.o=T[k]:y.o=T.$,s?(y.e&&(y.v=y.e(t,u,null)),(y.o!==w||l)&&y.o(m,y.n,y.v)):y.e||y.o(m,y.n,y.v)}}}p(o.c),l&&(1!==o.c.length||void 0===o.c[0].sn||o.c[0].compressed||(o.sn=o.c[0].sn,o.compressed=!0,o.c.pop()))}else o.e&&(o.o=N,o.c=s?o.e(t,u,null):"")}};return p(f,c,!0),l&&(_||f.push(y),1!==f.length||""!==f[0].sn||f[0].compressed||f.pop()),f},P=function(e,t){return function(r){if(this[e](r),t)return!1}},M=function(e,t,r,o,a,l,s,u){for(var f=null,p=0,h=null,v=0;v<e.length;v++){var m=s,b=e[v];if(3===b.t)f=b.e?t.createTextNode(b.e(o,a,null)):t.createTextNode(b.c),b.e&&c.addBindings(l,m,b.b,f,b),i.appendChild(r,f);else{var g=b.cl,y=b.st,S=b.a,E=!1;for(p=0;p<S.length;p++)if(h=S[p],h.d){var O=d[h.n].create(h.n,h,b,o,a,l,m,u,t,M,r);if(d[h.n].requireBlock){f=O,i.appendChild(r,f),E=!0;break}}if(E)continue;if(b.v)f=t.createVirtualNode(b.n);else if(b.p){for(f=t.cloneNativeNode(b.p),p=0;p<S.length;p++)h=S[p],h.d||(h.ev?u(f,h.ev,h.v,h.evCatch):h.o===x?f.__domElement&&(h.o(f.__domElement,h.n,h.e(o,a,null)),c.addBindings(l,m,h.b,f.__domElement,h)):(h.e&&h.o(f,h.n,h.e(o,a,null)),(h.e||h.o===w||h.o===k)&&c.addBindings(l,m,h.b,f,h)));y&&y.e&&("dom"===n.documentBackend?f.setAttribute("style",y.e(o,a,null)):"custom"===n.documentBackend&&f.__domElement.setStyle(y.e(o,a,null)),c.addBindings(l,m,y.b,f,y))}else{if(b.cpf){var N={},A=t.__wxHost;for(var T in b.cpf)!function(e){var t=b.cpf[e];N[e]=A.__behavior.methods[t]}(T);t.__childrenPropsFilter=N}for(f=t.createComponent(b.n,void 0,b.g,void 0),p=0;p<S.length;p++)if(h=S[p],!h.d){var L=h.v;h.o===C&&_.hasPublicProperty(f,h.n)?(h.e&&(L=h.e(o,a,null),c.addBindings(l,m,h.b,f,h)),h.e?C(f,h.n,L):f.__behavior.properties[h.n].type===Boolean?C(f,h.n,!0):C(f,h.n,L)):h.ev?u(f,h.ev,L,h.evCatch):h.o!==C&&(h.e&&(L=h.e(o,a,null),c.addBindings(l,m,h.b,f,h)),h.o(f,h.n,L))}y&&(y.e?("dom"===n.documentBackend?f.__domElement.setAttribute("style",y.e(o,a,null)):"custom"===n.documentBackend&&f.__domElement.setStyle(y.e(o,a,null)),c.addBindings(l,m,y.b,f.__domElement,y)):"dom"===n.documentBackend?f.__domElement.setAttribute("style",y.v):"custom"===n.documentBackend&&f.__domElement.setStyle(y.v))}b.id&&(f.id=b.id),g&&(g.e?f.class=g.e(o,a,null):f.class=g.v,g.o&&c.addBindings(l,m,g.b,f,g)),b.sl&&(f.slot=b.sl),void 0!==b.sn&&i.setSlotName(f,b.sn),i.appendChild(r,f),M(b.c,t,f,o,a,l,m,u)}}},R=function(e,t,r){for(var n=e.childNodes,o=0;o<n.length;o++){var i=n[o];i instanceof l||(i.__id&&(t[i.__id]=i),void 0!==i.__slotName&&(r[i.__slotName]=i),R(i,t,r))}},D=function(e,t,r,n,o,i){for(var a=null,l=0,s=null,_=0;_<e.length;_++){var d=e[_];if(void 0===d.n)a=document.createTextNode(d.c),d.e&&c.addBindings(o,i,d.b,a,d),t.appendChild(a);else{var u=d.cl,f=d.st,p=d.a;for(a=d.v?document.createElement("virtual"):document.importNode?document.importNode(d.p,!1):d.p.cloneNode(!1),l=0;l<p.length;l++)s=p[l],s.e&&c.addBindings(o,i,s.b,a,s);t.appendChild(a),d.id&&(r[d.id]=a),u&&u.e&&c.addBindings(o,i,u.b,a,u),f&&f.e&&c.addBindings(o,i,f.b,a,f),void 0!==d.sn&&(n[d.sn]=a),D(d.c,a,r,n,o,i)}}};u.prototype.createInstance=function(e){var t=Object.create(f.prototype),r=JSON.parse(this._initValuesJSON),o=null===this._dataJSON?r:JSON.parse(this._dataJSON),i=Object.create(null),a=Object.create(null),l=[],_=c.create("",null,null,null,null,[],function(e,t){}),d=null;if("native"===this._renderingMode)"dom"===n.documentBackend&&(d=document.createDocumentFragment()),D(this._tagTreeRoot,d,i,a,_,{}),a[""]||(a[""]=null);else{var u=function(e,t,r,n){d.__wxHost?e.addListener(t,P(r,n).bind(d.__wxHost)):l.push({target:e,name:t,func:P(r,n)})};if(d=s.create(e),e.ownerShadowRoot&&e.ownerShadowRoot.__childrenPropsFilter)if(d.__childrenPropsFilter)for(var p in e.ownerShadowRoot.__childrenPropsFilter)d.__childrenPropsFilter[p]||(d.__childrenPropsFilter[p]=e.ownerShadowRoot.__childrenPropsFilter[p]);else d.__childrenPropsFilter=e.ownerShadowRoot.__childrenPropsFilter;M(this._tagTreeRoot,d,d,r,{},_,{},u),R(d,i,a)}return t.data=o,t.shadowRoot=d,t.idMap=i,t.slots=a,t.listeners=l,t._topScope=_,t},f.prototype.updateValues=function(e,t,r){for(var n=i.getMethodCaller(e),o=0;o<r.length;o++){var a=r[o];c.updateBinding(this._topScope,a,t,{},n)}},e.exports=u},function(e,t){var r={};r.create=function(e,t,r,o,i,a,l){for(var s={inc:1,name:e,exp:o,lp:i,scopes:{},targets:{},children:null,lu:l,__scopeBinded:[]},_=0;_<a.length;_++){var c=a[_];null===c[0]?n(t,c,null,s):n(r[c[0]],c,null,s)}return s},r.proxyTopScope=function(e){var t={inc:1,linked:e,scopes:{},targets:{},children:null,__scopeBinded:[]};return n(e,[null],null,t),t},r.proxySubScopes=function(e){var t={};for(var r in e)t[r]={inc:1,linked:e[r],scopes:{},targets:{},children:null,__scopeBinded:[]},n(e[r],[null],null,t[r]);return t};var n=r.addBinding=function(e,t,r,n){for(var o=e,i=1;i<t.length;i++){var a=t[i];o.children||(o.children=Object.create(null));var l=o.children;l[a]||(l[a]={scopes:{},targets:{},children:null}),o=l[a]}var s=e.inc++;return r?o.targets[s]=[r,n]:(o.scopes[s]=n,n.__scopeBinded.push([o,s])),s};r.addBindings=function(e,t,r,o,i){for(var a=0;a<r.length;a++){var l=r[a];l[0]?n(t[l[0]],l,o,i):n(e,l,o,i)}},r.updateLvaluePath=function(e,t){e.lp=t},r.removeBindingsForScope=function(e){for(var t=e.__scopeBinded,r=0;r<t.length;r++){var n=t[r];delete n[0].scopes[n[1]]}};var o=function(e,t,r,n,o){if(e.linked)return void i(e,t,r,n,o);var a=n[e.name];n[e.name]=e.exp(r,n,o),i(e,t,r,n,o),n[e.name]=a},i=r.updateBinding=function(e,t,r,n,i){for(var a=e,l=0,s=0;s<t.length;s++){for(l in a.scopes)o(a.scopes[l],t,r,n,i);var _=t[s];if(!a.children)return;var c=a.children;if(!c[_])return;a=c[_]}var d=function(e){for(l in e.targets){var t=e.targets[l],a=t[1];a.o(t[0],a.n,a.e(r,n,i))}for(l in e.scopes)o(e.scopes[l],[],r,n,i);for(l in e.children)d(e.children[l])};d(a)};e.exports=r},function(e,t,r){e.exports={if:r(25),elif:r(25),else:r(25),for:r(27),key:r(28),"for-index":r(29),"for-item":r(30),alias:r(31)}},function(e,t,r){var n=r(23),o=r(26).RUNTIME_NAMES;o.TOP_SCOPE+","+o.SUB_SCOPE+","+o.CALLER;e.exports={requireBlock:!0,register:function(e,t,r){},create:function(e,t,r,o,i,a,l,s,_,c,d){var u=_.createVirtualNode("wx:"+e);u.__wxIfCondValue=!0,u.__wxIfNextNode=null,u.__wxIfHasTrueCond=!0;var f=null;"if"!==e&&(f=d.childNodes[d.childNodes.length-1],"wx:if"!==f.is&&"wx:elif"!==f.is?f=null:f.__wxIfNextNode=u),r.id&&(u.id=r.id);var p=u.__wxIfUpdateNode=function(){var e=u.__wxIfCondValue;if(f&&f.__wxIfHasTrueCond&&(e=!1),e&&!u.childNodes.length){var t=n.proxyTopScope(a),d=n.proxySubScopes(l);u.__wxTopScope=t,u.__wxSubScopes=d,c(r.c,_,u,o,i,t,d,s)}else if(!e&&u.childNodes.length){n.removeBindingsForScope(u.__wxTopScope);for(var p in u.__wxSubScopes)n.removeBindingsForScope(u.__wxSubScopes[p]);for(;u.childNodes.length;)u.removeChild(u.childNodes[0])}u.__wxIfNextNode&&u.__wxIfNextNode.__wxIfUpdateNode()},h=function(e){u.__wxIfCondValue=!!e,u.__wxIfHasTrueCond=u.__wxIfCondValue||f&&f.__wxIfHasTrueCond,p()};return"else"===e?h(!0):(n.addBindings(a,l,t.b,u,{e:t.d,o:function(e,t,r){h(r)}}),h(t.d(o,i,null))),u}}},function(e,t){t.TAG_TYPES={TAG_START:1,TAG_END:-1,TEXT:3,COMMENT:8},t.RUNTIME_NAMES={MEMBER:"m",CALL:"f",METHODS:"e",CALLER:"c",TOP_SCOPE:"t",SUB_SCOPE:"s"};var r=t.STRING_UNESCAPE_MAP={n:"\n",r:"\r",b:"\b",f:"\f",t:"\t",v:"\v",'"':'"',"'":"'","\\":"\\","\r":"\r","\n":"\n"},n=t.STRING_ESCAPE_MAP={},o="";for(var i in r)n[r[i]]=i,o+=r[i];t.STRING_ESCAPE_REGEXP=new RegExp("["+o+"]","g")},function(e,t,r){var n=(r(18),r(23)),o=r(26).RUNTIME_NAMES;o.TOP_SCOPE+","+o.SUB_SCOPE+","+o.CALLER;e.exports={requireBlock:!0,addDefaultAttrs:[{n:"wx:for-index",v:"index"},{n:"wx:for-item",v:"item"}],register:function(e,t,r){},create:function(e,t,r,o,i,a,l,s,_,c){var d=r._wxForIndex||"index",u=r._wxForItem||"item",f=r._wxKey,p=_.createVirtualNode("wx:for:list");r.id&&(p.id=r.id),n.create("",a,l,function(e,r,n){var o=t.d(e,r,null);return g(o,e,r,n),o},t.l,t.b);var h=function(e,t,o,i,f){var h=_.createVirtualNode("wx:for:item"),v=n.proxyTopScope(a),m=n.proxySubScopes(l);h.__wxTopScope=v,h.__wxSubScopes=m,h.__wxForToRemove=!1,h.__wxForKeyStr="";var b=n.create(d,v,m,null,null,[]),g=n.create(u,v,m,null,[o],[]);return m[d]=b,m[u]=g,t[d]=o,t[u]=i,c(r.c,_,h,e,t,v,m,s),void 0===f?p.appendChild(h):p.insertBefore(h,f),h},v=function(e,t,r,i,a,l){var s=e.__wxSubScopes[u];n.updateLvaluePath(s,[i]),a&&(l?p.insertBefore(e,l):p.appendChild(e));var _=e.__wxSubScopes[d];r[d]=i,n.updateBinding(_,[],o,r,t)},m=function(e,t,r,o,i,a){o[u]=i,n.updateBinding(e.__wxSubScopes[u],t,r,o,a)},b=function(e){n.removeBindingsForScope(e.__wxTopScope);for(var t in p.__wxSubScopes)n.removeBindingsForScope(e.__wxSubScopes[t]);p.removeChild(e)},g=function(e,t,r,n){var o="",i=e;"object"==typeof e&&null!==e||(i=[]);var a={};for(o in r)a[o]=r[o];var l=0;if(f){var s=[],_=e instanceof Array,c=[];if(!_){var d=i;i=[];for(o in d)i.push(d[o]),c.push(o)}for(l=0;l<i.length;l++)s.push(String(i[l][f]));if(0===i.length)for(;p.childNodes.length;)b(p.childNodes[0]);else{var u=Object.create(null),g=Object.create(null),y=p.childNodes,w=null,x="";for(l=0;l<y.length;l++)w=y[l],x=w.__wxForKeyStr,u[x]>=0?(b(w),l--):(u[x]=l,g[x]=w,w.__wxForToRemove=!0);var C=-1,S=0,E=1,O=[];for(S=u[i[0][f]],S>=0||(S=-1),y[S]&&(y[S].__wxForToRemove=!1),l=1;l<i.length;l++)E=u[i[l][f]],E>=0&&(C<S&&(S<E||C>E)&&(O.push(y[S]),C=S),S=E,y[S]&&(y[S].__wxForToRemove=!1));for(C<S&&O.push(y[S]),l=0;l<y.length;l++)w=y[l],w.__wxForToRemove&&(b(w),l--);var N=O.shift(),k=0;for(l=0;l<i.length;l++){var A=i[l],T=g[A[f]];if(g[A[f]]=null,T){var L=!0;if(T===N){for(;y[k]!==N;)k++;k++,N=O.shift(),L=!1}w=T,v(w,n,a,_?l:c[l],L,y[k]),L&&y[k]===w&&k++,m(w,[],t,a,i[l],n)}else w=h(t,a,_?l:c[l],i[l],y[k]),k++,w.__wxForKeyStr=String(A[f])}}}else{for(;p.childNodes.length;)b(p.childNodes[0]);if(e instanceof Array)for(l=0;l<i.length;l++)h(t,a,l,i[l]);else for(o in i)h(t,a,o,i[o])}};return g(t.d(o,i,null),o,i,null),p}}},function(e,t){e.exports={attachedToBlock:!0,register:function(e,t,r){r._wxKey=t.d},create:function(){}}},function(e,t){e.exports={attachedToBlock:"for",register:function(e,t,r){r._wxForIndex=t.d},create:function(){}}},function(e,t){e.exports={attachedToBlock:"for",register:function(e,t,r){r._wxForItem=t.d},create:function(){}}},function(e,t,r){var n=r(23),o=r(26).RUNTIME_NAMES;o.TOP_SCOPE+","+o.SUB_SCOPE+","+o.CALLER;e.exports={requireBlock:!0,register:function(e,t,r){},create:function(e,t,r,o,i,a,l,s,_,c){var d=t.s[0],u=n.create(d,a,l,t.d,t.l,t.b),f={},p="";for(p in l)f[p]=l[p];f[d]=u;var h={};for(p in i)h[p]=i[p];h[d]=t.d(o,i,null);var v=_.createVirtualNode("wx:alias");return r.id&&(v.id=r.id),c(r.c,_,v,o,h,a,f,s),v}}}]);

/***/ }),

/***/ 973:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfuECPtVA21wLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLW1hc2ttcC1idWJibGUtYWN0aW9uLXNoZWV0LS1tZW51bXAtYnViYmxlLWFjdGlvbi1zaGVldC0tY2VsbG1wLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNlbGwtaW1nLWNvbnRhaW5lcm1wLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNlbGwtaW1nLWNvbnRhaW5lcm1wLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNlbGxfX2hvdmVybXAtYnViYmxlLWFjdGlvbi1zaGVldC0tY2VsbC1pbWdtcC1idWJibGUtYWN0aW9uLXNoZWV0LS1jZWxsLWRlc2NtcC1idWJibGUtYWN0aW9uLXNoZWV0LS1mb290bXAtYnViYmxlLWFjdGlvbi1zaGVldC0tYnV0dG9uc2FmZS1hcmVhLWluc2V0LWJvdHRvbW1wLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWJ1dHRvbl9fYmVmb3JlbXAtYnViYmxlLWFjdGlvbi1zaGVldC0tYnV0dG9uX19jb250ZW50bXAtYnViYmxlLWFjdGlvbi1zaGVldC0tYnV0dG9uX19ob3Zlcm1wLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNvbnRlbnRtcC1idWJibGUtYWN0aW9uLXNoZWV0LS1jb250ZW50bXAtYnViYmxlLWFjdGlvbi1zaGVldC0tbWVudW1wLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNlbGwtaW1nLWNvbnRhaW5lcm1wLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNlbGwtaW1nLWNvbnRhaW5lcm1wLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNlbGxfX2hvdmVybXAtYnViYmxlLWFjdGlvbi1zaGVldC0tY2VsbC1kZXNjbXAtYnViYmxlLWFjdGlvbi1zaGVldC0tYnV0dG9ubXAtYnViYmxlLWFjdGlvbi1zaGVldC0tYnV0dG9uX19iZWZvcmVtcC1idWJibGUtYWN0aW9uLXNoZWV0LS1idXR0b25fX2NvbnRlbnRtcC1idWJibGUtYWN0aW9uLXNoZWV0LS1idXR0b25fX2hvdmVyMi4xLjQBAAEA+/UEFjkODAEKAAAAAAMBABwBABAlBQICQgBIBkIEAAAAAEcGQgQAAAAARgZCBAAAAABJBkIEAAAAAAAAAABxDgwBChwAHAADARwcAQAQXQ4IAkIAMAZCBO3t7f8CAkEASAZCBAAAAABHBkIEAAAAAEEGQgQAAApDQAZIBAAAgD9SBkIEAADAQVEGQgQAAMBBUwZCBAAAwEFQBkIEAADAQQECQgAgAkAAJQJFAAAAAAAZDgwBCjgAOAADATgcAQAQBQECAkEAAAAAANEODAEKVABUAAMBVCoBABC9GAgCQgBABkIEAABgQkEGQgQAAGBCUgZCBAAAQEFRBkIEAABAQVMGQgQAAEBBUAZCBAAAQEEwBkIE/////2YGQgQAAAAAYwZCBAAAAABpBkIEAAAAAGAGQgQAAAAAZwJAAGQCQABqAkAAYQJAAGgCQABlAkAAawJAAGICQABwDkAMAgQAAEBBAgQAAEBBcQ5ADAIEAABAQQIEAABAQXIOQAwCBAAAQEECBAAAQEFzDkAMAgQAAEBBAgQAAEBBAAAAACgZFwEVfgB+AAMBfioCCwqoAKgAAwGoIwEAIAkBMAZCBOzs7P8AAAAAJQ4MAQrLAMsAAwHLIAEAEBECQAZCBAAAAEJBBkIEAAAAQgAAAAAxDgwBCusA6wADAeshAQAQHQSQBkIEAAAgQREGQgQAAACAlAJBAFYGQgQAAABBAAAAACcUEgEQ+wwBAPsMAQAFAfsMARwBABANAgICQQBABkgEAACAPwAAAAAzFBIBEPsoAQD7KAEABQH7KAEeAQAQGQMCAkEAUwpJCAEG+0YBFgAAMAZCBP////8AAAAAbRQSARD7XAEA+1wBAAUB+1wBJgEAEFMIAgJCAEgGQgQAAAAARgZCBAAAAABHBkIEAAAAAEEGQgQAAIA/MAZCBAAAABrVFEASAgQAAAAAAgQAAAAAAgQAAAAACQ5ADAsBBQgAAIA/AAAAPwAAAABpFBIBEPuCAQD7ggEABQH7ggEnAQAQTwsIAkIAUgZCBAAAAABRBkIEAACAQVMGQgQAAAAAUAZCBAAAgEGUAkEAkAZCBAAAiEGTCEEGAgQAAGBCmgJCABEGQgQAAADmQQZCBAAAYEIAAAAAIxQSARD7qQEA+6kBAAUB+6kBJQEAEAkBMAZCBOzs7P8AAAAAJBQSARD7zgEA+84BAAUB+84BHwEAEAkBQAZDBAAAyEIBAQAAACQUEgEQ++0BAPvtAQAFAfvtAR8BABAJAUAGRAQAAMhCAQEBAAAkFBIBEPsMAgD7DAIABQH7DAIcAQAQCQEwBkIEERER/wEBAgAAJBQSARD7KAIA+ygCAAUB+ygCKgEAEAkBMAZCBB8fH/8BAQIAADUlIwEh+1ICAPtSAgAFAftSAioCERD7fAIA+3wCAAUB+3wCIwEAIAkBMAZCBDc3N/8BAQIAACQUEgEQ+58CAPufAgAFAfufAiEBABAJAREGQgT///+AAQECAAAkFBIBEPvAAgD7wAIABQH7wAIeAQAQCQEwBkIEHx8f/wEBAgAAJBQSARD73gIA+94CAAUB+94CJgEAEAkBMAZCBP///w0BAQIAACQUEgEQ+wQDAPsEAwAFAfsEAycBABAJAREGQgT////MAQECAAAkFBIBEPsrAwD7KwMABQH7KwMlAQAQCQEwBkIENzc3/wEBAgAAKwMNAAAKAQgAAAUBAgIBAA0AAAoBCAAABQECAgIADQAACgEIAAAFAQkCAgD7UAMF");
  

/***/ }),

/***/ 124:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfuWB/voAW1wLWRpYWxvZy0tcm9vdG1wLWRpYWxvZy0tbWFza21wLWRpYWxvZy0tbWFza19faW5tcC1kaWFsb2ctLWNvbnRhaW5lcm1wLWRpYWxvZy0tY29udGVudG1wLWRpYWxvZy0tY29udGVudF9faW5tcC1kaWFsb2ctLWhlYWRtcC1kaWFsb2ctLXRpdGxlbXAtZGlhbG9nLS1ib2R5bXAtZGlhbG9nLS1mb290bXAtZGlhbG9nLS1mb290bXAtZGlhbG9nLS1mb290X19hZnRlcm1wLWRpYWxvZy0tYnV0dG9ubXAtZGlhbG9nLS1idXR0b25fX2FjdGl2ZW1wLWRpYWxvZy0tYnV0dG9uX19hZnRlcm1wLWRpYWxvZy0tYnV0dG9uX19maXJzdC1jaGlsZF9fYWZ0ZXJtcC1kaWFsb2ctLWJ1dHRvbl9fZGVmYXVsdG1wLWRpYWxvZy0tY29udGVudG1wLWRpYWxvZy0tYm9keW1wLWRpYWxvZy0tYnV0dG9ubXAtZGlhbG9nLS1idXR0b25fX2RlZmF1bHRtcC1kaWFsb2ctLWJ1dHRvbl9fYWN0aXZlbXAtZGlhbG9nLS1mb290X19hZnRlcm1wLWRpYWxvZy0tYnV0dG9uX19hZnRlcjIuMS40AQABAPuQBRdJDgwBCgAAAAADAQAPAQAQNQlBBkQEAADIQkAGQwQAAMhCAQJCAJAGQgQAAIBBAwJBAAQCQQAgAkIAIgJCAAcGQAQAQHpEAAAAALMODAEKDwAPAAMBDw8BABCfEgICQgBIBkIEAAAAAEcGQgQAAAAARgZCBAAAAABJBkIEAAAAADAGQgQAAACZMQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAABIGQAQAAAAAgAZABAMBBACBBUADAgHIggZABAMBAgCDBUADAgEAAAAAAB0ODAEKHgAeAAMBHhMBABAJARIGQAQAAIA/AAAAAEUODAEKMQAxAAMBMRQBABAxCAICQgBIBkIEAAAAAEcGQgQAAAAARgZCBAAAAABJBkIEAAAAAAECQgAlAkAAIgJCAAAAAACfDgwBCkUARQADAUUSAQAQixAwBkIE/////5QCQQBwDkAMAgQAAABBAgQAAABBcQ5ADAIEAAAAQQIEAAAAQXIOQAwCBAAAAEECBAAAAEFzDkAMAgQAAABBAgQAAABBAwJBAAQCQQABAkIAIAJCAEAGQgQAAKBDEgZABAAAAACABkAEAwEEAIEFQAMCAciCBkAEAwECAIMFQAMCAQAAAAAAHQ4MAQpXAFcAAwFXFgEAEAkBEgZABAAAgD8AAAAAPQ4MAQptAG0AAwFtDwEAECkFVgZCBAAAAEJUBkIEAADAQVcGQgQAAAAAVQZCBAAAwEFBBkIEAADAQQAAAAArDgwBCnwAfAADAXwQAQAQFwOVAkEAkAZCBAAAiEGTCEIGAAQzM7M/AAAAAD8ODAEKjACMAAMBjA8BABArBVAGQgQAAMBBUQZCBAAAwEGQBkIEAACIQZMIQgYABDMzsz8RBkIEAAAAgAAAAAAZDgwBCpsAmwADAZsPAQAQBQEBAkIAAAAAADMODAEKqgCqAAMBqg8BABAfBAICQQBBBkIEAABgQpMIQQYCBAAAYEKQBkIEAACIQQAAAABnDgwBCrkAuQADAbkWAQAQUwgCAkIARgZCBAAAAABIBkIEAAAAAEcGQgQAAAAAQQZCBAAAgD8wBkIEAAAAGtUUQBICBAAAAAACBAAAAAACBAAAAAAJDkAMCwEFCAAAgD8AAAA/AAAAAEUODAEKzwDPAAMBzxEBABAxCAECQQAmBkAEAACAPycGQAQAAIA/KAZCBAAAAAARBkIEV2uV/5UCQQCgAkAAAgJBAAAAAAAdDgwBCuAA4AADAeAZAQAQCQEwBkIE7Ozs/wAAAABnDgwBCvkA+QADAfkYAQAQUwgCAkIARgZCBAAAAABIBkIEAACAP0AGQgQAAIA/SQZCBAAAAAAwBkIEAAAAGtUUQBICBAAAAAACBAAAAAACBAAAAAAJDkAMCwEFCAAAAD8AAIA/AAAAAB8UEgEQ+xEBAPsRAQAFAfsRASUBABAFAQECQAAAAAAAIxQSARD7NgEA+zYBAAUB+zYBGgEAEAkBEQZCBAAAAOYAAAAALBQSARD7UAEA+1ABAAUB+1ABEgEAEBECMAZCBB4eHv8RBkIE/////wEBAAAALBQSARD7YgEA+2IBAAUB+2IBDwEAEBECMAZCBB4eHv8RBkIE////gAEBAAAAJBQSARD7cQEA+3EBAAUB+3EBEQEAEAkBEQZCBH2Qqf8BAQAAACQUEgEQ+4IBAPuCAQAFAfuCARoBABAJAREGQgT///+ZAQEAAAAkFBIBEPucAQD7nAEABQH7nAEZAQAQCQEwBkIENzc3/wEBAAAANSUjAhD7tQEA+7UBAAUB+7UBFgEAEPvLAQD7ywEABQH7ywEYAQAQCQEwBkIE////DQEBAAAADwENAAAKAQgAAAUBCQICAPvjAQU=");
  

/***/ }),

/***/ 210:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AftMB/ufAm1wLWhhbGYtc2NyZWVuLWRpYWxvZy0tY29udGVudHNhZmUtYXJlYS1pbnNldC1ib3R0b21tcC1oYWxmLXNjcmVlbi1kaWFsb2ctLWhlYWRtcC1oYWxmLXNjcmVlbi1kaWFsb2ctLXRpdGxlbXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1ib2R5bXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1mb290bXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1mb290LXJldmVyc2VtcC1oYWxmLXNjcmVlbi1kaWFsb2ctLWJ1dHRvbm1wLWhhbGYtc2NyZWVuLWRpYWxvZy0tYnV0dG9ubXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1idXR0b25fX2FjdGl2ZW1wLWhhbGYtc2NyZWVuLWRpYWxvZy0tYnV0dG9uX19wcmltYXJ5bXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1idXR0b25fX3ByaW1hcnltcC1oYWxmLXNjcmVlbi1kaWFsb2ctLWJ1dHRvbl9fYWN0aXZlbXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1oZWFkbXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1ib2R5bXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1idXR0b25tcC1oYWxmLXNjcmVlbi1kaWFsb2ctLWJ1dHRvbm1wLWhhbGYtc2NyZWVuLWRpYWxvZy0tYnV0dG9uX19hY3RpdmVtcC1oYWxmLXNjcmVlbi1kaWFsb2ctLWJ1dHRvbl9fcHJpbWFyeW1wLWhhbGYtc2NyZWVuLWRpYWxvZy0tYnV0dG9uX19wcmltYXJ5bXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1idXR0b25fX2FjdGl2ZTIuMS40AQABAPuPBBBPDgwBCgAAAAADAQAeAQAQOwgIAkIAVwhJBgEEHhYAAJQCQQBSBkIEAADAQVEGQgQAAMBBUwZCBAAAwEFQBkIEAADAQUAGSAQAAIA/AAAAAC0ODAEKNAA0AAMBNBsBABAZA1YGQgQAAABBRQZCBAAAQEIRBkIEAAAA5gAAAAArDgwBCk8ATwADAU8cAQAQFwOVAkEAkAZCBAAAiEGTCEIGAAQzM7M/AAAAAEMODAEKawBrAAMBaxsBABAvBggCQgBQBkIEAADAQVEGQgQAAMBBkAZCBAAAiEGTCEIGAAQzM7M/EQZCBAAAAOYAAAAANQ4MAQqGAIYAAwGGGwEAECEGCAJCAAECQgACAkEAVgZCBAAAwEGQBkIEAACIQSUCQAAAAAAAGQ4MAQqhAKEAAwGhIwEAEAUBIAJBAAAAAAD7/QAODAEKxADEAAMBxB0BABDpGQgCQgBBBkIEAAAgQkAGQgQAAPBCkwhBBgIEAAAgQnAOQAwCBAAAgEACBAAAgEBxDkAMAgQAAIBAAgQAAIBAcg5ADAIEAACAQAIEAACAQHMOQAwCBAAAgEACBAAAgEAwBkIE8vLy/zEGQAQDAQAANApACAcBAAQAAAAAMxZAFBMBABACBggEAAAAAAAGCAQAAAAAMgZABAMBAAA1BkAEAwEAADcGQAQDAQEANgZABAMBAAABAkEAEQZCBAauVv+VAkEAoAJAAAICQQCbCEEGAgQAAIA/lAJBAFQGQgQAAABBVQZCBAAAAEEAAAAAIRIQAQ7hAOEABwLhHfv+ACUBACAJATAGQgTm5ub/AAAAAHcUEgEQ+yMBAPsjAQAFAfsjASYBABBdCTAGQgQHwWD/MQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAABEGQgT/////AAAAACcYFgEU+0kBAPtJAQAJAvtJASb7bwElAQAgCQEwBkIEBq5W/wAAAAAkFBIBEPuUAQD7lAEABQH7lAEbAQAQCQERBkIE////zAEBAAAAJBQSARD7rwEA+68BAAUB+68BGwEAEAkBEQZCBP///8wBAQAAAHgUEgEQ+8oBAPvKAQAFAfvKAR0BABBdCTAGQgT///8UMQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAABEGQgTW1tb/AQEAAAAoGBYBFPvnAQD75wEACQL75wEd+wQCJQEAIAkBMAZCBP///yABAQAAAHgUEgEQ+ykCAPspAgAFAfspAiYBABBdCTAGQgQHwWD/MQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAABEGQgT/////AQEAAAAoGBYBFPtPAgD7TwIACQL7TwIm+3UCJQEAIAkBMAZCBAauVpkBAQAAAA8BDQAACgEIAAAFAQkCAgD7mgIF");
  

/***/ }),

/***/ 169:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AftBBfuBAW1wLWhhbGYtc2NyZWVuLXBvcHVwLS1yb290bXAtaGFsZi1zY3JlZW4tcG9wdXAtLW1hc2ttcC1oYWxmLXNjcmVlbi1wb3B1cC0tbWFza19faW5tcC1oYWxmLXNjcmVlbi1wb3B1cC0tY29udGFpbmVybXAtaGFsZi1zY3JlZW4tcG9wdXAtLWNvbnRhaW5lcl9faW5tcC1oYWxmLXNjcmVlbi1wb3B1cC0tY29udGVudG1wLWhhbGYtc2NyZWVuLXBvcHVwLS1jb250ZW50bXAtaGFsZi1zY3JlZW4tcG9wdXAtLWNvbnRlbnRtcC1oYWxmLXNjcmVlbi1wb3B1cC0tY29udGVudG1wLWhhbGYtc2NyZWVuLXBvcHVwLS1jb250YWluZXJtcC1oYWxmLXNjcmVlbi1wb3B1cC0tcGFkbXAtaGFsZi1zY3JlZW4tcG9wdXAtLWNvbnRhaW5lcl9faW5tcC1oYWxmLXNjcmVlbi1wb3B1cC0tcGFkMi4xLjQBAAEA+4YDCz0ODAEKAAAAAAMBABoBABApBkEGRAQAAMhCQAZDBAAAyEKQBkIEAACAQQMCQQAEAkEABwZABABAekQAAAAAsw4MAQoaABoAAwEaGgEAEJ8SAgJCAEgGQgQAAAAARwZCBAAAAABGBkIEAAAAAEkGQgQAAAAAMAZCBAAAAJkxBkAEAwEAADQKQAgHAQAEAAAAADMWQBQTAQAQAgYIBAAAAAAABggEAAAAADIGQAQDAQAANQZABAMBAAA3BkAEAwEBADYGQAQDAQAAEgZABAAAAACABkAEAwEEAIEFQAMCAciCBkAEAwECAIMFQAMCAQAAAAAAHQ4MAQo0ADQAAwE0HgEAEAkBEgZABAAAgD8AAAAAdw4MAQpSAFIAAwFSHwEAEGMNAgJCAIAGQAQDAQEAgQVAAwIByIIGQAQDAQAAgwVAAwIBAEAGSAQAAIA/SAZIBAAAgD9GBkIEAAAAAEcGQgQAAAAACRJAEA8BAwwCBAAAAAAIBAAAAAABAkIAIAJAACUCQAAAAAAAKQ4MAQpxAHEAAwFxIwEAEBUBCRJAEA8BAwwCBAAAAAAIBAAAgL8AAAAAjQ4MAQqUAJQAAwGUHQEAEHkNCAJCAEAGQwQAAMhCMAZCBP////8RBkIEAAAA/3AOQAwCBAAAQEECBAAAQEFxDkAMAgQAAEBBAgQAAEBBcg5ADAIEAABAQQIEAABAQXMOQAwCBAAAQEECBAAAQEECAkEAVwZCBAAAQMFTBkIEAABAQQMCQQAEAkEAAAAAAB4ODAEKsQCxAAMBsR0BABAJAUAGQwQAAMhCAQEAAAAeDgwBCs4AzgADAc4dAQAQCQFABkQEAADIQgEBAQAAJg4MAQrrAOsAAwHrHQEAEBECMAZCBBkZGf8RBkIE/////wEBAgAAliUjASH7CAEA+wgBAAUB+wgBHwIREPsnAQD7JwEABQH7JwEZAQAgaw4CAkIASAZCBAAAAABGBkIEAAAAAEcGQgQAAAAASQZCBAAAAAABAkIAJQJAACICQgCABkAEAwEEAIEFQAMCAciCBkAEAwEEAIMFQAMCAQAJEkAQDwEDDAIEAAAAAAgEAAAAABIGQAQAAAAAAAAAAEglIwEh+0ABAPtAAQAFAftAASMCERD7YwEA+2MBAAUB+2MBGQEAIB0CCRJAEA8BAwwCBAAAAAAIBAAAAAASBkAEAACAPwAAAAArAw0AAAoBCAAABQECAgEADQAACgEIAAAFAQICAgANAAAKAQgAAAUBCQICAPt8AQU=");
  

/***/ }),

/***/ 336:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfveC/tuBG1wLWhvcml6b25hbC1idWJibGUtLXJvb3RtcC1ob3Jpem9uYWwtYnViYmxlLS1tYXNrbXAtaG9yaXpvbmFsLWJ1YmJsZS0tbWFza19faW5tcC1ob3Jpem9uYWwtYnViYmxlLS1jb250ZW50bXAtaG9yaXpvbmFsLWJ1YmJsZS0tY2xvc2UtY29udGFpbmVybXAtaG9yaXpvbmFsLWJ1YmJsZS0tY2xvc2UtY29udGFpbmVyX19pbm1wLWhvcml6b25hbC1idWJibGUtLWNsb3NlLWJ0bm1wLWhvcml6b25hbC1idWJibGUtLWNsb3NlLWJ0bi1pbWdtcC1ob3Jpem9uYWwtYnViYmxlLS1jbG9zZS1idG5fX2hvdmVybXAtaG9yaXpvbmFsLWJ1YmJsZS0tY29udGVudC1jb250YWluZXJtcC1ob3Jpem9uYWwtYnViYmxlLS1tZW51LWNvbnRhaW5lcm1wLWhvcml6b25hbC1idWJibGUtLW1lbnUtY29udGFpbmVyX19pbm1wLWhvcml6b25hbC1idWJibGUtLW1lbnVtcC1ob3Jpem9uYWwtYnViYmxlLS1tZW51LWJlZm9yZW1wLWhvcml6b25hbC1idWJibGUtLW1lbnUtaW5uZXJtcC1ob3Jpem9uYWwtYnViYmxlLS1tZW51LWFmdGVybXAtaG9yaXpvbmFsLWJ1YmJsZS0tY2VsbG1wLWhvcml6b25hbC1idWJibGUtLWNlbGwtaW1nLWNvbnRhaW5lcm1wLWhvcml6b25hbC1idWJibGUtLWNlbGwtaW1nLWNvbnRhaW5lcm1wLWhvcml6b25hbC1idWJibGUtLWNlbGxfX2hvdmVybXAtaG9yaXpvbmFsLWJ1YmJsZS0tY2VsbC1pbWdtcC1ob3Jpem9uYWwtYnViYmxlLS1jZWxsLWRlc2NtcC1ob3Jpem9uYWwtYnViYmxlLS1jZWxsLWltZy1jb250YWluZXJtcC1ob3Jpem9uYWwtYnViYmxlLS1jZWxsLWltZy1jb250YWluZXJtcC1ob3Jpem9uYWwtYnViYmxlLS1jZWxsX19ob3Zlcm1wLWhvcml6b25hbC1idWJibGUtLWNlbGwtZGVzY21wLWhvcml6b25hbC1idWJibGUtLW1lbnUtaW5uZXJtcC1ob3Jpem9uYWwtYnViYmxlLS1tZW51LWlubmVybXAtaG9yaXpvbmFsLWJ1YmJsZS0tY2xvc2UtY29udGFpbmVybXAtaG9yaXpvbmFsLWJ1YmJsZS0tbWVudS1jb250YWluZXJtcC1ob3Jpem9uYWwtYnViYmxlLS1jb250ZW50LWNvbnRhaW5lcm1wLWhvcml6b25hbC1idWJibGUtLWNsb3NlLWNvbnRhaW5lcm1wLWhvcml6b25hbC1idWJibGUtLW1lbnUtY29udGFpbmVybXAtaG9yaXpvbmFsLWJ1YmJsZS0tY29udGVudC1jb250YWluZXIyLjEuNAEAAQD7QAcePQ4MAQoAAAAAAwEAGQEAECkGQQZEBAAAyEJABkMEAADIQpAGQgQAAIBBAwJBAAQCQQAHBkAEAEB6RAAAAACzDgwBChkAGQADARkZAQAQnxICAkIASAZCBAAAAABHBkIEAAAAAEYGQgQAAAAASQZCBAAAAAAwBkIEAAAA2TEGQAQDAQAANApACAcBAAQAAAAAMxZAFBMBABACBggEAAAAAAAGCAQAAAAAMgZABAMBAAA1BkAEAwEAADcGQAQDAQEANgZABAMBAAASBkAEAAAAAIAGQAQDAQQAgQVAAwIByIIGQAQDAQIAgwVAAwIBAAAAAAAdDgwBCjIAMgADATIdAQAQCQESBkAEAACAPwAAAAApDgwBCk8ATwADAU8cAQAQFQMBAkIAQQZEBAAAyEJABkMEAADIQgAAAABTDgwBCmsAawADAWskAQAQPwcCAkEAQQZEBAAAyEKABkAEAwEBAIEFQAMCAciCBkAEAwEAAIMFQAMCAQAJEkAQDwEDDAgEAACAvwIEAAAAAAAAAAApDgwBCo8AjwADAY8oAQAQFQEJEkAQDwEDDAgEAAAAAAIEAAAAAAAAAACtDgwBCrcAtwADAbceAQAQmREIAkIAAgJCAEYGQgQAAJhCSQZCBAAAFEJBBkIEAAAAQkAGQgQAAABCUgZCBAAAgEBRBkIEAACAQFMGQgQAAIBAUAZCBAAAgEBwDkAMAgQAAIBBAgQAAIBBcQ5ADAIEAACAQQIEAACAQXIOQAwCBAAAgEECBAAAgEFzDkAMAgQAAIBBAgQAAIBBAwJBAAQCQQAwBkIEPjw//wAAAAAlDgwBCtUA1QADAdUiAQAQEQJBBkIEAADAQUAGQgQAAMBBAAAAAB0ODAEK9wD3AAMB9yUBABAJATAGQgQ3Nzf/AAAAACMUEgEQ+xwBAPscAQAFAfscASYBABAJAUEGRAQAAMhCAAAAAFUUEgEQ+0IBAPtCAQAFAftCASMBABA7BkEGRAQAAMhCgAZABAMBAQCBBUADAgHIggZABAMBAACDBUADAgEACRJAEA8BAwwIBAAAgD8CBAAAAAAAAAAALxQSARD7ZQEA+2UBAAUB+2UBJwEAEBUBCRJAEA8BAwwIBAAAAAACBAAAAAAAAAAAKxQSARD7jAEA+4wBAAUB+4wBGQEAEBEDQQZIBAAAgD8BAkIAIAJAAAAAAAAjFBIBEPulAQD7pQEABQH7pQEgAQAQCQEmBkAEAACAPwAAAAA3FBIBEPvFAQD7xQEABQH7xQEfAQAQHQUmBkAEAAAAAEEGSAQAAIA/AQJCACACQgAlAkMAAAAAACMUEgEQ++QBAPvkAQAFAfvkAR8BABAJASYGQAQAAEBAAAAAAB8UEgEQ+wMCAPsDAgAFAfsDAhkBABAFAQICQQAAAAAA1xQSARD7HAIA+xwCAAUB+xwCJwEAEL0YCAJCAEAGQgQAAGBCQQZCBAAAYEJSBkIEAABAQVEGQgQAAEBBUwZCBAAAQEFQBkIEAABAQTAGQgT/////ZgZCBAAAAABjBkIEAAAAAGkGQgQAAAAAYAZCBAAAAABnAkAAZAJAAGoCQABhAkAAaAJAAGUCQABrAkAAYgJAAHAOQAwCBAAAQEECBAAAQEFxDkAMAgQAAEBBAgQAAEBBcg5ADAIEAABAQQIEAABAQXMOQAwCBAAAQEECBAAAQEEAAAAANCUjASH7QwIA+0MCAAUB+0MCJwIREPtqAgD7agIABQH7agIgAQAgCQEwBkIE7Ozs/wAAAAArFBIBEPuKAgD7igIABQH7igIdAQAQEQJABkIEAAAAQkEGQgQAAABCAAAAAD8UEgEQ+6cCAPunAgAFAfunAh4BABAlBZAGQgQAACBBEQZCBP///4CUAkEAVgZCBAAAAEFBBkIEAABgQQAAAAAjFBIBEPvFAgD7xQIABQH7xQInAQAQCQEwBkIEHx8f/wAAAAA0JSMBIfvsAgD77AIABQH77AInAhEQ+xMDAPsTAwAFAfsTAyABACAJATAGQgQ3Nzf/AAAAACMUEgEQ+zMDAPszAwAFAfszAx4BABAJAREGQgT///+AAAAAAC8UEgEQ+1EDAPtRAwAFAftRAx8BABAVAwgCQgBSBkIEAACIQlMGQgQAAMBBAAAAADAUEgEQ+3ADAPtwAwAFAftwAx8BABAVAwgCQgBSBkIEAAAwQlMGQgQAAMBBAQEAAAA0JSMCEPuPAwD7jwMABQH7jwMkAQAQ+7MDAPuzAwAFAfuzAyMBABAJASYGQAQAAIA/AAAAACsUEgEQ+9YDAPvWAwAFAfvWAyYBABARAiYGQAQAAAAAQAZCBAAAr0MAAAAAPSUjAhD7/AMA+/wDAAUB+/wDJAEAEPsgBAD7IAQABQH7IAQjAQAQEQJABkIEAAAeQyYGQAQAAAAAAQEBAAAoFBIBEPtDBAD7QwQABQH7QwQmAQAQDQJAAkEAJgZABAAAgD8BAQEAACECDwAADAEKAAAHAQgEAACvQw8AAAwBCgAABwEFBADAJkT7aQQF");
  

/***/ }),

/***/ 818:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfuKDftdBW1wLXNlcGFyYXRlLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLXJvb3RtcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1tYXNrLWNvbnRhaW5lcm1wLXNlcGFyYXRlLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLW1hc2ttcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1tYXNrX19pbm1wLXNlcGFyYXRlLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNvbnRhaW5lcnNhZmUtYXJlYS1pbnNldC10b3BzYWZlLWFyZWEtaW5zZXQtbGVmdHNhZmUtYXJlYS1pbnNldC1ib3R0b21zYWZlLWFyZWEtaW5zZXQtcmlnaHRtcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1jb250YWluZXJtcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1jb250YWluZXJtcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1jb250ZW50bXAtc2VwYXJhdGUtYnViYmxlLWFjdGlvbi1zaGVldC0tY29udGVudG1wLXNlcGFyYXRlLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNvbnRlbnRtcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1pbWdtcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1pbWdtcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1pbWctY29udGFpbmVybXAtc2VwYXJhdGUtYnViYmxlLWFjdGlvbi1zaGVldC0taW1nLWNvbnRhaW5lcl9faW5tcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1pbWctY29udGFpbmVybXAtc2VwYXJhdGUtYnViYmxlLWFjdGlvbi1zaGVldC0taW1nLWNvbnRhaW5lcm1wLXNlcGFyYXRlLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWltZy1pbm5lcm1wLXNlcGFyYXRlLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLW1lbnVtcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1tZW51bXAtc2VwYXJhdGUtYnViYmxlLWFjdGlvbi1zaGVldC0tbWVudW1wLXNlcGFyYXRlLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLW1lbnVfX2lubXAtc2VwYXJhdGUtYnViYmxlLWFjdGlvbi1zaGVldC0tY2VsbG1wLXNlcGFyYXRlLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNlbGxtcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1jZWxsbXAtc2VwYXJhdGUtYnViYmxlLWFjdGlvbi1zaGVldC0tY2VsbC1pbWctY29udGFpbmVybXAtc2VwYXJhdGUtYnViYmxlLWFjdGlvbi1zaGVldC0tY2VsbC1pbWctY29udGFpbmVybXAtc2VwYXJhdGUtYnViYmxlLWFjdGlvbi1zaGVldC0tY2VsbF9faG92ZXJtcC1zZXBhcmF0ZS1idWJibGUtYWN0aW9uLXNoZWV0LS1jZWxsLWltZ21wLXNlcGFyYXRlLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNlbGwtZGVzY21wLXNlcGFyYXRlLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNlbGwtZGVzY21wLXNlcGFyYXRlLWJ1YmJsZS1hY3Rpb24tc2hlZXQtLWNlbGwtZGVzYzIuMS40AQABAPtnBx49DgwBCgAAAAADAQAlAQAQKQZBBkQEAADIQkAGQwQAAMhCkAZCBAAAgEEDAkEABAJBAAcGQAQAQHpEAAAAADkODAEKJQAlAAMBJS8BABAlBQICQgBIBkIEAAAAAEcGQgQAAAAARgZCBAAAAABJBkIEAAAAAAAAAAC1DgwBClQAVAADAVQlAQAQoRICAkIASAZCBAAAAABHBkIEAAAAAEYGQgQAAAAASQZCBAAAAAAwBkIEAAAAszEGQAQDAQAANApACAcBAAQAAAAAMxZAFBMBABACBggEAAAAAAAGCAQAAAAAMgZABAMBAAA1BkAEAwEAADcGQAQDAQEANgZABAMBAAASBkAEAAAAAIAGQAQDAQQAgQdABQQB+ywBggZABAMBBACDBUADAgEAAAAAAB0ODAEKeQB5AAMBeSkBABAJARIGQAQAAIA/AAAAAEsODAEKogCiAAMBoioBABA3BwICQgBICEkGAQTMEwAARghJBgEE3xQAAEkISQYBBPMWAABHCkkIAQb7CQEVAAABAkIAJQJAAAAAAAAgFBIBEPseAQD7HgEABQH7HgEqAQAQBQEgAkAAAQEAAAAkFBIBEPtIAQD7SAEABQH7SAEqAQAQCQIgAkIAIgJCAAEBAQAARxQSARD7cgEA+3IBAAUB+3IBKAEAEC0JCAJCAAICQQADAkEABAJBACYGQAQAAIA/JwZABAAAgD8oAkEAAQJCACICQAAAAAAAIBQSARD7mgEA+5oBAAUB+5oBKAEAEAUBIAJCAAEBAgAAIBQSARD7wgEA+8IBAAUB+8IBKAEAEAUBIAJAAAEBAwAAMxQSARD76gEA++oBAAUB++oBJAEAEBkEAQJCACYGQAQAAIA/JwZABAAAgD8oAkEAAAAAACQUEgEQ+w4CAPsOAgAFAfsOAiQBABAJAUAGSAQAAIA/AQEEAABzFBIBEPsyAgD7MgIABQH7MgIuAQAQWQ0IAkIAAQJCACACQgAlAkAAIgJCAIAGQAQDAQEAgQdABQQB+ywBggZABAMBBACDBUADAgEACQ5ADAsBBQhvEoM6bxKDOiYGQAQAAIA/JwZABAAAgD8oAkEAAAAAACsUEgEQ+2ACAPtgAgAFAftgAjIBABARAQkOQAwLAQUIAACAPwAAgD8AAAAARBQSARD7kgIA+5ICAAUB+5ICLgEAECkFQAZIBAAAgD9SBkIEAAAAQlMGQgQAACBCUAZCBAAAAEJRBkIEAAAAQgEBBQAAPBQSARD7wAIA+8ACAAUB+8ACLgEAECEEQQZIBAAAgD9SBkIEAABAQlMGQgQAAEBCUQZCBAAAIEIBAQYAAGMUEgEQ++4CAPvuAgAFAfvuAioBABBJBnAOQAwCBAAAQEECBAAAQEFxDkAMAgQAAEBBAgQAAEBBcg5ADAIEAABAQQIEAABAQXMOQAwCBAAAQEECBAAAQEEDAkEABAJBAAAAAABXFBIBEPsYAwD7GAMABQH7GAMlAQAQPQkIAkIAAgJBACUCRQAwBkIEAAAAABIGQAQAAAAAgAZABAMBBACBB0AFBAH7LAGCBkAEAwEEAIMFQAMCAQAAAAAARBQSARD7PQMA+z0DAAUB+z0DJQEAECkGSAZCBAAAAABHBkIEAAAAAEAGSAQAAIA/AQJCACACQABTBkIEAAAgQgEBBwAAPBQSARD7YgMA+2IDAAUB+2IDJQEAECEFSAZCBAAAAABHBkIEAAAAAEEGSAQAAIA/AQJCACACQwABAQgAACMUEgEQ+4cDAPuHAwAFAfuHAykBABAJARIGQAQAAIA/AAAAACMUEgEQ+7ADAPuwAwAFAfuwAyUBABAJAgICQQABAkIAAAAAACQUEgEQ+9UDAPvVAwAFAfvVAyUBABAJAiACQgAiAkIAAQEJAAAkFBIBEPv6AwD7+gMABQH7+gMlAQAQCQIgAkAAIgJCAAEBCgAA1xQSARD7HwQA+x8EAAUB+x8EMwEAEL0YCAJCAEAGQgQAAGBCQQZCBAAAYEJSBkIEAABAQVEGQgQAAEBBUwZCBAAAQEFQBkIEAABAQTAGQgTS0tJhZgZCBAAAAABjBkIEAAAAAGkGQgQAAAAAYAZCBAAAAABnAkAAZAJAAGoCQABhAkAAaAJAAGUCQABrAkAAYgJAAHAOQAwCBAAA4EECBAAA4EFxDkAMAgQAAOBBAgQAAOBBcg5ADAIEAADgQQIEAADgQXMOQAwCBAAA4EECBAAA4EEAAAAANCUjASH7UgQA+1IEAAUB+1IEMwIREPuFBAD7hQQABQH7hQQsAQAgCQEwBkIEqampYQAAAAArFBIBEPuxBAD7sQQABQH7sQQpAQAQEQJABkIEAAAAQkEGQgQAAABCAAAAACsUEgEQ+9oEAPvaBAAFAfvaBCoBABARApAGQgQAAEBBEQZCBP///8wAAAAAKBQSARD7BAUA+wQFAAUB+wQFKgEAEA0ClAJBAFYGQgQAAFBBAQELAAAkFBIBEPsuBQD7LgUABQH7LgUqAQAQCQFUBkIEAABQQQEBDAAAtw0NAAAKAQgAAAUBAgIBAA0AAAoBCAAABQECAgIADQAACgEIAAAFAQICAQANAAAKAQgAAAUBAgICAA0AAAoBCAAABQECAgEADQAACgEIAAAFAQICAQANAAAKAQgAAAUBAgICAA0AAAoBCAAABQECAgEADQAACgEIAAAFAQICAgANAAAKAQgAAAUBAgIBAA0AAAoBCAAABQECAgIADQAACgEIAAAFAQICAQANAAAKAQgAAAUBAgICAPtYBQU=");
  

/***/ }),

/***/ 501:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfuGAU1hZC1za2lwLWNhcmQtLXJvb3RhZC1za2lwLWNhcmQtLWljb25hZC1za2lwLWNhcmQtLXRpdGxlYWQtc2tpcC1jYXJkLS1zdWIyLjEuNAEAAQD7LQEEkQ4MAQoAAAAAAwEAEgEAEH0PQQZEBAAAyEJABkMEAADIQgECQgAgAkIAIgJCACUCQAAwBkIEAAAAmTEGQAQDAQAANApACAcBAAQAAAAAMxZAFBMBABACBggEAAAAAAAGCAQAAAAAMgZABAMBAAA1BkAEAwEAADcGQAQDAQEANgZABAMBAAAHBkAEAEB6RAAAAAAtDgwBChIAEgADARISAQAQGQNABkIEAIC7Q0EGQgQAAHBDVwZCBAAAwEEAAAAAMQ4MAQokACQAAwEkEwEAEB0EEQZCBP////+QBkIEAACIQVcGQgQAAABBlAJBAAAAAAA5DgwBCjcANwADATcRAQAQJQUSBkAEzcxMPxEGQgT/////kAZCBAAAYEFXBkIEAADAQJQCQQAAAAAAAQBIBQ==");
  

/***/ }),

/***/ 829:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfvBCPt4AWF1dGhvcml6ZS0tcm9vdGF1dGhvcml6ZS0tbWFza2F1dGhvcml6ZS0tbWFzay1pbmF1dGhvcml6ZS0tY29udGFpbmVyYXV0aG9yaXplLS1jb250ZW50YXV0aG9yaXplLS1jb250ZW50LWluYXV0aG9yaXplLS1oZWFkYXV0aG9yaXplLS1pY29uYXV0aG9yaXplLS10aXRsZWF1dGhvcml6ZS0tYm9keWF1dGhvcml6ZS0tYXBwbHktaW5mb2F1dGhvcml6ZS0tYnV0dG9uc2F1dGhvcml6ZS0tYnV0dG9uYXV0aG9yaXplLS1jYW5jZWxhdXRob3JpemUtLWNvbmZpcm1hdXRob3JpemUtLWNvbnRhaW5lcmF1dGhvcml6ZS0tY29udGFpbmVyYXV0aG9yaXplLS1jb250ZW50YXV0aG9yaXplLS10aXRsZWF1dGhvcml6ZS0tYXBwbHktaW5mb2F1dGhvcml6ZS0tY2FuY2VsMi4xLjQBAAEA+w8HFUkODAEKAAAAAAMBAA8BABA1CUEGRAQAAMhCQAZDBAAAyEIBAkIAkAZCBAAAgEEDAkEABAJBACACQgAiAkIABwZABABAekQAAAAAnw4MAQoPAA8AAwEPDwEAEIsPQAZIBAAAgD9BBkgEAACAPzAGQgQAAAD/MQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAABIGQAQAAAAAgAZABAMBBACBBUADAgHIggZABAMBAACDBUADAgEAAAAAAB0ODAEKHgAeAAMBHhIBABAJARIGQATNzMw+AAAAAE0ODAEKMAAwAAMBMBQBABA5BwMCQQAEAkEAQQZIBAAAgD8CAkIARgZIBAAAAD9JBkIEAABAwQkSQBAPAQMMCAQAAAC/AgQAAAAAAAAAAPsVAQ4MAQpEAEQAAwFEEgEAEPv/ABsBAkIAIAJCAIAGQAQDAQEAgQVAAwIByIIGQAQDAQAAgwVAAwIBAFIGQgQAAAAAUQZCBAAAwEFTBkIEAAAAAFAGQgQAAMBBQAZIBAAAgD9BBkIEAAB6Q3AOQAwCBAAAQEECBAAAQEFxDkAMAgQAAEBBAgQAAEBBcg5ADAIEAABAQQIEAABAQXMOQAwCBAAAQEECBAAAQEEwBkIE/////zEGQAQDAQAANApACAcBAAQAAAAAMxZAFBMBABACBggEAAAAAAAGCAQAAAAAMgZABAMBAAA1BkAEAwEAADcGQAQDAQEANgZABAMBAAACAkIASAZIBAAAgD9GBkIEAAAAAAAAAAApDgwBClYAVgADAVYVAQAQFQEJEkAQDwEDDAIEAAAAAAgEAACAvwAAAAAlDgwBCmsAawADAWsPAQAQEQNBBkIEAACAQgECQgAiAkIAAAAAACUODAEKegB6AAMBeg8BABARAkAGQgQAAMBBQQZCBAAAwEEAAAAAUw4MAQqJAIkAAwGJEAEAED8IVAZCBAAAAEESBkAEZmZmPxEGQgQAAAD/kAZCBAAAcEGVAkEAQQZCBAAAqEGTCEEGAgQAAKhBJgZABAAAgD8AAAAAOQ4MAQqZAJkAAwGZDwEAECUFJgZABAAAgD8nBkAEAACAPygGQgQAAAAAIAJCAFYGQgQAAIBAAAAAAEMODAEKqACoAAMBqBUBABAvBhIGQARmZmY/kAZCBAAAiEERBkIEAAAA/5UCQQBBBkIEZma+QZMIQQYCBGZmvkEAAAAAUQ4MAQq9AL0AAwG9EgEAED0KQAZIBAAAgD9BBkIEAAAgQgICQgBJBkIEAACcQkYGQgQAAAAAkAZCBAAAiEGVAkEAAQJCACACQAAlAkAAAAAAAJMODAEKzwDPAAMBzxEBABB/DEAGQgQAAPBCQQZCBAAAIEKTCEEGAgQAACBClAJBAFYGQgQAAAAAVQZCBAAAAEFXBkIEAAAAAFQGQgQAAABBcA5ADAIEAACAQAIEAACAQHEOQAwCBAAAgEACBAAAgEByDkAMAgQAAIBAAgQAAIBAcw5ADAIEAACAQAIEAACAQAAAAABxDgwBCuAA4AADAeARAQAQXQkwBkIE8vLy/zEGQAQDAQAANApACAcBAAQAAAAAMxZAFBMBABACBggEAAAAAAAGCAQAAAAAMgZABAMBAAA1BkAEAwEAADcGQAQDAQEANgZABAMBAAARBkIEB8Fg/wAAAABxDgwBCvEA8QADAfESAQAQXQkwBkIEBMFg/zEGQAQDAQAANApACAcBAAQAAAAAMxZAFBMBABACBggEAAAAAAAGCAQAAAAAMgZABAMBAAA1BkAEAwEAADcGQAQDAQEANgZABAMBAAARBkIE/////wAAAAAkFBIBEPsDAQD7AwEABQH7AwEUAQAQCQFABkMEAADIQgEBAAAAJBQSARD7FwEA+xcBAAUB+xcBFAEAEAkBQAZEBAAAyEIBAQEAAHAUEgEQ+ysBAPsrAQAFAfsrARIBABBVCDAGQgQsLCz/MQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAAAEBAgAALBQSARD7PQEA+z0BAAUB+z0BEAEAEBECEgZABM3MTD8RBkIE/////wEBAgAALBQSARD7TQEA+00BAAUB+00BFQEAEBECEgZABM3MTD8RBkIE/////wEBAgAAeBQSARD7YgEA+2IBAAUB+2IBEQEAEF0JMAZCBP///xQxBkAEAwEAADQKQAgHAQAEAAAAADMWQBQTAQAQAgYIBAAAAAAABggEAAAAADIGQAQDAQAANQZABAMBAAA3BkAEAwEBADYGQAQDAQAAEQZCBP////8BAQIAACsDDQAACgEIAAAFAQICAQANAAAKAQgAAAUBAgICAA0AAAoBCAAABQEJAgIA+3MBBQ==");
  

/***/ }),

/***/ 47:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("Ad8WZmlyc3QtcGF5LS1jb3Vwb24yLjEuNAEAAQC/Ab0ODAEKAAAAAAMBABEBABCpDwECQgBABkgEAACAP0EGQgQAALBCMAZCBPf39/8xBkAEAwEAADQKQAgHAQAEAAAAADMWQBQTAQAQAgYIBAAAAAAABggEAAAAADIGQAQDAQAANQZABAMBAAA3BkAEAwEBADYGQAQDAQAAcA5ADAIEAACAQAIEAACAQHEOQAwCBAAAgEACBAAAgEByDkAMAgQAAIBAAgQAAIBAcw5ADAIEAACAQAIEAACAQAAAAAABABEF");
  

/***/ }),

/***/ 368:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfvjAvtBAWdhbWUtZ3JhbnQtaW5mby0tcm9vdG1wLWhhbGYtc2NyZWVuLWRpYWxvZy0tYm9keWdhbWUtZ3JhbnQtaW5mby0tcm9vdG1wLWhhbGYtc2NyZWVuLWRpYWxvZy0tZm9vdGdhbWUtZ3JhbnQtaW5mby0tcm9vdG1wLWhhbGYtc2NyZWVuLWRpYWxvZy0taGVhZGdhbWUtZ3JhbnQtaW5mby0tYWN0aW9ubXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1jb250ZW50Z2FtZS1ncmFudC1pbmZvLS1hY3Rpb25tcC1oYWxmLXNjcmVlbi1kaWFsb2ctLWZvb3RnYW1lLWdyYW50LWluZm8tLWFjdGlvbmdhbWUtZ3JhbnQtaW5mby0tc2Nyb2xsZ2FtZS1ncmFudC1pbmZvLS1zY3JvbGwyLjEuNAEAAQD7hAEIJA4MAQoAAAAAAwEAFQEAEBACDgVBAwEBAgcGQAQAAIA/AAAAAEAZFwEVFQAVAAMBFRsCCwowADAAAwEwFQEAICEEUgZCBAAAAABRBkIEAAAAAFMGQgQAAAAAUAZCBAAAAAAAAAAAKBkXARVFAEUAAwFFGwILCmAAYAADAWAVAQAgCQFTBkIEAAAgQgAAAAAoGRcBFXUAdQADAXUbAgsKkACQAAMBkBcBACAJAVYGQgQAAAAAAAAAACgZFwEVpwCnAAMBpx4CCwrFAMUAAwHFFwEAIAkBUgZCBAAAoEEAAAAAKBkXARXcANwAAwHcGwILCvcA9wADAfcXAQAgCQFTBkIEAACAQgAAAABDFBIBEPsOAQD7DgEABQH7DgEXAQAQKQcBAkIAIAJCAJUCQACQBkIEAABgQZQCQABWBkIEAADAQVcGQgQAACBCAAAAADQUEgEQ+yUBAPslAQAFAfslARcBABAZBFcGQgQAAKBBAwJCAAQCQgBBBkIEAADwQgEBAAAADwENAAAKAQgAAAUBAgICAPs8AQU=");
  

/***/ }),

/***/ 168:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfvMAs1sYXVuY2gtc2NyZWVuLS1yb290bGF1bmNoLXNjcmVlbi0tbWFza2xhdW5jaC1zY3JlZW4tLXdyYXBwZXJsYXVuY2gtc2NyZWVuLS1jbG9zZWxhdW5jaC1zY3JlZW4tLWNoZWNrLWJveGxhdW5jaC1zY3JlZW4tLWNoZWNrLWJveF9faWNvbmxhdW5jaC1zY3JlZW4tLWNoZWNrLWJveF9faWNvbi1pbm5lcmxhdW5jaC1zY3JlZW4tLWNoZWNrLWJveF9fdGV4dDIuMS40AQABAPvzAQg9DgwBCgAAAAADAQATAQAQKQdBBkQEAADIQkAGQwQAAMhCAQJCACACQgAiAkIAJQJAAAcGQAQAwHlEAAAAAI0ODAEKEwATAAMBExMBABB5DQICQgBGBkIEAAAAAEgGQgQAAAAAQQZEBAAAyEJABkMEAADIQjAGQgQAAACZMQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAAAAAAAAZDgwBCiYAJgADASYWAQAQBQECAkEAAAAAAEEODAEKPAA8AAMBPBQBABAtBgICQgBIBkIEAAAAQEcGQgQAAABAQAZCBAAAAEJBBkIEAAAAQlcGQgQAAMBBAAAAAC0ODAEKUABQAAMBUBgBABAZBQICQgBBBkIEAADAQQECQgAiAkIAJQJAAAAAAAApDgwBCmgAaAADAWgeAQAQFQMCAkEAQAZCBAAAgEFBBkIEAACAQQAAAAA5DgwBCoYAhgADAYYkAQAQJQUCAkIARgZCBAAAAABIBkIEAAAAAEAGQgQAAIBBQQZCBAAAgEEAAAAANw4MAQqqAKoAAwGqHgEAECMEkAZCBAAAQEGTCEEGAgQAAIhBEQZCBP///4BUBkIEAADAQAAAAAABAMgF");
  

/***/ }),

/***/ 527:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("Aft1AU5vZmZpY2lhbFRvYXN0LXBvcC0tcm9vdG9mZmljaWFsVG9hc3QtcG9wLS1jb250ZW50b2ZmaWNpYWxUb2FzdC1wb3AtLXRpdGxlMi4xLjQBAAEA+xsBAyEODAEKAAAAAAMBABcBABANAwECQgAlAkAAlAJBAAAAAADRDgwBChcAFwADARcaAQAQvRFSBkIEAAAgQVEGQgQAACBBUwZCBAAAIEFQBkIEAAAgQXAOQAwCBAAAoEACBAAAoEBxDkAMAgQAAKBAAgQAAKBAcg5ADAIEAACgQAIEAACgQHMOQAwCBAAAoEACBAAAoEAwBkIEAAAA/zEGQAQDAQAANApACAcBAAQAAAAAMxZAFBMBABACBggEAAAAAAAGCAQAAAAAMgZABAMBAAA1BkAEAwEAADcGQAQDAQEANgZABAMBAAASBkAEMzMzPwAAAAAlDgwBCjEAMQADATEYAQAQEQKQBkIEAABwQREGQgT/////AAAAAAEASQU=");
  

/***/ }),

/***/ 49:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfucA/ubAXBsYXRmb3JtLWNvaW4tcGF5LW1vZGFsLS1yb290bXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1ib2R5cGxhdGZvcm0tY29pbi1wYXktbW9kYWwtLXJvb3RtcC1oYWxmLXNjcmVlbi1kaWFsb2ctLWNvbnRlbnRwbGF0Zm9ybS1jb2luLXBheS1tb2RhbC0tcm9vdG1wLWhhbGYtc2NyZWVuLWRpYWxvZy0taGVhZHBsYXRmb3JtLWNvaW4tcGF5LW1vZGFsLS1yb290cGxhdGZvcm0tY29pbi1wYXktbW9kYWwtLXNjcm9sbHBsYXRmb3JtLWNvaW4tcGF5LW1vZGFsLS1zY3JvbGxwbGF0Zm9ybS1jb2luLXBheS1tb2RhbC0taW5kZXgtcGFnZXBsYXRmb3JtLWNvaW4tcGF5LW1vZGFsLS1pbmRleC1wYWdlLWhlYWRwbGF0Zm9ybS1jb2luLXBheS1tb2RhbC0tcXVlc3Rpb24taWNvbnBsYXRmb3JtLWNvaW4tcGF5LW1vZGFsLS1yZW1haW4yLjEuNAEAAQD74wEKGQ4MAQoAAAAAAwEAHQEAEAUBAgJCAAAAAABAGRcBFR0AHQADAR0bAgsKOAA4AAMBOB0BACAhBFIGQgQAAAAAUQZCBAAAAABTBkIEAAAAAFAGQgQAAAAAAAAAAEAZFwEVVQBVAAMBVR4CCwpzAHMAAwFzHQEAICEEUgZCBAAAAABRBkIEAAAAAFMGQgQAAAAAUAZCBAAAAAAAAAAAKBkXARWQAJAAAwGQGwILCqsAqwADAasdAQAgCQFWBkIEAAAAAAAAAAA9DgwBCsgAyAADAcgfAQAQKQYDAkIABAJCAFIGQgQAAIBBUQZCBAAAgEFTBkIEAACAQVAGQgQAAIBBAAAAAB4ODAEK5wDnAAMB5x8BABAJAUEGQgQAAFpDAQEAAAArFBIBEPsGAQD7BgEABQH7BgEjAQAQEQJQBkIEAACAQVEGQgQAAIBBAAAAADMUEgEQ+ykBAPspAQAFAfspASgBABAZBAECQgCQBkIEAABAQVMGQgQAACBBIgJCAAAAAAAzFBIBEPtRAQD7UQEABQH7UQEmAQAQGQNABkIEAACAQUEGQgQAAIBBVAZCBAAAgEAAAAAAKxQSARD7dwEA+3cBAAUB+3cBHwEAEBEDEQZCBIiIiP8BAkIAIgJCAAAAAAAPAQ0AAAoBCAAABQECAgIA+5YBBQ==");
  

/***/ }),

/***/ 203:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfthA/sdAW1wLWhhbGYtc2NyZWVuLWRpYWxvZy0tdGl0bGVwcml2YWN5LXBvcC0tcm9vdG1wLWhhbGYtc2NyZWVuLWRpYWxvZy0tYm9keXByaXZhY3ktcG9wLS1yb290bXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1mb290cHJpdmFjeS1wb3AtLXJvb3RtcC1oYWxmLXNjcmVlbi1kaWFsb2ctLWJ1dHRvbnByaXZhY3ktcG9wLS1yb290bXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1idXR0b25fX3ByaW1hcnlwcml2YWN5LXBvcC0tcm9vdG1wLWhhbGYtc2NyZWVuLWRpYWxvZy0tYnV0dG9ucHJpdmFjeS1wb3AtLXJvb3QyLjEuNAEAAQD7JgIGMhkXARUAAAAAAwEAHAILChwAHAADARwRAQAgEwJSBkIEAAAAQZUIRAYABAAA+kMAAAAAUBkXARUtAC0AAwEtGwILCkgASAADAUgRAQAgMQZSBkIEAAAAAFEGQgQAAAAAUwZCBAAAAABQBkIEAAAAAFcGQgQAAGBCEQZCBH6AgP8AAAAAOBkXARVZAFkAAwFZGwILCnQAdAADAXQRAQAgGQNBBkIEAACwQlAGQgQAANxBUQZCBAAA3EEAAAAApBkXARWFAIUAAwGFHQILCqIAogADAaIRAQAghQwRBkIEAAAA/0AGQgQAAPBCQQZCBAAAQEKTCEEGAgQAAEBCVAZCBAAAAEFVBkIEAAAAQVcGQgQAACBCcA5ADAIEAAAAQQIEAAAAQXEOQAwCBAAAAEECBAAAAEFyDkAMAgQAAABBAgQAAABBcw5ADAIEAAAAQQIEAAAAQZUIRAYABAAA+kMAAAAAKBkXARWzALMAAwGzJgILCtkA2QADAdkRAQAgCQERBkIE/////wAAAACZHx0BG+oA6gADAeodAhEQ+wcBAPsHAQAFAfsHAREBACBzCkAGQgQAAPBCQQZCBAAAQEKTCEEGAgQAAEBCVAZCBAAAAEFVBkIEAAAAQXAOQAwCBAAAAEECBAAAAEFxDkAMAgQAAABBAgQAAABBcg5ADAIEAAAAQQIEAAAAQXMOQAwCBAAAAEECBAAAAEERBkIE/////wEBAAAADwENAAAKAQgAAAUBCQICAPsYAQU=");
  

/***/ }),

/***/ 300:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AftyB/t1AnNoYXJlLWFwcC1tZXNzYWdlLXBvcHVwLS1jb250ZW50c2hhcmUtYXBwLW1lc3NhZ2UtcG9wdXAtLXRvcHNoYXJlLWFwcC1tZXNzYWdlLXBvcHVwLS10aXRsZXNoYXJlLWFwcC1tZXNzYWdlLXBvcHVwLS1hcnJvdy1pY29uc2hhcmUtYXBwLW1lc3NhZ2UtcG9wdXAtLXVzZXItY29udGVudHNoYXJlLWFwcC1tZXNzYWdlLXBvcHVwLS11c2VyLWNvbnRlbnQtaXRlbXNoYXJlLWFwcC1tZXNzYWdlLXBvcHVwLS11c2VyLWNvbnRlbnQtaXRlbS1pbWdzaGFyZS1hcHAtbWVzc2FnZS1wb3B1cC0tdXNlci1jb250ZW50LWl0ZW0tbmFtZXNoYXJlLWFwcC1tZXNzYWdlLXBvcHVwLS1ib3R0b21zaGFyZS1hcHAtbWVzc2FnZS1wb3B1cC0tYm90dG9tc2hhcmUtYXBwLW1lc3NhZ2UtcG9wdXAtLXNoYXJlLWJ1dHRvbnNoYXJlLWFwcC1tZXNzYWdlLXBvcHVwLS1zaGFyZS1idXR0b24taWNvbnNoYXJlLWFwcC1tZXNzYWdlLXBvcHVwLS1zaGFyZS1idXR0b24tdGV4dHNoYXJlLWFwcC1tZXNzYWdlLXBvcHVwLS1zaGFyZS1idXR0b24tdGV4dHNoYXJlLWFwcC1tZXNzYWdlLXBvcHVwLS1zaGFyZS1idXR0b24taWNvbm1wLWhhbGYtc2NyZWVuLXBvcHVwLS1jb250ZW50bXAtaGFsZi1zY3JlZW4tcG9wdXAtLWNvbnRhaW5lcjIuMS40AQABAPvRBBFpDgwBCgAAAAADAQAgAQAQVQgwBkIE9/f38jEGQAQDAQAANApACAcBAAQAAAAAMxZAFBMBABACBggEAAAAAAAGCAQAAAAAMgZABAMBAAA1BkAEAwEAADcGQAQDAQEANgZABAMBAAAAAAAALQ4MAQogACAAAwEgHAEAEBkFQQZCBAAAgEIBAkIAJQJAACICQgACAkEAAAAAACEODAEKPAA8AAMBPB4BABANApAGQgQAAHBBlQJBAAAAAAAxDgwBCloAWgADAVojAQAQHQRBBkIEAADAQQICQgBGBkIEAACAQUgGQgQAAKBBAAAAAD0ODAEKfQB9AAMBfSUBABApB0AGSARmZmY/VgZCBAAAAABVAkEAVwZCBAAAAABUAkEAAQJCACECQQAAAAAAJQ4MAQqiAKIAAwGiKgEAEBEDQAZCBAAApEIBAkIAIAJCAAAAAACNDgwBCswAzAADAcwuAQAQeQxABkIEAABgQkEGQgQAAGBCcA5ADAIEAAAAQQIEAAAAQXEOQAwCBAAAAEECBAAAAEFyDkAMAgQAAABBAgQAAABBcw5ADAIEAAAAQQIEAAAAQVYGQgQAAAAAVQZCBAAAUEFXBkIEAAAAAFQGQgQAAFBBAwJBAAQCQQAAAAAAZQ4MAQr6APoAAwH6LwEAEFEMkAZCBAAAQEGTCEEGAgQAAIhBlQhEBgAEAADIQ0AGQgQAAKRClAJBAEEGQgQAAIhBAwJBAAQCQQBWBkIEAAAAQFUCQQBXBkIEAACgQFQCQQAAAAAAYxQSARD7KQEA+ykBAAUB+ykBHwEAEEkKQwZCBAAAQEJABkgEZmZmP1IGQgQAAMhBUQZCBAAAAABTBkIEAABcQlAGQgQAAAAAVgZCBAAAAABVAkEAVwZCBAAAAABUAkEAAAAAADwUEgEQ+0gBAPtIAQAFAftIAR8BABAhBFIGQgQAAKBBUQZCBAAAAABTBkIEAADwQVAGQgQAAAAAAQEAAADHFBIBEPtnAQD7ZwEABQH7ZwElAQAQrRBwDkAMAgQAAABBAgQAAABBcQ5ADAIEAAAAQQIEAAAAQXIOQAwCBAAAAEECBAAAAEFzDkAMAgQAAABBAgQAAABBMAZCBP////8xBkAEAwEAADQKQAgHAQAEAAAAADMWQBQTAQAQAgYIBAAAAAAABggEAAAAADIGQAQDAQAANQZABAMBAAA3BkAEAwEBADYGQAQDAQAAQQZCBAAAQEJABkgEAACAPwECQgAiAkIAAAAAACsUEgEQ+4wBAPuMAQAFAfuMASoBABARAkAGQgQAAMBBQQZCBAAAwEEAAAAALRQSARD7tgEA+7YBAAUB+7YBKgEAEBMClQhEBgAEAADIQ5AGQgQAAIhBAAAAACMUEgEQ++ABAPvgAQAFAfvgASoBABAJAVQGQgQAAEBBAAAAACMUEgEQ+woCAPsKAgAFAfsKAioBABAJAVQGQgQAAHBBAAAAAFsUEgEQ+zQCAPs0AgAFAfs0Ah0BABBBBHAOQAwCBAAAgEECBAAAgEFxDkAMAgQAAIBBAgQAAIBBcg5ADAIEAACAQQIEAACAQXMOQAwCBAAAgEECBAAAgEEAAAAAJBQSARD7UQIA+1ECAAUB+1ECHwEAEAkBRQZEBAAAvkIBAQEAAB0CDQAACgEIAAAFAQICAgANAAAKAQgAAAUBAgICAPtwAgU=");
  

/***/ }),

/***/ 82:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfsSBvvcAXNoYXJlLWltYWdlLS1tYXNrc2hhcmUtaW1hZ2UtLW1hc2tfX2luc2hhcmUtaW1hZ2UtLWNvbnRhaW5lcnNoYXJlLWltYWdlLS1sYW5kc2NhcGUtY29udGFpbmVyc2hhcmUtaW1hZ2UtLWNvbnRhaW5lcl9faW5zaGFyZS1pbWFnZS0tbGFuZHNjYXBlLWNvbnRhaW5lcl9faW5zaGFyZS1pbWFnZS0tY29udGFpbmVyc2FmZS1hcmVhLWluc2V0LWxlZnRzYWZlLWFyZWEtaW5zZXQtYm90dG9tc2FmZS1hcmVhLWluc2V0LXJpZ2h0c2hhcmUtaW1hZ2UtLWxhbmRzY2FwZS1jb250YWluZXJzaGFyZS1pbWFnZS0tc2Nyb2xsZXItY29udGFpbmVyc2hhcmUtaW1hZ2UtLWxhbmRzY2FwZS1zY3JvbGxlci1jb250YWluZXJzaGFyZS1pbWFnZS0tc2Nyb2xsZXJzaGFyZS1pbWFnZS0taW1nc2hhcmUtaW1hZ2UtLWltZy13cmFwcGVyc2hhcmUtaW1hZ2UtLWNvbnRhaW5lcnNoYXJlLWltYWdlLS1zY3JvbGxlcnNoYXJlLWltYWdlLS1pbWctd3JhcHBlcjIuMS40AQABAPsYBA6zDgwBCgAAAAADAQARAQAQnxICAkIASAZCBAAAAABHBkIEAAAAAEYGQgQAAAAASQZCBAAAAAAwBkIEAAAA2TEGQAQDAQAANApACAcBAAQAAAAAMxZAFBMBABACBggEAAAAAAAGCAQAAAAAMgZABAMBAAA1BkAEAwEAADcGQAQDAQEANgZABAMBAAASBkAEAAAAAIAGQAQDAQQAgQVAAwIByIIGQAQDAQIAgwVAAwIBAAAAAAAdDgwBChEAEQADAREVAQAQCQESBkAEAACAPwAAAABSGRcCCiYAJgADASYWAQAKPAA8AAMBPCABABAzCBIGQAQAAAAAgAZABAMBBACBBUADAgHIggZABAMBAgCDBUADAgEAAQJCACACQAAlAkAAAAAAACgZFwIKXABcAAMBXBoBAAp2AHYAAwF2JAEAEAkBEgZABAAAgD8AAAAASw4MAQqaAJoAAwGaFgEAEDcHCAJCAAICQgBIBkIEAAAAAEYISQYBBLAUAABJCEkGAQTEFgAARwhJBgEE2hUAAFMGQgQAAEJDAAAAACUODAEK7wDvAAMB7yABABARAkAGSAQAAIA/QQZIBAAAgD8AAAAAbxQSARD7DwEA+w8BAAUB+w8BHwEAEFUMQAZIBAAAgD9SBkIEAAAAAFEGQgQAAAAAUwZCBAAAAABQBkIEAAAAAFYGQgQAAAAAVQZCBAAAAABXBkIEAAAAAFQGQgQAAAAAAQJCACACQgAlAkAAAAAAACMUEgEQ+y4BAPsuAQAFAfsuASkBABAJAUEGRAQAAMhCAAAAAGsUEgEQ+1cBAPtXAQAFAftXARUBABBRCkAGSAQAAIA/RQZIBAAAgD9SBkIEAAAAAFEGQgQAAAAAUwZCBAAAAABQBkIEAAAAAFYGQgQAAAAAVQZCBAAAAABXBkIEAAAAAFQGQgQAAAAAAAAAAGMUEgEQ+2wBAPtsAQAFAftsARABABBJBnAOQAwCBAAAQEECBAAAQEFxDkAMAgQAAEBBAgQAAEBBcg5ADAIEAABAQQIEAABAQXMOQAwCBAAAQEECBAAAQEEDAkEABAJBAAAAAABPFBIBEPt8AQD7fAEABQH7fAEYAQAQNQcIAkIAUgZCBAAAMEJTBkIEAAAAQlAGQgQAAABCUQZCBAAAAEJABkgEAACAPycGQAQAAAAAAAAAACwUEgEQ+5QBAPuUAQAFAfuUARYBABARAlMGQgQAAAAASQZCBAAAAAABAQAAACwUEgEQ+6oBAPuqAQAFAfuqARUBABARAkAGSAQAAIA/RQZEBAAAyEIBAQAAAEgUEgEQ+78BAPu/AQAFAfu/ARgBABAtBggCQgBSBkIEAADAQVMGQgQAAMBBUAZCBAAAAABRBkIEAAAAAEAGSAQAAIA/AQEAAAAPAQ0AAAoBCAAABQECAgIA+9cBBQ==");
  

/***/ }),

/***/ 44:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfutATh0b2FzdC0tcm9vdHRvYXN0LS1jb250ZW50dG9hc3QtLWxvYWRpbmd0b2FzdC0tdGl0bGUyLjEuNAEAAQD7aQEEMQ4MAQoAAAAAAwEACwEAEB0FQAZDBAAAyEJBBkQEAADIQgECQgAiAkIAJQJAAAAAAADZDgwBCgsACwADAQsOAQAQxRNBBkIEAAAwQlIGQgQAAAAAUQZCBAAAoEFTBkIEAAAAAFAGQgQAAKBBcA5ADAIEAAAAQQIEAAAAQXEOQAwCBAAAAEECBAAAAEFyDkAMAgQAAABBAgQAAABBcw5ADAIEAAAAQQIEAAAAQTAGQgRMTEz/MQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAACICQgABAkIAAAAAAC0ODAEKGQAZAAMBGQ4BABAZA0AGQgQAAIBBQQZCBAAAgEFVBkIEAACAQAAAAAAtDgwBCicAJwADAScMAQAQGQMSBkAEZmZmP5AGQgQAAGBBEQZCBP////8AAAAAAQAzBQ==");
  

/***/ }),

/***/ 150:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfvMAbB1c2UtY291cG9uLW1vZGFsLS1yb290bXAtaGFsZi1zY3JlZW4tZGlhbG9nLS1ib2R5dXNlLWNvdXBvbi1tb2RhbC0tcm9vdG1wLWhhbGYtc2NyZWVuLWRpYWxvZy0tY29udGVudHVzZS1jb3Vwb24tbW9kYWwtLXJvb3R1c2UtY291cG9uLW1vZGFsLS1zY3JvbGx1c2UtY291cG9uLW1vZGFsLS1zY3JvbGwyLjEuNAEAAQD7AgEFGQ4MAQoAAAAAAwEAFgEAEAUBAgJCAAAAAABAGRcBFRYAFgADARYbAgsKMQAxAAMBMRYBACAhBFIGQgQAAAAAUQZCBAAAAABTBkIEAAAAAFAGQgQAAAAAAAAAAEAZFwEVRwBHAAMBRx4CCwplAGUAAwFlFgEAICEEUgZCBAAAAABRBkIEAAAAAFMGQgQAAAAAUAZCBAAAAAAAAAAARQ4MAQp7AHsAAwF7GAEAEDEHAwJCAAQCQgBBBkIEAADIQ1IGQgQAAIBBUQZCBAAAgEFTBkIEAACAQVAGQgQAAIBBAAAAAB4ODAEKkwCTAAMBkxgBABAJAUEGQgQAAHpDAQEAAAAPAQ0AAAoBCAAABQECAgIAqwU=");
  

/***/ }),

/***/ 510:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("Afv+EPtLBHVzZXItcHJvZmlsZS0tcm9vdHVzZXItcHJvZmlsZS0taGlkZXVzZXItcHJvZmlsZS0tbWFza3VzZXItcHJvZmlsZS0tbWFzay1pbnVzZXItcHJvZmlsZS0tY29udGFpbmVydXNlci1wcm9maWxlLS1jb250ZW50dXNlci1wcm9maWxlLS1jb250ZW50LWludXNlci1wcm9maWxlLS1oZWFkdXNlci1wcm9maWxlLS1ib2R5dXNlci1wcm9maWxlLS1idXR0b25zdXNlci1wcm9maWxlLS1pY29udXNlci1wcm9maWxlLS10aXRsZXVzZXItcHJvZmlsZS0tYXBwbHktaW5mb3VzZXItcHJvZmlsZS0tc3BsaXQtbGluZXVzZXItcHJvZmlsZS0taW5mby1pdGVtLWFkZHVzZXItcHJvZmlsZS0taW5mby1pdGVtLWFkZF9fcGx1c3VzZXItcHJvZmlsZS0taW5mby1pdGVtLWFkZF9fdGV4dHVzZXItcHJvZmlsZS0taW5mby1pdGVtdXNlci1wcm9maWxlLS1pbmZvLWl0ZW1fX2xlZnR1c2VyLXByb2ZpbGUtLWluZm8taXRlbV9fYXZhdGFydXNlci1wcm9maWxlLS1pbmZvLWl0ZW1fX2Rlc2NfX3dycHVzZXItcHJvZmlsZS0taW5mby1pdGVtX19uaWNrbmFtZXVzZXItcHJvZmlsZS0taW5mby1pdGVtX19kZXNjdXNlci1wcm9maWxlLS1pbmZvLWl0ZW1fX3JpZ2h0dXNlci1wcm9maWxlLS1pY29uLWNoZWNrZWR1c2VyLXByb2ZpbGUtLWV4Y2VlZC10aXB1c2VyLXByb2ZpbGUtLXVzZS1vdGhlci1hdmF0YXJ1c2VyLXByb2ZpbGUtLWJ1dHRvbnVzZXItcHJvZmlsZS0tY2FuY2VsdXNlci1wcm9maWxlLS1jb25maXJtdXNlci1wcm9maWxlLS1leGNlZWQtdGlwdXNlci1wcm9maWxlLS1jb250YWluZXJ1c2VyLXByb2ZpbGUtLWNvbnRhaW5lcnVzZXItcHJvZmlsZS0taGVhZHVzZXItcHJvZmlsZS0tYnV0dG9uc3VzZXItcHJvZmlsZS0tY29udGVudHVzZXItcHJvZmlsZS0tdGl0bGV1c2VyLXByb2ZpbGUtLWluZm8taXRlbV9fbmlja25hbWV1c2VyLXByb2ZpbGUtLWluZm8taXRlbV9fZGVzY3VzZXItcHJvZmlsZS0taW5mby1pdGVtLWFkZF9fdGV4dHVzZXItcHJvZmlsZS0tYXBwbHktaW5mb3VzZXItcHJvZmlsZS0tdXNlLW90aGVyLWF2YXRhcnVzZXItcHJvZmlsZS0tY2FuY2VsdXNlci1wcm9maWxlLS1leGNlZWQtdGlwdXNlci1wcm9maWxlLS1zcGxpdC1saW5lMi4xLjQBAAEA+3kMLUkODAEKAAAAAAMBABIBABA1CUEGRAQAAMhCQAZDBAAAyEIBAkIAkAZCBAAAYEEDAkEABAJBACACQgAiAkIABwZABABAekQAAAAAHQ4MAQoSABIAAwESEgEAEAkBQQZCBAAAAAAAAAAAnw4MAQokACQAAwEkEgEAEIsPQAZIBAAAgD9BBkgEAACAPzAGQgQAAAD/MQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAABIGQAQAAAAAgAZABAMBBACBBUADAgHIggZABAMBAACDBUADAgEAAAAAAB0ODAEKNgA2AAMBNhUBABAJARIGQAQAAAA/AAAAAE0ODAEKSwBLAAMBSxcBABA5BwMCQQAEAkEAQQZIBAAAgD8CAkIARgZIBAAAAD9JBkIEAABAwQkSQBAPAQMMCAQAAAC/AgQAAAAAAAAAAPsZAQ4MAQpiAGIAAwFiFQEAEPsDARwBAkIAQAZIBAAAgD8IAkIAUgZCBAAAAABRBkIEAADAQVMGQgQAAAAAUAZCBAAAwEEgAkIAgAZABAMBAQCBBUADAgHIggZABAMBAACDBUADAgEAUwZCBAAAQEFwDkAMAgQAAEBBAgQAAEBBcQ5ADAIEAABAQQIEAABAQXIOQAwCBAAAQEECBAAAQEFzDkAMAgQAAEBBAgQAAEBBMAZCBP////8xBkAEAwEAADQKQAgHAQAEAAAAADMWQBQTAQAQAgYIBAAAAAAABggEAAAAADIGQAQDAQAANQZABAMBAAA3BkAEAwEBADYGQAQDAQAAAgJCAEgGSAQAAIA/RgZCBAAAAAAAAAAAKQ4MAQp3AHcAAwF3GAEAEBUBCRJAEA8BAwwCBAAAAAAIBAAAgL8AAAAANQ4MAQqPAI8AAwGPEgEAECEFVgZCBAAAAEJXBkIEAACAQUEGQgQAAMBBAQJCACICQgAAAAAAIQ4MAQqhAKEAAwGhEgEAEA0CIAJCAFMGQgQAAEJDAAAAAFkODAEKswCzAAMBsxUBABBFC1QGQgQAAMBBQAZIBAAAgD9BBkIEAAAgQgICQgBJBkIEAADEQkYGQgQAAAAAkAZCBAAAiEGVAkEAAQJCACACQAAlAkAAAAAAAGUODAEKyADIAAMByBIBABBRBkAGQgQAAMBBQQZCBAAAwEFwDkAMCAQAAAA/CAQAAAA/cQ5ADAgEAAAAPwgEAAAAP3IOQAwIBAAAAD8IBAAAAD9zDkAMCAQAAAA/CAQAAAA/AAAAAFMODAEK2gDaAAMB2hMBABA/CFQGQgQAACBBEgZABGZmZj8RBkIEAAAA/5AGQgQAAHBBlQJBAEEGQgQAAKhBkwhBBgIEAACoQSYGQAQAAIA/AAAAAFsODAEK7QDtAAMB7RgBABBHCUAGSAQAAIA/QQZCBAAAQEISBkAEZmZmP5AGQgQAAIhBEQZCBAAAAP+VAkEAkwhBBgIEZma+QVYGQgQAAABBVwZCBAAAgEEAAAAAMxQSARD7BQEA+wUBAAUB+wUBGAEAEBkDQAZIBAAAgD9BBkIEAACAPzAGQgQAAAANAAAAACsUEgEQ+x0BAPsdAQAFAfsdARsBABARA0EGQgQAAIBCAQJCACICQgAAAAAAOxQSARD7OAEA+zgBAAUB+zgBIQEAECEEQAZCBAAAwEFBBkIEAADAQVQGQgQAAABBVQZCBAAAgEEAAAAARRQSARD7WQEA+1kBAAUB+1kBIQEAECsFJgZABAAAgD9BBkIEAADAQZMIQQYCBAAAwEGQBkIEAACIQREGQgQAAADmAAAAAC8UEgEQ+3oBAPt6AQAFAft6ARcBABAVBEEGQgQAAIBCAQJCACICQgAlAkMAAAAAADMUEgEQ+5EBAPuRAQAFAfuRAR0BABAZBEEGSAQAAIA/AQJCACICQgAmBkAEAACAPwAAAAB3FBIBEPuuAQD7rgEABQH7rgEfAQAQXQgBAkQAVQZCBAAAAEFABkIEAAAgQkEGQgQAACBCcA5ADAIEAACAQAIEAACAQHEOQAwCBAAAgEACBAAAgEByDkAMAgQAAIBAAgQAAIBAcw5ADAIEAACAQAIEAACAQAAAAAA3FBIBEPvNAQD7zQEABQH7zQEiAQAQHQUBAkIAQQZIBAAAgD8gAkIAJQJAACYGQAQAAIA/AAAAAD0UEgEQ++8BAPvvAQAFAfvvASEBABAjBEEGQgQAAMBBkwhBBgIEAADAQREGQgQAAADmkAZCBAAAiEEAAAAATRQSARD7EAIA+xACAAUB+xACHQEAEDMGVgZCBAAAAEBBBkIEAACgQZMIQQYCBAAAoEGQBkIEAABgQREGQgQAAAD/EgZABJqZmT4AAAAARxQSARD7LQIA+y0CAAUB+y0CHgEAEC0IQAZCBAAAwEFBBkIEAADAQQMCQQAEAkEAVQZCBAAAAEEBAkIAIgJCACUCQAAAAAAAKxQSARD7SwIA+0sCAAUB+0sCGgEAEBECQAZCBAAAwEFBBkIEAADAQQAAAABNFBIBEPtlAgD7ZQIABQH7ZQIYAQAQMwZABkgEAACAP0EGQgQAAKBBkwhBBgIEAACgQVYGQgQAAABBkAZCBAAAYEERBkIEAAAATQAAAABNFBIBEPt9AgD7fQIABQH7fQIeAQAQMwZABkgEAACAP0EGQgQAAKBBkwhBBgIEAACgQVYGQgQAAABBkAZCBAAAYEERBkIEWWuV/wAAAACZFBIBEPubAgD7mwIABQH7mwIUAQAQfwxABkIEAADwQkEGQgQAACBCkwhBBgIEAAAgQpQCQQBWBkIEAAAAAFUGQgQAAABBVwZCBAAAAABUBkIEAAAAQXAOQAwCBAAAgEACBAAAgEBxDkAMAgQAAIBAAgQAAIBAcg5ADAIEAACAQAIEAACAQHMOQAwCBAAAgEACBAAAgEAAAAAAdxQSARD7rwIA+68CAAUB+68CFAEAEF0JMAZCBAAAAA0xBkAEAwEAADQKQAgHAQAEAAAAADMWQBQTAQAQAgYIBAAAAAAABggEAAAAADIGQAQDAQAANQZABAMBAAA3BkAEAwEBADYGQAQDAQAAEQZCBAfBYP8AAAAAdxQSARD7wwIA+8MCAAUB+8MCFQEAEF0JMAZCBAfBYP8xBkAEAwEAADQKQAgHAQAEAAAAADMWQBQTAQAQAgYIBAAAAAAABggEAAAAADIGQAQDAQAANQZABAMBAAA3BkAEAwEBADYGQAQDAQAAEQZCBP////8AAAAAIxQSARD72AIA+9gCAAUB+9gCGAEAEAkBEQZCBAAAAE0AAAAAJBQSARD78AIA+/ACAAUB+/ACFwEAEAkBQAZDBAAAyEIBAQAAACQUEgEQ+wcDAPsHAwAFAfsHAxcBABAJAUAGRAQAAMhCAQEBAAAkFBIBEPseAwD7HgMABQH7HgMSAQAQCQFWBkIEAADAQQEBAQAAJBQSARD7MAMA+zADAAUB+zADFQEAEAkBSQZCBAAAVEIBAQEAAHAUEgEQ+0UDAPtFAwAFAftFAxUBABBVCDAGQgQeHh7/MQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAAAEBAgAALBQSARD7WgMA+1oDAAUB+1oDEwEAEBECEgZABM3MTD8RBkIE/////wEBAgAAJBQSARD7bQMA+20DAAUB+20DIQEAEAkBEQZCBP///8wBAQIAACQUEgEQ+44DAPuOAwAFAfuOAx0BABAJAREGQgT///9NAQECAAAkFBIBEPurAwD7qwMABQH7qwMhAQAQCQERBkIE////zAEBAgAALBQSARD7zAMA+8wDAAUB+8wDGAEAEBECEgZABM3MTD8RBkIE/////wEBAgAAJBQSARD75AMA++QDAAUB++QDHgEAEAkBEQZCBH2Qqf8BAQIAAHgUEgEQ+wIEAPsCBAAFAfsCBBQBABBdCTAGQgT///8UMQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAABEGQgT/////AQECAAAkFBIBEPsWBAD7FgQABQH7FgQYAQAQCQERBkIE////TQEBAgAAJBQSARD7LgQA+y4EAAUB+y4EGAEAEAkBMAZCBP///w0BAQIAACsDDQAACgEIAAAFAQICAQANAAAKAQgAAAUBAgICAA0AAAoBCAAABQEJAgIA+0YEBQ==");
  

/***/ }),

/***/ 133:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfvbAVZ2ZXJpZnktdGlwLS1yb290dmVyaWZ5LXRpcC0tY29udGVudHZlcmlmeS10aXAtLWZpcnN0dmVyaWZ5LXRpcC0tY2R2ZXJpZnktdGlwLS1tc2cyLjEuNAEAAQD7eQEFJQ4MAQoAAAAAAwEAEAEAEBECQAZDBAAAyEJBBkQEAADIQgAAAADnDgwBChAAEAADARATAQAQ0xUBAkIAIgJCAJAGQgQAAEBBkwhBBgIEAACgQREGQgQAAACAcA5ADAIEAAAgQQIEAAAgQXEOQAwCBAAAIEECBAAAIEFyDkAMAgQAACBBAgQAACBBcw5ADAIEAAAgQQIEAAAgQTAGQgT/////MQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAAAICQgBBBkIEAACgQVAGQgQAAABBUQZCBAAAAEEAAAAAIQ4MAQojACMAAwEjEQEAEA0DAQJCACUCQAAiAkIAAAAAACUODAEKNAA0AAMBNA4BABARBAECQgAgAkAAIgJCACUCQAAAAAAAIQ4MAQpCAEIAAwFCDwEAEA0DAQJCACUCQAAiAkIAAAAAAAEAUQU=");
  

/***/ }),

/***/ 505:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


    (__webpack_require__(498)/* .binStyles.push */ .J.push)("AfvIB91fX3d4X3RhYmJhcl9jb250YWluZXJfX3d4X3RhYmJhcl9jb250YWluZXItaGlkZV9fd3hfc2NsX19yb290X25vZGVfX3d4X3NjbF9fbGF5ZXJfX3d4X3NjbF9fbGF5ZXJfdW5kZXJfbWVudV9idXR0b25yb290cm9vdC1pbmNvbnRlbnRyb290Y29udGVudGNvbnRlbnQtaW5yb290Y29udGVudGNvbnRlbnQtaW50aXRsZWJvZHlidXR0b25zYnV0dG9ub2tvay1ob3ZlcmRlbnktaG92ZXIyLjEuNAEAAQD7wwYVIQ4MAQoAAAAAAwEAFQEAEA0CAgJDAEkGRAQAAMjCAAAAAB0ODAEKFQAVAAMBFRoBABAJAUkGRAQAAPDCAAAAAB0ODAEKLwAvAAMBLxMBABAJAUAGQwQAAMhCAAAAAB0ODAEKQgBCAAMBQg8BABAJAQcGQAQAQHpEAAAAAB0ODAEKUQBRAAMBUSEBABAJAQcGQAQAwHlEAAAAAKsODAEKcgByAAMBcgQBABCXEkEGRAQAAMhCAQJCADAGQgQgICC/MQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAAAMCQQAEAkEAkAZCBAAAgEESBkAEzczMPYAGQAQDAQQAgQVAAwIByIIGQAQDAQMAgwVAAwIBAAAAAAAdDgwBCnYAdgADAXYHAQAQCQESBkAEAACAPwAAAADbDgwBCn0AfQADAX0HAQAQxxMwBkIE+Pj4/zEGQAQDAQAANApACAcBAAQAAAAAMxZAFBMBABACBggEAAAAAAAGCAQAAAAAMgZABAMBAAA1BkAEAwEAADcGQAQDAQEANgZABAMBAAARBkIERERE/3AOQAwCBAAAIEECBAAAIEFxDkAMAgQAACBBAgQAACBBcg5ADAIEAAAgQQIEAAAgQXMOQAwCBAAAIEECBAAAIEGABkAEAwEBAIEFQAMCAciCBkAEAwEDAIMFQAMCAQBTBkIEAAAgQZQCQQAAAAAAGg4MAQqEAIQAAwGEBAEAEAUBIAJDAAEBAAAAMg4MAQqIAIgAAwGIBwEAEB0CQQZCBAAAm0MJEkAQDwEDDAIEAAAAAAIEAACbQwEBAAAAKg4MAQqPAI8AAwGPCgEAEBUBCRJAEA8BAwwCBAAAAAACBAAAIEEBAQAAABoODAEKmQCZAAMBmQQBABAFASACQQABAQEAADoODAEKnQCdAAMBnQcBABAlA0EGRAQAAMhCQAZCBAAAzUMJEkAQDwEDDAIEAADNQwIEAAAAAAEBAQAAKg4MAQqkAKQAAwGkCgEAEBUBCRJAEA8BAwwCBAAAIEECBAAAAAABAQEAACsODAEKrgCuAAMBrgUBABAXA5UCQQCQBkcEAADAP5MIQQYHBAAAAEAAAAAAVQ4MAQqzALMAAwGzBAEAEEEIJgZABAAAgD8nBkAEAACAPygGQgQAAAAAkAZHBJqZmT9WBkIEAABIQlUGQgQAAAAAVwZCBAAASEJUBkIEAAAAAAAAAAAxDgwBCrcAtwADAbcHAQAQHQWQBkcEmpmZPwECQgAgAkAAJQJAAFMGQgQAAEhCAAAAAPtDAQ4MAQq+AL4AAwG+BgEAEPstASFABkIEAADwQlIGRwQAAAA/UQZHBM3MzD1TBkcEAAAAP1AGRwTNzMw9MAZCBP////8xBkAEAwEAADQKQAgHAQAEAAAAADMWQBQTAQAQAgYIBAAAAAAABggEAAAAADIGQAQDAQAANQZABAMBAAA3BkAEAwEBADYGQAQDAQAAVgZCBAAAAABVBkIEAACgQVcGQgQAAAAAVAZCBAAAoEFwDkAMAgQAAIBAAgQAAIBAcQ5ADAIEAACAQAIEAACAQHIOQAwCBAAAgEACBAAAgEBzDkAMAgQAAIBAAgQAAIBAZgZCBAAAgD9jBkIEAACAP2kGQgQAAIA/YAZCBAAAgD9nAkEAZAJBAGoCQQBhAkEAaAZCBMzMzP9lBkIEzMzM/2sGQgTMzMz/YgZCBMzMzP8AAAAAuQ4MAQrEAMQAAwHEAgEAEKUUMAZCBAD/0v8xBkAEAwEAADQKQAgHAQAEAAAAADMWQBQTAQAQAgYIBAAAAAAABggEAAAAADIGQAQDAQAANQZABAMBAAA3BkAEAwEBADYGQAQDAQAAZgZCBAAAgD9jBkIEAACAP2kGQgQAAIA/YAZCBAAAgD9nAkEAZAJBAGoCQQBhAkEAaAZCBADMqv9lBkIEAMyq/2sGQgQAzKr/YgZCBADMqv8AAAAAaQ4MAQrGAMYAAwHGCAEAEFUIMAZCBADMqv8xBkAEAwEAADQKQAgHAQAEAAAAADMWQBQTAQAQAgYIBAAAAAAABggEAAAAADIGQAQDAQAANQZABAMBAAA3BkAEAwEBADYGQAQDAQAAAAAAAGkODAEKzgDOAAMBzgoBABBVCDAGQgTMzMz/MQZABAMBAAA0CkAIBwEABAAAAAAzFkAUEwEAEAIGCAQAAAAAAAYIBAAAAAAyBkAEAwEAADUGQAQDAQAANwZABAMBAQA2BkAEAwEAAAAAAAAdAg0AAAoBCAAABQECAgEADQAACgEIAAAFAQICAgDYBQ==");
  

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

// UNUSED EXPORTS: checkProducts

// NAMESPACE OBJECT: ./src/common.js
var common_namespaceObject = {};
__webpack_require__.r(common_namespaceObject);
__webpack_require__.d(common_namespaceObject, {
  appendStyleSheet: () => (appendStyleSheet),
  destroyTabBarContainer: () => (destroyTabBarContainer),
  exparser: () => (engine.exparser),
  getExparserElementByViewId: () => (getExparserElementByViewId),
  getMainRoot: () => (getMainRoot),
  getTabBarContainer: () => (getTabBarContainer),
  hideTabBarContainer: () => (hideTabBarContainer),
  initScl: () => (initScl),
  isInitialized: () => (isInitialized),
  loadStyleBincode: () => (loadStyleBincode),
  onViewportResize: () => (onViewportResize),
  registerComponent: () => (registerComponent),
  setCurrentFrameView: () => (setCurrentFrameView),
  setValidInit: () => (setValidInit),
  showTabBarContainer: () => (showTabBarContainer),
  triggerRender: () => (triggerRender)
});

// NAMESPACE OBJECT: ./src/components/forGameComponents.js
var forGameComponents_namespaceObject = {};
__webpack_require__.r(forGameComponents_namespaceObject);
__webpack_require__.d(forGameComponents_namespaceObject, {
  adSkipCard: () => (adSkipCard),
  authorize: () => (authorize),
  firstPay: () => (firstPay_firstPay),
  gameGrantInfo: () => (gameGrantInfo_gameGrantInfo),
  launchScreen: () => (launchScreen_launchScreen),
  officialToastPop: () => (officialToastPop),
  platformCoinPayModal: () => (platformCoinPayModal_platformCoinPayModal),
  privacyPop: () => (privacyPop),
  shareAppMessagePopup: () => (shareAppMessagePopup),
  shareImage: () => (shareImage),
  toast: () => (toast),
  useCouponModal: () => (useCouponModal_useCouponModal),
  userProfile: () => (userProfile),
  verifyTip: () => (verifyTip_verifyTip)
});

// EXTERNAL MODULE: ../../node_modules/.pnpm/@babel+runtime@7.22.6/node_modules/@babel/runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(715);
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);
// EXTERNAL MODULE: ./src/engine.js
var engine = __webpack_require__(817);
// EXTERNAL MODULE: ./src/styles/global_style.scss
var global_style = __webpack_require__(505);
// EXTERNAL MODULE: ./src/vendor/exparser.cmd.js
var exparser_cmd = __webpack_require__(995);
;// CONCATENATED MODULE: ./src/behaviors/theme.js


var themeChangeListeners = [];
engine.onThemeChange(res => {
  themeChangeListeners.forEach(cb => cb(res));
});
exparser_cmd.registerBehavior({
  is: 'wx-theme',
  data: {
    theme: 'light'
  },
  created() {
    this._onThemeChange({
      theme: engine.getTheme()
    });
  },
  attached() {
    this.__onThemeChange = this._onThemeChange.bind(this);
    themeChangeListeners.push(this.__onThemeChange);
  },
  detached() {
    themeChangeListeners.splice(themeChangeListeners.indexOf(this.__onThemeChange), 1);
  },
  methods: {
    _onThemeChange({
      theme
    }) {
      this.setData({
        theme
      });
    }
  }
});
;// CONCATENATED MODULE: ./src/behaviors/index.js

;// CONCATENATED MODULE: ./src/components/root.js

var root = exparser_cmd.registerElement({
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          V: 5,
          N: "",
          C: []
        }],
        BM: {}
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  methods: {
    append(compName, data, options = {}) {
      wxConsole.log('Append SCL root child', compName);
      var comp = this.shadowRoot.createComponent(compName);
      if (options.underMenuButton) {
        comp.classList.toggle('__wx_scl__layer_under_menu_button', true);
        comp.classList.toggle('__wx_scl__layer', false);
      } else {
        comp.classList.toggle('__wx_scl__layer_under_menu_button', false);
        comp.classList.toggle('__wx_scl__layer', true);
      }
      comp.addListener('destroy', e => {
        if (e.target === comp) this.remove(comp);
      });
      if (data) comp.setData(data);
      this.shadowRoot.appendChild(comp);
      exparser_cmd.triggerRender(() => {});
      return comp;
    },
    remove(comp) {
      wxConsole.log('Remove SCL root child', comp.is);
      this.shadowRoot.removeChild(comp);
    }
  }
});
;// CONCATENATED MODULE: ./src/components/tabBarRoot.js

var tabBarRoot = exparser_cmd.registerElement({
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          V: 5,
          N: "",
          C: []
        }],
        BM: {}
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  methods: {}
});
;// CONCATENATED MODULE: ./src/basicComponents/wx-view.js

var view = exparser_cmd.registerElement({
  is: 'wx-view',
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          V: 5,
          N: "",
          C: []
        }],
        BM: {}
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    hoverClass: String
  },
  listeners: {
    'this.touchstart': function () {
      this.hoverStart();
    },
    'this.touchend': function () {
      this.hoverEnd();
    },
    'this.canceltap': function () {
      this.hoverEnd();
    }
  },
  methods: {
    hoverStart() {
      if (!this.data.hoverClass) return;
      this.classList.toggle(this.data.hoverClass, true);
      exparser_cmd.triggerRender(() => {});
    },
    hoverEnd() {
      if (!this.data.hoverClass) return;
      this.classList.toggle(this.data.hoverClass, false);
      exparser_cmd.triggerRender(() => {});
    }
  }
});
;// CONCATENATED MODULE: ./src/basicComponents/wx-image.js

var wx_image_image = exparser_cmd.registerElement({
  is: 'wx-image',
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "image",
          A: {
            "src": {
              L: function (D, S, T) {
                return D.src;
              },
              F: function (D, S, T, W) {
                return D.src;
              }
            },
            "style": "width: 100%; height: 100%;"
          },
          C: []
        }],
        BM: {
          src: [[0, "src"]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    src: {
      type: String,
      public: true
    }
  }
});
;// CONCATENATED MODULE: ./src/basicComponents/wx-adaptive-image.js

var adaptiveImage = exparser_cmd.registerElement({
  is: 'wx-adaptive-image',
  externalClasses: ['img-class'],
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "wx-view",
          A: {
            "id": "wrapper",
            "style": {
              L: function (D, S, T) {
                return !!(D.objectFit || D.objectFit || D.objectFit) || undefined;
              },
              F: function (D, S, T, W) {
                return (D.objectFit !== "fill-height" ? "width: 100%;" : "") + (D.objectFit !== "fill-width" ? "height: 100%;" : "") + " display: " + (D.objectFit === "fill-height" ? "inline-flex" : "flex") + "; flex-direction: column; flex: auto; flex-shrink: 0; align-items: center; justify-content: center;";
              }
            }
          },
          C: [{
            T: "image",
            A: {
              "src": {
                L: function (D, S, T) {
                  return D.src;
                },
                F: function (D, S, T, W) {
                  return D.src;
                }
              },
              "class": "img-class",
              "style": {
                L: function (D, S, T) {
                  return !!(D.imgStyleWidth || D.imgStyleHeight) || undefined;
                },
                F: function (D, S, T, W) {
                  return "width: " + D.imgStyleWidth + "px; height: " + D.imgStyleHeight + "px;";
                }
              }
            },
            C: []
          }]
        }],
        BM: {
          objectFit: [[0, "style"], [0, "style"], [0, "style"]],
          imgStyleHeight: [[0, 0, "style"]],
          imgStyleWidth: [[0, 0, "style"]],
          src: [[0, 0, "src"]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    src: {
      type: String,
      public: true
    },
    srcWidth: {
      type: Number,
      public: true,
      value: 0,
      observer: '_onSrcSizeChange'
    },
    srcHeight: {
      type: Number,
      public: true,
      value: 0,
      observer: '_onSrcSizeChange'
    },
    objectFit: {
      type: String,
      public: true,
      value: 'fill-width',
      observer: '_onSrcSizeChange'
    }
  },
  data: {
    imgStyleWidth: 0,
    imgStyleHeight: 0
  },
  attached() {
    this.attached = true;
    this._onSrcSizeChange();
  },
  detached() {
    this.attached = false;
  },
  methods: {
    _onSrcSizeChange() {
      if (!this.attached) return;
      var imgRect = this.$$.getBoundingClientRect();
      switch (this.data.objectFit) {
        case 'contain':
          {
            var widthRatio = Math.min(imgRect.width, this.data.srcWidth) / this.data.srcWidth;
            var heightRatio = Math.min(imgRect.height, this.data.srcHeight) / this.data.srcHeight;
            var ratio = Math.min(widthRatio, heightRatio);
            var width = this.data.srcWidth * ratio;
            var height = this.data.srcHeight * ratio;
            this.setData({
              imgStyleWidth: width,
              imgStyleHeight: height
            });
            return;
          }
        case 'fill-height':
          {
            var _height = Math.min(imgRect.height, this.data.srcHeight);
            var _width = _height * this.data.srcWidth / this.data.srcHeight;
            this.setData({
              imgStyleWidth: _width,
              imgStyleHeight: _height
            });
            return;
          }
        case 'fill-width':
        default:
          {
            var _width2 = Math.min(imgRect.width, this.data.srcWidth);
            var _height2 = _width2 * this.data.srcHeight / this.data.srcWidth;
            this.setData({
              imgStyleWidth: _width2,
              imgStyleHeight: _height2
            });
            return;
          }
      }
    }
  }
});
;// CONCATENATED MODULE: ./src/basicComponents/wx-scroll-view.js

var scrollView = exparser_cmd.registerElement({
  is: 'wx-scroll-view',
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "scrollview",
          A: {
            "scroll-x": {
              L: function (D, S, T) {
                return !!D.scrollX || undefined;
              },
              F: function (D, S, T, W) {
                return D.scrollX ? "1" : "";
              }
            },
            "scroll-y": {
              L: function (D, S, T) {
                return !!D.scrollY || undefined;
              },
              F: function (D, S, T, W) {
                return D.scrollY ? "1" : "";
              }
            },
            "style": "width: 100%; height: 100%"
          },
          C: [{
            T: "view",
            A: {},
            C: [{
              V: 5,
              N: "",
              C: []
            }]
          }]
        }],
        BM: {
          scrollX: [[0, "scroll-x"]],
          scrollY: [[0, "scroll-y"]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    scrollX: {
      type: Boolean,
      public: true,
      value: false
    },
    scrollY: {
      type: Boolean,
      public: true,
      value: false
    }
  }
});
;// CONCATENATED MODULE: ../../node_modules/.pnpm/val-loader@3.1.0_webpack@5.88.1/node_modules/val-loader/dist/cjs.js!./src/vendor/glass_easel_template_runtime.js

      var X=function(a){return a==null?Object.create(null):a};var Z=function(a,b){if(a===true)return true;if(a)return a[b]};;
      
    
// EXTERNAL MODULE: ./src/basicComponents/mpBubbleActionSheet/style.scss
var style = __webpack_require__(973);
;// CONCATENATED MODULE: ./src/basicComponents/mpBubbleActionSheet/index.js










var mpBubbleActionSheet = engine.exparser.registerElement({
  is: 'mp-bubble-action-sheet',
  behaviors: ['wx-theme'],
  options: {
    multipleSlots: true,
    classPrefix: 'mp-bubble-action-sheet',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "mp-half-screen-popup",
          A: {
            "show": {
              L: function (D, S, T) {
                return D.show;
              },
              F: function (D, S, T, W) {
                return D.show;
              }
            },
            "mask": {
              L: function (D, S, T) {
                return D.mask;
              },
              F: function (D, S, T, W) {
                return D.mask;
              }
            },
            "mask-closable": {
              L: function (D, S, T) {
                return D.maskClosable;
              },
              F: function (D, S, T, W) {
                return D.maskClosable;
              }
            },
            "bind:close": "handleClose",
            "bind:closed": "handleClosed"
          },
          C: [{
            T: "wx-view",
            A: {
              "class": "mask",
              "slot": "mask"
            },
            C: [{
              V: 5,
              N: "mask",
              C: []
            }]
          }, {
            T: "wx-view",
            A: {
              "class": "content"
            },
            C: [{
              T: "wx-view",
              A: {
                "class": "menu"
              },
              C: [{
                V: 1,
                B: [{
                  B: {
                    L: function (D, S, T) {
                      return !!D.theme || undefined;
                    },
                    F: function (D, S, T, W) {
                      return D.theme === "light";
                    }
                  },
                  C: [{
                    V: 2,
                    L: {
                      M: ["actions"],
                      L: function (D, S, T) {
                        return D.actions;
                      },
                      F: function (D, S, T, W) {
                        return D.actions;
                      }
                    },
                    K: "index",
                    C: [{
                      T: "wx-view",
                      A: {
                        "class": "cell",
                        "hover-class": "cell__hover",
                        "data-index": {
                          L: function (D, S, T) {
                            return S[1];
                          },
                          F: function (D, S, T, W) {
                            return S[1];
                          }
                        },
                        "bind:tap": "buttonTap"
                      },
                      C: [{
                        T: "wx-view",
                        A: {
                          "class": "cell-img-container"
                        },
                        C: [{
                          T: "wx-image",
                          A: {
                            "class": "cell-img",
                            "src": {
                              L: function (D, S, T) {
                                return Z(S[0], "imageSrc");
                              },
                              F: function (D, S, T, W) {
                                return X(S[0]).imageSrc;
                              }
                            }
                          },
                          C: []
                        }]
                      }, {
                        T: "wx-view",
                        A: {
                          "class": "cell-desc"
                        },
                        C: [{
                          S: {
                            L: function (D, S, T) {
                              return Z(S[0], "text");
                            },
                            F: function (D, S, T, W) {
                              return X(S[0]).text;
                            }
                          }
                        }]
                      }]
                    }]
                  }]
                }, {
                  B: {
                    L: function (D, S, T) {
                      return !!D.theme || undefined;
                    },
                    F: function (D, S, T, W) {
                      return D.theme === "dark";
                    }
                  },
                  C: [{
                    V: 2,
                    L: {
                      M: ["actions"],
                      L: function (D, S, T) {
                        return D.actions;
                      },
                      F: function (D, S, T, W) {
                        return D.actions;
                      }
                    },
                    K: "index",
                    C: [{
                      T: "wx-view",
                      A: {
                        "class": "cell",
                        "hover-class": "cell__hover",
                        "data-index": {
                          L: function (D, S, T) {
                            return S[1];
                          },
                          F: function (D, S, T, W) {
                            return S[1];
                          }
                        },
                        "bind:tap": "buttonTap"
                      },
                      C: [{
                        T: "wx-view",
                        A: {
                          "class": "cell-img-container"
                        },
                        C: [{
                          T: "wx-image",
                          A: {
                            "class": "cell-img",
                            "src": {
                              L: function (D, S, T) {
                                return Z(S[0], "imageDarkSrc");
                              },
                              F: function (D, S, T, W) {
                                return X(S[0]).imageDarkSrc;
                              }
                            }
                          },
                          C: []
                        }]
                      }, {
                        T: "wx-view",
                        A: {
                          "class": "cell-desc"
                        },
                        C: [{
                          S: {
                            L: function (D, S, T) {
                              return Z(S[0], "text");
                            },
                            F: function (D, S, T, W) {
                              return X(S[0]).text;
                            }
                          }
                        }]
                      }]
                    }]
                  }]
                }]
              }]
            }, {
              T: "wx-view",
              A: {
                "class": "foot"
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": "button",
                  "hover-class": "button__hover",
                  "bind:tap": "handleClose"
                },
                C: [{
                  T: "wx-view",
                  A: {
                    "class": "button__before"
                  },
                  C: []
                }, {
                  T: "wx-view",
                  A: {
                    "class": "button__content"
                  },
                  C: [{
                    S: {
                      L: function (D, S, T) {
                        return D.cancelText;
                      },
                      F: function (D, S, T, W) {
                        return D.cancelText;
                      }
                    }
                  }]
                }]
              }]
            }]
          }]
        }],
        BM: {
          show: [[0, "show"]],
          mask: [[0, "mask"]],
          cancelText: [[0, 1, 1, 0, 1, 0]],
          maskClosable: [[0, "mask-closable"]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    maskClosable: {
      type: Boolean,
      value: true
    },
    mask: {
      type: Boolean,
      value: true
    },
    show: {
      type: Boolean,
      value: false
    },
    cancelText: {
      type: String,
      value: '取消'
    },
    actions: {
      type: Array,
      value: []
    }
  },
  methods: {
    buttonTap(e) {
      var {
        index
      } = e.currentTarget.dataset;
      this.triggerEvent('buttontap', {
        index,
        item: this.data.actions[index]
      }, {});
    },
    handleClose() {
      this.triggerEvent('close', {}, {});
    },
    handleClosed() {
      this.triggerEvent('closed', {}, {});
    },
    stopEvent() {}
  }
});
;// CONCATENATED MODULE: ./src/utils.js


var getUsefulData = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_default()(function* () {
    var _wxConfig, _wxConfig$host;
    var theme = engine.getTheme();
    var {
      width,
      height
    } = yield engine.getViewportSize();
    var realWidth = Math.min(width, height) || 0;
    return {
      theme,
      isCar: ((_wxConfig = __wxConfig) === null || _wxConfig === void 0 ? void 0 : (_wxConfig$host = _wxConfig.host) === null || _wxConfig$host === void 0 ? void 0 : _wxConfig$host.type) === 'vehicle',
      isPad: realWidth >= 600,
      popWidth: `width: ${Math.max(realWidth / 2, 414)}px;`
    };
  });
  return function getUsefulData() {
    return _ref.apply(this, arguments);
  };
}();
var viewportResizeEvent = () => {
  var listeners = [];
  engine.onViewportResize(() => {
    listeners.forEach(cb => cb());
  });
  return {
    on(callback) {
      listeners.push(callback);
    },
    off(callback) {
      listeners.splice(listeners.indexOf(callback), 1);
    }
  };
};
// EXTERNAL MODULE: ./src/basicComponents/mpSeparateBubbleActionSheet/style.scss
var mpSeparateBubbleActionSheet_style = __webpack_require__(818);
;// CONCATENATED MODULE: ./src/basicComponents/mpSeparateBubbleActionSheet/index.js







var viewportResizeListeners = [];
engine.onViewportResize(res => {
  viewportResizeListeners.forEach(cb => cb(res));
});
var exparser = engine.exparser;
var mpSeparateBubbleActionSheet = exparser.registerElement({
  is: 'mp-separate-bubble-action-sheet',
  options: {
    multipleSlots: true,
    classPrefix: 'mp-separate-bubble-action-sheet',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "wx-view",
          A: {
            "class": "root"
          },
          C: [{
            T: "wx-view",
            A: {
              "class": "mask-container"
            },
            C: [{
              V: 1,
              B: [{
                B: {
                  L: function (D, S, T) {
                    return D.mask;
                  },
                  F: function (D, S, T, W) {
                    return D.mask;
                  }
                },
                C: [{
                  T: "wx-view",
                  A: {
                    "class": {
                      L: function (D, S, T) {
                        return !!D.show || undefined;
                      },
                      F: function (D, S, T, W) {
                        return "mask " + (D.show ? "mask__in" : "");
                      }
                    }
                  },
                  C: []
                }]
              }]
            }]
          }, {
            T: "wx-view",
            A: {
              "class": "container",
              "bind:tap": "handleClose"
            },
            C: [{
              T: "wx-view",
              A: {
                "class": "content",
                "catch:tap": "stopEvent"
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": {
                    L: function (D, S, T) {
                      return !!D.show || undefined;
                    },
                    F: function (D, S, T, W) {
                      return "img-container " + (D.show ? "img-container__in" : "");
                    }
                  }
                },
                C: [{
                  T: "wx-adaptive-image",
                  A: {
                    "class": "img",
                    "img-class": "img-inner",
                    "src": {
                      L: function (D, S, T) {
                        return D.imgPath;
                      },
                      F: function (D, S, T, W) {
                        return D.imgPath;
                      }
                    },
                    "srcHeight": {
                      L: function (D, S, T) {
                        return D.imgHeight;
                      },
                      F: function (D, S, T, W) {
                        return D.imgHeight;
                      }
                    },
                    "srcWidth": {
                      L: function (D, S, T) {
                        return D.imgWidth;
                      },
                      F: function (D, S, T, W) {
                        return D.imgWidth;
                      }
                    },
                    "object-fit": {
                      L: function (D, S, T) {
                        return !!D.orientation || undefined;
                      },
                      F: function (D, S, T, W) {
                        return D.orientation === "portrait" ? "contain" : "fill-height";
                      }
                    }
                  },
                  C: []
                }]
              }, {
                T: "wx-view",
                A: {
                  "class": {
                    L: function (D, S, T) {
                      return !!D.show || undefined;
                    },
                    F: function (D, S, T, W) {
                      return "menu " + (D.show ? "menu__in" : "");
                    }
                  }
                },
                C: [{
                  V: 2,
                  L: {
                    M: ["actions"],
                    L: function (D, S, T) {
                      return D.actions;
                    },
                    F: function (D, S, T, W) {
                      return D.actions;
                    }
                  },
                  K: "index",
                  C: [{
                    T: "wx-view",
                    A: {
                      "class": "cell",
                      "hover-class": "cell__hover",
                      "data-index": {
                        L: function (D, S, T) {
                          return S[1];
                        },
                        F: function (D, S, T, W) {
                          return S[1];
                        }
                      },
                      "bind:tap": "buttonTap"
                    },
                    C: [{
                      T: "wx-view",
                      A: {
                        "class": "cell-img-container"
                      },
                      C: [{
                        T: "wx-image",
                        A: {
                          "class": "cell-img",
                          "src": {
                            L: function (D, S, T) {
                              return Z(S[0], "imageSrc");
                            },
                            F: function (D, S, T, W) {
                              return X(S[0]).imageSrc;
                            }
                          }
                        },
                        C: []
                      }]
                    }, {
                      T: "wx-view",
                      A: {
                        "class": "cell-desc"
                      },
                      C: [{
                        S: {
                          L: function (D, S, T) {
                            return Z(S[0], "text");
                          },
                          F: function (D, S, T, W) {
                            return X(S[0]).text;
                          }
                        }
                      }]
                    }]
                  }]
                }]
              }]
            }]
          }]
        }],
        BM: {
          imgPath: [[0, 1, 0, 0, 0, "src"]],
          imgWidth: [[0, 1, 0, 0, 0, "srcWidth"]],
          imgHeight: [[0, 1, 0, 0, 0, "srcHeight"]],
          orientation: [[0, 1, 0, 0, 0, "object-fit"]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    maskClosable: {
      type: Boolean,
      value: true
    },
    mask: {
      type: Boolean,
      value: true
    },
    show: {
      type: Boolean,
      value: false
    },
    actions: {
      type: Array,
      value: []
    },
    imgPath: {
      type: String,
      public: true,
      value: ''
    },
    imgHeight: {
      type: Number,
      public: true,
      value: 0
    },
    imgWidth: {
      type: Number,
      public: true,
      value: 0
    }
  },
  data: {
    orientation: 'portrait'
  },
  created() {
    this.onViewportResize();
  },
  attached() {
    this.attached = true;
    exparser.triggerRender(() => {
      getUsefulData().then(data => this.setData(data));
    });
    this._onViewportResize = this.onViewportResize.bind(this);
    viewportResizeListeners.push(this._onViewportResize);
  },
  detached() {
    viewportResizeListeners.splice(viewportResizeListeners.indexOf(this._onViewportResize), 1);
  },
  observers: {
    show(show) {
      if (!this.attached) return;
      clearTimeout(this.closeTimeout);
      clearTimeout(this.showTimeout);
      if (!show) {
        this.closeTimeout = setTimeout(() => {
          this.triggerEvent('closed', {}, {});
        }, 300);
      } else {
        this.showTimeout = setTimeout(() => {
          this.triggerEvent('showed', {}, {});
        }, 300);
      }
    }
  },
  methods: {
    onViewportResize() {
      var viewportWidth = engine.getWindowWidth();
      var viewportHeight = engine.getWindowHeight();
      this.updateOrientation(viewportWidth, viewportHeight);
    },
    updateOrientation(viewportWidth, viewportHeight) {
      this.setData({
        orientation: viewportWidth <= viewportHeight ? 'portrait' : 'landscape'
      });
    },
    buttonTap(e) {
      var {
        index
      } = e.currentTarget.dataset;
      this.triggerEvent('buttontap', {
        index,
        item: this.data.actions[index]
      }, {});
    },
    handleClose() {
      if (!this.data.maskClosable) return;
      this.triggerEvent('close', {}, {});
    },
    stopEvent() {}
  }
});
// EXTERNAL MODULE: ./src/basicComponents/mpDialog/style.scss
var mpDialog_style = __webpack_require__(124);
;// CONCATENATED MODULE: ./src/basicComponents/mpDialog/index.js








var mpDialog = exparser_cmd.registerElement({
  is: 'mp-dialog',
  options: {
    multipleSlots: true,
    classPrefix: 'mp-dialog',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "wx-view",
          A: {
            "class": "root"
          },
          C: [{
            V: 1,
            B: [{
              B: {
                L: function (D, S, T) {
                  return D.mask;
                },
                F: function (D, S, T, W) {
                  return D.mask;
                }
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": {
                    L: function (D, S, T) {
                      return !!D.show || undefined;
                    },
                    F: function (D, S, T, W) {
                      return "mask " + (D.show ? "mask__in" : "");
                    }
                  },
                  "bind:tap": "handleClose"
                },
                C: []
              }]
            }]
          }, {
            T: "wx-view",
            A: {
              "class": "container",
              "bind:tap": "handleClose"
            },
            C: [{
              T: "wx-view",
              A: {
                "class": {
                  L: function (D, S, T) {
                    return !!D.show || undefined;
                  },
                  F: function (D, S, T, W) {
                    return "content " + (D.show ? "content__in" : "");
                  }
                },
                "catch:tap": "stopEvent"
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": "head"
                },
                C: [{
                  T: "wx-view",
                  A: {
                    "class": "title"
                  },
                  C: [{
                    V: 5,
                    N: "title",
                    C: []
                  }]
                }]
              }, {
                T: "wx-view",
                A: {
                  "class": "body"
                },
                C: [{
                  V: 5,
                  N: "body",
                  C: []
                }]
              }, {
                T: "wx-view",
                A: {
                  "class": "foot"
                },
                C: [{
                  V: 1,
                  B: [{
                    B: {
                      L: function (D, S, T) {
                        return !!(D.innerButtons || Z(D.innerButtons, "length")) || undefined;
                      },
                      F: function (D, S, T, W) {
                        return D.innerButtons && X(D.innerButtons).length;
                      }
                    },
                    C: [{
                      V: 2,
                      L: {
                        M: ["innerButtons"],
                        L: function (D, S, T) {
                          return D.innerButtons;
                        },
                        F: function (D, S, T, W) {
                          return D.innerButtons;
                        }
                      },
                      K: "index",
                      C: [{
                        T: "wx-view",
                        A: {
                          "class": {
                            L: function (D, S, T) {
                              return !!Z(S[0], "className") || undefined;
                            },
                            F: function (D, S, T, W) {
                              return "button " + X(S[0]).className;
                            }
                          },
                          "hover-class": "button__active",
                          "data-index": {
                            L: function (D, S, T) {
                              return S[1];
                            },
                            F: function (D, S, T, W) {
                              return S[1];
                            }
                          },
                          "bind:tap": "buttonTap"
                        },
                        C: [{
                          S: {
                            L: function (D, S, T) {
                              return !!Z(S[0], "text") || undefined;
                            },
                            F: function (D, S, T, W) {
                              return "\n                  " + X(S[0]).text + "\n                  ";
                            }
                          }
                        }, {
                          V: 1,
                          B: [{
                            B: {
                              L: function (D, S, T) {
                                return !!S[1] || undefined;
                              },
                              F: function (D, S, T, W) {
                                return S[1] > 0;
                              }
                            },
                            C: [{
                              T: "wx-view",
                              A: {
                                "class": "button__after"
                              },
                              C: []
                            }]
                          }]
                        }]
                      }]
                    }]
                  }]
                }, {
                  V: 5,
                  N: "footer",
                  C: []
                }, {
                  T: "wx-view",
                  A: {
                    "class": "foot__after"
                  },
                  C: []
                }]
              }]
            }]
          }]
        }],
        BM: {}
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    title: {
      type: String,
      value: ''
    },
    maskClosable: {
      type: Boolean,
      value: true
    },
    mask: {
      type: Boolean,
      value: true
    },
    show: {
      type: Boolean,
      value: false
    },
    buttons: {
      type: Array,
      value: []
    }
  },
  data: {
    innerButtons: []
  },
  attached() {
    this.attached = true;
  },
  observers: {
    buttons(buttons) {
      var len = buttons.length;
      this.setData({
        innerButtons: buttons.map((btn, index) => {
          var type = btn.type || (len >= 1 && index === 0 ? 'default' : 'primary');
          var className = (btn.className || '') + ' button__' + type;
          return {
            className,
            text: btn.text
          };
        })
      });
    },
    show(show) {
      if (!this.attached) return;
      clearTimeout(this.closeTimeout);
      clearTimeout(this.showTimeout);
      if (!show) {
        this.closeTimeout = setTimeout(() => {
          this.triggerEvent('closed', {}, {});
        }, 200);
      } else {
        this.showTimeout = setTimeout(() => {
          this.triggerEvent('showed', {}, {});
        }, 200);
      }
    }
  },
  methods: {
    buttonTap(e) {
      var {
        index
      } = e.currentTarget.dataset;
      this.triggerEvent('buttontap', {
        index,
        item: this.data.buttons[index]
      }, {});
    },
    handleClose() {
      if (!this.data.maskClosable) return;
      this.triggerEvent('close', {}, {});
    },
    stopEvent() {}
  }
});
// EXTERNAL MODULE: ./src/basicComponents/mpHalfScreenDialog/style.scss
var mpHalfScreenDialog_style = __webpack_require__(210);
;// CONCATENATED MODULE: ./src/basicComponents/mpHalfScreenDialog/index.js









var viewportResize = viewportResizeEvent();
var mpHalfScreenDialog = exparser_cmd.registerElement({
  is: 'mp-half-screen-dialog',
  options: {
    multipleSlots: true,
    classPrefix: 'mp-half-screen-dialog',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "mp-half-screen-popup",
          A: {
            "show": {
              L: function (D, S, T) {
                return D.show;
              },
              F: function (D, S, T, W) {
                return D.show;
              }
            },
            "mask": {
              L: function (D, S, T) {
                return D.mask;
              },
              F: function (D, S, T, W) {
                return D.mask;
              }
            },
            "mask-closable": {
              L: function (D, S, T) {
                return D.maskClosable;
              },
              F: function (D, S, T, W) {
                return D.maskClosable;
              }
            },
            "bind:close": "handleClose",
            "bind:closed": "handleClosed"
          },
          C: [{
            T: "wx-view",
            A: {
              "class": "content"
            },
            C: [{
              T: "wx-view",
              A: {
                "class": "head"
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": "title"
                },
                C: [{
                  V: 5,
                  N: "title",
                  C: []
                }]
              }]
            }, {
              T: "wx-view",
              A: {
                "class": "body"
              },
              C: [{
                V: 5,
                N: "body",
                C: []
              }]
            }, {
              T: "wx-view",
              A: {
                "class": {
                  L: function (D, S, T) {
                    return !!D.isCar || undefined;
                  },
                  F: function (D, S, T, W) {
                    return "foot " + (D.isCar ? "foot-reverse" : "");
                  }
                }
              },
              C: [{
                V: 1,
                B: [{
                  B: {
                    L: function (D, S, T) {
                      return !!(D.innerButtons || Z(D.innerButtons, "length")) || undefined;
                    },
                    F: function (D, S, T, W) {
                      return D.innerButtons && X(D.innerButtons).length;
                    }
                  },
                  C: [{
                    V: 2,
                    L: {
                      M: ["innerButtons"],
                      L: function (D, S, T) {
                        return D.innerButtons;
                      },
                      F: function (D, S, T, W) {
                        return D.innerButtons;
                      }
                    },
                    K: "index",
                    C: [{
                      T: "wx-view",
                      A: {
                        "class": {
                          L: function (D, S, T) {
                            return !!Z(S[0], "className") || undefined;
                          },
                          F: function (D, S, T, W) {
                            return "button " + X(S[0]).className;
                          }
                        },
                        "hover-class": "button__active",
                        "data-index": {
                          L: function (D, S, T) {
                            return S[1];
                          },
                          F: function (D, S, T, W) {
                            return S[1];
                          }
                        },
                        "bind:tap": "buttonTap"
                      },
                      C: [{
                        S: {
                          L: function (D, S, T) {
                            return !!Z(S[0], "text") || undefined;
                          },
                          F: function (D, S, T, W) {
                            return "\n                " + X(S[0]).text + "\n              ";
                          }
                        }
                      }]
                    }]
                  }]
                }]
              }, {
                V: 5,
                N: "footer",
                C: []
              }]
            }]
          }]
        }],
        BM: {
          isCar: [[0, 0, 2, "class"]],
          mask: [[0, "mask"]],
          show: [[0, "show"]],
          maskClosable: [[0, "mask-closable"]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    title: {
      type: String,
      value: ''
    },
    maskClosable: {
      type: Boolean,
      value: true
    },
    mask: {
      type: Boolean,
      value: true
    },
    show: {
      type: Boolean,
      value: false
    },
    buttons: {
      type: Array,
      value: []
    }
  },
  data: {
    innerShow: false,
    innerButtons: []
  },
  attached() {
    exparser_cmd.triggerRender(() => {
      this.onViewportResize();
    });
    this._onViewportResize = this.onViewportResize.bind(this);
    viewportResize.on(this._onViewportResize);
  },
  detached() {
    viewportResize.off(this._onViewportResize);
  },
  observers: {
    buttons(buttons) {
      var len = buttons.length;
      this.setData({
        innerButtons: buttons.map((btn, index) => {
          var type = btn.type || (len >= 1 && index === 0 ? 'default' : 'primary');
          var className = (btn.className || '') + ' button__' + type;
          return {
            className,
            text: btn.text
          };
        })
      });
    }
  },
  methods: {
    onViewportResize() {
      getUsefulData().then(data => this.setData(data));
    },
    buttonTap(e) {
      var {
        index
      } = e.currentTarget.dataset;
      this.triggerEvent('buttontap', {
        index,
        item: this.data.buttons[index]
      }, {});
    },
    handleClose() {
      this.triggerEvent('close', {}, {});
    },
    handleClosed() {
      this.triggerEvent('closed', {}, {});
    },
    stopEvent() {}
  }
});
// EXTERNAL MODULE: ./src/basicComponents/mpHalfScreenPopup/style.scss
var mpHalfScreenPopup_style = __webpack_require__(169);
;// CONCATENATED MODULE: ./src/basicComponents/mpHalfScreenPopup/index.js



var mpHalfScreenPopup_viewportResize = viewportResizeEvent();
var mpHalfScreenPopup = exparser_cmd.registerElement({
  is: 'mp-half-screen-popup',
  options: {
    multipleSlots: true,
    classPrefix: 'mp-half-screen-popup',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "wx-view",
          A: {
            "class": {
              L: function (D, S, T) {
                return !!D.isPad || undefined;
              },
              F: function (D, S, T, W) {
                return "root " + (D.isPad ? "pad" : "");
              }
            }
          },
          C: [{
            V: 1,
            B: [{
              B: {
                L: function (D, S, T) {
                  return D.mask;
                },
                F: function (D, S, T, W) {
                  return D.mask;
                }
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": {
                    L: function (D, S, T) {
                      return !!D.show || undefined;
                    },
                    F: function (D, S, T, W) {
                      return "mask " + (D.show ? "mask__in" : "");
                    }
                  },
                  "bind:tap": "handleClose"
                },
                C: []
              }]
            }]
          }, {
            V: 5,
            N: "mask",
            C: []
          }, {
            T: "wx-view",
            A: {
              "class": {
                L: function (D, S, T) {
                  return !!D.show || undefined;
                },
                F: function (D, S, T, W) {
                  return "container " + (D.show ? "container__in" : "");
                }
              },
              "bind:tap": "handleClose"
            },
            C: [{
              T: "wx-view",
              A: {
                "class": "content",
                "catch:tap": "stopEvent",
                "style": {
                  L: function (D, S, T) {
                    return !!(D.isPad || D.popWidth) || undefined;
                  },
                  F: function (D, S, T, W) {
                    return D.isPad ? D.popWidth : "";
                  }
                }
              },
              C: [{
                V: 5,
                N: "",
                C: []
              }]
            }]
          }]
        }],
        BM: {
          isPad: [[0, "class"], [0, 2, 0, "style"]],
          popWidth: [[0, 2, 0, "style"]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    maskClosable: {
      type: Boolean,
      value: true
    },
    mask: {
      type: Boolean,
      value: true
    },
    show: {
      type: Boolean,
      value: false
    }
  },
  attached() {
    this.attached = true;
    exparser_cmd.triggerRender(() => {
      this.onViewportResize();
    });
    this._onViewportResize = this.onViewportResize.bind(this);
    mpHalfScreenPopup_viewportResize.on(this._onViewportResize);
  },
  detached() {
    mpHalfScreenPopup_viewportResize.off(this._onViewportResize);
  },
  observers: {
    show(show) {
      if (!this.attached) return;
      clearTimeout(this.closeTimeout);
      clearTimeout(this.showTimeout);
      if (!show) {
        this.closeTimeout = setTimeout(() => {
          this.triggerEvent('closed', {}, {});
        }, 200);
      } else {
        this.showTimeout = setTimeout(() => {
          this.triggerEvent('showed', {}, {});
        }, 200);
      }
    }
  },
  methods: {
    onViewportResize() {
      getUsefulData().then(data => this.setData(data));
    },
    handleClose() {
      if (!this.data.maskClosable) return;
      this.triggerEvent('close', {}, {});
    },
    stopEvent() {}
  }
});
// EXTERNAL MODULE: ./src/basicComponents/mpHorizonalBubble/style.scss
var mpHorizonalBubble_style = __webpack_require__(336);
;// CONCATENATED MODULE: ./src/basicComponents/mpHorizonalBubble/index.js






var mpHorizonalBubble = exparser_cmd.registerElement({
  is: 'mp-horizonal-bubble',
  options: {
    multipleSlots: true,
    classPrefix: 'mp-horizonal-bubble',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "wx-view",
          A: {
            "class": "root"
          },
          C: [{
            V: 1,
            B: [{
              B: {
                L: function (D, S, T) {
                  return D.mask;
                },
                F: function (D, S, T, W) {
                  return D.mask;
                }
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": {
                    L: function (D, S, T) {
                      return !!D.show || undefined;
                    },
                    F: function (D, S, T, W) {
                      return "mask " + (D.show ? "mask__in" : "");
                    }
                  }
                },
                C: []
              }]
            }]
          }, {
            T: "wx-view",
            A: {
              "class": "content"
            },
            C: [{
              T: "wx-view",
              A: {
                "class": {
                  L: function (D, S, T) {
                    return !!D.show || undefined;
                  },
                  F: function (D, S, T, W) {
                    return "close-container " + (D.show ? "close-container__in" : "");
                  }
                }
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": "close-btn",
                  "hover-class": "close-btn__hover",
                  "bind:tap": "handleClose"
                },
                C: [{
                  T: "wx-image",
                  A: {
                    "class": "close-btn-img",
                    "src": {
                      L: function (D, S, T) {
                        return D.closeBtn;
                      },
                      F: function (D, S, T, W) {
                        return D.closeBtn;
                      }
                    }
                  },
                  C: []
                }]
              }]
            }, {
              T: "wx-view",
              A: {
                "class": "content-container"
              },
              C: [{
                V: 5,
                N: "content",
                C: []
              }]
            }, {
              T: "wx-view",
              A: {
                "class": {
                  L: function (D, S, T) {
                    return !!D.show || undefined;
                  },
                  F: function (D, S, T, W) {
                    return "menu-container " + (D.show ? "menu-container__in" : "");
                  }
                }
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": "menu"
                },
                C: [{
                  T: "wx-view",
                  A: {
                    "class": "menu-before"
                  },
                  C: []
                }, {
                  T: "wx-view",
                  A: {
                    "class": "menu-inner"
                  },
                  C: [{
                    V: 2,
                    L: {
                      M: ["actions"],
                      L: function (D, S, T) {
                        return D.actions;
                      },
                      F: function (D, S, T, W) {
                        return D.actions;
                      }
                    },
                    K: "index",
                    C: [{
                      T: "wx-view",
                      A: {
                        "class": "cell",
                        "hover-class": "cell__hover",
                        "data-index": {
                          L: function (D, S, T) {
                            return S[1];
                          },
                          F: function (D, S, T, W) {
                            return S[1];
                          }
                        },
                        "bind:tap": "buttonTap"
                      },
                      C: [{
                        T: "wx-view",
                        A: {
                          "class": "cell-img-container"
                        },
                        C: [{
                          T: "wx-image",
                          A: {
                            "class": "cell-img",
                            "src": {
                              L: function (D, S, T) {
                                return Z(S[0], "imageDarkSrc");
                              },
                              F: function (D, S, T, W) {
                                return X(S[0]).imageDarkSrc;
                              }
                            }
                          },
                          C: []
                        }]
                      }, {
                        T: "wx-view",
                        A: {
                          "class": "cell-desc"
                        },
                        C: [{
                          S: {
                            L: function (D, S, T) {
                              return Z(S[0], "text");
                            },
                            F: function (D, S, T, W) {
                              return X(S[0]).text;
                            }
                          }
                        }]
                      }]
                    }]
                  }]
                }, {
                  T: "wx-view",
                  A: {
                    "class": "menu-after"
                  },
                  C: []
                }]
              }]
            }]
          }]
        }],
        BM: {
          closeBtn: [[0, 1, 0, 0, 0, "src"]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    maskClosable: {
      type: Boolean,
      value: true
    },
    mask: {
      type: Boolean,
      value: true
    },
    show: {
      type: Boolean,
      value: false
    },
    cancelText: {
      type: String,
      value: '取消'
    },
    actions: {
      type: Array,
      value: []
    }
  },
  attached() {
    this.attached = true;
    exparser_cmd.triggerRender(() => {
      this.setData({
        closeBtn: 'https://res.wx.qq.com/op_res/hlMx1wXYJya8ib3DpW10m6aLCGf7RoluABX1QvNEAxVIyhhGuY0iI62dzv56y5rq9nBrd-H44CqoH5dM9JTr0g'
      });
    });
  },
  observers: {
    show(show) {
      if (!this.attached) return;
      clearTimeout(this.closeTimeout);
      clearTimeout(this.showTimeout);
      if (!show) {
        this.closeTimeout = setTimeout(() => {
          this.triggerEvent('closed', {}, {});
        }, 200);
      } else {
        this.showTimeout = setTimeout(() => {
          this.triggerEvent('showed', {}, {});
        }, 200);
      }
    }
  },
  methods: {
    buttonTap(e) {
      var {
        index
      } = e.currentTarget.dataset;
      this.triggerEvent('buttontap', {
        index,
        item: this.data.actions[index]
      }, {});
    },
    handleClose() {
      this.triggerEvent('close', {}, {});
    },
    stopEvent() {}
  }
});
;// CONCATENATED MODULE: ./src/basicComponents/index.js










// EXTERNAL MODULE: ./src/styles/all_styles.js
var all_styles = __webpack_require__(498);
;// CONCATENATED MODULE: ./src/common.js

var _wxConfig;







var IS_ANDROID = ((_wxConfig = __wxConfig) === null || _wxConfig === void 0 ? void 0 : _wxConfig.platform) === 'android';
var isRemoteDebugV1 = typeof __initHelper !== 'undefined' && __initHelper === 1;
var isSupportWasmCache = () => {
  var _wxConfig2;
  return IS_ANDROID && ((_wxConfig2 = __wxConfig) === null || _wxConfig2 === void 0 ? void 0 : _wxConfig2.clientVersion) >= 0x28001800 && !isRemoteDebugV1;
};
var exparserSclBackend = __webpack_require__(908);

var context = null;
var rootNode = null;
var mainRoot = null;
var tabBarContainer = null;
var wasmInitialingQueue = [];
var doWasmInitialize = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_default()(function* (cb) {
    if (!wasmInitialingQueue) {
      cb();
      return;
    }
    wasmInitialingQueue.push(cb);
    if (wasmInitialingQueue.length === 1) {
      exparserSclBackend.setErrorListener(e => {
        Reporter.errorReport({
          key: 'exparserScriptError',
          error: e
        });
      });
      try {
        var loadWAFile = () => new Promise(resolve => {
          WeixinJSBridge.invoke('loadWAFile', {
            filename: 'WASclBackend.wasm'
          }, resolve);
        });
        var bin;
        var fileType = 0;
        var useCache = isSupportWasmCache();
        wxConsole.info(`[SCL] support wasm cache: ${useCache}`);
        if (useCache) {
          bin = 'WASclBackend.wasm';
          fileType = 1;
        } else {
          var res = yield loadWAFile();
          bin = res.arrayBuffer;
        }
        var begin = Date.now();
        exparserSclBackend.wasm_initialize({
          bin,
          fileType
        }, () => {
          var cost = Date.now() - begin;
          wxConsole.log(`[SCL] wasm initialize cost: ${cost} ms, use cache: ${useCache}`);
          var q = wasmInitialingQueue;
          wasmInitialingQueue = null;
          q.forEach(cb => cb());
        });
      } catch (e) {
        wxConsole.error('[SCL] wasm initialize error', e, e.stack);
      }
    }
  });
  return function doWasmInitialize(_x) {
    return _ref.apply(this, arguments);
  };
}();
var getMainRoot = () => mainRoot;
var getTabBarContainer = () => {
  if (!mainRoot) wxNativeConsole.error('[CustomTabBar] mainRoot is not initialized');
  if (tabBarContainer) return tabBarContainer;
  var exparser = __webpack_require__(995);
  tabBarContainer = exparser.createElement('virtuallayout', tabBarRoot);
  tabBarContainer.classList.toggle('__wx_tabbar_container', true);
  mainRoot.appendChild(tabBarContainer);
  return tabBarContainer;
};
var showTabBarContainer = () => {
  wxNativeConsole.info(`[CustomTabBar] showTabBar`);
  if (!tabBarContainer) wxNativeConsole.error(`[CustomTabBar] tabBarContainer is not initialized`);
  tabBarContainer.classList.toggle('__wx_tabbar_container-hide', false);
  var exparser = __webpack_require__(995);
  exparser.triggerRender(() => {});
};
var hideTabBarContainer = () => {
  wxNativeConsole.info(`[CustomTabBar] hideTabBar`);
  if (!tabBarContainer) wxNativeConsole.error(`[CustomTabBar] tabBarContainer is not initialized`);
  tabBarContainer.classList.toggle('__wx_tabbar_container-hide', true);
  var exparser = __webpack_require__(995);
  exparser.triggerRender(() => {});
};
var destroyTabBarContainer = () => {
  if (!mainRoot || !tabBarContainer) return;
  mainRoot.removeChild(tabBarContainer);
  tabBarContainer = null;
};
var loadStyleBincode = (path, cb) => {
  WeixinJSBridge.invoke('readFile', {
    filePath: path
  }, res => {
    var bin = new Uint8Array(res.data);
    context.appendStyleSheetBincode(bin);
    if (typeof cb === 'function') cb();
  });
};
var onViewportResize = cb => {
  engine.onViewportResize(cb);
};
var atob = function (input) {
  if (typeof globalThis.atob === 'function') return globalThis.atob(input);
  var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  var str = String(input).replace(/[=]+$/, '');
  var output = '';
  if (str.length % 4 === 1) throw new Error('"atob" failed');
  for (var bc = 0, bs, buffer, idx = 0; buffer = str.charAt(idx++); ~buffer && (bs = bc % 4 ? bs * 64 + buffer : buffer, bc++ % 4) ? output += String.fromCharCode(255 & bs >> (-2 * bc & 6)) : 0) {
    buffer = chars.indexOf(buffer);
  }
  return output;
};
var base64ToArrayBuffer = base64 => {
  var binaryString = atob(base64);
  var len = binaryString.length;
  var bytes = new Uint8Array(len);
  for (var i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};
var initCallbacks = [];
var initStart = false;
var isInitialized = () => wasmInitialingQueue === null;
var validInit = !!true;
var setValidInit = () => {
  validInit = true;
};
var appSubpackageChannelCreated = false;
var initScl = (cb, forceInit = false) => {
  if (typeof IS_APP_SUBPACKAGE !== 'undefined' && IS_APP_SUBPACKAGE && !appSubpackageChannelCreated) {
    appSubpackageChannelCreated = true;
    packageChannel.on('initReady', () => {
      validInit = true;
    });
  }
  if (!validInit && !forceInit) {
    var error = new Error('invalid init scl: init before tap');
    console.error(error.message, error.stack);
    Reporter.errorReport({
      key: 'invalidInitScl',
      error
    });
  }
  var done = () => {
    setTimeout(() => cb({
      mainRoot
    }), 0);
  };
  if (initStart) {
    if (rootNode) {
      done();
      return;
    } else {
      initCallbacks.push(done);
      return;
    }
  }
  initStart = true;
  initCallbacks.push(done);
  var init = () => {
    try {
      onViewportResize(() => {
        var exparser = __webpack_require__(995);
        exparser.triggerRender(() => {});
      });
      context = exparserSclBackend.Context.create();
      rootNode = context.createElement('empty', 'virtuallayout');
      context.bindRootNode(rootNode);
      rootNode.setClass('__wx_scl__root_node');
      var exparser = __webpack_require__(995);
      exparser.globalOptions.documentBackend = 'custom';
      exparser.globalOptions.customContext = context;
      exparser.initBackend();
      if (all_styles/* styles */.W.length) {
        context.appendStyleSheet(all_styles/* styles */.W.join(''));
      }
      if (all_styles/* binStyles */.J.length) {
        all_styles/* binStyles */.J.forEach(binStyle => context.appendStyleSheetBincode(base64ToArrayBuffer(binStyle)));
      }
      var placeholder = context.createElement('empty', 'virtuallayout');
      rootNode.appendChild(placeholder);
      placeholder.release();
      mainRoot = exparser.createElement('virtuallayout', root);
      mainRoot.classList.toggle('__wx_scl__main_root', true);
      exparser.Element.replaceDocumentElement(mainRoot, rootNode);
      wxConsole.log('SCL initialized');
      initCallbacks.forEach(cb => cb());
      initCallbacks = [];
    } catch (e) {
      wxConsole.error('SCL initialize error', e, e.stack);
    }
  };
  doWasmInitialize(init);
};
var getExparserElementByViewId = viewId => {
  var exparser = __webpack_require__(995);
  var context = exparser.globalOptions.customContext;
  return context.constructor.getExparserElementByViewId(viewId);
};
var triggerRender = (element, cb) => {
  var exparser = __webpack_require__(995);
  exparser.triggerRender(element, cb);
};
var setCurrentFrameView = viewId => {
  exparserSclBackend.setCurrentFrameView(viewId);
};
var appendStyleSheet = styleSheet => {
  context.appendStyleSheet(styleSheet);
};
var registerComponent = options => {
  var exparser = __webpack_require__(995);
  exparser.registerElement(options);
};
// EXTERNAL MODULE: ./src/components/adSkipCard/style.scss
var adSkipCard_style = __webpack_require__(501);
;// CONCATENATED MODULE: ./src/components/adSkipCard/index.js


var icon = 'https://res.wx.qq.com/t/fed_upload/d3b06ed8-7ff2-4477-ae39-c37621d06f20/Frame%20348.png';
var adSkipCard = exparser_cmd.registerElement({
  is: 'ad-skip-card',
  options: {
    classPrefix: 'ad-skip-card',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "wx-view",
          A: {
            "class": "root",
            "bind:tap": "close"
          },
          C: [{
            T: "wx-image",
            A: {
              "class": "icon",
              "src": "https://res.wx.qq.com/t/fed_upload/d3b06ed8-7ff2-4477-ae39-c37621d06f20/Frame%20348.png"
            },
            C: []
          }, {
            T: "wx-view",
            A: {
              "class": "title"
            },
            C: [{
              S: {
                L: function (D, S, T) {
                  return !!D.amount || undefined;
                },
                F: function (D, S, T, W) {
                  return "恭喜获得 广告跳过卡x" + D.amount;
                }
              }
            }]
          }, {
            T: "wx-view",
            A: {
              "class": "sub"
            },
            C: [{
              S: "在小游戏中使用可跳过对应视频广告"
            }]
          }, {
            T: "wx-view",
            A: {
              "class": "sub"
            },
            C: [{
              S: "点击任意处关闭"
            }]
          }]
        }],
        BM: {
          amount: [[0, 1, 0]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    amount: {
      type: Number,
      value: 1
    }
  },
  methods: {
    close() {
      this.triggerEvent('destroy');
    }
  }
});
// EXTERNAL MODULE: ./src/components/verifyTip/style.scss
var verifyTip_style = __webpack_require__(133);
;// CONCATENATED MODULE: ./src/components/verifyTip/index.wxml

    /* harmony default export */ const verifyTip = ({ content: (function(){var P="";var R={};var T={P:P,C:[{T:"virtuallayout",A:{"class":"root"},C:[{T:"wx-view",A:{"class":"content","style":{L:function(D,S,T){return !!(D.top||D.right)||undefined},F:function(D,S,T,W){return "top:"+D.top+"px;right:"+D.right+"px"}},"bind:tap":"tap"},C:[{V:1,B:[{B:{L:function(D,S,T){return !!D.showSeconds||undefined},F:function(D,S,T,W){return !D.showSeconds}},C:[{T:"wx-view",A:{"class":"first"},C:[{S:"\n      尚未实名认证，仅可玩1小时\n    "}]}]},{B:{L:function(D,S,T){return !!D.remainSeconds||undefined},F:function(D,S,T,W){return D.remainSeconds>0}},C:[{T:"wx-view",A:{"class":"cd"},C:[{T:"wx-view",A:{"style":{L:function(D,S,T){return !!(D.remainSeconds||D.remainThreshold)||undefined},F:function(D,S,T,W){return "overflow-wrap:normal;color:"+(D.remainSeconds<D.remainThreshold?"#fa5151":"rgba(0,0,0,.5)")}}},C:[{S:{L:function(D,S,T){return !!D.remainStr||undefined},F:function(D,S,T,W){return "\n        "+D.remainStr+"\n      "}}}]},{T:"wx-view",A:{"style":"margin-left:4px"},C:[{S:"微信小游戏实名认证"}]}]}]},{B:1,C:[{T:"wx-view",A:{"class":"msg"},C:[{S:"\n      微信小游戏实名认证\n    "}]}]}]},{T:"wx-image",A:{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAwBAMAAAD5pqeQAAAAElBMVEUAAAAAAAAAAAAAAAAAAAAAAADgKxmiAAAABnRSTlMAgEAIaFCMCA7dAAAAMUlEQVQoz2MYfEAJic0kqIDgmAgKITjMjgMnJYzgsCJzAoHKEBJC9JNABBUiEAcnAACUTAh6KPgabwAAAABJRU5ErkJggg==","style":"height: 16px; width: 8px;"},C:[]}]}]}],BM:{right:[[0,0,"style"]],top:[[0,0,"style"]]}};R[""]=function(){return T};return function(a){var b=R[a];return b?b():null}})() });
;// CONCATENATED MODULE: ./src/components/verifyTip/index.js


var zero2 = x => x < 10 ? `0${x}` : `${x}`;
var __exparserSclEngine__ = __webpack_require__(817);
var verifyTip_exparser = __exparserSclEngine__.exparser;
var globalShowSeconds = false;
var timer = null;
var destroy = false;
var verifyTip_verifyTip = verifyTip_exparser.registerElement({
  is: 'verify-tip',
  options: {
    classPrefix: 'verify-tip',
    writeIdToDOM: true,
    virtualHost: true
  },
  template: verifyTip,
  properties: {
    top: {
      type: Number,
      value: 20
    },
    right: {
      type: Number,
      value: 100
    },
    remainThreshold: {
      type: Number,
      value: 300
    },
    info: {
      type: String,
      value: '{}'
    }
  },
  data: {
    showSeconds: globalShowSeconds,
    remainStr: '00:00',
    remainSeconds: -1
  },
  observers: {
    info(value) {
      this.setData(JSON.parse(value));
    },
    remainSeconds(seconds) {
      wxConsole.log('[verify-tip] remainSeconds', seconds);
      if (seconds < 0) seconds = 0;
      var s = seconds % 60;
      var m = Math.floor(seconds / 60);
      this.setData({
        remainStr: zero2(m) + ':' + zero2(s)
      });
    }
  },
  attached() {
    destroy = false;
    this.setData({
      showSeconds: globalShowSeconds
    });
    globalShowSeconds || setTimeout(() => {
      globalShowSeconds = true;
      if (!destroy) {
        this.setData({
          showSeconds: true
        });
      }
    }, 10000);
    timer = setInterval(() => {
      var {
        remainSeconds
      } = this.data;
      if (remainSeconds) {
        remainSeconds--;
        this.setData({
          remainSeconds
        });
        if (!remainSeconds) this.triggerEvent('stop');
      }
    }, 1000);
  },
  methods: {
    tap() {
      wxConsole.log('verify-tip tap');
      this.triggerEvent('click');
    },
    des() {
      clearInterval(timer);
      destroy = true;
      this.triggerEvent('destroy');
    }
  }
});
// EXTERNAL MODULE: ./src/components/userProfile/style.scss
var userProfile_style = __webpack_require__(510);
;// CONCATENATED MODULE: ./src/components/userProfile/index.js
















var userProfile_exparser = engine.exparser;
var icon_checkd = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAASKADAAQAAAABAAAASAAAAACQMUbvAAACT0lEQVR4Ae3asUoDMRgH8ORaqgh26CYOujk4uUlBBRFXVxcXfQJfQOqDWHyBIiI4SEEEKW4OPoduWqtt4n3IQSntXa6XpEn6D7TXHl+OfD+SI5cLYygQgAAEIAABCEAAAhCAAAQgAAEIQAACPgs0ZCPK036eJ9j32OXn040fIVqlcunkq371qpJPLk2VC7oaQzi/QjwyyTZFX7SXOmdbKm2dix6U4EjJVhIUzvlHVI4OsnpS8D1oHA4hxVhVOZDrCdikY9BAk3AY4/2I8+PuTvNmEkxyPtghlomz22wlCGnHIIF04RBccEA6cYID0o0TFJAJnGCATOEEAWQSx3sg0zheA9nA8RbIFo6XQDZxvAOyjeMV0CxwlIGqnbPaT1/cSckve3vNB6pos8wKh3LMfBYjnN6vaMcrKLQC981YdGQTaZY4mUAjOBRPxRrSrHEo2dQFswEbrHLO1ihwqCwyJm4Xnk4Ph85p/+kCDiWVCvRZv36jdVtavx0RMIrkCg7lnHkPoiB6A0BvAqSUNfo/VLQPN5dwKE8lIAq0geQaTi4g00gu4uQGMoXkKs5UQLqRXMaZGkgXkus4hYCKIvmAUxhoWiRfcLQA5UXyCUcbkCqSbzhagTKReHTOmbgY3oJCdeK56v9GAsV35f917H0rz6RVm5Qy4x5zCbdxqMHageiiakju4xgDykbyA8co0GQkf3Aoh9T1IAooUmj/X6Uit+ORfB+P5ff488JLcr/r6A25SK6oCwEIQAACEIAABCAAAQhAAAIQgAAEIACBuRD4AzKlWWPvanSJAAAAAElFTkSuQmCC';
var icon_plus_light = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAASKADAAQAAAABAAAASAAAAACQMUbvAAABEElEQVR4Ae3aQQqCQACF4Yp2XaQDdP8T1L6LtC4FXf8RWhLfQIzwYBw/X250tzMIECBAgAABAgQIbFzgOuzvOf3G402MwyZ2seFNAIqbAwhQCESsQYBCIGINAhQCEWsQoBCIWIMAhUDEGgQoBCLWIEAhELEGAQqBiDUIUAhErEGAQiBiDQIUAhHvI5/jb7zIOw8nO00nfAzzfT75ivOl1n4XaHzj+Y8jr98zKG77MfI5vs0HK86/+IuteDnLL+3jheVN11/RMyiMAQEKgYg1CFAIRKxBgEIgYg0CFAIRaxCgEIhYgwCFQMQaBCgEItYgQCEQsQYBCoGINQhQCESsQYBCQEyAAAECBAgQIEDgE4EXsiEOYoSfPhkAAAAASUVORK5CYII=';
var icon_plus_dark = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAASKADAAQAAAABAAAASAAAAACQMUbvAAABT0lEQVR4Ae3aMQ6CQBRFUcdYuAxKF+XyXBSly7BDTMaQ3EzyJiLQXBt4fJjBkw/NcDr5U0ABBRRQQAEFFFCgIVAaxw45NE3TY574VicfSyn3Q24Ek56RjRAQCCCMAlEEWSCAMApEEWSBAMIoEEWQBQIIo0AUQRYIIIwCUQRZIIAwCkQRZIEAwigQRZAFAgijQBRBFgggjAJRBFkggDAKRBFkgQDCKBBFkAUCCGPXwmFd1OO1/87DPOC1Dvqat8+6v9mmZ3Hy0jn7d8Wz8/TVp32g9p6zedM+Yk2W5WBvB43LJZvtDfPIuz5iPf+k6x3UM9Dac/x4Ya3gQdf7DgrwAgkUBELZDhIoCISyHSRQEAhlO0igIBDKdpBAQSCU7SCBgkAo20ECBYFQtoMECgKhbAcJFARC2Q4SKAiEsh0kUBCwrIACCiiggAIKKKDALwJvdcMTni08WagAAAAASUVORK5CYII=';
var userProfile_viewportResizeListeners = [];
engine.onViewportResize(res => {
  userProfile_viewportResizeListeners.forEach(cb => cb(res));
});
var userProfile = userProfile_exparser.registerElement({
  is: 'user-profile',
  options: {
    classPrefix: 'user-profile',
    writeIdToDOM: true
  },
  behaviors: ['wx-theme'],
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "wx-view",
          A: {
            "class": {
              L: function (D, S, T) {
                return !!D.hide || undefined;
              },
              F: function (D, S, T, W) {
                return "root " + (D.hide ? "hide" : "");
              }
            }
          },
          C: [{
            V: 1,
            B: [{
              B: {
                L: function (D, S, T) {
                  return D.overlay;
                },
                F: function (D, S, T, W) {
                  return D.overlay;
                }
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": {
                    L: function (D, S, T) {
                      return !!D.enter || undefined;
                    },
                    F: function (D, S, T, W) {
                      return "mask " + (D.enter ? "mask-in" : "");
                    }
                  }
                },
                C: []
              }]
            }]
          }, {
            T: "wx-view",
            A: {
              "class": "container"
            },
            C: [{
              T: "wx-view",
              A: {
                "class": {
                  L: function (D, S, T) {
                    return !!D.enter || undefined;
                  },
                  F: function (D, S, T, W) {
                    return "content " + (D.enter ? "content-in" : "");
                  }
                }
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": "head"
                },
                C: [{
                  T: "wx-image",
                  A: {
                    "class": "icon",
                    "src": {
                      L: function (D, S, T) {
                        return D.appIcon;
                      },
                      F: function (D, S, T, W) {
                        return D.appIcon;
                      }
                    }
                  },
                  C: []
                }, {
                  T: "wx-view",
                  A: {
                    "class": "title"
                  },
                  C: [{
                    S: {
                      L: function (D, S, T) {
                        return !!D.appName || undefined;
                      },
                      F: function (D, S, T, W) {
                        return D.appName + " 申请";
                      }
                    }
                  }]
                }]
              }, {
                T: "wx-view",
                A: {
                  "class": "body",
                  "style": {
                    L: function (D, S, T) {
                      return !!D.paddingBottom || undefined;
                    },
                    F: function (D, S, T, W) {
                      return "padding-bottom: " + D.paddingBottom + "px";
                    }
                  }
                },
                C: [{
                  T: "wx-view",
                  A: {
                    "class": "apply-info"
                  },
                  C: [{
                    S: {
                      L: function (D, S, T) {
                        return !!(D.wording || D.wording) || undefined;
                      },
                      F: function (D, S, T, W) {
                        return D.wording ? D.wording : "使用你的头像、昵称、性别及地区，用于个人信息展示。";
                      }
                    }
                  }]
                }, {
                  T: "wx-view",
                  A: {
                    "class": "info-list"
                  },
                  C: [{
                    T: "wx-scroll-view",
                    A: {
                      "scroll-y": {
                        L: function (D, S, T) {},
                        F: function (D, S, T, W) {
                          return true;
                        }
                      },
                      "style": {
                        L: function (D, S, T) {
                          return !!D.scrollHeight || undefined;
                        },
                        F: function (D, S, T, W) {
                          return "height: " + D.scrollHeight + "px;";
                        }
                      }
                    },
                    C: [{
                      V: 2,
                      L: {
                        M: ["infoList"],
                        L: function (D, S, T) {
                          return D.infoList;
                        },
                        F: function (D, S, T, W) {
                          return D.infoList;
                        }
                      },
                      K: "id",
                      C: [{
                        T: "wx-view",
                        A: {
                          "bind:tap": "handleChoose",
                          "data-id": {
                            L: function (D, S, T) {
                              return Z(S[0], "id");
                            },
                            F: function (D, S, T, W) {
                              return X(S[0]).id;
                            }
                          },
                          "style": "flex-shrink: 0;"
                        },
                        C: [{
                          T: "wx-view",
                          A: {
                            "class": "split-line"
                          },
                          C: []
                        }, {
                          T: "wx-view",
                          A: {
                            "class": "info-item",
                            "id": {
                              L: function (D, S, T) {
                                return !!Z(S[0], "id") || undefined;
                              },
                              F: function (D, S, T, W) {
                                return "item_" + X(S[0]).id;
                              }
                            }
                          },
                          C: [{
                            T: "wx-view",
                            A: {
                              "class": "info-item__left"
                            },
                            C: [{
                              T: "wx-image",
                              A: {
                                "class": "info-item__avatar",
                                "src": {
                                  L: function (D, S, T) {
                                    return Z(S[0], "avatar");
                                  },
                                  F: function (D, S, T, W) {
                                    return X(S[0]).avatar;
                                  }
                                }
                              },
                              C: []
                            }, {
                              T: "wx-view",
                              A: {
                                "class": "info-item__desc__wrp"
                              },
                              C: [{
                                T: "wx-view",
                                A: {
                                  "class": "info-item__nickname"
                                },
                                C: [{
                                  S: {
                                    L: function (D, S, T) {
                                      return Z(S[0], "nickname");
                                    },
                                    F: function (D, S, T, W) {
                                      return X(S[0]).nickname;
                                    }
                                  }
                                }]
                              }, {
                                V: 1,
                                B: [{
                                  B: {
                                    L: function (D, S, T) {
                                      return Z(S[0], "desc");
                                    },
                                    F: function (D, S, T, W) {
                                      return X(S[0]).desc;
                                    }
                                  },
                                  C: [{
                                    T: "wx-view",
                                    A: {
                                      "class": "info-item__desc"
                                    },
                                    C: [{
                                      S: {
                                        L: function (D, S, T) {
                                          return Z(S[0], "desc");
                                        },
                                        F: function (D, S, T, W) {
                                          return X(S[0]).desc;
                                        }
                                      }
                                    }]
                                  }]
                                }]
                              }]
                            }]
                          }, {
                            V: 1,
                            B: [{
                              B: {
                                L: function (D, S, T) {
                                  return !!(D.selected || Z(S[0], "id")) || undefined;
                                },
                                F: function (D, S, T, W) {
                                  return D.selected === X(S[0]).id;
                                }
                              },
                              C: [{
                                T: "wx-view",
                                A: {
                                  "class": "info-item__right"
                                },
                                C: [{
                                  T: "wx-image",
                                  A: {
                                    "class": "icon-checked",
                                    "src": {
                                      L: function (D, S, T) {
                                        return D.iconChecked;
                                      },
                                      F: function (D, S, T, W) {
                                        return D.iconChecked;
                                      }
                                    }
                                  },
                                  C: []
                                }]
                              }]
                            }]
                          }]
                        }]
                      }]
                    }, {
                      T: "wx-view",
                      A: {
                        "class": "split-line"
                      },
                      C: []
                    }]
                  }, {
                    V: 1,
                    B: [{
                      B: {
                        L: function (D, S, T) {
                          return !!(D.showType || D.exceed || D.isBanModifyAvatar) || undefined;
                        },
                        F: function (D, S, T, W) {
                          return D.showType === 1 && !D.exceed && !D.isBanModifyAvatar;
                        }
                      },
                      C: [{
                        T: "wx-view",
                        A: {
                          "class": "use-other-avatar",
                          "bind:tap": "handleCreate"
                        },
                        C: [{
                          S: "使用其它头像和昵称"
                        }]
                      }]
                    }]
                  }, {
                    V: 1,
                    B: [{
                      B: {
                        L: function (D, S, T) {
                          return !!(D.showType || D.exceed || D.isBanModifyAvatar) || undefined;
                        },
                        F: function (D, S, T, W) {
                          return D.showType === 2 && !D.exceed && !D.isBanModifyAvatar;
                        }
                      },
                      C: [{
                        T: "wx-view",
                        A: {
                          "class": "info-item-add",
                          "bind:tap": "handleCreate"
                        },
                        C: [{
                          T: "wx-image",
                          A: {
                            "class": "info-item-add__plus",
                            "src": {
                              L: function (D, S, T) {
                                return D.iconPlus;
                              },
                              F: function (D, S, T, W) {
                                return D.iconPlus;
                              }
                            }
                          },
                          C: []
                        }, {
                          T: "wx-view",
                          A: {
                            "class": "info-item-add__text"
                          },
                          C: [{
                            S: "使用其它头像和昵称"
                          }]
                        }]
                      }, {
                        T: "wx-view",
                        A: {
                          "class": "split-line"
                        },
                        C: []
                      }]
                    }]
                  }, {
                    V: 1,
                    B: [{
                      B: {
                        L: function (D, S, T) {
                          return D.exceed;
                        },
                        F: function (D, S, T, W) {
                          return D.exceed;
                        }
                      },
                      C: [{
                        T: "wx-view",
                        A: {
                          "class": "exceed-tip"
                        },
                        C: [{
                          S: "数量已达上限，无法新增"
                        }]
                      }]
                    }]
                  }]
                }]
              }, {
                T: "wx-view",
                A: {
                  "class": "buttons"
                },
                C: [{
                  T: "wx-view",
                  A: {
                    "class": "button cancel",
                    "bind:tap": "handleCancel",
                    "hover-class": "hand-over"
                  },
                  C: [{
                    S: "取消"
                  }]
                }, {
                  T: "wx-view",
                  A: {
                    "class": "button confirm",
                    "bind:tap": "handleConfirm",
                    "hover-class": "hand-over"
                  },
                  C: [{
                    S: "允许"
                  }]
                }]
              }]
            }]
          }]
        }],
        BM: {
          appIcon: [[0, 1, 0, 0, 0, "src"]],
          paddingBottom: [[0, 1, 0, 1, "style"]],
          wording: [[0, 1, 0, 1, 0, 0], [0, 1, 0, 1, 0, 0]],
          hide: [[0, "class"]],
          scrollHeight: [[0, 1, 0, 1, 1, 0, "style"]],
          appName: [[0, 1, 0, 0, 1, 0]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  data: {
    overlay: true,
    enter: false,
    hide: false,
    duration: 200,
    appName: '',
    appIcon: '',
    infoList: [],
    input: '',
    iconChecked: icon_checkd,
    iconPlus: icon_plus_light,
    scrollHeight: 66,
    screenHeight: 812,
    screenWidth: 375,
    showType: 1,
    selected: 0,
    limit: 4,
    exceed: false,
    isBanModifyAvatar: false,
    paddingBottom: 194,
    wording: ''
  },
  observers: {
    input(newVal) {
      if (!newVal) return;
      var data = JSON.parse(newVal);
      this.setData(data);
    },
    infoList(newVal = []) {
      console.log('[user-profile]: infoListChanged');
      var num = newVal.length;
      var limit = this.data.limit;
      this.setData({
        exceed: num >= limit
      });
      this.didChangeScrollHeight();
    }
  },
  created() {
    console.log('[user-profile]: created');
    this.onViewportResize();
  },
  attached() {
    console.log('[user-profile]: attached');
    userProfile_exparser.triggerRender(() => {
      this.setData({
        enter: true
      });
    });
    this._onViewportResize = this.onViewportResize.bind(this);
    userProfile_viewportResizeListeners.push(this._onViewportResize);
  },
  detached() {
    userProfile_viewportResizeListeners.splice(userProfile_viewportResizeListeners.indexOf(this._onViewportResize), 1);
  },
  methods: {
    _onThemeChange({
      theme
    }) {
      console.log('[user-profile] _onThemeChange: ', theme);
      if (theme === 'dark') {
        this.setData({
          iconPlus: icon_plus_dark
        });
      } else {
        this.setData({
          iconPlus: icon_plus_light
        });
      }
    },
    didChangeScrollHeight() {
      var {
        screenHeight,
        screenWidth
      } = this.data;
      var num = this.data.infoList.length;
      var scrollHeight = 65 * num + 1;
      var isPortrait = screenHeight > screenWidth;
      var maxHeight = isPortrait ? 0.75 * screenHeight : 0.9 * screenHeight;
      var paddingBottom = isPortrait ? 194 : 118;
      var fixedHeight = isPortrait ? 361 : 277;
      var contentHeight = fixedHeight + scrollHeight;
      if (contentHeight > maxHeight) {
        scrollHeight = maxHeight - fixedHeight;
      }
      console.log('[user-profile]: screenHeight', screenHeight, 'scrollHeight: ', scrollHeight);
      this.setData({
        scrollHeight,
        paddingBottom
      });
    },
    onViewportResize() {
      console.log('[user-profile]: onViewportResize');
      var viewportHeight = engine.getWindowHeight();
      var viewportWidth = engine.getWindowWidth();
      this.setData({
        screenHeight: viewportHeight,
        screenWidth: viewportWidth
      });
      this.didChangeScrollHeight();
    },
    handleCancel() {
      this.triggerEvent('cancel');
      this.destory();
    },
    handleConfirm() {
      var selected = this.data.selected;
      this.triggerEvent('confirm', {
        selected
      });
      this.destory();
    },
    handleCreate() {
      if (this.data.exceed) return;
      this.setData({
        hide: true
      });
      this.triggerEvent('create');
    },
    handleChoose(e) {
      var id = e.currentTarget.dataset.id;
      if (id !== this.data.selected) {
        this.setData({
          selected: id
        });
      }
    },
    destory() {
      this.setData({
        enter: false
      });
      setTimeout(() => {
        this.triggerEvent('destroy');
      }, this.data.duration);
    }
  }
});
// EXTERNAL MODULE: ./src/components/toast/style.scss
var toast_style = __webpack_require__(44);
;// CONCATENATED MODULE: ./src/components/toast/index.js


var LOAD_IMG = 'https://res.wx.qq.com/op_res/4gTGxmOnjTG1Pmsfj7JwUaZHfOb677UMxDEVI8p20yTosmcwujlY9-UEvMZm0ePGFGKS_PoQJNEN_S9YFfGTWA';
var toast = exparser_cmd.registerElement({
  is: 'toast',
  options: {
    classPrefix: 'toast',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "wx-view",
          A: {
            "class": "root"
          },
          C: [{
            T: "wx-view",
            A: {
              "class": "content"
            },
            C: [{
              V: 1,
              B: [{
                B: {
                  L: function (D, S, T) {
                    return D.loading;
                  },
                  F: function (D, S, T, W) {
                    return D.loading;
                  }
                },
                C: [{
                  T: "wx-image",
                  A: {
                    "src": "https://res.wx.qq.com/op_res/4gTGxmOnjTG1Pmsfj7JwUaZHfOb677UMxDEVI8p20yTosmcwujlY9-UEvMZm0ePGFGKS_PoQJNEN_S9YFfGTWA",
                    "class": "loading"
                  },
                  C: []
                }]
              }]
            }, {
              T: "wx-view",
              A: {
                "class": "title"
              },
              C: [{
                S: {
                  L: function (D, S, T) {
                    return D.title;
                  },
                  F: function (D, S, T, W) {
                    return D.title;
                  }
                }
              }]
            }]
          }]
        }],
        BM: {
          title: [[0, 0, 1, 0]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    loading: {
      type: Boolean,
      value: false
    },
    title: {
      type: String
    }
  },
  methods: {
    close() {
      this.triggerEvent('destroy');
    }
  }
});
// EXTERNAL MODULE: ./src/components/shareImage/style.scss
var shareImage_style = __webpack_require__(82);
;// CONCATENATED MODULE: ./src/components/shareImage/index.js



var shareImage_viewportResizeListeners = [];
engine.onViewportResize(res => {
  shareImage_viewportResizeListeners.forEach(cb => cb(res));
});
var shareImage = exparser_cmd.registerElement({
  is: 'share-image',
  behaviors: ['wx-theme'],
  options: {
    multipleSlots: true,
    classPrefix: 'share-image',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          V: 1,
          B: [{
            B: {
              L: function (D, S, T) {
                return !!D.style || undefined;
              },
              F: function (D, S, T, W) {
                return D.style === "v2";
              }
            },
            C: [{
              T: "mp-separate-bubble-action-sheet",
              A: {
                "actions": {
                  L: function (D, S, T) {
                    return D.actionsArr;
                  },
                  F: function (D, S, T, W) {
                    return D.actionsArr;
                  }
                },
                "show": {
                  L: function (D, S, T) {
                    return D.show;
                  },
                  F: function (D, S, T, W) {
                    return D.show;
                  }
                },
                "imgPath": {
                  L: function (D, S, T) {
                    return D.imgPath;
                  },
                  F: function (D, S, T, W) {
                    return D.imgPath;
                  }
                },
                "imgHeight": {
                  L: function (D, S, T) {
                    return D.height;
                  },
                  F: function (D, S, T, W) {
                    return D.height;
                  }
                },
                "imgWidth": {
                  L: function (D, S, T) {
                    return D.width;
                  },
                  F: function (D, S, T, W) {
                    return D.width;
                  }
                },
                "bind:buttontap": "onButtonTap",
                "bind:close": "handleClose",
                "bind:closed": "handleClosed"
              },
              C: []
            }]
          }, {
            B: {
              L: function (D, S, T) {
                return !!D.orientation || undefined;
              },
              F: function (D, S, T, W) {
                return D.orientation === "portrait";
              }
            },
            C: [{
              T: "mp-bubble-action-sheet",
              A: {
                "actions": {
                  L: function (D, S, T) {
                    return D.actionsArr;
                  },
                  F: function (D, S, T, W) {
                    return D.actionsArr;
                  }
                },
                "show": {
                  L: function (D, S, T) {
                    return D.show;
                  },
                  F: function (D, S, T, W) {
                    return D.show;
                  }
                },
                "mask": {
                  L: function (D, S, T) {},
                  F: function (D, S, T, W) {
                    return false;
                  }
                },
                "bind:buttontap": "onButtonTap",
                "bind:close": "handleClose",
                "bind:closed": "handleClosed"
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": {
                    L: function (D, S, T) {
                      return !!D.show || undefined;
                    },
                    F: function (D, S, T, W) {
                      return "mask " + (D.show ? "mask__in" : "");
                    }
                  },
                  "slot": "mask"
                },
                C: []
              }, {
                T: "wx-view",
                A: {
                  "class": {
                    L: function (D, S, T) {
                      return !!D.show || undefined;
                    },
                    F: function (D, S, T, W) {
                      return "container " + (D.show ? "container__in" : "");
                    }
                  },
                  "slot": "mask"
                },
                C: [{
                  T: "wx-view",
                  A: {
                    "class": "scroller-container"
                  },
                  C: [{
                    T: "scrollview",
                    A: {
                      "class": "scroller",
                      "scroll-y": "1"
                    },
                    C: [{
                      T: "wx-view",
                      A: {
                        "class": "img-wrapper"
                      },
                      C: [{
                        T: "wx-adaptive-image",
                        A: {
                          "class": "img",
                          "src": {
                            L: function (D, S, T) {
                              return D.imgPath;
                            },
                            F: function (D, S, T, W) {
                              return D.imgPath;
                            }
                          },
                          "srcHeight": {
                            L: function (D, S, T) {
                              return D.height;
                            },
                            F: function (D, S, T, W) {
                              return D.height;
                            }
                          },
                          "srcWidth": {
                            L: function (D, S, T) {
                              return D.width;
                            },
                            F: function (D, S, T, W) {
                              return D.width;
                            }
                          }
                        },
                        C: []
                      }]
                    }]
                  }]
                }]
              }]
            }]
          }, {
            B: 1,
            C: [{
              T: "mp-horizonal-bubble",
              A: {
                "actions": {
                  L: function (D, S, T) {
                    return D.actionsArr;
                  },
                  F: function (D, S, T, W) {
                    return D.actionsArr;
                  }
                },
                "show": {
                  L: function (D, S, T) {
                    return D.show;
                  },
                  F: function (D, S, T, W) {
                    return D.show;
                  }
                },
                "bind:buttontap": "onButtonTap",
                "bind:close": "handleClose",
                "bind:closed": "handleClosed"
              },
              C: [{
                T: "wx-view",
                A: {
                  "slot": "content"
                },
                C: [{
                  T: "wx-view",
                  A: {
                    "class": {
                      L: function (D, S, T) {
                        return !!D.show || undefined;
                      },
                      F: function (D, S, T, W) {
                        return "landscape-container " + (D.show ? "container__in" : "");
                      }
                    }
                  },
                  C: [{
                    T: "wx-view",
                    A: {
                      "class": "scroller-container landscape-scroller-container"
                    },
                    C: [{
                      T: "scrollview",
                      A: {
                        "class": "scroller",
                        "scroll-y": "1"
                      },
                      C: [{
                        T: "wx-view",
                        A: {
                          "class": "img-wrapper"
                        },
                        C: [{
                          T: "wx-adaptive-image",
                          A: {
                            "class": "img",
                            "src": {
                              L: function (D, S, T) {
                                return D.imgPath;
                              },
                              F: function (D, S, T, W) {
                                return D.imgPath;
                              }
                            },
                            "srcHeight": {
                              L: function (D, S, T) {
                                return D.height;
                              },
                              F: function (D, S, T, W) {
                                return D.height;
                              }
                            },
                            "srcWidth": {
                              L: function (D, S, T) {
                                return D.width;
                              },
                              F: function (D, S, T, W) {
                                return D.width;
                              }
                            }
                          },
                          C: []
                        }]
                      }]
                    }]
                  }]
                }]
              }]
            }]
          }]
        }],
        BM: {}
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    imgPath: {
      type: String,
      public: true,
      value: ''
    },
    height: {
      type: Number,
      public: true,
      value: 0
    },
    width: {
      type: Number,
      public: true,
      value: 0
    },
    actions: {
      type: String,
      public: true,
      value: '[]'
    },
    style: {
      type: String,
      public: true,
      value: ''
    }
  },
  data: {
    show: false,
    actionsArr: [],
    imgHeight: 0,
    imgWidth: 0,
    orientation: 'portrait'
  },
  observers: {
    actions() {
      this.getActions(this.data.actions);
    }
  },
  created() {
    this.onViewportResize();
  },
  attached() {
    exparser_cmd.triggerRender(() => {
      this.setData({
        show: true
      });
    });
    this._onViewportResize = this.onViewportResize.bind(this);
    shareImage_viewportResizeListeners.push(this._onViewportResize);
  },
  detached() {
    shareImage_viewportResizeListeners.splice(shareImage_viewportResizeListeners.indexOf(this._onViewportResize), 1);
  },
  methods: {
    onViewportResize() {
      var viewportWidth = engine.getWindowWidth();
      var viewportHeight = engine.getWindowHeight();
      this.updateOrientation(viewportWidth, viewportHeight);
    },
    updateOrientation(viewportWidth, viewportHeight) {
      this.setData({
        orientation: viewportWidth <= viewportHeight ? 'portrait' : 'landscape'
      });
    },
    getActions(actions) {
      var actionsArr = JSON.parse(actions);
      this.setData({
        actionsArr
      });
    },
    onButtonTap(e) {
      var {
        item
      } = e.detail;
      this.triggerEvent(item.action);
      this.triggerDestroy();
    },
    handleClose() {
      if (this.data.show) {
        this.triggerEvent('cancel');
        this.triggerDestroy();
      }
    },
    handleClosed() {
      this.triggerEvent('destroy');
    },
    triggerDestroy() {
      this.setData({
        show: false
      });
    }
  }
});
// EXTERNAL MODULE: ./src/components/gameGrantInfo/index.scss
var gameGrantInfo = __webpack_require__(368);
;// CONCATENATED MODULE: ./src/components/gameGrantInfo/index.wxml

    /* harmony default export */ const components_gameGrantInfo = ({ content: (function(){var P="";var R={};var T0={P:P,C:[{T:"wx-view",A:{"style":"display:flex;line-height:24px"},C:[{T:"wx-view",A:{"style":"color:rgba(0,0,0,.5);margin-right:4px"},C:[{S:{L:function(D,S,T){return D.item_status_name},F:function(D,S,T,W){return D.item_status_name}}}]},{T:"wx-image",A:{"src":"https://res.wx.qq.com/t/fed_upload/17a92d3f-e1d4-413a-bbe5-b8a08d75810b/right.png","style":"width:12px;height:24px;margin-right:4px"},C:[]}]}]};R["select"]=function(){return T0};var T={P:P,C:[{T:"wx-view",A:{"class":{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return "root "+D.page}}},C:[{T:"mp-half-screen-dialog",A:{"show":{L:function(D,S,T){return D.show},F:function(D,S,T,W){return D.show}},"buttons":{L:function(D,S,T){return D.buttons},F:function(D,S,T,W){return D.buttons}},"bind:buttontap":"handleTaps"},C:[{V:7,N:"title",C:[{V:1,B:[{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="index"}},C:[{T:"wx-view",A:{"style":"display:flex"},C:[{T:"wx-image",A:{"src":{L:function(D,S,T){return Z(Z(D.config,"title"),"icon_url")},F:function(D,S,T,W){return X(X(D.config).title).icon_url}},"style":"width:24px;height:24px"},C:[]},{T:"wx-view",A:{"style":"font-size:15px;padding-left:8px;font-weight:500;width:100%;text-align:left;"},C:[{S:{L:function(D,S,T){return !!(Z(Z(D.config,"title"),"icon_wording")||Z(Z(D.config,"title"),"title"))||undefined},F:function(D,S,T,W){return "\n        "+X(X(D.config).title).icon_wording+" "+X(X(D.config).title).title+"\n      "}}}]}]}]},{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="action"}},C:[{T:"wx-view",A:{"style":"display:flex"},C:[{T:"wx-image",A:{"src":"https://res.wx.qq.com/t/fed_upload/0609c729-3ccf-4d93-a650-0c0e03634883/light.png","style":"width:24px;height:24px;position:absolute;-wx-partial-z-index:3000;left:-8px","bind:tap":"backToIndex"},C:[]},{T:"wx-view",A:{"style":"font-size:15px;font-weight:500;text-align:center;width:100%"},C:[{S:"选择授权范围"}]}]}]}]}]},{V:7,N:"body",C:[{V:1,B:[{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="index"}},C:[{T:"wx-scroll-view",A:{"class":"scroll","scroll-y":{L:function(D,S,T){},F:function(D,S,T,W){return true}},"scroll-x":{L:function(D,S,T){},F:function(D,S,T,W){return false}}},C:[{T:"wx-view",A:{"style":"font-size:17px;font-weight:500;margin-bottom:12px"},C:[{S:{L:function(D,S,T){return Z(Z(D.config,"title"),"sub_title")},F:function(D,S,T,W){return X(X(D.config).title).sub_title}}}]},{T:"wx-view",A:{"style":{L:function(D,S,T){return !!D.fdpr||undefined},F:function(D,S,T,W){return "height:"+D.fdpr+"px;background:rgba(0,0,0,.1)"}}},C:[]},{V:2,L:{M:["config","body","item_list"],L:function(D,S,T){return Z(Z(D.config,"body"),"item_list")},F:function(D,S,T,W){return X(X(D.config).body).item_list}},K:null,C:[{T:"wx-view",A:{"style":"display:flex;margin-top:16px;margin-bottom:16px","bind:tap":"showAction","data-id":{L:function(D,S,T){return Z(S[0],"item_id")},F:function(D,S,T,W){return X(S[0]).item_id}}},C:[{T:"wx-view",A:{"style":"display:flex;flex-direction:column;text-align:left;line-height:24px"},C:[{T:"wx-view",A:{"style":"font-size:17px;font-weight:normal"},C:[{S:{L:function(D,S,T){return Z(S[0],"item_name")},F:function(D,S,T,W){return X(S[0]).item_name}}}]},{V:1,B:[{B:{L:function(D,S,T){return Z(S[0],"item_desc")},F:function(D,S,T,W){return X(S[0]).item_desc}},C:[{T:"wx-view",A:{"style":"color:rgba(0,0,0,.3)"},C:[{S:{L:function(D,S,T){return !!Z(S[0],"item_desc")||undefined},F:function(D,S,T,W){return "\n                "+X(S[0]).item_desc+"\n              "}}}]}]}]}]},{T:"wx-view",A:{"style":"flex:1"},C:[]},{V:3,N:"select",D:{I:[function(D,S,T,W){return X(S[0]).item_id},function(D,S,T,W){return X(D.infoMap)[T(0)]}],L:function(D,S,T){return {item_id:Z(S[0],"item_id"),item_status_name:!!(Z(S[0],"item_id")||Z(D.infoMap,T(0)))||Z(D.statusMap,T(1))}},F:function(D,S,T,W){return {item_id:X(S[0]).item_id,item_status_name:X(D.statusMap)[T(1)]}}}}]},{T:"wx-view",A:{"style":{L:function(D,S,T){return !!D.fdpr||undefined},F:function(D,S,T,W){return "height:"+D.fdpr+"px;background:rgba(0,0,0,.1)"}}},C:[]}]},{T:"wx-view",A:{"style":"color:rgba(0,0,0,.3);display:flex;flex-direction:column;font-size:12px;margin-top:8px"},C:[{S:{L:function(D,S,T){return !!Z(Z(D.config,"footer"),"content")||undefined},F:function(D,S,T,W){return "\n          "+X(X(D.config).footer).content+"\n        "}}}]}]}]},{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="action"}},C:[{T:"wx-view",A:{"style":"margin-top: 20px"},C:[{T:"wx-view",A:{"style":{L:function(D,S,T){return !!D.fdpr||undefined},F:function(D,S,T,W){return "height:"+D.fdpr+"px;background:rgba(0,0,0,.1)"}}},C:[]},{V:2,L:{M:["selections"],L:function(D,S,T){return D.selections},F:function(D,S,T,W){return D.selections}},K:null,C:[{T:"wx-view",A:{"style":"display:flex;margin-top:16px;margin-bottom:16px","bind:tap":"select","data-index":{L:function(D,S,T){return S[1]},F:function(D,S,T,W){return S[1]}}},C:[{T:"wx-view",A:{},C:[{S:{L:function(D,S,T){return Z(S[0],"item_status_name")},F:function(D,S,T,W){return X(S[0]).item_status_name}}}]},{T:"wx-view",A:{"style":"flex:1"},C:[]},{V:1,B:[{B:{L:function(D,S,T){return !!(S[1]||D.selected)||undefined},F:function(D,S,T,W){return S[1]===D.selected}},C:[{T:"wx-image",A:{"style":"width:24px;height:24px;margin-right:8px","src":"https://res.wx.qq.com/t/fed_upload/0609c729-3ccf-4d93-a650-0c0e03634883/done.png"},C:[]}]}]}]},{T:"wx-view",A:{"style":{L:function(D,S,T){return !!D.fdpr||undefined},F:function(D,S,T,W){return "height:"+D.fdpr+"px;background:rgba(0,0,0,.1)"}}},C:[]}]}]}]}]}]}]},{T:"wx-view",A:{},C:[]}]}],BM:{show:[[0,0,"show"]],buttons:[[0,0,"buttons"]]}};R[""]=function(){return T};return function(a){var b=R[a];return b?b():null}})() });
;// CONCATENATED MODULE: ./src/components/gameGrantInfo/index.js



var gameGrantInfo_gameGrantInfo = engine.exparser.registerElement({
  is: 'game-grant-info',
  options: {
    classPrefix: 'game-grant-info',
    writeIdToDOM: true,
    virtualHost: true
  },
  template: components_gameGrantInfo,
  properties: {},
  data: {
    infoMap: {},
    statusMap: {},
    selected: 0,
    selections: [],
    config: {},
    infoList: {},
    page: 'index',
    show: false,
    fdpr: 1,
    buttons: [{
      type: 'default',
      text: '取消'
    }, {
      type: 'primary',
      text: '确定'
    }]
  },
  attached() {
    this.setData({
      fdpr: 1 / __wxConfig.devicePixelRatio
    });
    setTimeout(() => {
      this.setData({
        show: true
      });
    }, 100);
  },
  methods: {
    select(e) {
      this.triggerEvent('select', {
        index: e.currentTarget.dataset.index
      });
    },
    backToIndex() {
      this.triggerEvent('back');
    },
    showAction(e) {
      this.triggerEvent('showAction', {
        id: e.currentTarget.dataset.id
      });
    },
    handleTaps(e) {
      if (e.detail.index === 0) {
        this.deny();
      } else if (e.detail.index === 1) {
        this.submit();
      }
    },
    submit() {
      this.triggerEvent('submit');
      this.destroy();
    },
    deny() {
      this.triggerEvent('deny');
      this.destroy();
    },
    destroy() {
      this.setData({
        show: false
      });
      setTimeout(() => this.triggerEvent('destroy'), 300);
    }
  }
});
// EXTERNAL MODULE: ./src/components/firstPay/index.scss
var firstPay = __webpack_require__(47);
;// CONCATENATED MODULE: ./src/components/firstPay/index.xml

    /* harmony default export */ const components_firstPay = ({ content: (function(){var P="";var R={};var T={P:P,C:[{T:"mp-half-screen-dialog",A:{"show":{L:function(D,S,T){return D.show},F:function(D,S,T,W){return D.show}},"buttons":{L:function(D,S,T){return D.buttons},F:function(D,S,T,W){return D.buttons}},"bind:buttontap":"tap","bind:close":"close"},C:[{V:7,N:"title",C:[{T:"wx-view",A:{"style":"display:flex;justify-content:center"},C:[{T:"wx-image",A:{"src":"https://res.wx.qq.com/t/fed_upload/14e2bcd5-0b22-4e24-8f2c-b9a2aeda7a8a/logo.png","style":"height:24px;width:24px"},C:[]}]}]},{V:7,N:"body",C:[{T:"wx-view",A:{"style":"display:flex;flex-direction:column;align-items:center;margin-top:24px;margin-bottom:40px"},C:[{T:"wx-view",A:{"style":"font-weight:bold;color:rgba(0,0,0,.9);font-size:17px;line-height:24px;text-align:center;margin-bottom:8px"},C:[{S:"\n        首次充值权益\n      "}]},{T:"wx-view",A:{"style":"color:rgba(0,0,0,.5);font-size:14px;line-height:20px;text-align:center;margin-bottom:20px"},C:[{S:{L:function(D,S,T){return !!D.amt||undefined},F:function(D,S,T,W){return "\n        恭喜获得"+D.amt+"元优惠券，将在微信小游戏充值时自动抵扣\n      "}}}]},{T:"wx-view",A:{"class":"coupon"},C:[{V:1,B:[{B:{L:function(D,S,T){return D.animation},F:function(D,S,T,W){return D.animation}},C:[{T:"wx-image",A:{"style":"position:absolute;-wx-partial-z-index:3000;width:100%;height:100%;border-radius:10px","src":{L:function(D,S,T){return D.gifSrc},F:function(D,S,T,W){return D.gifSrc}}},C:[]}]}]},{T:"wx-view",A:{"style":"color:#06AE56;display:flex;flex-direction:column;justify-content:center;font-size:12px;margin-right:20px;margin-left:8px"},C:[{T:"wx-view",A:{"style":"font-size:22px;line-height:27px;font-weight:bold"},C:[{S:{L:function(D,S,T){return !!D.amt||undefined},F:function(D,S,T,W){return "¥"+D.amt}}}]},{S:"\n          充值优惠\n        "}]},{T:"wx-view",A:{"style":"text-align:left;font-size:12px"},C:[{T:"wx-view",A:{"style":"font-size:14px;margin-bottom:4px;margin-top:12px"},C:[{S:{L:function(D,S,T){return D.title},F:function(D,S,T,W){return D.title}}}]},{T:"wx-view",A:{"style":"color:#F06B1F;margin-bottom:10px"},C:[{S:"无门槛"}]},{T:"wx-view",A:{"style":"color:rgba(0,0,0,.3)"},C:[{S:{L:function(D,S,T){return !!(D.begintime||D.endtime)||undefined},F:function(D,S,T,W){return D.begintime+" ~ "+D.endtime}}}]}]}]}]}]}]}],BM:{show:[[0,"show"]],buttons:[[0,"buttons"]]}};R[""]=function(){return T};return function(a){var b=R[a];return b?b():null}})() });
;// CONCATENATED MODULE: ./src/components/firstPay/index.js



var firstPay_firstPay = engine.exparser.registerElement({
  is: 'first-pay',
  options: {
    classPrefix: 'first-pay',
    writeIdToDOM: true,
    virtualHost: true
  },
  template: components_firstPay,
  properties: {
    amt: {
      type: Number,
      value: 1
    },
    title: {
      type: String,
      value: '充值现金抵扣券'
    },
    begintime: {
      type: String,
      value: '2021.10.10'
    },
    endtime: {
      type: String,
      value: '2099.12.31'
    },
    gifSrc: {
      type: String,
      value: 'wxfile://ad/firstpay.gif'
    }
  },
  data: {
    show: false,
    animation: true,
    buttons: [{
      type: 'primary',
      text: '去使用'
    }]
  },
  attached() {
    setTimeout(() => {
      this.setData({
        show: true
      });
    }, 0);
    setTimeout(() => {
      this.setData({
        animation: false
      });
    }, 3000);
  },
  methods: {
    tap() {
      this.triggerEvent('click');
      this.close();
    },
    close() {
      this.setData({
        show: false
      });
      setTimeout(() => this.triggerEvent('destroy'), 300);
    }
  }
});
// EXTERNAL MODULE: ./src/components/useCouponModal/index.scss
var useCouponModal = __webpack_require__(150);
;// CONCATENATED MODULE: ./src/components/useCouponModal/index.wxml

    /* harmony default export */ const components_useCouponModal = ({ content: (function(){var P="";var R={};var T={P:P,C:[{T:"mp-half-screen-dialog",A:{"class":"root","show":{L:function(D,S,T){return D.enter},F:function(D,S,T,W){return D.enter}}},C:[{V:7,N:"title",C:[{V:1,B:[{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="index"}},C:[{T:"wx-view",A:{"style":"padding:16px"},C:[{T:"wx-image",A:{"bind:tap":"close","style":"position:absolute;height:24px;width:24px;-wx-partial-z-index:20000","src":"https://res.wx.qq.com/t/fed_upload/eac2a9fe-fd4d-4187-8f4a-fb25fa4a21fa/close.png"},C:[]},{S:"\n      优惠券订单确认\n    "}]}]},{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="choose"}},C:[{T:"wx-view",A:{"style":"padding:16px"},C:[{T:"wx-image",A:{"bind:tap":"showIndex","style":"position:absolute;height:24px;width:24px;-wx-partial-z-index:20000","src":"https://res.wx.qq.com/t/fed_upload/eac2a9fe-fd4d-4187-8f4a-fb25fa4a21fa/back.png"},C:[]},{S:"\n      小游戏专属充值优惠\n    "}]}]}]}]},{V:7,N:"body",C:[{V:1,B:[{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="index"}},C:[{T:"wx-view",A:{"style":"display:flex;flex-direction:column"},C:[{T:"wx-view",A:{"style":"padding:16px"},C:[{T:"wx-view",A:{"style":"display:flex;font-size:14px;color:rgba(0,0,0,.5)"},C:[{T:"wx-image",A:{"src":{L:function(D,S,T){return Z(D.accountInfo,"icon")},F:function(D,S,T,W){return X(D.accountInfo).icon}},"style":"width:24px;height:24px;border-radius:12px;margin-right:4px"},C:[]},{S:{L:function(D,S,T){return !!Z(D.accountInfo,"nickname")||undefined},F:function(D,S,T,W){return "\n            "+(X(D.accountInfo).nickname||"")+"\n          "}}}]},{T:"wx-view",A:{"style":"display:flex;flex-direction:column;justify-content:center;align-items:center;color:rgba(0,0,0,.9);width:100%"},C:[{T:"wx-view",A:{"style":"color: rgba(0,0,0,.5);font-size:14px"},C:[{S:"付款金额"}]},{T:"wx-view",A:{"style":"flex:1"},C:[]},{T:"wx-view",A:{"style":"font-weight:bold;display:flex;font-family:\'WeChat Sans Std\'"},C:[{T:"wx-view",A:{"style":"font-size:28px;line-height:33px;"},C:[{S:"￥"}]},{T:"wx-view",A:{"style":"font-size:40px;line-height:44px; width:200px; "},C:[{S:{L:function(D,S,T){return !!(Z(D.selectedCoupon,"pay_amt")||D.pay_ori_amt)||undefined},F:function(D,S,T,W){return "\n                "+(X(D.selectedCoupon).pay_amt||D.pay_ori_amt)+"\n              "}}}]},{V:1,B:[{B:{L:function(D,S,T){return !!(Z(D.selectedCoupon,"pay_amt")||Z(D.selectedCoupon,"pay_amt")||D.pay_ori_amt)||undefined},F:function(D,S,T,W){return X(D.selectedCoupon).pay_amt&&X(D.selectedCoupon).pay_amt!==D.pay_ori_amt}},C:[{T:"wx-view",A:{"style":"align-self:flex-end;display:flex"},C:[{T:"wx-view",A:{"style":"position:absolute;width:100%;height:2px;background:rgba(0,0,0,.5);top:8px"},C:[]},{T:"wx-view",A:{"style":"font-size:12px;line-height:14px;"},C:[{S:"￥"}]},{T:"wx-view",A:{"style":"font-size:16px;line-height:18px;font-weight:bold;color:rgba(0,0,0,.5);"},C:[{S:{L:function(D,S,T){return !!D.pay_ori_amt||undefined},F:function(D,S,T,W){return "\n                  "+D.pay_ori_amt+"\n                "}}}]}]}]}]}]}]}]},{T:"wx-view",A:{"style":"height:1px;width:100%;background:rgba(0,0,0,.1)"},C:[]},{T:"wx-view",A:{"style":"display:flex;padding:16px;justify-content:space-between","bind:tap":"choose"},C:[{T:"wx-view",A:{},C:[{S:"优惠券"}]},{T:"wx-view",A:{"style":"display:flex"},C:[{V:1,B:[{B:{L:function(D,S,T){return D.nouse},F:function(D,S,T,W){return D.nouse}},C:[{T:"wx-view",A:{"style":"display:flex;margin-right:8px;color:rgb(164, 164, 164);font-size:17px;justify-self:flex-end;-wx-partial-z-index:20000"},C:[{S:"\n                不使用优惠券\n              "}]}]},{B:{L:function(D,S,T){return Z(D.selectedCoupon,"amt")},F:function(D,S,T,W){return X(D.selectedCoupon).amt}},C:[{T:"wx-view",A:{"style":"display:flex;margin-right:8px;color:#F06B1F;font-size:17px;justify-self:flex-end;-wx-partial-z-index:20000"},C:[{S:{L:function(D,S,T){return !!Z(D.selectedCoupon,"tips")||undefined},F:function(D,S,T,W){return "\n                "+X(D.selectedCoupon).tips+"\n              "}}}]}]}]},{T:"wx-image",A:{"style":"width:12px;height:24px","src":"https://res.wx.qq.com/t/fed_upload/17a92d3f-e1d4-413a-bbe5-b8a08d75810b/right.png"},C:[]}]}]},{T:"wx-view",A:{"style":"height:1px;width:100vw;background:rgba(0,0,0,.1)"},C:[]},{T:"wx-view",A:{"style":"display:flex;justify-content:center;padding:16px"},C:[{T:"wx-view",A:{"style":"background:#07C160;border-radius:4px;color:#fff;width:184px;height:40px;display:flex;justify-content:center;align-items:center;text-align:center","bind:tap":"submit"},C:[{S:"\n            立即支付\n          "}]}]}]}]},{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="choose"}},C:[{T:"wx-scroll-view",A:{"scroll-y":"1","scrollY":{L:function(D,S,T){},F:function(D,S,T,W){return true}},"scroll-x":{L:function(D,S,T){},F:function(D,S,T,W){return false}},"class":"scroll"},C:[{T:"wx-view",A:{"style":"display:flex;margin-top: 24px;margin-bottom:24px;justify-content:center"},C:[{S:"\n          你已获得总价值\n          "},{T:"wx-view",A:{"style":"color:#06AE56;margin-left:4px;margin-right:4px"},C:[{S:{L:function(D,S,T){return !!D.amount||undefined},F:function(D,S,T,W){return D.amount+"元"}}}]},{S:"\n          的充值优惠\n        "}]},{V:2,L:{M:["coupons"],L:function(D,S,T){return D.coupons},F:function(D,S,T,W){return D.coupons}},K:"index",C:[{T:"wx-view",A:{"style":"background:#F7F7F7;border-radius:4px;display:flex;padding:8px;margin-top:8px"},C:[{T:"wx-view",A:{"style":"color:#06AE56;display:flex;flex-direction:column;justify-content:center;font-size:12px;"},C:[{T:"wx-view",A:{"style":"font-size:22px;line-height:27px;font-weight:bold"},C:[{S:{L:function(D,S,T){return !!Z(S[0],"amt")||undefined},F:function(D,S,T,W){return "\n                ¥"+X(S[0]).amt+"\n              "}}}]},{S:"\n              充值优惠\n            "}]},{T:"wx-view",A:{"style":"flex:1"},C:[]},{T:"wx-view",A:{"style":"display:flex;flex-direction:column;flex:2;text-align:left;font-size: 12px;"},C:[{T:"wx-view",A:{},C:[{S:{L:function(D,S,T){return Z(S[0],"title")},F:function(D,S,T,W){return X(S[0]).title}}}]},{T:"wx-view",A:{"style":"flex:1"},C:[]},{T:"wx-view",A:{"style":"color:#F06B1F"},C:[{S:{L:function(D,S,T){return !!Z(S[0],"least_price")||undefined},F:function(D,S,T,W){return "满"+X(S[0]).least_price+"元自动抵扣"}}}]},{T:"wx-view",A:{"style":"flex:2"},C:[]},{T:"wx-view",A:{"style":"color:rgba(0,0,0,.3)"},C:[{S:{L:function(D,S,T){return !!(Z(S[0],"begintime")||Z(S[0],"endtime"))||undefined},F:function(D,S,T,W){return "\n                "+X(S[0]).begintime+" ~ "+X(S[0]).endtime+"\n              "}}}]}]},{T:"wx-view",A:{"style":"flex:1"},C:[]},{T:"wx-view",A:{"style":"display:flex;justify-content:center;align-items:center;font-size: 14px;"},C:[{T:"wx-view",A:{"style":{L:function(D,S,T){return !!Z(S[0],"disabled")||undefined},F:function(D,S,T,W){return "background:rgba(0,0,0,.05);width:64px;height:32px;adding-right:12px;display:flex;justify-content:center;align-items:center;color:"+(X(S[0]).disabled?"rgba(0,0,0,.2)":"#06AE56")}},"bind:tap":"use","data-index":{L:function(D,S,T){return S[1]},F:function(D,S,T,W){return S[1]}}},C:[{S:{L:function(D,S,T){return !!Z(S[0],"disabled")||undefined},F:function(D,S,T,W){return "\n                "+(X(S[0]).disabled?"不可用":"使用")+"\n              "}}}]}]}]}]},{T:"wx-view",A:{"bind:tap":"nouse","style":"display:flex;color:rgb(79, 101, 144);margin-top:8px;font-size:17px;justify-content:center;-wx-partial-z-index:20000"},C:[{S:"\n          不使用优惠券\n        "}]}]}]}]}]}]}],BM:{enter:[[0,"show"]]}};R[""]=function(){return T};return function(a){var b=R[a];return b?b():null}})() });
;// CONCATENATED MODULE: ./src/components/useCouponModal/index.js



var useCouponModal_useCouponModal = engine.exparser.registerElement({
  is: 'use-coupon-modal',
  options: {
    classPrefix: 'use-coupon-modal',
    writeIdToDOM: true,
    virtualHost: true
  },
  template: components_useCouponModal,
  properties: {
    buy_quantity: {
      type: Number,
      value: 0
    },
    pay_ori_amt: {
      type: String,
      value: ''
    },
    amount: {
      type: Number,
      value: 0
    },
    IS_ANDROID: {
      type: Boolean,
      value: true
    },
    IS_PC: {
      type: Boolean,
      value: false
    },
    coupons: {
      type: Array,
      value: []
    }
  },
  data: {
    data: '{}',
    accountInfo: {},
    page: 'index',
    selectedCoupon: {},
    enter: false,
    nouse: false,
    chooseNumber: 1
  },
  attached() {
    setTimeout(() => {
      this.setData({
        ...JSON.parse(this.data.data),
        enter: true
      });
    }, 0);
  },
  methods: {
    use(e) {
      var _this$data$coupons$in;
      var {
        index
      } = e.currentTarget.dataset;
      if ((_this$data$coupons$in = this.data.coupons[index]) !== null && _this$data$coupons$in !== void 0 && _this$data$coupons$in.disabled) {
        return;
      }
      this.setData({
        page: 'index',
        selectedCoupon: this.data.coupons[index],
        nouse: false,
        chooseNumber: index === 0 ? 1 : 2
      });
    },
    nouse() {
      this.setData({
        page: 'index',
        selectedCoupon: undefined,
        nouse: true,
        chooseNumber: 3
      });
    },
    showIndex() {
      this.setData({
        page: 'index'
      });
    },
    choose() {
      this.setData({
        page: 'choose'
      });
    },
    submit() {
      this.setData({
        enter: false
      });
      setTimeout(() => {
        this.triggerEvent('destroy', {
          reason: 'submit',
          chooseNumber: this.data.chooseNumber
        });
      }, 200);
    },
    close() {
      this.setData({
        enter: false,
        selectedCoupon: null
      });
      setTimeout(() => {
        this.triggerEvent('destroy', {
          reason: 'cancel'
        });
      }, 200);
    }
  }
});
// EXTERNAL MODULE: ./src/components/privacyPop/style.scss
var privacyPop_style = __webpack_require__(203);
;// CONCATENATED MODULE: ./src/components/privacyPop/index.js


var privacyPop = exparser_cmd.registerElement({
  is: 'privacy-pop',
  options: {
    classPrefix: 'privacy-pop',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "mp-half-screen-dialog",
          A: {
            "class": "root",
            "show": {
              L: function (D, S, T) {
                return D.show;
              },
              F: function (D, S, T, W) {
                return D.show;
              }
            },
            "buttons": {
              L: function (D, S, T) {
                return D.buttons;
              },
              F: function (D, S, T, W) {
                return D.buttons;
              }
            },
            "bind:close": "handleClose",
            "bind:closed": "handleClosed",
            "bind:buttontap": "handleTapButton",
            "mask-closable": {
              L: function (D, S, T) {},
              F: function (D, S, T, W) {
                return false;
              }
            }
          },
          C: [{
            T: "wx-view",
            A: {
              "style": "text-align: left; font-size: 17px; margin-bottom: 16px",
              "slot": "title"
            },
            C: [{
              S: {
                L: function (D, S, T) {
                  return D.title;
                },
                F: function (D, S, T, W) {
                  return D.title;
                }
              }
            }]
          }, {
            T: "wx-view",
            A: {
              "style": "text-align: left; font-size: 14px; ",
              "slot": "body"
            },
            C: [{
              T: "wx-text",
              A: {},
              C: [{
                S: {
                  L: function (D, S, T) {
                    return D.desc1;
                  },
                  F: function (D, S, T, W) {
                    return D.desc1;
                  }
                }
              }, {
                T: "wx-text",
                A: {
                  "style": "color:#576B95",
                  "bind:tap": "jumpUrl"
                },
                C: [{
                  S: {
                    L: function (D, S, T) {
                      return D.urlTitle;
                    },
                    F: function (D, S, T, W) {
                      return D.urlTitle;
                    }
                  }
                }]
              }, {
                S: {
                  L: function (D, S, T) {
                    return D.desc2;
                  },
                  F: function (D, S, T, W) {
                    return D.desc2;
                  }
                }
              }]
            }]
          }, {
            T: "wx-view",
            A: {
              "style": {
                L: function (D, S, T) {
                  return !!D.safeAreaHeight || undefined;
                },
                F: function (D, S, T, W) {
                  return "padding-bottom: " + D.safeAreaHeight + "px";
                }
              },
              "slot": "footer"
            },
            C: []
          }]
        }],
        BM: {
          show: [[0, "show"]],
          desc2: [[0, 1, 0, 2]],
          buttons: [[0, "buttons"]],
          title: [[0, 0, 0]],
          desc1: [[0, 1, 0, 0]],
          urlTitle: [[0, 1, 0, 1, 0]],
          safeAreaHeight: [[0, 2, "style"]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    type: {
      type: Number
    },
    title: {
      type: String,
      value: '即将打开以下小程序'
    },
    logo: {
      type: String,
      value: ''
    },
    name: {
      type: String,
      value: ''
    },
    desc1: {
      type: String,
      value: ''
    },
    safeAreaHeight: {
      type: Number
    },
    urlTitle: {
      type: String,
      value: ''
    },
    desc2: {
      type: String,
      value: ''
    },
    confirmText: {
      type: String,
      value: '允许'
    },
    cancelText: {
      type: String,
      value: '取消'
    },
    maskClosable: {
      type: Boolean,
      value: false
    }
  },
  observers: {
    confirmText(confirmText) {
      this.setData({
        buttons: this.getButtons(confirmText, this.data.cancelText)
      });
    },
    cancelText(cancelText) {
      this.setData({
        buttons: this.getButtons(this.data.confirmText, cancelText)
      });
    }
  },
  data: {
    show: false,
    buttons: []
  },
  attached() {
    exparser_cmd.triggerRender(() => {
      this.setData({
        buttons: this.getButtons(this.data.confirmText, this.data.cancelText),
        show: true
      });
    });
  },
  methods: {
    getButtons(confirmText, cancelText) {
      return [{
        type: 'default',
        text: cancelText
      }, {
        type: 'primary',
        text: confirmText
      }];
    },
    handleTapButton(e) {
      var index = e.detail.index;
      if (index === 1) {
        this.handleConfirm();
      } else {
        this.handleCancel();
      }
    },
    handleClose() {
      this.handleCancel();
    },
    handleCancel() {
      this.setData({
        show: false
      });
      setTimeout(() => {
        this.triggerEvent('destroy', {
          reason: 'cancel'
        });
      }, 200);
    },
    jumpUrl() {
      setTimeout(() => {
        this.triggerEvent('jump', {
          reason: 'jump'
        });
      }, 200);
    },
    handleConfirm() {
      this.setData({
        show: false
      });
      setTimeout(() => {
        this.triggerEvent('destroy', {
          reason: 'allow'
        });
      }, 200);
    },
    handleClosed() {}
  }
});
// EXTERNAL MODULE: ./src/components/authorize/style.scss
var authorize_style = __webpack_require__(829);
;// CONCATENATED MODULE: ./src/components/authorize/index.js


var authorize = exparser_cmd.registerElement({
  is: 'authorize',
  options: {
    classPrefix: 'authorize',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "wx-view",
          A: {
            "class": "root"
          },
          C: [{
            V: 1,
            B: [{
              B: {
                L: function (D, S, T) {
                  return D.overlay;
                },
                F: function (D, S, T, W) {
                  return D.overlay;
                }
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": {
                    L: function (D, S, T) {
                      return !!D.enter || undefined;
                    },
                    F: function (D, S, T, W) {
                      return "mask " + (D.enter ? "mask-in" : "");
                    }
                  }
                },
                C: []
              }]
            }]
          }, {
            T: "wx-view",
            A: {
              "class": "container"
            },
            C: [{
              T: "wx-view",
              A: {
                "class": {
                  L: function (D, S, T) {
                    return !!D.enter || undefined;
                  },
                  F: function (D, S, T, W) {
                    return "content " + (D.enter ? "content-in" : "");
                  }
                }
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": "head"
                },
                C: [{
                  T: "wx-image",
                  A: {
                    "class": "icon",
                    "src": {
                      L: function (D, S, T) {
                        return D.icon;
                      },
                      F: function (D, S, T, W) {
                        return D.icon;
                      }
                    }
                  },
                  C: []
                }, {
                  T: "wx-view",
                  A: {
                    "class": "title"
                  },
                  C: [{
                    S: {
                      L: function (D, S, T) {
                        return !!D.nickname || undefined;
                      },
                      F: function (D, S, T, W) {
                        return D.nickname + " 申请";
                      }
                    }
                  }]
                }]
              }, {
                T: "wx-view",
                A: {
                  "class": "body"
                },
                C: [{
                  T: "wx-view",
                  A: {
                    "class": "apply-info"
                  },
                  C: [{
                    S: {
                      L: function (D, S, T) {
                        return D.apply;
                      },
                      F: function (D, S, T, W) {
                        return D.apply;
                      }
                    }
                  }]
                }]
              }, {
                T: "wx-view",
                A: {
                  "class": "buttons"
                },
                C: [{
                  T: "wx-view",
                  A: {
                    "class": "button cancel",
                    "bind:tap": "handleCancel"
                  },
                  C: [{
                    S: "拒绝"
                  }]
                }, {
                  T: "wx-view",
                  A: {
                    "class": "button confirm",
                    "bind:tap": "handleConfirm"
                  },
                  C: [{
                    S: "允许"
                  }]
                }]
              }]
            }]
          }]
        }],
        BM: {
          icon: [[0, 1, 0, 0, 0, "src"]],
          nickname: [[0, 1, 0, 0, 1, 0]],
          apply: [[0, 1, 0, 1, 0, 0]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    nickname: {
      type: String,
      value: ''
    },
    icon: {
      type: String,
      value: ''
    },
    overlay: {
      type: Boolean,
      value: true
    },
    apply: {
      type: String,
      value: ''
    },
    input: {
      type: String,
      value: ''
    }
  },
  data: {
    enter: false,
    duration: 300
  },
  observers: {
    input(newVal) {
      if (!newVal) return;
      var data = JSON.parse(newVal);
      this.setData(data);
    }
  },
  attached() {
    exparser_cmd.triggerRender(() => {
      this.setData({
        enter: true
      });
    });
  },
  methods: {
    handleCancel() {
      this.triggerEvent('cancel');
      this.destory();
    },
    handleConfirm() {
      this.triggerEvent('confirm');
      this.destory();
    },
    destory() {
      this.setData({
        enter: false
      });
      setTimeout(() => {
        this.triggerEvent('destroy');
      }, this.data.duration);
    }
  }
});
// EXTERNAL MODULE: ./src/components/launchScreen/style.scss
var launchScreen_style = __webpack_require__(168);
;// CONCATENATED MODULE: ./src/components/launchScreen/index.wxml

    /* harmony default export */ const launchScreen = ({ content: (function(){var P="";var R={};var T={P:P,C:[{T:"wx-view",A:{"class":"root"},C:[{T:"wx-view",A:{"class":"mask","bind:tap":"hide"},C:[]},{V:1,B:[{B:{L:function(D,S,T){return D.ready},F:function(D,S,T,W){return D.ready}},C:[{T:"wx-view",A:{"class":"wrapper","style":{L:function(D,S,T){return !!(D.renderWidth||D.renderHeight||D.footerHeight)||undefined},F:function(D,S,T,W){return "width:"+D.renderWidth+"px; height: "+(D.renderHeight+D.footerHeight)+"px;"}}},C:[{V:1,B:[{B:{L:function(D,S,T){return !!(D.type||Z(D.dataType,"Image"))||undefined},F:function(D,S,T,W){return D.type===X(D.dataType).Image}},C:[{T:"wx-view",A:{"class":"wrapper__main","style":{L:function(D,S,T){return !!(D.renderWidth||D.renderHeight)||undefined},F:function(D,S,T,W){return "width: "+D.renderWidth+"px; height: "+D.renderHeight+"px;"}}},C:[{V:2,L:{M:["banners"],L:function(D,S,T){return D.banners},F:function(D,S,T,W){return D.banners}},K:"index",C:[{V:1,B:[{B:{L:function(D,S,T){return !!(S[1]||D.bannerIndex)||undefined},F:function(D,S,T,W){return S[1]===D.bannerIndex}},C:[{T:"wx-image",A:{"data-url":{L:function(D,S,T){return Z(S[0],"jumpUrl")},F:function(D,S,T,W){return X(S[0]).jumpUrl}},"bind:tap":"openUrl","style":{L:function(D,S,T){return !!(D.renderWidth||D.renderHeight)||undefined},F:function(D,S,T,W){return "width: "+D.renderWidth+"px; height: "+D.renderHeight+"px;"}},"src":{L:function(D,S,T){return Z(S[0],"imageUrl")},F:function(D,S,T,W){return X(S[0]).imageUrl}}},C:[]}]}]}]}]}]}]},{T:"wx-image",A:{"class":"close","bind:tap":"close","src":"https://res.wx.qq.com/wechatgame/product/webpack/userupload/20221209/105707/close.png"},C:[]},{V:1,B:[{B:{L:function(D,S,T){return D.needCache},F:function(D,S,T,W){return D.needCache}},C:[{T:"wx-view",A:{"class":"check-box","style":{L:function(D,S,T){return !!(D.renderWidth||D.renderHeight)||undefined},F:function(D,S,T,W){return "width:"+D.renderWidth+"px; top:"+(D.renderHeight+8)+"px;"}},"bind:tap":"toggleCacheToday"},C:[{T:"wx-view",A:{"class":"check-box__icon"},C:[{T:"wx-image",A:{"class":"check-box__icon-inner","src":"https://res.wx.qq.com/wechatgame/product/webpack/userupload/20221209/164939/check-false.png"},C:[]},{V:1,B:[{B:{L:function(D,S,T){return D.isCacheToday},F:function(D,S,T,W){return D.isCacheToday}},C:[{T:"wx-image",A:{"class":"check-box__icon-inner","src":"https://res.wx.qq.com/wechatgame/product/webpack/userupload/20221209/165047/check-true.png"},C:[]}]}]}]},{T:"wx-view",A:{"class":"check-box__text"},C:[{S:"今日内不再弹出"}]}]}]}]}]}]}]}]}],BM:{}};R[""]=function(){return T};return function(a){var b=R[a];return b?b():null}})() });
;// CONCATENATED MODULE: ./src/components/launchScreen/index.js




var launchScreen_viewportResizeListeners = [];
engine.onViewportResize(res => {
  launchScreen_viewportResizeListeners.forEach(cb => cb(res));
});
var launchScreen_launchScreen = exparser_cmd.registerElement({
  is: 'launch-screen',
  options: {
    classPrefix: 'launch-screen',
    writeIdToDOM: true,
    virtualHost: true
  },
  template: launchScreen,
  properties: {
    type: {
      type: Number,
      value: 0
    },
    width: {
      type: Number,
      value: 260
    },
    height: {
      type: Number,
      value: 260
    },
    banners: {
      type: Array,
      value: []
    },
    videos: {
      type: Array,
      value: []
    },
    needCache: {
      type: Boolean,
      value: true
    }
  },
  data: {
    activeIndex: 0,
    isCacheToday: false,
    renderWidth: 260,
    renderHeight: 500,
    bannerIndex: 0,
    screenWidth: 375,
    screenHeight: 812,
    maxWidth: 375,
    maxHeight: 812,
    footerHeight: 32,
    dataType: {
      Image: 0,
      Video: 1,
      Live: 2
    },
    ready: false
  },
  created() {
    console.log('[launch-screen]: created');
  },
  attached() {
    console.log('[launch-screen]: attached');
    this._onViewportResize = this.onViewportResize.bind(this);
    launchScreen_viewportResizeListeners.push(this._onViewportResize);
    exparser_cmd.triggerRender(() => {
      this.triggerEvent('ready');
      this.onViewportResize();
    });
  },
  detached() {
    console.log('[launch-screen]: detached');
    launchScreen_viewportResizeListeners.splice(launchScreen_viewportResizeListeners.indexOf(this._onViewportResize), 1);
  },
  methods: {
    onViewportResize() {
      console.log('[launch-screen]: onViewportResize');
      var viewportWidth = engine.getWindowWidth();
      var viewportHeight = engine.getWindowHeight();
      var isLandscape = viewportWidth > viewportHeight;
      var safeArea = engine.getSafeArea();
      var menuRect = engine.getMenuButtonBoundingClientRect();
      var menuRight = viewportWidth - (menuRect.left || viewportWidth);
      var menuTop = menuRect.bottom || 0;
      var paddingLeftRight = Math.max(safeArea.left, safeArea.right);
      var paddingTopBottom = Math.max(safeArea.bottom, safeArea.top);
      if (isLandscape) {
        paddingLeftRight = Math.max(safeArea.left, menuRight);
      } else {
        paddingTopBottom = Math.max(safeArea.bottom, menuTop);
      }
      this.setData({
        screenWidth: viewportWidth,
        screenHeight: viewportHeight,
        maxWidth: viewportWidth - paddingLeftRight * 2,
        maxHeight: viewportHeight - this.data.footerHeight - paddingTopBottom * 2
      });
      this.changeActive();
    },
    getAdaptScreenScale(width, height) {
      var scaleWidth = 1;
      var scaleHeight = 1;
      if (width > this.data.maxWidth) {
        scaleWidth = this.data.maxWidth / width;
      }
      if (height > this.data.maxHeight) {
        scaleHeight = this.data.maxHeight / height;
      }
      return Math.min(scaleWidth, scaleHeight);
    },
    changeActive() {
      var scale = this.getAdaptScreenScale(this.width, this.height);
      this.setData({
        renderWidth: this.width * scale,
        renderHeight: this.height * scale,
        ready: scale > 0
      });
    },
    toggleCacheToday() {
      this.setData({
        isCacheToday: !this.data.isCacheToday
      });
    },
    hide() {
      this.triggerEvent('close', {
        isButton: true,
        isCacheToday: this.data.isCacheToday
      });
      this.destroyComp();
    },
    close() {
      this.triggerEvent('close', {
        isButton: false,
        isCacheToday: this.data.isCacheToday
      });
      this.destroyComp();
    },
    openUrl(e) {
      if (!this.data.ready) {
        return;
      }
      var url = e.currentTarget.dataset.url;
      this.destroyComp();
      setTimeout(() => {
        this.triggerEvent('openUrl', {
          url,
          isCacheToday: this.data.isCacheToday
        });
      }, 20);
    },
    destroyComp() {
      this.triggerEvent('destroy');
    }
  }
});
// EXTERNAL MODULE: ./src/components/platformCoinPayModal/style.scss
var platformCoinPayModal_style = __webpack_require__(49);
;// CONCATENATED MODULE: ./src/components/platformCoinPayModal/index.wxml

    /* harmony default export */ const platformCoinPayModal = ({ content: (function(){var P="";var R={};var T={P:P,C:[{T:"mp-half-screen-dialog",A:{"class":"root","show":{L:function(D,S,T){return D.enter},F:function(D,S,T,W){return D.enter}}},C:[{V:7,N:"title",C:[{V:1,B:[{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="index"}},C:[{T:"wx-view",A:{"style":"height: 64px; font-size: 15px; font-weight: 500; display: flex; align-items: center; justify-content: center;"},C:[{T:"wx-view",A:{"style":"position:absolute; display: flex; align-items: center; justify-content: center; height:64px; width:56px; -wx-partial-z-index:20000","bind:tap":"close"},C:[{T:"wx-image",A:{"style":"height:24px;width:24px;","src":"https://res.wx.qq.com/t/fed_upload/eac2a9fe-fd4d-4187-8f4a-fb25fa4a21fa/close.png"},C:[]}]},{S:{L:function(D,S,T){return !!D.channel_title||undefined},F:function(D,S,T,W){return "\n      "+D.channel_title+"\n    "}}}]}]},{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="whats"}},C:[{T:"wx-view",A:{"style":"padding:20px; font-size: 15px; font-weight: 500;"},C:[{T:"wx-image",A:{"bind:tap":"close","style":"position:absolute;height:24px;width:24px;-wx-partial-z-index:20000","src":"https://res.wx.qq.com/t/fed_upload/eac2a9fe-fd4d-4187-8f4a-fb25fa4a21fa/close.png"},C:[]},{S:{L:function(D,S,T){return !!D.coin_rule_title||undefined},F:function(D,S,T,W){return "\n      "+D.coin_rule_title+"\n    "}}}]}]}]}]},{V:7,N:"body",C:[{V:1,B:[{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="index"}},C:[{T:"wx-view",A:{"class":"index-page"},C:[{T:"wx-view",A:{"class":"index-page-head","style":{L:function(D,S,T){return !!D.isLandscape||undefined},F:function(D,S,T,W){return D.isLandscape?"padding-top: 10px;":"padding-top: 28px;"}}},C:[{T:"wx-view",A:{"catch:tap":"handleTapQuestion","id":"coin_name","style":{L:function(D,S,T){return !!D.coin_name_width||undefined},F:function(D,S,T,W){return "width: "+D.coin_name_width+"px;"}}},C:[{S:{L:function(D,S,T){return D.coin_name},F:function(D,S,T,W){return D.coin_name}}}]},{T:"wx-image",A:{"catch:tap":"handleTapQuestion","id":"question_icon","class":"question-icon","src":"https://res.wx.qq.com/op_res/lRe6qzrxTW63ohRiZ2MoDsppqbwHj_d0iS0wEH1RPJZIr_eOv-KChZb2puMR71vMaoj3iYtTO4ZO5ejjH7dWKA"},C:[]},{T:"wx-view",A:{"class":"remain"},C:[{T:"wx-text",A:{},C:[{S:"（余额："}]},{T:"wx-text",A:{"style":{L:function(D,S,T){return !!D.coinRemainNumPaddingRight||undefined},F:function(D,S,T,W){return "padding-right: "+D.coinRemainNumPaddingRight+"px;"}}},C:[{S:{L:function(D,S,T){return D.coin_remain_num},F:function(D,S,T,W){return D.coin_remain_num}}}]},{T:"wx-text",A:{},C:[{S:{L:function(D,S,T){return !!D.remain_num_wording||undefined},F:function(D,S,T,W){return D.remain_num_wording+"）"}}}]}]},{V:1,B:[{B:{L:function(D,S,T){return D.recharge_url},F:function(D,S,T,W){return D.recharge_url}},C:[{T:"wx-view",A:{"style":"color: #576B95; padding-right: 10px;","bind:tap":"handleTapCharge"},C:[{S:{L:function(D,S,T){return D.coin_recharge_button},F:function(D,S,T,W){return D.coin_recharge_button}}}]}]}]}]},{T:"wx-view",A:{"style":"height: 0.5px; width:100%; background:#D9D9D9;"},C:[]},{T:"wx-view",A:{"bind:tap":"handleSelectCoinPay","style":"padding-top: 21px; padding-bottom: 21px; display: flex; justify-content: space-between; align-items: center;"},C:[{T:"wx-view",A:{"style":"display: flex; align-items: center; height: 24px;"},C:[{T:"wx-image",A:{"style":"width: 18px; height: 18px;","src":"https://res.wx.qq.com/op_res/lRe6qzrxTW63ohRiZ2MoDuBWsKuaQgcXJIVQpoDvG9qizKWG1hEdbqeFE4XZyPQTEk-DOvlVDfBHgTuqHf3mqg"},C:[]},{T:"wx-view",A:{"style":{L:function(D,S,T){return !!D.coin_pay_wording_width||undefined},F:function(D,S,T,W){return "padding-left: 8px; font-size: 17px; width: "+D.coin_pay_wording_width+"px;"}}},C:[{S:{L:function(D,S,T){return D.coin_pay_wording},F:function(D,S,T,W){return D.coin_pay_wording}}}]}]},{T:"wx-image",A:{"style":{L:function(D,S,T){return !!D.selectedType||undefined},F:function(D,S,T,W){return "opacity: "+(D.selectedType==="coinpay"?1:0)+"; width: 24px; height: 24px;"}},"src":"https://res.wx.qq.com/op_res/lRe6qzrxTW63ohRiZ2MoDqrdurTzRolMBZuo1URZeOaw7pX9lLLICJC_LGrmEDgAqyE9pntJwimeMpZVnO1xgg"},C:[]}]},{V:1,B:[{B:{L:function(D,S,T){return D.wechat_pay_wording},F:function(D,S,T,W){return D.wechat_pay_wording}},C:[{T:"wx-view",A:{"style":"height: 0.5px; width:100%; background:#D9D9D9;"},C:[]}]}]},{V:1,B:[{B:{L:function(D,S,T){return D.wechat_pay_wording},F:function(D,S,T,W){return D.wechat_pay_wording}},C:[{T:"wx-view",A:{"bind:tap":"handleSelectWeChatPay","style":"padding-top: 21px; padding-bottom: 21px; display: flex; justify-content: space-between; align-items: center;"},C:[{T:"wx-view",A:{"style":"display: flex; align-items: center; height: 24px;"},C:[{T:"wx-image",A:{"style":"width: 18px; height: 18px;","src":"https://res.wx.qq.com/op_res/lRe6qzrxTW63ohRiZ2MoDlQQlecDu9a5hc0Yglgi2_9dPTIfRgWzX4fnGPslEoi4LLrOwxYO0dprEDJOFSq90g"},C:[]},{T:"wx-view",A:{"style":{L:function(D,S,T){return !!D.wechat_pay_wording_width||undefined},F:function(D,S,T,W){return "padding-left: 8px; font-size: 17px; width: "+D.wechat_pay_wording_width+"px;"}}},C:[{S:{L:function(D,S,T){return D.wechat_pay_wording},F:function(D,S,T,W){return D.wechat_pay_wording}}}]}]},{T:"wx-image",A:{"style":{L:function(D,S,T){return !!D.selectedType||undefined},F:function(D,S,T,W){return "opacity: "+(D.selectedType==="wechatpay"?1:0)+"; width: 24px; height: 24px;"}},"src":"https://res.wx.qq.com/op_res/lRe6qzrxTW63ohRiZ2MoDqrdurTzRolMBZuo1URZeOaw7pX9lLLICJC_LGrmEDgAqyE9pntJwimeMpZVnO1xgg"},C:[]}]}]}]},{T:"wx-view",A:{"style":"height: 0.5px; width:100%; background:#D9D9D9;"},C:[]},{T:"wx-view",A:{"style":{L:function(D,S,T){return !!(D.isLandscape||D.isLandscape)||undefined},F:function(D,S,T,W){return "display:flex;justify-content:center; "+(D.isLandscape?"padding-top: 12px;":"padding-top: 38px;")+" "+(D.isLandscape?"padding-bottom: 0px;":"padding-bottom: 27px;")}}},C:[{T:"wx-view",A:{"style":"background:#07C160; border-radius:4px; color:#fff; width:184px; height:40px; display:flex; justify-content:center; align-items:center; text-align:center; font-size: 17px; font-weight: 500;","bind:tap":"submit"},C:[{S:{L:function(D,S,T){return !!D.confirm_button_wording||undefined},F:function(D,S,T,W){return "\n            "+D.confirm_button_wording+"\n          "}}}]}]}]}]},{B:{L:function(D,S,T){return !!D.page||undefined},F:function(D,S,T,W){return D.page==="whats"}},C:[{T:"wx-scroll-view",A:{"scroll-y":"1","scrollY":{L:function(D,S,T){},F:function(D,S,T,W){return true}},"scroll-x":{L:function(D,S,T){},F:function(D,S,T,W){return false}},"class":"scroll","style":{L:function(D,S,T){return !!(D.isLandscape||D.landscapeScrollViewHeight)||undefined},F:function(D,S,T,W){return D.isLandscape?"height: "+D.landscapeScrollViewHeight+"px;":"height: 218px;"}}},C:[{V:2,L:{M:["coin_rule_list"],L:function(D,S,T){return D.coin_rule_list},F:function(D,S,T,W){return D.coin_rule_list}},K:null,C:[{T:"wx-view",A:{"style":"font-size: 14px; text-align: left;"},C:[{S:{L:function(D,S,T){return S[0]},F:function(D,S,T,W){return S[0]}}}]}]}]},{T:"wx-view",A:{"style":{L:function(D,S,T){return !!D.isLandscape||undefined},F:function(D,S,T,W){return "display:flex; justify-content: center; "+(D.isLandscape?"padding-bottom: 0px;":"padding-bottom: 27px;")}}},C:[{T:"wx-view",A:{"style":"background: rgba(0, 0, 0, 0.05); border-radius:4px; color:#07C160; width: 120px; height:40px; display:flex; justify-content:center; align-items:center; text-align:center;","bind:tap":"handleTapBack"},C:[{S:"\n          返回\n        "}]},{V:1,B:[{B:{L:function(D,S,T){return D.recharge_url},F:function(D,S,T,W){return D.recharge_url}},C:[{T:"wx-view",A:{"style":"background:#07c160; border-radius:4px; color:#fff; width: 120px; height:40px; display:flex;justify-content:center;align-items:center;text-align:center; margin-left: 40px;","bind:tap":"handleTapCharge"},C:[{S:{L:function(D,S,T){return !!D.coin_rule_button||undefined},F:function(D,S,T,W){return "\n          "+D.coin_rule_button+"\n        "}}}]}]}]}]}]}]}]}]}],BM:{enter:[[0,"show"]]}};R[""]=function(){return T};return function(a){var b=R[a];return b?b():null}})() });
;// CONCATENATED MODULE: ./src/components/platformCoinPayModal/index.js



var platformCoinPayModal_platformCoinPayModal = exparser_cmd.registerElement({
  is: 'platform-coin-pay-modal',
  options: {
    classPrefix: 'platform-coin-pay-modal',
    writeIdToDOM: true,
    virtualHost: true
  },
  template: platformCoinPayModal,
  properties: {
    coin_name: {
      type: String,
      value: ''
    },
    coin_name_width: {
      type: Number,
      value: 100
    },
    coin_pay_wording: {
      type: String,
      value: ''
    },
    coin_pay_wording_width: {
      type: Number,
      value: 100
    },
    coin_remain_num: {
      type: Number,
      value: 0
    },
    recharge_url: {
      type: String,
      value: ''
    },
    coin_rule_button: {
      type: String,
      value: ''
    },
    coin_rule_title: {
      type: String,
      value: ''
    },
    wechat_pay_wording: {
      type: String,
      value: ''
    },
    wechat_pay_wording_width: {
      type: Number,
      value: 100
    },
    coin_need_num: {
      type: String,
      value: 0
    },
    coin_recharge_button: {
      type: String,
      value: ''
    },
    coin_rule_list: {
      type: Array,
      value: []
    },
    channel_title: {
      type: String,
      value: ''
    },
    confirm_button_wording: {
      type: String,
      value: ''
    },
    remain_num_wording: {
      type: String,
      value: ''
    }
  },
  data: {
    data: '{}',
    accountInfo: {},
    page: 'index',
    selectedCoupon: {},
    enter: false,
    nouse: false,
    chooseNumber: 1,
    selectedType: 'coinpay',
    isLandscape: false,
    landscapeScrollViewHeight: 180
  },
  attached() {
    setTimeout(() => {
      this.setData({
        enter: true,
        isLandscape: __wxConfig.deviceOrientation === 'landscape' && __wxConfig.platform !== 'windows' && __wxConfig.platform !== 'mac',
        landscapeScrollViewHeight: Math.min(__wxConfig.screenHeight * 0.5, 218),
        coinRemainNumPaddingRight: __wxConfig.platform === 'windows' || __wxConfig.platform === 'mac' ? String(this.data.coin_remain_num).length * 2 : 0
      });
    }, 0);
  },
  methods: {
    handleTapQuestion() {
      this.setData({
        page: 'whats'
      });
    },
    handleTapBack() {
      this.setData({
        page: 'index'
      });
    },
    handleTapCharge() {
      if (this.data.recharge_url) {
        this.triggerEvent('gotoCharge');
      }
    },
    handleSelectCoinPay() {
      this.setData({
        selectedType: 'coinpay'
      });
    },
    handleSelectWeChatPay() {
      this.setData({
        selectedType: 'wechatpay'
      });
    },
    submit() {
      if (this.data.selectedType === 'coinpay' && this.data.coin_need_num > this.data.coin_remain_num) {
        this.triggerEvent('insufficient');
        return;
      }
      this.setData({
        enter: false
      });
      setTimeout(() => {
        this.triggerEvent('destroy', {
          reason: 'submit',
          selectedType: this.data.selectedType
        });
      }, 200);
    },
    close() {
      this.setData({
        enter: false
      });
      setTimeout(() => {
        this.triggerEvent('destroy', {
          reason: 'cancel'
        });
      }, 200);
    },
    update(args) {
      this.setData(args);
    }
  }
});
// EXTERNAL MODULE: ./src/components/officialToastPop/style.scss
var officialToastPop_style = __webpack_require__(527);
;// CONCATENATED MODULE: ./src/components/officialToastPop/index.js


var officialToastPop = exparser_cmd.registerElement({
  is: 'officialToast-pop',
  options: {
    classPrefix: 'officialToast-pop',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "wx-view",
          A: {
            "class": "root",
            "style": {
              L: function (D, S, T) {
                return !!D.paddingTop || undefined;
              },
              F: function (D, S, T, W) {
                return "padding-top: " + D.paddingTop + "px;";
              }
            }
          },
          C: [{
            T: "wx-view",
            A: {
              "class": "content"
            },
            C: [{
              T: "wx-view",
              A: {
                "class": "title"
              },
              C: [{
                S: {
                  L: function (D, S, T) {
                    return D.title;
                  },
                  F: function (D, S, T, W) {
                    return D.title;
                  }
                }
              }]
            }]
          }]
        }],
        BM: {
          title: [[0, 0, 0, 0]],
          paddingTop: [[0, "style"]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    duration: {
      type: Number,
      value: 1500
    },
    title: {
      type: String,
      value: '这里是文字内容'
    },
    maskClosable: {
      type: Boolean,
      value: false
    },
    paddingTop: {
      type: Number,
      value: 100
    }
  },
  data: {
    show: false
  },
  attached() {
    this.handleClose();
  },
  methods: {
    handleClose() {
      setTimeout(() => {
        this.triggerEvent('destroy');
      }, this.data.duration);
    }
  }
});
// EXTERNAL MODULE: ./src/components/shareAppMessagePopup/style.scss
var shareAppMessagePopup_style = __webpack_require__(300);
;// CONCATENATED MODULE: ./src/components/shareAppMessagePopup/index.js








function truncateString(str = '') {
  if (str.length <= 6) {
    return str;
  }
  var charArray = str.split('');
  charArray.splice(5, charArray.length - 5, '.', '.', '.');
  return charArray.join('');
}
var shareAppMessagePopup = exparser_cmd.registerElement({
  is: 'share-app-message-popup',
  options: {
    classPrefix: 'share-app-message-popup',
    writeIdToDOM: true
  },
  template: {
    content: function () {
      var P = "";
      var R = {};
      var T = {
        P: P,
        C: [{
          T: "mp-half-screen-popup",
          A: {
            "bindtouchstart": "onTouchStart",
            "bindtouchend": "onTouchEnd",
            "show": {
              L: function (D, S, T) {
                return D.show;
              },
              F: function (D, S, T, W) {
                return D.show;
              }
            },
            "bind:close": "handClosedByEmpty"
          },
          C: [{
            T: "wx-view",
            A: {
              "class": "content"
            },
            C: [{
              T: "wx-view",
              A: {
                "class": "top"
              },
              C: [{
                T: "wx-image",
                A: {
                  "bind:tap": "handClosedByButton",
                  "class": "arrow-icon",
                  "src": "https://res.wx.qq.com/op_res/yW3tvwqh2LRV5SdpMtB1WlBxrZKc2227xcukDqH1d3ScK8icWYUIuPKTXl9mAWvzOgW1Ah0aAYxh-KKC7GGldQ"
                },
                C: []
              }, {
                T: "wx-view",
                A: {
                  "class": "title"
                },
                C: [{
                  S: {
                    L: function (D, S, T) {
                      return D.title;
                    },
                    F: function (D, S, T, W) {
                      return D.title;
                    }
                  }
                }]
              }]
            }, {
              T: "wx-view",
              A: {
                "style": "width: 100%"
              },
              C: [{
                T: "wx-view",
                A: {
                  "class": "user-content"
                },
                C: [{
                  V: 2,
                  L: {
                    M: ["potentialFriendList"],
                    L: function (D, S, T) {
                      return D.potentialFriendList;
                    },
                    F: function (D, S, T, W) {
                      return D.potentialFriendList;
                    }
                  },
                  K: "(item||\'\').openid",
                  C: [{
                    T: "wx-view",
                    A: {
                      "class": "user-content-item",
                      "style": {
                        L: function (D, S, T) {
                          return !!D.itemGap || undefined;
                        },
                        F: function (D, S, T, W) {
                          return "margin: 8px " + D.itemGap + "px";
                        }
                      }
                    },
                    C: [{
                      T: "wx-view",
                      A: {
                        "bind:tap": "shareToFiriendDirectly",
                        "data-id": {
                          L: function (D, S, T) {
                            return Z(S[0], "openid");
                          },
                          F: function (D, S, T, W) {
                            return X(S[0]).openid;
                          }
                        },
                        "data-index": {
                          L: function (D, S, T) {
                            return S[1];
                          },
                          F: function (D, S, T, W) {
                            return S[1];
                          }
                        }
                      },
                      C: [{
                        T: "wx-image",
                        A: {
                          "class": "user-content-item-img",
                          "src": {
                            L: function (D, S, T) {
                              return Z(S[0], "avatarUrl");
                            },
                            F: function (D, S, T, W) {
                              return X(S[0]).avatarUrl;
                            }
                          },
                          "mode": "scaleToFill"
                        },
                        C: [{
                          T: "wx-image",
                          A: {},
                          C: []
                        }]
                      }]
                    }, {
                      T: "wx-view",
                      A: {
                        "class": "user-content-item-name"
                      },
                      C: [{
                        S: {
                          L: function (D, S, T) {
                            return Z(S[0], "nickname");
                          },
                          F: function (D, S, T, W) {
                            return X(S[0]).nickname;
                          }
                        }
                      }]
                    }]
                  }]
                }]
              }]
            }, {
              T: "wx-view",
              A: {
                "class": "bottom"
              },
              C: [{
                T: "wx-view",
                A: {
                  "bind:tap": "shareToFiriend",
                  "class": "share-button"
                },
                C: [{
                  T: "wx-image",
                  A: {
                    "class": "share-button-icon",
                    "src": "https://res.wx.qq.com/op_res/-5lWqy3Iccx0xePdBNQOz6U4PBreHZFH0Xg6abqYFdKXnFcdV30BFL6734QIcL8IEIqA-GmqVKimbt36i_il1A"
                  },
                  C: []
                }, {
                  T: "wx-view",
                  A: {
                    "class": "share-button-text"
                  },
                  C: [{
                    S: {
                      L: function (D, S, T) {
                        return D.shareButtonText;
                      },
                      F: function (D, S, T, W) {
                        return D.shareButtonText;
                      }
                    }
                  }]
                }]
              }]
            }]
          }]
        }],
        BM: {
          show: [[0, "show"]],
          title: [[0, 0, 0, 1, 0]],
          shareButtonText: [[0, 0, 2, 0, 1, 0]]
        }
      };
      R[""] = function () {
        return T;
      };
      return function (a) {
        var b = R[a];
        return b ? b() : null;
      };
    }()
  },
  properties: {
    title: {
      type: String,
      value: '转发给'
    },
    friendList: {
      type: Object,
      value: []
    }
  },
  data: {
    show: false,
    buttons: [],
    shareButtonText: '发送给朋友',
    itemGap: 2,
    potentialFriendList: [],
    startY: 9999
  },
  attached() {
    var screenWidth = __wxConfig.screenWidth;
    var screenHeight = __wxConfig.screenHeight;
    var gap = Math.floor((Math.min(screenWidth, screenHeight) * 0.9 - 82 * 4) / 8);
    var friendList = this.data.friendList.map(item => {
      item.nickname = truncateString(item.nickname);
      return item;
    });
    exparser_cmd.triggerRender(() => {
      this.setData({
        show: true,
        itemGap: gap,
        potentialFriendList: screenHeight < screenWidth && screenHeight < 375 ? friendList.slice(0, 4) : friendList
      });
    });
  },
  methods: {
    onTouchStart(e) {
      this.setData({
        startY: e.touches[0].clientY
      });
    },
    onTouchEnd(e) {
      if (e.touches[0].clientY > this.data.startY && this.data.show) {
        this.handleClosed();
      }
    },
    handClosedByButton() {
      this.triggerEvent('closeByButton');
      this.handleClosed();
    },
    handClosedByEmpty() {
      this.triggerEvent('closeByEmpty');
      this.handleClosed();
    },
    handleClosed() {
      this.setData({
        show: false
      });
      setTimeout(() => {
        this.triggerEvent('destroy');
      }, 100);
    },
    shareToFiriendDirectly(e) {
      var id = e.currentTarget.dataset.id;
      var positionId = e.currentTarget.dataset.index + 1;
      this.triggerEvent('shareDirectly', {
        openId: id,
        positionId
      });
      this.handleClosed();
    },
    shareToFiriend() {
      this.triggerEvent('shareByMessageList');
      this.triggerEvent('closeByshareByMessageList');
      this.handleClosed();
    }
  }
});
;// CONCATENATED MODULE: ./src/components/forGameComponents.js














;// CONCATENATED MODULE: ./src/game-index.js


var exportApis = {
  ...common_namespaceObject,
  ...forGameComponents_namespaceObject
};
Object.defineProperty(globalThis, '__sclEngine__', {
  get() {
    return exportApis;
  }
});
var checkProducts = () => {
  console.log('__magic_sdk_subpackge_product_check_sclEngine__');
};
wxConsole.warn('game-scl-engine inject success');
})();

/******/ })()
;
null

})(); /* LIBRARY_CLOSURE_END () */


} catch(err) {
      console.error('catch sdkSubPackage: sclEngine error: ', err)
    }
